# SECURITY.md — Modelo de amenaza de JEAN_FLOW 2.4.0

(Modelo vigente desde 2.3.0; el alcance no ha cambiado desde entonces.)

Este documento dice lo que la cadena de verificación PRUEBA y lo que NO puede
probar, en los términos de la auditoría v2.2.2 (familia I).

## Lo que se verifica

- Cada wheel del wheelhouse se compara byte a byte contra el SHA-256 de
  `requirements.lock`; su RECORD se valida fila a fila (hash, tamaño, rutas,
  sin `.pth`, sin symlinks, sin rutas absolutas ni `..` ni `:`), con cotas de
  descompresión comprobadas ANTES de leer y con detección de colisiones de
  mayúsculas al construir el plan. Implementación única:
  `src/binance_collector/supply_chain.py` (el bootstrap consume esa misma
  implementación; no hay una segunda copia).
- El árbol del release se compara contra `RELEASE_MANIFEST.sha256`
  (normalización NFC+casefold, sin enlaces). Los `.ps1` del gate de reloj se
  re-verifican contra el manifest inmediatamente antes de CADA ejecución.
- El proceso comprueba en tiempo de ejecución `sys.flags.isolated` y
  `sys.flags.no_site` (se re-ejecuta con `-I -S -B -u` si faltan), de modo que
  ningún `.pth` de `%APPDATA%` se procesa antes del verificador.

## Lo que NO se puede probar (I1: autenticidad)

`requirements.lock`, `WHEELHOUSE_MANIFEST.sha256` y `RELEASE_MANIFEST.sha256`
viven DENTRO del release y no están firmados con una clave externa. Quien pueda
modificar la carpeta puede modificar un wheel, recalcular los tres hashes y
ejecutar `tools/build_release.py` (que también viaja dentro): todo pasará.
Esto es integridad-ante-accidente, no autenticidad. Una firma externa (clave
fuera del árbol) es la única forma de cerrar I1.

## Lo que la firma tampoco arreglaría hoy (I2: no vacuidad)

El verificador (`release_integrity.py`, `supply_chain.py`) se importa DESDE el
árbol que aún no se ha verificado. Mientras `C_V ⊂ T`, firmar `E` no prueba
nada: el atacante edita el verificador. Cerrar I2 exige un verificador fuera
del árbol o su hash anclado como constante en un componente ya confiable.
Estado: ABIERTO y documentado; no afirmamos lo contrario en ningún documento.

## Intérprete (I4)

`INICIAR.cmd` localiza `python.exe` en las rutas de instalación estándar
(incluida `%LocalAppData%`, escribible por el usuario por diseño) y solo
comprueba versión 3.12 y puntero de 64 bits. El intérprete NO está
autenticado: toda la cadena de verificación se ejecuta dentro de él y hereda
ese límite.

## Sellado (I6)

El runtime `.runtime/packages` se hashea al arrancar; NO se imponen ACL ni se
retienen handles después. Una escritura posterior al sellado (t0+Δ) entra en
los imports perezosos de `aiohttp`/`websockets`. El certificado afirma
"runtime verificado en t0", no "runtime inmutable durante la captura".

## Exclusión mutua

Los mutex (`Global\JEAN_FLOW_*`) usan ruta resuelta y normalizada y el patrón
`use_last_error`; excluyen dos sesiones de usuario sobre la misma carpeta.
Cualquier proceso local puede crear el nombre antes (squatting) y provocar
`ALREADY_RUNNING`: es una limitación conocida de los objetos con nombre de
Windows, no una defensa contra malware local.

## Heartbeat

`HEARTBEAT.json` está etiquetado por sesión y PID; NO lleva firma
criptográfica (HMAC). Protege contra huérfanos y confusión de sesión, no
contra un proceso local malicioso que lo fabrique.

## Endpoints y procedencia

Los endpoints efectivos quedan registrados en READY/session/RESULT. Los
overrides `BINANCE_*_URL` se rechazan en modo supervisado salvo
`--allow-endpoint-override`, que marca el certificado con
`provenance: ENDPOINT_OVERRIDDEN`. `trust_env=False`: un proxy ambiental ya no
puede desviar el tráfico REST sin dejar rastro.
