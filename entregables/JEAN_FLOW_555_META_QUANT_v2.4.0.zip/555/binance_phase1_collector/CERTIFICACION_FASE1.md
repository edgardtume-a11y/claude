# Certificación JEAN_FLOW 2.3.7

## Regla de progresión

```text
offline -> live 10 min -> live 30 min -> soak 120 min -> dataset habilitado
```

Un FAIL conserva evidencia y detiene la progresión. El launcher nunca salta
automáticamente una etapa ni crea un certificado parcial con nombre final.

## Gates obligatorios

| Gate | PASS mínimo |
|---|---|
| Versión | launcher, paquete, proyecto y manifest coinciden |
| Privilegios | Python/motor no elevados; solo `/resync` puntual puede solicitar UAC |
| NTP | un disciplinador y fuente válida; W32Time Phase Offset absoluto <= 50 ms o Meinberg p95 <= 50 ms |
| Identidad | sesión, PID, proceso padre, símbolo, mercados y versiones iguales |
| Dashboard | loopback, HTTP 200 e identidad igual a READY |
| Spot | libro `SYNCED`, fresco, ambos lados y secuencia válida |
| Futures | libro `SYNCED`, fresco, ambos lados y secuencia válida |
| Causalidad | cero pérdida silenciosa y gaps no reconciliados |
| Persistencia | writer drenado, cero `.partial` y auditorías PASS |
| Cierre | commitment exacto de CSV, tamaños, SHA-256 y secuencia final |
| Reproducibilidad | dos replays independientes por mercado con estado idéntico |
| Rendimiento | cinco p99 dentro de límites cuando sus rutas tuvieron actividad |
| Postflight | NTP de solo lectura PASS después de cada etapa |

## Límites p99 vigentes

Basis desde 2.3.9: worst-p99 sobre las ventanas emitidas DESPUÉS de los
primeros 120 s de calentamiento (referencia: primera ventana de métricas del
mercado). Ambos valores — con y sin calentamiento — se publican SIEMPRE en
`audit_metrics.json`; si el log no alcanza el corte se evalúan todas las
ventanas, como hasta 2.3.8. Ver la revisión 2.3.9 abajo.

| Métrica | Límite | Nota |
|---|---|---|
| `parse` | 5 ms | |
| `book_apply` | 5 ms | |
| `book_pipeline_total` | 5 ms | |
| `event_loop_lag` | 40 ms | revisado en 2.3.4 (antes 20 ms), ver abajo |
| `writer_cooperative_yield` | 5 ms | solo si hubo yields |

## Revisiones de criterio

Toda revisión de umbral es EXPLÍCITA: queda registrada aquí, en el README y
en el `CAMBIOS_vX.Y.Z.md` de la versión que la introduce. Nunca se relaja un
gate en silencio.

- **2.3.4 — `event_loop_lag_p99`: 20 ms → 40 ms.** El límite anterior era de
  grado servidor. En Windows de escritorio el cuanto del temporizador es
  15.625 ms y el colector no fuerza `timeBeginPeriod(1)` por diseño, de modo
  que la cola de la distribución cae en múltiplos del cuanto por construcción
  del sistema operativo anfitrión, no por atasco del colector. Evidencia de
  campo: sesión `99a0f0a51142` (etapa certificable de 10 min, BTCUSDT,
  2026-08-14) SANA de punta a punta (0 overflows, aggTrade en ambos mercados,
  libros SYNCED, causalidad e identidad PASS) con p99 clavado en 21-22 ms
  durante toda la etapa como único gate FAIL. Nuevo corte = 2 cuantos
  (31.25 ms) + margen de despacho ≈ 40 ms; un atasco real (GC, paginación,
  E/S sostenida) sigue condenado porque aparece como p99 >= 100 ms sobre
  ventanas de 10 000 muestras. La métrica se publica sin recorte.

- **2.3.5 — sin cambios de criterio.** Se corrigió el TRANSPORTE de los
  informes de auditoría, no su contenido ni sus umbrales: en Windows es-ES
  los hijos aislados escribían su JSON por stdout en cp1252 ('é' = 0xE9,
  'θ̂' irrepresentable) y el verificador lo relee como UTF-8 estricto, de
  modo que la certificación se vetaba por el propio informe aunque los
  datos estuvieran íntegros (commitment PASS, identidad 38 612/38 612,
  replays 1 y 2 con sha256 idénticos — sesión `d64fea5560ac`, C:). Desde
  2.3.5 todos los hijos aislados corren con `-X utf8` y además
  reconfiguran stdout/stderr a UTF-8 (defensa en profundidad, con
  regresión en `tests/test_utf8_stdio.py`).

- **2.3.6 — sin cambios de criterio.** Se corrigió la REGLA DE MEDIR, no
  la regla. Evidencia (sesión `5ebb3efde620`, C:, primer examen de
  métricas completo): `book_pipeline_p99`/`book_apply_p99` clavados en
  15/16 ms — el tic de 15.625 ms de `GetTickCount64`, el reloj de
  `time.monotonic_ns()` en Windows + Python 3.12 — mientras el banco del
  preflight medía 0.136 ms en la misma máquina; y una foto de contadores
  con `count > count_total` (off-by-one, snapshot 76). Desde 2.3.6 las
  duraciones locales se miden con `perf_counter_ns`, la captura corre con
  el temporizador de 1 ms (`fine_timer_resolution`, restaurado al salir)
  y la foto de métricas garantiza `count <= count_total`
  (regresión en `tests/test_metrics_fidelity.py`). Los umbrales de 5 ms y
  40 ms quedan EXACTAMENTE iguales.

- **2.3.7 — sin cambios de criterio.** El primer run de 2.3.6 (sesión
  `dda44a52ff1f`) probó la regla de medir (decimales reales, off-by-one
  muerto) y destapó la capa siguiente: `fine_timer_1ms=True` en el log y
  aun así `event_loop_lag` p99 en 24 ms y el sleep del writer 2-3x más
  lento que en la sesión previa. Windows 11 ignora las peticiones de
  temporizador y degrada a E-cores (EcoQoS) los procesos con ventana
  minimizada. Desde 2.3.7 el motor se exime con
  `SetProcessInformation(ProcessPowerThrottling)`
  (`EXECUTION_SPEED | IGNORE_TIMER_RESOLUTION`, StateMask=0) y devuelve el
  control al sistema al salir (regresión en
  `tests/test_metrics_fidelity.py`). Umbrales intactos.

- **2.3.9 — basis del gate p99: exclusión de calentamiento EXPLÍCITA
  (120 s).** Los límites de 5 ms y 40 ms quedan EXACTAMENTE iguales; cambia
  sobre qué ventanas se evalúan. Evidencia de campo (sesión `b977be885902`,
  etapa certificable de 10 min, BTCUSDT, 2026-08-14, motor 2.3.8): captura
  SANA de punta a punta (0 overflows, libros SYNCED, causalidad, identidad,
  commitment y doble replay PASS, 600.0 s sanos completados) vetada
  únicamente por `writer_yield_p99` spot = 9.525 ms. El detalle por ventana
  muestra que el pico pertenece al ARRANQUE: ~3 muestras de 9.5-13.7 ms en
  los primeros segundos del proceso quedaron dentro de la ventana deslizante
  y, con solo ~200 muestras acumuladas, el estimador nearest-rank devolvió
  esos picos como p99 hasta el segundo ~70; el estado estacionario fue
  2.8-3.2 ms durante los 530 s restantes. El gate certifica salud SOSTENIDA
  de captura, no el costo fijo de arranque: desde 2.3.9 el basis es
  worst-p99 sobre las ventanas posteriores a los primeros 120 s (referencia:
  primera ventana de métricas del mercado). Honestidad del cambio: AMBOS
  valores se publican siempre (`worst_value_ms` y
  `worst_value_ms_incl_warmup`), el informe declara cuántas ventanas se
  excluyeron (`warmup_exclusion`), un log más corto que el corte se evalúa
  COMPLETO (sin estado estacionario no hay exclusión), el fallback de
  muestra pequeña (`max_fallback_small_n`) mantiene el MAX absoluto sin
  recorte, y un problema sostenido sigue vetando porque sus picos aparecen
  también después del corte (regresión en `tests/test_metrics_warmup.py`).
  Además, cuando el opt-out de EcoQoS falla, el log registra ahora
  `foreground_qos_error` (GetLastError) para diagnosticar la causa
  (evidencia: la misma sesión registró `foreground_qos=False` sin detalle).

- **2.4.0 — el opt-out de EcoQoS por fin se aplica (corrección de BUG, sin
  cambio de criterio).** Ningún límite, basis ni gate se toca. El
  diagnóstico que añadió 2.3.9 dio su primer fruto: la sesión
  `aa1e3beafeec` (30 min, BTCUSDT, 2026-08-15, equipo desatendido) registró
  `foreground_qos=False foreground_qos_error=6`, y 6 es ERROR_INVALID_HANDLE
  — Windows rechazaba el HANDLE, no la operación. La causa era que
  `_set_power_throttling` llamaba a `GetCurrentProcess` y a
  `SetProcessInformation` sin declarar `restype`/`argtypes`, de modo que
  ctypes trataba el pseudo-handle `(HANDLE)-1` como entero de 32 bits: **el
  opt-out introducido en 2.3.7 nunca llegó a aplicarse en ningún equipo
  x64**. Desde 2.4.0 los tipos Win64 se declaran explícitamente, un handle
  nulo no llega a la API y el struct usa `c_uint32` (DWORD es 32 bits por
  definición; `c_ulong` sólo medía bien en Windows, justo donde la suite no
  corre). Regresiones en `tests/test_power_qos_handle.py`. Que Windows
  ACEPTE la llamada sólo puede comprobarse en campo: la señal es
  `foreground_qos=True` en el log de arranque de la siguiente sesión.

## Evidencia offline de esta entrega

Debe verificarse antes del empaquetado:

- `python -m compileall` sobre `src`, pruebas, herramientas y bootstrap;
- suite offline completa con un único smoke live opt-in omitido;
- benchmark sintético con `--enforce`;
- verificación del manifest por archivo, CRC y SHA-256 del ZIP;
- prueba desde una segunda extracción limpia.

Nada de lo anterior sustituye el live real en Windows.

Resultado offline de construcción de esta entrega: `238 passed, 2 skipped`; lo
omitido es exclusivamente el smoke Binance activable con `RUN_BINANCE_LIVE=1`.
El benchmark sintético `--enforce` fue PASS. La observación Meinberg consulta 20
veces la estimación mantenida por `ntpd`; no se describe como 20 paquetes NTP
independientes.

## Marcador final

`runs\CAPTURA_COMPLETA_AUDITADA.json` contiene versión, esquema, hash del
manifest de release, intento, host, NTP, sesiones, duraciones, auditorías y
hashes de evidencia. Un intento completo nuevo archiva el marcador previo. Su
ausencia significa que la Fase 1 todavía no está certificada para iniciar
LightGBM.
