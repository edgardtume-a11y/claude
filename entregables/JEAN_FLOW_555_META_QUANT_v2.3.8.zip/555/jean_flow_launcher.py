from __future__ import annotations

import ctypes
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from contextlib import AbstractContextManager, suppress
from ctypes import wintypes
from pathlib import Path
from types import ModuleType
from typing import Any, BinaryIO

LAUNCHER_VERSION = "2.3.8"


ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = (ROOT / "binance_phase1_collector").resolve()
RUNTIME_ROOT = PROJECT_ROOT / ".runtime"
RUNTIME_PACKAGES = RUNTIME_ROOT / "packages"
ENV_STAMP = RUNTIME_ROOT / ".jean_flow_environment.json"
WHEELHOUSE = PROJECT_ROOT / "wheelhouse"
WHEELHOUSE_MANIFEST = WHEELHOUSE / "WHEELHOUSE_MANIFEST.sha256"
RELEASE_MANIFEST = ROOT / "RELEASE_MANIFEST.sha256"
BOOTSTRAP_LOCK = PROJECT_ROOT / ".jean_flow_bootstrap.lock"
RUNTIME_MANIFEST = RUNTIME_ROOT / "RUNTIME_MANIFEST.sha256"


class BootstrapFailure(RuntimeError):
    pass


class BootstrapLock(AbstractContextManager["BootstrapLock"]):
    def __init__(self) -> None:
        self.stream: BinaryIO | None = None
        self.handle: int | None = None
        self.kernel32: Any | None = None
        # [S7]: Global\ (exclusión entre sesiones RDP/consola sobre la misma
        # carpeta) e identidad por ruta resuelta+normalizada (subst y nombres
        # 8.3 ya no generan tokens distintos). El squatting del nombre por un
        # proceso local sin privilegios sigue siendo posible y está
        # documentado en SECURITY.md como limitación.
        token = hashlib.sha256(
            os.path.normcase(str(ROOT.resolve())).casefold().encode("utf-8")
        ).hexdigest()[:24]
        self.name = f"Global\\JEAN_FLOW_BOOTSTRAP_{token}"

    def __enter__(self) -> "BootstrapLock":
        if os.name == "nt":
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.CreateMutexW.argtypes = (
                wintypes.LPVOID,
                wintypes.BOOL,
                wintypes.LPCWSTR,
            )
            kernel32.CreateMutexW.restype = wintypes.HANDLE
            kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
            kernel32.CloseHandle.restype = wintypes.BOOL
            self.kernel32 = kernel32
            ctypes.set_last_error(0)
            handle = kernel32.CreateMutexW(None, False, self.name)
            if not handle:
                creation_error = ctypes.get_last_error()
                raise BootstrapFailure(
                    "MUTEX_FAILED: no se pudo crear el mutex "
                    f"(WinError {creation_error})"
                )
            self.handle = int(handle)
            if ctypes.get_last_error() == 183:
                kernel32.CloseHandle(handle)
                self.handle = None
                self.kernel32 = None
                raise BootstrapFailure(
                    "ALREADY_RUNNING: otro inicio está preparando o ejecutando JEAN_FLOW"
                )
        else:
            import fcntl

            stream = BOOTSTRAP_LOCK.open("a+b")
            try:
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as exc:
                stream.close()
                raise BootstrapFailure(
                    "ALREADY_RUNNING: otro inicio está preparando o ejecutando JEAN_FLOW"
                ) from exc
            self.stream = stream
        return self

    def __exit__(self, *_exc_info: object) -> None:
        if self.handle is not None:
            assert self.kernel32 is not None
            self.kernel32.CloseHandle(wintypes.HANDLE(self.handle))
            self.handle = None
            self.kernel32 = None
        if self.stream is not None:
            with suppress(OSError):
                self.stream.close()
            self.stream = None


def _fingerprint() -> str:
    digest = hashlib.sha256()
    for path in (
        PROJECT_ROOT / "requirements.lock",
        PROJECT_ROOT / "pyproject.toml",
        Path(__file__).resolve(),
        WHEELHOUSE_MANIFEST,
        RELEASE_MANIFEST,
    ):
        digest.update(path.name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\n")
    digest.update(
        f"{sys.version_info.major}.{sys.version_info.minor}:{platform.machine()}".encode()
    )
    return digest.hexdigest()


def _runtime_manifest_entries() -> dict[str, str]:
    if not RUNTIME_MANIFEST.is_file() or RUNTIME_MANIFEST.is_symlink():
        raise BootstrapFailure("RUNTIME_MANIFEST_INVALID: manifest ausente")
    entries: dict[str, str] = {}
    try:
        lines = RUNTIME_MANIFEST.read_text(encoding="ascii").splitlines()
    except (OSError, UnicodeError) as exc:
        raise BootstrapFailure(f"RUNTIME_MANIFEST_INVALID: {exc}") from exc
    for line in lines:
        digest, separator, relative = line.partition("  ")
        path = Path(relative)
        if (
            separator != "  "
            or len(digest) != 64
            or any(character not in "0123456789abcdef" for character in digest)
            or not relative
            or "\\" in relative
            or path.is_absolute()
            or any(part in {"", ".", ".."} for part in path.parts)
            or relative in entries
        ):
            raise BootstrapFailure("RUNTIME_MANIFEST_INVALID: línea no canónica")
        entries[relative] = digest
    if not entries:
        raise BootstrapFailure("RUNTIME_MANIFEST_INVALID: manifest vacío")
    return entries


def _supply_chain() -> ModuleType:
    """Importa el verificador único de wheels desde src (P1.8c/[S11]).

    El bootstrap ya importaba supply_chain para el plan; mantener aquí una
    segunda copia del extractor produjo guardas divergentes verificadas
    ('C:evil.py' pasaba el build y moría en la instalación). Una sola
    implementación, un solo comportamiento.
    """

    source_root = str(PROJECT_ROOT / "src")
    inserted = source_root not in sys.path
    if inserted:
        sys.path.insert(0, source_root)
    try:
        from binance_collector import supply_chain

        return supply_chain
    finally:
        if inserted:
            with suppress(ValueError):
                sys.path.remove(source_root)


def _expected_runtime_hashes(plan: tuple[Any, ...]) -> dict[str, str]:
    supply_chain = _supply_chain()
    try:
        return supply_chain.expected_runtime_inventory(plan)
    except supply_chain.SupplyChainError as exc:
        raise BootstrapFailure(f"WHEELHOUSE_INVALID: {exc}") from exc


def _runtime_bytes_match_plan(plan: tuple[Any, ...]) -> bool:
    try:
        expected = _expected_runtime_hashes(plan)
        if _runtime_manifest_entries() != expected:
            return False
        actual: dict[str, Path] = {}
        for path in RUNTIME_PACKAGES.rglob("*"):
            relative = path.relative_to(RUNTIME_PACKAGES).as_posix()
            if (
                path.is_symlink()
                or (hasattr(path, "is_junction") and path.is_junction())
                or (not path.is_file() and not path.is_dir())
            ):
                return False
            if path.is_file():
                actual[relative] = path
        if set(actual) != set(expected):
            return False
        return all(_sha256(actual[name]) == digest for name, digest in expected.items())
    except OSError:
        # [S9]: SOLO los fallos de ENTORNO devuelven False (reconstruir puede
        # arreglarlos). Un BootstrapFailure aquí es un fallo de INTEGRIDAD
        # (wheel cambiado tras el plan, RECORD inválido) y antes se tragaba,
        # convirtiéndose en una reconstrucción silenciosa.
        return False


def _sha256(path: Path) -> str:
    return _supply_chain().sha256_file(path)


class _ProbeResult:
    __slots__ = ("ok", "reason")

    def __init__(self, ok: bool, reason: str) -> None:
        self.ok = ok
        self.reason = reason


def _environment_probe(plan: tuple[Any, ...]) -> _ProbeResult:
    """[S9]/F4: el probe ya no es un booleano mudo para ≥6 causas distintas.

    El subproceso emite un diagnóstico JSON por stdout y el fallo nombra la
    causa concreta (versión que difiere, import que falla, origen fuera del
    runtime sellado), no "imports/versiones no coinciden" a secas.
    """

    if not RUNTIME_PACKAGES.is_dir():
        return _ProbeResult(False, "no existe .runtime/packages")
    if not _runtime_bytes_match_plan(plan):
        return _ProbeResult(
            False,
            "los bytes del runtime no coinciden con el plan de wheels "
            "(RUNTIME_MANIFEST o contenido alterado)",
        )
    expected = {entry.distribution: entry.version for entry in plan}
    probe = (
        "import importlib.metadata as m,json,pathlib,sys\n"
        f"source=pathlib.Path({str(PROJECT_ROOT / 'src')!r}).resolve()\n"
        f"site=pathlib.Path({str(RUNTIME_PACKAGES)!r}).resolve()\n"
        "sys.path.insert(0,str(source));sys.path.append(str(site))\n"
        f"expected=json.loads({json.dumps(json.dumps(expected, sort_keys=True))})\n"
        "diagnosis={'versions_mismatch':{}, 'import_error':None,"
        "'package_out_of_tree':None,'origins_out_of_runtime':[],"
        "'engine_version':None}\n"
        "ok=True\n"
        "try:\n"
        "    actual={name:m.version(name) for name in expected}\n"
        "    for name in expected:\n"
        "        if actual.get(name)!=expected[name]:\n"
        "            diagnosis['versions_mismatch'][name]="
        "{'expected':expected[name],'actual':actual.get(name)}\n"
        "            ok=False\n"
        "    import aiohttp,binance_collector,orjson,sortedcontainers,websockets\n"
        "    package=pathlib.Path(binance_collector.__file__).resolve()\n"
        "    if not package.is_relative_to(source):\n"
        "        diagnosis['package_out_of_tree']=str(package)\n"
        "        ok=False\n"
        "    for module in (aiohttp,orjson,sortedcontainers,websockets):\n"
        "        origin=pathlib.Path(module.__file__).resolve()\n"
        "        if not origin.is_relative_to(site):\n"
        "            diagnosis['origins_out_of_runtime'].append(str(origin))\n"
        "            ok=False\n"
        "    diagnosis['engine_version']=binance_collector.__version__\n"
        f"    if binance_collector.__version__!={LAUNCHER_VERSION!r}:\n"
        "        ok=False\n"
        "except BaseException as exc:\n"
        "    diagnosis['import_error']=f'{type(exc).__name__}: {exc}'\n"
        "    ok=False\n"
        "print(json.dumps(diagnosis,sort_keys=True))\n"
        "raise SystemExit(0 if ok else 1)\n"
    )
    check = subprocess.run(
        [sys.executable, "-I", "-S", "-B", "-c", probe],
        cwd=PROJECT_ROOT,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if check.returncode == 0:
        return _ProbeResult(True, "ok")
    detail = (check.stdout or b"").decode("utf-8", errors="replace").strip()
    stderr_tail = (check.stderr or b"").decode("utf-8", errors="replace").strip()
    reason = detail or stderr_tail or f"probe exit={check.returncode} sin salida"
    if stderr_tail and detail:
        reason = f"{detail}; stderr: {stderr_tail[-500:]}"
    return _ProbeResult(False, reason)


def _stamp_matches(fingerprint: str, plan: tuple[Any, ...]) -> bool:
    if not RUNTIME_PACKAGES.is_dir() or not ENV_STAMP.is_file():
        return False
    try:
        payload = json.loads(ENV_STAMP.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return False
    if payload.get("fingerprint") != fingerprint:
        return False
    return _environment_probe(plan).ok


def _find_preserved_destination() -> Path:
    prefix = ".runtime_preserved_" + time.strftime("%Y%m%d_%H%M%S")
    for sequence in range(1_000):
        candidate = PROJECT_ROOT / f"{prefix}_{sequence:03d}"
        if not candidate.exists():
            return candidate
    raise BootstrapFailure("No se encontró nombre libre para preservar el runtime")


def _preserve_invalid_environment() -> None:
    if not RUNTIME_ROOT.exists():
        return
    destination = _find_preserved_destination()
    try:
        RUNTIME_ROOT.replace(destination)
    except OSError as exc:
        raise BootstrapFailure(
            f"No se pudo preservar el runtime inválido {RUNTIME_ROOT}: {exc}"
        ) from exc
    print(f"Runtime anterior preservado en: {destination}")
    _prune_preserved_runtimes()


def _prune_preserved_runtimes(keep: int = 2) -> None:
    """P1.8b: los `.runtime_preserved_*` (793 ficheros cada uno) crecían sin
    control y el manifest los excluye, así que nada los detectaba."""

    preserved = sorted(
        (
            path
            for path in PROJECT_ROOT.glob(".runtime_preserved_*")
            if path.is_dir() and not path.is_symlink()
        ),
        key=lambda path: path.name,
    )
    for stale in preserved[: max(0, len(preserved) - keep)]:
        try:
            shutil.rmtree(stale)
            print(f"Runtime preservado antiguo eliminado: {stale.name}")
        except OSError as exc:
            print(
                f"AVISO: no se pudo podar {stale.name}: {exc}; "
                "elimínelo manualmente cuando nada lo use"
            )


def _recover_orphan_staging(staging_root: Path) -> None:
    """[S4]/R1.3/F5: un `.runtime_building` huérfano (Ctrl-C, disco lleno,
    handle de Defender durante la extracción) brickeaba el producto para
    siempre con RUNTIME_STAGING_EXISTS. Un arranque fallido no puede impedir
    el siguiente: el huérfano se preserva y el bootstrap continúa."""

    if not staging_root.exists():
        return
    destination = _find_preserved_destination().with_name(
        _find_preserved_destination().name + "_staging"
    )
    try:
        staging_root.replace(destination)
    except OSError as exc:
        raise BootstrapFailure(
            "RUNTIME_STAGING_UNRECOVERABLE: no se pudo apartar "
            f"{staging_root} ({exc}). Cierre procesos que lo usen (antivirus/"
            "explorador) y reintente; si persiste, elimine esa carpeta."
        ) from exc
    print(
        f"Staging huérfano de un arranque anterior preservado en: {destination}"
    )
    _prune_preserved_runtimes()


def _validate_wheelhouse() -> tuple[Any, ...]:
    source_root = PROJECT_ROOT / "src"
    sys.path.insert(0, str(source_root))
    try:
        from binance_collector.supply_chain import (
            SupplyChainError,
            verified_wheel_plan,
        )

        try:
            return verified_wheel_plan(PROJECT_ROOT)
        except SupplyChainError as exc:
            raise BootstrapFailure(f"WHEELHOUSE_INVALID: {exc}") from exc
    finally:
        with suppress(ValueError):
            sys.path.remove(str(source_root))


def _write_stamp(fingerprint: str, plan: tuple[Any, ...]) -> None:
    temporary = ENV_STAMP.with_suffix(".tmp")
    payload = {
        "fingerprint": fingerprint,
        "launcher_version": LAUNCHER_VERSION,
        "python": platform.python_version(),
        "architecture": platform.machine(),
        "dependency_count": len(plan),
        "created_utc_ns": time.time_ns(),
    }
    temporary.write_text(
        json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, ENV_STAMP)


def _safe_extract_wheel(entry: Any, destination: Path) -> None:
    """Extract one authenticated wheel without executing package code.

    La verificación (hash del wheel, RECORD, filtros de rutas, cotas de
    descompresión) vive en UNA sola implementación: supply_chain ([S11]/I7).
    """

    supply_chain = _supply_chain()
    try:
        payloads = supply_chain.verified_wheel_payloads(entry)
    except MemoryError as exc:
        raise BootstrapFailure(
            f"WHEEL_EXTRACT_FAILED: descompresión agotó la memoria: "
            f"{entry.path.name}"
        ) from exc
    except supply_chain.SupplyChainError as exc:
        raise BootstrapFailure(f"WHEEL_EXTRACT_FAILED: {entry.path.name}: {exc}") from exc
    for relative, payload in payloads.items():
        target = (destination / relative).resolve()
        if not target.is_relative_to(destination.resolve()):
            raise BootstrapFailure(
                f"WHEEL_LAYOUT_INVALID: ruta fuera del runtime: {relative!r}"
            )
        if target.exists():
            if not target.is_file() or target.read_bytes() != payload:
                raise BootstrapFailure(f"WHEEL_COLLISION: {relative!r}")
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)


def _assert_plain_runtime_path(path: Path, project_root: Path) -> None:
    """Reject links/junctions before writing or trusting the runtime tree."""

    project = project_root.absolute()
    candidate = path.absolute()
    if candidate != project and not candidate.is_relative_to(project):
        raise BootstrapFailure("RUNTIME_PATH_INVALID: ruta fuera del proyecto")
    current = project
    relative_parts = (
        () if candidate == project else candidate.relative_to(project).parts
    )
    for part in relative_parts:
        current = current / part
        if current.exists() and (
            current.is_symlink()
            or (hasattr(current, "is_junction") and current.is_junction())
        ):
            raise BootstrapFailure(
                f"RUNTIME_PATH_INVALID: enlace/reparse point no admitido: {current}"
            )


def _create_environment(fingerprint: str, plan: tuple[Any, ...]) -> None:
    print("Preparando el runtime hash-verificado de JEAN_FLOW...")
    staging_root = PROJECT_ROOT / ".runtime_building"
    _assert_plain_runtime_path(staging_root, PROJECT_ROOT)
    _recover_orphan_staging(staging_root)
    # F5: primero se valida TODO el plan (barato: hashes en memoria; además
    # detecta colisiones de mayúsculas [S5] y bombas [S6]); solo entonces se
    # toca el runtime del usuario. Antes se preservaba el runtime ANTES de
    # descubrir que los wheels eran inservibles.
    expected = _expected_runtime_hashes(plan)
    _preserve_invalid_environment()
    staging_packages = staging_root / "packages"
    try:
        staging_packages.mkdir(parents=True, exist_ok=False)
        for entry in plan:
            _safe_extract_wheel(entry, staging_packages)
        lines = [f"{expected[relative]}  {relative}" for relative in sorted(expected)]
        (staging_root / RUNTIME_MANIFEST.name).write_text(
            "\n".join(lines) + "\n", encoding="ascii"
        )
        _assert_plain_runtime_path(RUNTIME_ROOT, PROJECT_ROOT)
        os.replace(staging_root, RUNTIME_ROOT)
    except BaseException:
        # F5: nunca dejar `.runtime_building` huérfano tras un fallo o un
        # Ctrl-C: es lo que brickeaba todos los arranques posteriores.
        with suppress(OSError):
            if staging_root.exists():
                shutil.rmtree(staging_root)
        raise
    _assert_plain_runtime_path(RUNTIME_ROOT, PROJECT_ROOT)
    _assert_plain_runtime_path(RUNTIME_PACKAGES, PROJECT_ROOT)
    probe = _environment_probe(plan)
    if not probe.ok:
        _invalidate_visible_certificate_after_integrity_failure(
            "ENVIRONMENT_SEAL_FAILED"
        )
        raise BootstrapFailure(
            f"ENVIRONMENT_SEAL_FAILED: {probe.reason}"
        )
    _write_stamp(fingerprint, plan)


def _activate_verified_runtime_paths() -> None:
    source_root = (PROJECT_ROOT / "src").resolve()
    _assert_plain_runtime_path(RUNTIME_ROOT, PROJECT_ROOT)
    _assert_plain_runtime_path(RUNTIME_PACKAGES, PROJECT_ROOT)
    site_packages = RUNTIME_PACKAGES.resolve()
    if not source_root.is_dir() or not site_packages.is_dir():
        raise BootstrapFailure("RUNTIME_PATH_INVALID: src/site-packages ausente")
    source_text = str(source_root)
    site_text = str(site_packages)
    sys.dont_write_bytecode = True
    if source_text not in sys.path:
        sys.path.insert(0, source_text)
    if site_text not in sys.path:
        # -S evita ejecutar .pth; las dependencias verificadas se añaden como
        # un directorio pasivo y no pueden ejecutar código antes del verifier.
        sys.path.append(site_text)
    os.environ["JEAN_FLOW_SOURCE_ROOT"] = source_text
    os.environ["JEAN_FLOW_RUNTIME_PACKAGES"] = site_text
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"


def _validate_bootstrap_python() -> None:
    if os.name != "nt":
        raise BootstrapFailure(
            "Este paquete de un clic está destinado a Windows 11 x64"
        )
    if sys.version_info[:2] != (3, 12):
        raise BootstrapFailure("Se requiere Python 3.12 de 64 bits")
    if sys.maxsize <= 2**32:
        raise BootstrapFailure("Se requiere Python de 64 bits")
    if platform.machine().casefold() not in {"amd64", "x86_64"}:
        raise BootstrapFailure(
            "Se requiere Windows x64/AMD64 para los wheels incluidos"
        )


def _windows_process_is_elevated() -> bool:
    """Read TokenElevation directly; never infer privilege from the window title."""

    if os.name != "nt":
        return False
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel32.CloseHandle.restype = wintypes.BOOL
    advapi32.OpenProcessToken.argtypes = (
        wintypes.HANDLE,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.HANDLE),
    )
    advapi32.OpenProcessToken.restype = wintypes.BOOL
    advapi32.GetTokenInformation.argtypes = (
        wintypes.HANDLE,
        ctypes.c_int,
        wintypes.LPVOID,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
    )
    advapi32.GetTokenInformation.restype = wintypes.BOOL
    token = wintypes.HANDLE()
    if not advapi32.OpenProcessToken(
        kernel32.GetCurrentProcess(), 0x0008, ctypes.byref(token)
    ):
        raise BootstrapFailure(
            f"ELEVATION_STATE_UNKNOWN: OpenProcessToken WinError {ctypes.get_last_error()}"
        )
    try:
        elevated = wintypes.DWORD()
        returned = wintypes.DWORD()
        if not advapi32.GetTokenInformation(
            token,
            20,  # TokenElevation
            ctypes.byref(elevated),
            ctypes.sizeof(elevated),
            ctypes.byref(returned),
        ):
            raise BootstrapFailure(
                "ELEVATION_STATE_UNKNOWN: GetTokenInformation "
                f"WinError {ctypes.get_last_error()}"
            )
        if returned.value != ctypes.sizeof(elevated):
            raise BootstrapFailure("ELEVATION_STATE_UNKNOWN: tamaño TokenElevation")
        return bool(elevated.value)
    finally:
        kernel32.CloseHandle(token)


def _reject_elevated_process() -> None:
    if _windows_process_is_elevated():
        raise BootstrapFailure(
            "ELEVATED_PROCESS_FORBIDDEN: ejecuta INICIAR con doble clic normal; "
            "no uses 'Ejecutar como administrador'"
        )


def _verify_release_integrity() -> dict[str, object]:
    source_root = PROJECT_ROOT / "src"
    sys.path.insert(0, str(source_root))
    try:
        # [S10]/R5.6: la política estaba INVERTIDA. Un antivirus que bloquea
        # momentáneamente el import del verificador NO es evidencia de
        # manipulación: no destruye el certificado de una captura de 2 horas.
        # Solo un fallo de integridad REAL (ReleaseIntegrityError) invalida.
        try:
            from binance_collector.release_integrity import (
                ReleaseIntegrityError,
                verify_release_tree,
            )
        except Exception as exc:
            raise BootstrapFailure(
                f"RELEASE_VERIFIER_LOAD_FAILED: {type(exc).__name__}: {exc} "
                "(fallo de entorno; el certificado existente se conserva)"
            ) from exc

        try:
            return verify_release_tree(ROOT, expected_version=LAUNCHER_VERSION)
        except ReleaseIntegrityError as exc:
            _invalidate_visible_certificate_after_integrity_failure(exc.code)
            raise BootstrapFailure(f"{exc.code}: {exc}") from exc
        except OSError as exc:
            raise BootstrapFailure(
                f"RELEASE_VERIFIER_IO_FAILED: {exc} "
                "(fallo de entorno; el certificado existente se conserva)"
            ) from exc
        except Exception as exc:
            raise BootstrapFailure(
                f"RELEASE_VERIFIER_FAILED: {type(exc).__name__}: {exc}"
            ) from exc
    finally:
        try:
            sys.path.remove(str(source_root))
        except ValueError:
            pass


def _invalidate_visible_certificate_after_integrity_failure(code: str) -> None:
    """A certificate for a different/tampered tree must not remain current."""

    marker = PROJECT_ROOT / "runs" / "CAPTURA_COMPLETA_AUDITADA.json"
    if not marker.is_file() or marker.is_symlink():
        return
    history = marker.parent / "certificate_history"
    try:
        history.mkdir(parents=True, exist_ok=True)
        destination = history / (
            "INVALIDATED_RELEASE_"
            + time.strftime("%Y%m%d_%H%M%S")
            + "_"
            + code
            + ".json"
        )
        os.replace(marker, destination)
    except OSError:
        # Preserve the original bootstrap integrity error. The launcher still
        # fails closed and never treats this marker as evidence in a new run.
        pass


def _enforce_isolated_flags() -> None:
    """[S1]/R5.1/I5: `-I -S` era una afirmación de un comentario, no una
    propiedad verificada. Si el proceso arrancó sin las banderas (doble clic
    sobre el .py, consola), `site` ya procesó los .pth de %APPDATA% ANTES de
    esta línea: el proceso se re-ejecuta con las banderas correctas; si tras
    re-ejecutar siguen ausentes, se falla con código propio."""

    if sys.flags.isolated and sys.flags.no_site:
        return
    if os.environ.get("JEAN_FLOW_REEXEC_GUARD") == "1":
        raise BootstrapFailure(
            "ISOLATED_FLAGS_MISSING: el intérprete ignoró -I -S tras "
            "re-ejecutar; ejecute mediante INICIAR.cmd"
        )
    os.environ["JEAN_FLOW_REEXEC_GUARD"] = "1"
    print("Re-ejecutando con -I -S -B para garantizar el aislamiento...")
    os.execv(
        sys.executable,
        [
            sys.executable,
            "-I",
            "-S",
            "-B",
            "-u",
            str(Path(__file__).resolve()),
            *sys.argv[1:],
        ],
    )


def main() -> int:
    arguments = sys.argv[1:]
    if "--inside-venv" in arguments:
        raise BootstrapFailure("ARGUMENT_NOT_ALLOWED: --inside-venv es interno")
    _enforce_isolated_flags()
    _validate_bootstrap_python()
    _reject_elevated_process()
    integrity = _verify_release_integrity()
    os.environ["JEAN_FLOW_RELEASE_MANIFEST_SHA256"] = str(integrity["manifest_sha256"])
    with BootstrapLock():
        if not PROJECT_ROOT.joinpath("pyproject.toml").is_file():
            raise BootstrapFailure(f"Proyecto incompleto: {PROJECT_ROOT}")
        try:
            plan = _validate_wheelhouse()
        except BootstrapFailure as exc:
            # [S10] simétrico: WHEELHOUSE_INVALID sí es integridad real.
            if str(exc).startswith("WHEELHOUSE_INVALID"):
                _invalidate_visible_certificate_after_integrity_failure(
                    "WHEELHOUSE_INVALID"
                )
            raise
        fingerprint = _fingerprint()
        if not _stamp_matches(fingerprint, plan):
            _create_environment(fingerprint, plan)
        _activate_verified_runtime_paths()
        from binance_collector.supply_chain import (
            SupplyChainError,
            verify_runtime_tree,
        )

        try:
            runtime_integrity = verify_runtime_tree(PROJECT_ROOT, RUNTIME_PACKAGES)
        except SupplyChainError as exc:
            _invalidate_visible_certificate_after_integrity_failure(
                "RUNTIME_TREE_INVALID"
            )
            raise BootstrapFailure(f"RUNTIME_TREE_INVALID: {exc}") from exc
        os.environ["JEAN_FLOW_RUNTIME_INVENTORY_SHA256"] = str(
            runtime_integrity["inventory_sha256"]
        )
        from binance_collector.launcher import main as launcher_main

        # El mutex de bootstrap permanece vivo durante toda la captura. El
        # mutex interno del launcher sigue siendo una segunda defensa.
        return launcher_main(arguments)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BootstrapFailure as exc:
        print(f"BOOTSTRAP_FAILED: {exc}")
        raise SystemExit(2)
    except KeyboardInterrupt:
        print("BOOTSTRAP_INTERRUPTED: operación cancelada por el usuario")
        raise SystemExit(130)
    except Exception as exc:
        print(f"BOOTSTRAP_INTERNAL_ERROR: {type(exc).__name__}: {exc}")
        raise SystemExit(70)
