# CAMBIOS v2.3.4 — Revisión documentada del gate event_loop_lag y robustez operativa

Todo lo listado tiene evidencia de campo de la noche de certificación del
2026-08-13/14 en el host Windows 11 de referencia (laptop del operador,
disco de trabajo D:). Ningún cambio relaja un gate en silencio: la única
revisión de criterio está fundamentada abajo y registrada además en
`CERTIFICACION_FASE1.md` y `README.md`.

## 1. REVISIÓN DE CRITERIO — `event_loop_lag_p99`: 20 ms → 40 ms

**Evidencia.** Sesión `99a0f0a51142400a97b4e064dfd62fab` (modo 3, etapa
10 min, BTCUSDT, 2026-08-14 04:12Z): captura SANA de punta a punta —
`HEALTHY_DURATION_COMPLETE seconds=600.0`, 0 overflows en todas las colas,
aggTrade activo en ambos mercados (futures 2443 / spot 1760 en ventana),
libros `SYNCED`, snapshot terminal y rotaciones escritas — y sin embargo
`POSTFLIGHT_FAILED: Auditoría FAIL` con `event_loop_lag` p99 clavado en
21-22 ms durante TODA la etapa (máximos aislados de 30-100 ms que no mueven
el p99 sobre ventanas de 10 000 muestras). Único gate FAIL de la sesión.
Antecedente coherente: `benchmark --enforce` ocioso en el mismo host midió
p99 = 16 ms.

**Causa raíz.** El cuanto del temporizador de Windows de escritorio es
15.625 ms (64 Hz) y el colector NO fuerza `timeBeginPeriod(1)` por diseño
(ver README «Reloj y scheduler»): toda espera del event loop se redondea al
múltiplo del cuanto, así que la cola de la distribución vive en
{15.6, 31.25} ms por construcción del sistema operativo anfitrión, no por
atasco del colector. Con el límite de 20 ms — un criterio de grado servidor
Linux — el examen era estructuralmente inaprobable en Windows aunque la
captura fuera íntegra.

**Cambio.** `EVENT_LOOP_P99_LIMIT_MS = 40.0` en `audit.py` (default de
`audit_metrics_logs` y del CLI `--event-loop-p99-ms`), alineado en
`benchmarks/benchmark_latency.py`. Fundamento del valor: 2 cuantos
(31.25 ms) + margen de despacho ≈ 40 ms. Un atasco real (GC, paginación,
E/S sostenida) sigue condenado: aparece como p99 >= 100 ms. La métrica se
sigue midiendo y publicando SIN recorte; solo cambia la línea de corte.
Ningún otro límite cambió (`parse`/`book_apply`/`book_pipeline_total`/
`writer_cooperative_yield` siguen en 5 ms).

## 2. Presupuesto real para la re-verificación del reloj

**Evidencia.** `CLOCK_REVALIDATION_FAILED: NTP_COMMAND_TIMEOUT` en el host
cargado: el tope de 15 s por intento era menor que lo que tarda
`Test-ClockSync` bajo carga. **Cambio** (`launcher.py`): presupuesto total
de 240 s con intentos de 20-60 s (`timeout_s=min(60, max(20, restante))`) y
descarte de intentos condenados (<20 s restantes).

## 3. Modo normal (1): aviso de reloj en lugar de bloqueo

El desfase NTP solo compromete la CERTIFICACIÓN (sello temporal cruzado);
una captura de uso normal es utilizable igual. **Cambio**: en modo 1 el
preflight de reloj que falla deja constancia (`clock_preflight_waived.json`
+ `AVISO RELOJ` en consola) y continúa; el postflight registra
`waived_mode` sin abortar. Los modos 2/3 mantienen el gate completo.

## 4. Prompt de símbolo con re-pregunta

**Evidencia.** Un dedazo (`}`) mató el arranque minutos después con
`BINANCE_SYMBOL debe ser ASCII alfanumérico`. **Cambio**: el prompt valida
en el momento (ASCII alfanumérico) y re-pregunta hasta 3 veces con mensaje
claro (`Símbolo inválido: solo letras y números (ej. BTCUSDT)`); Enter vacío
sigue siendo BTCUSDT.

## 5. `tools/capture_fixtures.py` reescrito sobre la fuente de verdad

**Evidencia.** El golden USDⓈ-M del 2026-08-14 (TUTUSDT) salió con 0
aggTrade: la herramienta tenía la URL legada `/stream` codificada a mano,
la misma regresión que 2.3.3 corrigió en el motor. **Cambio**: la captura
golden itera `Settings.for_market(m).websocket_sources` — la MISMA tabla de
endpoints por niveles del motor (`/public` depth + `/market` aggTrade) — con
un archivo por socket (`{market}.{rol}.jsonl`), validación de cada payload
con `decode_combined`, y `PROVENANCE.json` por socket con bandera
`complete`. `validar_red.py` pasa ahora `--smoke-symbol` (BTCUSDT) también a
la captura de fixtures para que el golden siempre contenga trades.

## Estado de la suite

`pytest` offline completo tras estos cambios: ver `README.md` («Estado
verificable») — el único skip esperado es el smoke live opt-in
(`RUN_BINANCE_LIVE=1`).
