# Cambios JEAN_FLOW 2.1.5 - continuidad Spot y prueba inicial de 10 minutos

## Causa corregida

La captura recibia datos Spot, pero el bootstrap rechazaba como gap el primer
diff perfectamente contiguo `U=L+1`. Cada snapshot REST se descartaba, por eso
`rest_snapshots` y `bootstrap_gaps` crecian juntos hasta terminar en
`PipelineBackpressure: Buffer de bootstrap L2 saturado`. Futures no usaba esa
rama y continuaba funcionando.

## Correccion

- Spot descarta `u <= L` y acepta el primer rango que cubre el siguiente ID:
  `U <= L+1 <= u`.
- La comprobacion previa de snapshot usa el mismo piso `first_U-1` para Spot.
- Futures conserva sin cambios su puente y la cadena estricta `pu`.
- Se agregaron regresiones unitarias, de sincronizacion y de publicacion dual:
  el sucesor exacto debe producir un libro Spot `SYNCED` sin volver a pedir
  snapshot.

## Automatizacion por etapas

`555\EJECUTAR_TODO_JEAN_FLOW.cmd` ejecuta ahora una sola prueba dual de 600
segundos, audita Spot, Futures, identidad, metricas y archivos parciales, escribe
`PRUEBA_10M_PASS.txt` y se detiene. No inicia automaticamente 30 minutos ni dos
horas. Un PASS de 10 minutos es funcional, no una certificacion final.

## Alcance conservado

- Motor: `2.1.5`.
- Schema causal: `2.0.0` sin cambios.
- Dependencias fijadas: sin cambios.
- La correccion NTP 2.1.4 permanece incluida.
- `book_apply` y `event_loop_lag` siguen usando reloj monotonico; el cambio Spot
  no depende de UTC ni de W32Time.
