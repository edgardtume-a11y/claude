# Cambios JEAN_FLOW 2.2.1

- `LocalOrderBook` migra de `Decimal` a enteros exactos base `10^8`, con dominio
  de 64 bits, parser ASCII acotado y rechazo fail-closed de cualquier valor que
  requiera redondeo.
- Se elimina `_price_cache`, que podía retener hasta 400.000 strings/precios
  antiguos durante capturas con churn. Lo sustituye una LRU global de solo 8192
  tokens para absorber precios/cantidades repetidos sin retención por libro.
- La proyección productiva pasa top-N como enteros al hub en O(N); el formateo a
  strings se difiere al worker de serialización del dashboard. CSV y replay
  histórico mantienen los strings originales y el esquema `2.0.0`.
- El writer conserva el sleep positivo de 0,5 ms: CPython 3.12 ya usa un timer
  Windows de alta resolución. No se introduce busy-spin ni `timeBeginPeriod`.
  Se miden duración real, p99 y oversleeps del yield.
- `requirements.lock` incorpora un SHA-256 por cada una de las 20 dependencias
  runtime/test; `setuptools` y `wheel` se retiraron del wheelhouse/runtime al
  dejar de usar pip (siguen declarados solo como metadata de build del proyecto).
  El bootstrap exige una biyección requisito↔wheel↔manifest y construye un plan
  inmutable de rutas y hashes SHA-256.
- El bootstrap no confía en `pip` ni en un ejecutable dentro de `.venv`: extrae
  directamente cada wheel hash-verificado, comprueba su `RECORD`, sella todos
  los bytes instalados y reconstruye ante cualquier divergencia.
- Se elimina la instalación editable y el sentinel público del antiguo hijo.
  El Python global validado ejecuta con `-I -S` y rutas explícitas; ningún `.pth`
  ni `sitecustomize` del runtime se ejecuta.
- El lock de bootstrap en Windows pasa a mutex nombrado y permanece adquirido
  durante toda la captura. El mutex runtime continúa como defensa independiente.
- El build usa el mismo validador de cadena de suministro y un dry-run aislado
  para CPython 3.12/Windows x64.
- Validación offline: 162 PASS, 1 smoke Binance live opt-in omitido; benchmark
  sintético `--enforce` PASS. Windows 11, PowerShell/UAC/NTP y gates live
  10/30/120 minutos continúan siendo validación externa obligatoria.
