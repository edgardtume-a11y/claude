# Cambios JEAN_FLOW 2.3.0

Remediación integral de las dos auditorías de v2.2.2 (hallazgos [N*]/[S*]/[W*]/[P*]
y bloques P0–P3). Cada corrección de comportamiento tiene un test de regresión
que falla contra 2.2.2; los tests nuevos se citan por nombre.

## Bloqueantes de realidad (P0)

- **USDⓈ-M contra Binance real** ([P1]/[P2]/P0.1): los endpoints inventados
  `/public/stream` y `/market/stream` se sustituyen por el único endpoint
  combinado documentado `wss://fstream.binance.com/stream?streams=`
  (se conservan dos sockets para la separación causal). El campo `st` pasa a
  ser opcional y tolerante hacia delante: presente y ≠1 sigue rechazando
  (COIN-M); ausente se acepta y se cuenta (`usdm_st_absent`). Fixtures USD-M
  sin `st`/`nq`/`ps` (forma documentada). `tools/capture_fixtures.py` captura
  fixtures crudas con procedencia del socket real (opt-in con red).
  Tests: `test_usdm_futures.py::test_usdm_uses_documented_combined_stream_endpoint`,
  `::test_usdm_accepts_absent_discriminator_and_counts_it`.
- **Busy-loop del writer ocioso** (P0.2): el timeout se rearma al intervalo
  completo sin pendientes; ~2 s de CPU por cada 2 s de reloj pasan a <0,2 s.
  Test: `test_writer_idle_cpu.py`.
- **Heartbeat launcher↔motor** (P0.3): reintentos de `os.replace` ante la
  sharing violation de Windows, variante no durable (sin fsync) para el
  heartbeat, presupuesto de ~3 s por ciclo en el hilo, y monitor que tolera
  lecturas ilegibles mientras la última lectura VÁLIDA siga fresca
  (`PARENT_HEARTBEAT_UNREADABLE` ≠ `PARENT_HEARTBEAT_LOST`).
  Tests: `test_launcher_codes.py::test_atomic_write_retries_windows_sharing_violation`,
  `::test_heartbeat_validator_distinguishes_unreadable_from_lost`.
- **Certificación p99** (P0.4): percentil nearest-rank único (`metrics._percentile`,
  audit lo importa); `count_total`/`evicted` por métrica con gate de evicción;
  `writer_yield_p99` con n<100 evalúa el máx observado (`basis:
  max_fallback_small_n`); frontera `high_water == capacity` legal sin overflow
  (campo `overflows` para diagnóstico); ventana terminal elegida por
  `terminal_metric_snapshots == 1` con `TERMINAL_SNAPSHOT_AMBIGUOUS` explícito.
  Referencia de benchmark regenerada (`BENCHMARK_REFERENCIA_20260813.json`,
  motor 2.3.0; baseline Linux — regenerar en el Windows objetivo).
  Tests: `test_metrics_eviction.py`, `test_audit.py`.

## Anti-brick (Fase 1 de la remediación)

- **[N1] overflow de dominio**: `load_snapshot` queda dentro de un manejador
  que clasifica la causa. `BookDomainError` (determinista) → ABORT
  `SYMBOL_OUT_OF_DOMAIN` con mensaje que nombra símbolo, valor y límite;
  invariantes transitorias → RESYNC acotado (3 consecutivos →
  `SNAPSHOT_INVARIANT_PERSISTENT`). El bucle infinito que baneaba la IP en
  ~72 s desaparece. Tests: `test_anti_brick.py`.
- **R1.1 admisibilidad X2/X3**: chequeo contra `/exchangeInfo` EN EL ARRANQUE,
  antes de abrir un socket: `maxPrice·10⁸ ≤ 2⁶³−1`, `maxQty·10⁸ ≤ 2⁶³−1`,
  `tickSize/stepSize·10⁸ ∈ ℤ`, margen m(s) ≥ 10 (aviso en métricas/log).
  Decisión X4 documentada en `admissibility.py`: se mantiene el dominio 2⁶³
  con el gate obligatorio.
- **[S4] staging huérfano**: `.runtime_building` residual se preserva y el
  bootstrap continúa; `try/finally` limpia el staging ante cualquier fallo;
  poda de `.runtime_preserved_*` a 2. Test: `test_bootstrap_recovery.py`.
- **[S5] colisión de mayúsculas**: NFC+casefold en el inventario de wheels al
  construir el PLAN, con mensaje que nombra ambas rutas.
- **[W1] locale del gate NTP**: fallo de parser ≠ fallo de reloj. Nuevo código
  `STATUS_LOCALE_UNSUPPORTED` (exit 21) con el status crudo adjunto y los
  hechos ausentes nombrados; etiquetas reales añadidas ('Estrato', variantes
  'Desfase') y tolerancia a mojibake de 2 caracteres por acento.

## Coherencia numérica

- **X5/X6**: `reconstruct.py` migra a `fixed_point` (misma gramática que el
  libro vivo: `A_live = A_replay`) y a la forma canónica única `format_fixed`
  (`canonical_hash_version: 2`). `hash_live(B) == hash_replay(B)` por primera
  vez. Tests: `test_reconstruct_grammar.py`.
- **X7/[N5]**: los eventos stale se validan en el libro vivo al clasificarlos
  y el replay ejerce la misma gramática también sobre stale: ninguna fila del
  journal queda sin validar por ningún camino.
- **[P13]/R2.5**: contigüidad Spot estricta tras el anclaje (`U == u+1`
  exacto); el solapamiento lanza `SequenceOverlap` y cuenta
  `l2_overlap_events`.
- **R4.2/R4.3/[P3]/[P15]**: `reconstruct` detecta conflictos K1 de
  `ingest_seq` (mismo ordinal, payloads distintos → `ReplayError`), publica
  contadores de unicidad, y los esquemas legacy 1.x salen de
  `SUPPORTED_SCHEMA_VERSIONS`. `causal_replay` deja de ser un literal: se
  computa (R0.1) y el CLI journal falla si es FAIL. `identity` publica
  `completeness` (C_ing con numerador/denominador).

## Contrato con el exchange y REST

- **[P5]/R3.3**: allowlist de esquema+host en `Settings.validated()`,
  `trust_env=False`, endpoints efectivos registrados en
  READY/session/RESULT, y `ENV_OVERRIDE_FORBIDDEN` en modo supervisado salvo
  `--allow-endpoint-override` (certificado marcado `ENDPOINT_OVERRIDDEN`).
- **[P10]/P1.3**: 418 = ban de IP → terminal (`RestBanError`, retirada TOTAL);
  `Retry-After` acotado a 60 s con rechazo de NaN/inf; el último intento no
  duerme; `X-MBX-USED-WEIGHT-1M` observado como gauge. Tests:
  `test_rest_hardening.py`.
- **M3/R7.1**: estimador de cuatro marcas contra `/api/v3|/fapi/v1/time` en el
  arranque; θ̂ y δ publicados como gauges y en el log; métricas etiquetadas
  por dominio de reloj (`clock_domains` en el informe de métricas).

## Gate de reloj

- **[W2]/M8**: eliminada la re-derivación cruzada del redondeo; `phase` se
  compara contra el valor CRUDO con media unidad del último dígito (5e-4).
  El 3,74 % de falsos rechazos (y descartes de capturas completas en
  postflight) desaparece.
- **[W4]/R6.3**: el postflight ya no puede emitir `error_code: "PASS"`; misma
  taxonomía que el preflight (`CLOCK_GATE_EVIDENCE_INVALID`).
- **[W3]/R6.1**: hash de los `.ps1` re-verificado contra el manifest
  INMEDIATAMENTE antes de cada `subprocess.run` (`CLOCK_SCRIPT_INTEGRITY_FAILED`).
- **[W5]**: consultas nativas envueltas (`Invoke-JeanFlowNativeQuery`); el
  stderr de w32tm ya no se convierte en `INTERNAL_ERROR` y el camino
  `QUERY_ACCESS_DENIED` (18) deja de ser código muerto.
- **[W9]/R6.4**: `registry_read_ok` como hecho propio del payload; el launcher
  lo exige junto a `sync_type` no vacío (cierra el fail-open vacuo).
- **[W10]/R6.6**: la vía de PASS exige exactamente un disciplinador W32Time
  activo y la evidencia de dominio/política, como la rama Meinberg.
- **[W11]**: contador de peers anclado a su etiqueta; guardia contra
  `[double]$null → 0`; `Configure/Start-W32TimeRepair` resuelven
  `powershell.exe` desde `SystemDirectory` (funciona bajo pwsh 7).

## Cadena de suministro y bootstrap

- **[S11]/P1.8c**: implementación ÚNICA del verificador de wheels
  (`supply_chain`); el bootstrap consume `verified_wheel_payloads`/
  `expected_runtime_inventory`; una sola `_sha256` (`sha256_file`).
  `:` rechazado en nombres de entrada (cubre `C:evil.py` en build E
  instalación).
- **[S6]/R5.4**: cotas de descompresión comprobadas ANTES de leer
  (miembro 64 MiB, wheel 256 MiB) y `MemoryError` tipado (salida 2, no 70).
- **[N7]**: wheels FIRMADOS instalables (`RECORD.jws`/`RECORD.p7s` sin hash u
  omitidos de RECORD, según la especificación).
- **[S1]/R5.1**: `sys.flags.isolated and sys.flags.no_site` verificados en la
  primera línea de `main()` con re-exec `-I -S -B -u`; `isolated_entry`
  también los exige, ancla el proyecto a su propia ubicación (fin de la
  validación tautológica [S12]) y aplica allowlist a `mode == "module"`.
- **[S9]/F4**: el probe del entorno emite un diagnóstico JSON con la causa
  (versión, import, origen fuera del runtime); `ENVIRONMENT_SEAL_FAILED`
  nombra la causa real. Fallos de integridad ya no se degradan a
  reconstrucción silenciosa.
- **[S10]/R5.6**: política del invalidador de certificados corregida: los
  fallos REALES de integridad (release, wheelhouse, runtime, sellado)
  invalidan; los transitorios de entorno (ImportError/OSError) conservan la
  evidencia.
- **[S7]/[S8]**: mutex `Global\` con ruta resuelta+normalizada y patrón
  `use_last_error` también en el supervisor; `MUTEX_FAILED` incluye WinError.
- **[S14]**: `requirements.lock` tolera comentarios y líneas vacías otra vez;
  hash case-insensitive; `*.tmp` excluido del manifest/ZIP del build;
  `SubprocessError` no rompe el contrato JSON del build.

## Durabilidad y robustez operativa

- **[P8]/R8.1**: fsync periódico en `_flush_file` (`FSYNC_INTERVAL_S`,
  5 s por defecto): el RPO ante corte de energía baja de hasta 1 hora a ~5 s.
- **P1.1**: la auditoría acepta directorios (rutas con corchetes ya no
  rompen glob) y el launcher pasa directorios, no globs.
- **P1.2**: drenaje adaptativo: mientras el manifest de sesión progrese
  (ventanas de 15 s) se espera hasta un techo duro de 900 s antes de
  `terminate()`.
- **P1.4**: códigos veraces: `DASHBOARD_RESPONSE_INVALID`,
  `NTP_OUTPUT_INVALID`, `ENGINE_EXIT_NONZERO`; `READY_STALE` es retryable y
  el motor refresca READY cada 5 s mientras siga operativo ([P11]).
- **P1.5**: middleware anti DNS-rebinding (Host y Origin contra el bind real),
  security headers también en `/api/state` y el Origin del WS ya no se
  compara contra `request.host`.
- **P1.9**: `desktop.ini`/`Thumbs.db` se reportan con ruta y hash sin
  invalidar un soak.
- **P2.4**: STOP inválido detiene igual (fail-closed) pero queda registrado
  como `STOP_TAMPERED`.
- **P2.5/P2.6**: `finiteNumber(null)` ya no pinta "+0.00 bps"; `seenTrades`
  se limpia en la frontera de época; símbolo normalizado una sola vez
  (`strip().upper()`), y ASCII estricto en config/dashboard ([P14]).
- **[P12]**: señales con fallback real en Windows también en `main.py`;
  logger JSONL con hora del EVENTO y `exc_info`.
- **[P16]**: `_synchronize` sin busy-poll de 100 despertares/s (espera
  simultánea snapshot+cola) y sin fuga de `task_done`.
- **R9.4/T4**: fixture autouse de aislamiento de entorno: la suite da el
  mismo resultado con `SNAPSHOT_LIMIT=100` ambiental (antes, 12 fallos).

## Validación

- Suite offline: **214 passed, 2 skipped** (smoke live opt-in, parametrizado por mercado) — misma cifra
  con entorno hostil.
- `benchmark_latency.py --enforce`: PASS (motor 2.3.0, host Linux de
  remediación; regenerar baseline en el Windows objetivo).
- `tools/build_release.py`: manifest regenerado y ZIP reproducible PASS.
- Smoke live contra Binance real: **BLOQUEADO en el entorno de remediación**
  (sin salida de red hacia Binance); ejecutar `RUN_BINANCE_LIVE=1 pytest
  tests/test_live_smoke.py` y `tools/capture_fixtures.py` en una máquina con
  red antes de certificar.
