"""Validación de red y de host que el entorno de remediación no pudo ejecutar.

Ejecuta, EN LA MÁQUINA DEL USUARIO (idealmente el Windows objetivo, vía
VALIDAR_EN_WINDOWS.cmd), los ítems marcados BLOQUEADOS en
INFORME_CIERRE_v2.3.0.md:

  1. Conectividad REST a Binance (ping/time Spot y USDⓈ-M).
  2. Admisibilidad del símbolo contra /exchangeInfo (gate X2/X3 real).
  3. Smoke live: >=100 mensajes por socket decodificados sin ProtocolError,
     con cadena `pu` verificada en USDⓈ-M (tests/test_live_smoke.py).
  4. Captura de fixtures golden CRUDAS con procedencia (capture_fixtures).
  5. Solo Windows: salida CRUDA de `w32tm /query /status /verbose`, `/peers`
     y `/source` (evidencia real del idioma para el gate NTP, hallazgo [W1])
     y Test-TimeSyncAssets.ps1 con el PowerShell real del sistema.

La evidencia queda FUERA del árbol del release (no rompe el manifest):
`validacion_<UTC>/` junto a la carpeta 555. Requiere haber ejecutado
INICIAR.cmd al menos una vez (usa el runtime verificado .runtime/packages).
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

TOOLS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = TOOLS_DIR.parent
RELEASE_ROOT = PROJECT_ROOT.parent
RUNTIME_PACKAGES = PROJECT_ROOT / ".runtime" / "packages"
SOURCE_ROOT = PROJECT_ROOT / "src"

REST_PROBES = (
    ("spot_ping", "https://api.binance.com/api/v3/ping"),
    ("spot_time", "https://api.binance.com/api/v3/time"),
    ("usdm_ping", "https://fapi.binance.com/fapi/v1/ping"),
    ("usdm_time", "https://fapi.binance.com/fapi/v1/time"),
)


def _probe_rest() -> dict[str, object]:
    results: dict[str, object] = {}
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for name, url in REST_PROBES:
        try:
            with opener.open(url, timeout=10) as response:
                body = response.read(4_096)
                results[name] = {
                    "ok": response.status == 200,
                    "status": response.status,
                    "body": body.decode("utf-8", errors="replace")[:200],
                }
        except Exception as exc:  # noqa: BLE001 - se reporta, no se decide
            results[name] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    results["ok"] = all(
        isinstance(item, dict) and item.get("ok") is True
        for key, item in results.items()
        if key != "ok"
    )
    return results


def _admissibility(symbol: str) -> dict[str, object]:
    from binance_collector.admissibility import (
        SymbolNotAdmissible,
        evaluate_symbol_admissibility,
    )

    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    out: dict[str, object] = {}
    for market, url in (
        ("spot", f"https://api.binance.com/api/v3/exchangeInfo?symbol={symbol}"),
        ("usdm_futures", "https://fapi.binance.com/fapi/v1/exchangeInfo"),
    ):
        try:
            with opener.open(url, timeout=20) as response:
                payload = json.loads(response.read())
            report = evaluate_symbol_admissibility(
                payload, symbol=symbol, market=market
            )
            out[market] = {"ok": True, "report": report.as_payload()}
        except SymbolNotAdmissible as exc:
            out[market] = {"ok": False, "refused": exc.code, "message": str(exc)}
        except Exception as exc:  # noqa: BLE001
            out[market] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return out


def _run_live_smoke(evidence: Path, symbol: str) -> dict[str, object]:
    import pytest

    os.environ["RUN_BINANCE_LIVE"] = "1"
    os.environ["RUN_BINANCE_LIVE_SYMBOL"] = symbol
    log = evidence / "pytest_live_smoke.txt"

    class _Capture:
        def __init__(self) -> None:
            self.lines: list[str] = []

    exit_code = pytest.main(
        [
            "-q",
            "-p",
            "no:cacheprovider",
            str(PROJECT_ROOT / "tests" / "test_live_smoke.py"),
            f"--junitxml={evidence / 'live_smoke.xml'}",
        ]
    )
    log.write_text(
        f"pytest exit code: {int(exit_code)}\n(la salida detallada quedó en "
        "la consola; live_smoke.xml contiene el resultado por test)\n",
        encoding="utf-8",
    )
    return {"ok": int(exit_code) == 0, "exit_code": int(exit_code)}


def _run_capture_fixtures(evidence: Path, symbol: str, messages: int) -> dict[str, object]:
    os.environ["RUN_BINANCE_LIVE"] = "1"
    command = [
        sys.executable,
        "-S",
        "-B",
        str(TOOLS_DIR / "capture_fixtures.py"),
        "--symbol",
        symbol,
        "--messages",
        str(messages),
        "--output",
        str(evidence / "golden"),
    ]
    environment = dict(os.environ)
    environment["PYTHONPATH"] = os.pathsep.join(
        [str(SOURCE_ROOT), str(RUNTIME_PACKAGES)]
    )
    completed = subprocess.run(
        command,
        cwd=PROJECT_ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=environment,
        check=False,
        timeout=600,
    )
    (evidence / "capture_fixtures.txt").write_bytes(completed.stdout or b"")
    provenance = evidence / "golden" / "PROVENANCE.json"
    return {
        "ok": completed.returncode == 0 and provenance.is_file(),
        "exit_code": completed.returncode,
        "provenance": str(provenance) if provenance.is_file() else None,
    }


def _windows_clock_evidence(evidence: Path) -> dict[str, object]:
    if os.name != "nt":
        return {"ok": None, "skipped": "solo Windows"}
    system32 = Path(os.environ.get("SystemRoot", r"C:\\Windows")) / "System32"
    w32tm = system32 / "w32tm.exe"
    powershell = system32 / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    results: dict[str, object] = {}
    for name, arguments in (
        ("status_verbose", ["/query", "/status", "/verbose"]),
        ("peers", ["/query", "/peers"]),
        ("source", ["/query", "/source"]),
    ):
        try:
            completed = subprocess.run(
                [str(w32tm), *arguments],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
                timeout=60,
            )
            # BYTES exactos: la evidencia del idioma real no se recodifica.
            (evidence / f"w32tm_{name}_crudo.bin").write_bytes(
                completed.stdout or b""
            )
            results[name] = {"exit_code": completed.returncode}
        except Exception as exc:  # noqa: BLE001
            results[name] = {"error": f"{type(exc).__name__}: {exc}"}
    assets = (
        PROJECT_ROOT / "tools" / "windows" / "time-sync" / "Test-TimeSyncAssets.ps1"
    )
    try:
        completed = subprocess.run(
            [
                str(powershell),
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(assets),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=300,
        )
        (evidence / "test_timesync_assets.txt").write_bytes(completed.stdout or b"")
        results["timesync_assets"] = {"exit_code": completed.returncode}
        results["ok"] = completed.returncode == 0
    except Exception as exc:  # noqa: BLE001
        results["timesync_assets"] = {"error": f"{type(exc).__name__}: {exc}"}
        results["ok"] = False
    return results


def _ensure_runtime() -> bool:
    """Prepara el runtime verificado si aún no existe (mismo flujo que
    INICIAR.cmd, sin lanzar la captura): así la validación es de UN clic y no
    depende del orden en que el operador ejecute las cosas."""

    if RUNTIME_PACKAGES.is_dir():
        return True
    if os.name != "nt":
        print(
            "BLOQUEADO: no existe .runtime/packages y este preparador "
            "automático es solo Windows. Ejecuta INICIAR.cmd una vez y "
            "relanza la validación."
        )
        return False
    print("Primera vez: preparando el runtime hash-verificado (1-3 min)...")
    import importlib.util

    bootstrap_path = RELEASE_ROOT / "jean_flow_launcher.py"
    specification = importlib.util.spec_from_file_location(
        "jean_flow_bootstrap_for_validation", bootstrap_path
    )
    if specification is None or specification.loader is None:
        print(f"BLOQUEADO: no se pudo cargar {bootstrap_path}")
        return False
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    try:
        module._validate_bootstrap_python()
        module._reject_elevated_process()
        integrity = module._verify_release_integrity()
        os.environ["JEAN_FLOW_RELEASE_MANIFEST_SHA256"] = str(
            integrity["manifest_sha256"]
        )
        with module.BootstrapLock():
            plan = module._validate_wheelhouse()
            fingerprint = module._fingerprint()
            if not module._stamp_matches(fingerprint, plan):
                module._create_environment(fingerprint, plan)
    except module.BootstrapFailure as exc:
        print(f"BLOQUEADO: {exc}")
        return False
    return RUNTIME_PACKAGES.is_dir()


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--symbol", default="TUTUSDT", help="Símbolo a capturar")
    parser.add_argument(
        "--smoke-symbol",
        default="BTCUSDT",
        help="Símbolo del smoke (alto volumen para llenar cuotas rápido)",
    )
    parser.add_argument("--messages", type=int, default=50)
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()

    if not _ensure_runtime():
        return 2
    for path in (str(SOURCE_ROOT), str(RUNTIME_PACKAGES)):
        if path not in sys.path:
            sys.path.insert(0, path)

    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    evidence = args.output or (RELEASE_ROOT.parent / f"validacion_{stamp}")
    evidence.mkdir(parents=True, exist_ok=True)
    print(f"Evidencia en: {evidence}")

    summary: dict[str, object] = {"started_utc": stamp, "symbol": args.symbol}
    print("1/5 Conectividad REST a Binance...")
    summary["rest"] = _probe_rest()
    print(f"    -> {'OK' if summary['rest']['ok'] else 'FALLO'}")

    if summary["rest"]["ok"]:
        print("2/5 Admisibilidad del símbolo (X2/X3) contra /exchangeInfo...")
        summary["admissibility"] = _admissibility(args.symbol)
        print("3/5 Smoke live (>=100 mensajes por socket, cadena pu)...")
        summary["live_smoke"] = _run_live_smoke(evidence, args.smoke_symbol)
        print(
            f"    -> {'OK' if summary['live_smoke']['ok'] else 'FALLO'}"
        )
        if not summary["live_smoke"]["ok"]:
            hint = (
                "Ejecute la validación SOLA: sin INICIAR.cmd ni otros "
                "programas pesados a la vez, y reintente. Cada socket ya "
                "reintenta una vez e imprime su telemetría."
            )
            summary["live_smoke"]["hint"] = hint
            print(f"    ({hint})")
        print("4/5 Captura de fixtures golden con procedencia...")
        # [2.3.4] Con el símbolo del smoke (BTCUSDT): un símbolo ilíquido
        # deja el socket de trades de futuros sin material (evidencia:
        # fixtures TUTUSDT del 2026-08-14 con 0 aggTrade en USDⓈ-M).
        summary["golden_fixtures"] = _run_capture_fixtures(
            evidence, args.smoke_symbol, args.messages
        )
        print(
            f"    -> {'OK' if summary['golden_fixtures']['ok'] else 'FALLO'}"
        )
    else:
        print("    Sin red a Binance: pasos 2-4 omitidos.")
        summary["admissibility"] = {"skipped": "sin red"}
        summary["live_smoke"] = {"ok": False, "skipped": "sin red"}
        summary["golden_fixtures"] = {"ok": False, "skipped": "sin red"}

    print("5/5 Evidencia W32Time + Test-TimeSyncAssets (solo Windows)...")
    summary["windows_clock"] = _windows_clock_evidence(evidence)

    (evidence / "RESUMEN_VALIDACION.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )
    network_ok = bool(
        summary["rest"]["ok"]
        and summary["live_smoke"].get("ok")
        and summary["golden_fixtures"].get("ok")
    )
    clock = summary["windows_clock"]
    clock_ok = clock.get("ok")
    print()
    print("================ RESUMEN ================")
    print(f"Red + smoke + golden : {'PASS' if network_ok else 'FALLO/OMITIDO'}")
    if clock_ok is None:
        print("Evidencia W32Time    : omitida (no es Windows)")
    else:
        print(f"Evidencia W32Time    : {'PASS' if clock_ok else 'REVISAR'}")
    print(f"Detalle              : {evidence / 'RESUMEN_VALIDACION.json'}")
    print("Siguiente paso       : INICIAR.cmd modo 3 en este mismo equipo.")
    return 0 if network_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
