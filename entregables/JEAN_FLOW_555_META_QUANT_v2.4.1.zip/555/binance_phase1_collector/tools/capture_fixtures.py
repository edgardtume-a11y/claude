"""Captura fixtures CRUDAS del socket real de Binance con procedencia (T2).

Uso (opt-in, requiere red):

    RUN_BINANCE_LIVE=1 python tools/capture_fixtures.py --messages 20 \
        --output tests/fixtures/golden

[2.3.4] Las URLs YA NO están codificadas aquí: se derivan de
``Settings.websocket_sources`` — la MISMA fuente de verdad que usa el motor —
capturando un archivo por socket causal. Evidencia de campo que obligó al
cambio: la validación real del 2026-08-14 archivó fixtures de USDⓈ-M desde el
endpoint legado sin ruta (retirado el 2026-04-23) y el archivo quedó SIN un
solo aggTrade (50/50 mensajes eran profundidad), porque el legado solo
entrega el nivel Public. Cada payload se valida además con
``decode_combined`` (cero ProtocolError) antes de archivarse: una fixture
golden que no decodifica no es golden.

Por cada socket archiva los primeros N mensajes SIN FILTRAR como JSONL,
junto a PROVENANCE.json con el endpoint exacto, el rol causal, el timestamp
UTC, el conteo y el SHA-256 del fichero. Objetivo: oráculo EXTERNO (O = 1)
por contrato del exchange (auditoría v2.2.2, T2/R3.1).
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import sys
import time
from pathlib import Path

TOOLS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = TOOLS_DIR.parent
for _candidate in (PROJECT_ROOT / "src", PROJECT_ROOT / ".runtime" / "packages"):
    if _candidate.is_dir() and str(_candidate) not in sys.path:
        sys.path.insert(0, str(_candidate))

_MARKETS = ("spot", "usdm_futures")
_SOCKET_TIMEOUT_S = 120.0


async def _capture_socket(
    market: str,
    source_role: str,
    url: str,
    symbol: str,
    count: int,
    output: Path,
) -> dict[str, object]:
    from websockets.asyncio.client import connect

    from binance_collector.config import Settings
    from binance_collector.models import RawEnvelope
    from binance_collector.protocol import decode_combined

    settings = Settings.for_market(market, symbol=symbol)
    output.mkdir(parents=True, exist_ok=True)
    destination = output / f"{market}.{source_role}.jsonl"
    started_utc = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    deadline = time.monotonic() + _SOCKET_TIMEOUT_S
    lines: list[bytes] = []
    error: str | None = None
    try:
        async with connect(
            url, compression=None, max_size=2 * 1024 * 1024, open_timeout=15
        ) as socket:
            while len(lines) < count:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                payload = await asyncio.wait_for(
                    socket.recv(decode=False), timeout=remaining
                )
                if isinstance(payload, str):
                    payload = payload.encode("utf-8")
                envelope = RawEnvelope(
                    connection_id="golden",
                    payload=payload,
                    receive_utc_ns=time.time_ns(),
                    receive_monotonic_ns=time.monotonic_ns(),
                    payload_bytes=len(payload),
                    raw_queue_size=0,
                    capture_session_id="golden-capture",
                    ingest_seq=len(lines) + 1,
                    source_socket_id=f"golden:{source_role}",
                )
                # Una fixture golden debe decodificar limpia con el MISMO
                # decoder del motor; ProtocolError aborta la captura.
                decode_combined(
                    envelope,
                    symbol=settings.symbol,
                    stream_names=settings.stream_names,
                    market=market,
                )
                lines.append(payload)
    except TimeoutError:
        pass
    except Exception as exc:  # noqa: BLE001 - queda en la procedencia
        error = f"{type(exc).__name__}: {exc}"
    if lines:
        destination.write_bytes(b"\n".join(lines) + b"\n")
    entry: dict[str, object] = {
        "market": market,
        "source_role": source_role,
        "endpoint": url,
        "symbol": symbol.upper(),
        "captured_utc": started_utc,
        "messages": len(lines),
        "requested": count,
        "complete": len(lines) >= count,
        "file": destination.name if lines else None,
        "sha256": (
            hashlib.sha256(destination.read_bytes()).hexdigest()
            if lines
            else None
        ),
        "command": " ".join(sys.argv),
    }
    if error is not None:
        entry["error"] = error
    return entry


async def _run(symbol: str, count: int, output: Path) -> int:
    from binance_collector.config import Settings

    provenance: list[dict[str, object]] = []
    for market in _MARKETS:
        settings = Settings.for_market(market, symbol=symbol)
        for source_role, url in settings.websocket_sources:
            print(
                f"Capturando {count} mensajes de {market}/{source_role}: {url}"
            )
            entry = await _capture_socket(
                market, source_role, url, symbol, count, output
            )
            print(
                f"  -> {entry['messages']}/{count} mensajes"
                + ("" if entry["complete"] else " (INCOMPLETO)")
                + (f" [{entry['error']}]" if "error" in entry else "")
            )
            provenance.append(entry)
    manifest = output / "PROVENANCE.json"
    manifest.write_text(
        json.dumps(provenance, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(f"Procedencia escrita en {manifest}")
    return 0 if all(entry["complete"] for entry in provenance) else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--symbol",
        default="BTCUSDT",
        help=(
            "Símbolo a capturar. BTCUSDT por defecto: un símbolo ilíquido "
            "deja el socket de trades sin material dentro del timeout."
        ),
    )
    parser.add_argument("--messages", type=int, default=20)
    parser.add_argument(
        "--output", type=Path, default=Path("tests/fixtures/golden")
    )
    args = parser.parse_args()
    if os.getenv("RUN_BINANCE_LIVE") != "1":
        print(
            "BLOQUEADO: exporte RUN_BINANCE_LIVE=1 para capturar del socket "
            "real (esta herramienta usa red por diseño)."
        )
        return 2
    return asyncio.run(_run(args.symbol, args.messages, args.output))


if __name__ == "__main__":
    raise SystemExit(main())
