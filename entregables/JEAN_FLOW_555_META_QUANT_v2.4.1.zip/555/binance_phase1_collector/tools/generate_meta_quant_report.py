from __future__ import annotations

import html
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RELEASE_ROOT = PROJECT_ROOT.parent
OUTPUT = RELEASE_ROOT / "INFORME_META_QUANT_v2.2.2.html"
SOURCES = (
    ("fixed_point.py", PROJECT_ROOT / "src/binance_collector/fixed_point.py"),
    ("order_book.py", PROJECT_ROOT / "src/binance_collector/order_book.py"),
    ("writer.py", PROJECT_ROOT / "src/binance_collector/writer.py"),
    ("jean_flow_launcher.py", RELEASE_ROOT / "jean_flow_launcher.py"),
    (
        "launcher.py (supervisor interno)",
        PROJECT_ROOT / "src/binance_collector/launcher.py",
    ),
    (
        "Test-W32Time.ps1",
        PROJECT_ROOT / "tools/windows/time-sync/Test-W32Time.ps1",
    ),
)


def _source_sections() -> str:
    sections: list[str] = []
    for index, (name, path) in enumerate(SOURCES, start=1):
        source = html.escape(path.read_text(encoding="utf-8"))
        sections.append(
            f'<section class="code-card"><div class="code-head">'
            f"<h3>{html.escape(name)}</h3>"
            f'<button data-copy="code-{index}">Copiar código</button></div>'
            f'<pre><code id="code-{index}">{source}</code></pre></section>'
        )
    return "\n".join(sections)


def build() -> str:
    document = f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>JEAN_FLOW 2.2.2 — Informe META-QUANT</title>
<style>
:root{{--bg:#05080d;--panel:#0b111a;--line:#18334a;--cyan:#42f5e9;--green:#85ff89;--amber:#ffc857;--red:#ff647c;--text:#d9e6f2;--muted:#8da2b6}}
*{{box-sizing:border-box}}body{{margin:0;background:radial-gradient(circle at 15% 0,#102034 0,var(--bg) 38%);color:var(--text);font:15px/1.58 ui-monospace,SFMono-Regular,Consolas,monospace}}
main{{max-width:1180px;margin:auto;padding:42px 22px 80px}}h1,h2,h3{{color:var(--cyan);letter-spacing:.02em}}h1{{font-size:clamp(28px,5vw,54px);margin:.2em 0}}h2{{margin-top:42px;border-bottom:1px solid var(--line);padding-bottom:8px}}a{{color:var(--cyan)}}code{{color:var(--green)}}.tag{{display:inline-block;border:1px solid var(--cyan);color:var(--cyan);padding:4px 9px;margin:2px;border-radius:999px}}.lead{{font-size:17px;color:#eef8ff;max-width:920px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}}.card,.code-card{{background:linear-gradient(145deg,#0d1621,#080d14);border:1px solid var(--line);border-radius:10px;padding:18px;box-shadow:0 12px 30px #0008}}.pass{{color:var(--green)}}.warn{{color:var(--amber)}}.reject{{color:var(--red)}}table{{border-collapse:collapse;width:100%;background:#080e16}}th,td{{border:1px solid var(--line);padding:10px;text-align:left;vertical-align:top}}th{{color:var(--cyan)}}.formula{{padding:14px;border-left:3px solid var(--green);background:#07120e;overflow:auto}}.code-card{{margin:18px 0;padding:0;overflow:hidden}}.code-head{{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;border-bottom:1px solid var(--line)}}.code-head h3{{margin:0;font-size:15px}}button{{background:#102a31;color:var(--cyan);border:1px solid var(--cyan);border-radius:6px;padding:7px 11px;cursor:pointer}}button:hover{{background:#16414a}}pre{{margin:0;padding:18px;max-height:720px;overflow:auto;tab-size:4}}pre code{{color:#c8e1f3;white-space:pre}}small,.muted{{color:var(--muted)}}
</style></head><body><main>
<span class="tag">META-QUANT</span><span class="tag">JEAN_FLOW 2.2.2</span><span class="tag">FAIL-CLOSED</span>
<h1>Refactor formal de baja latencia</h1>
<p class="lead">Resultado: se cerró una vulnerabilidad reproducible de cadena de suministro, se migró el estado L2 vivo a punto fijo exacto, se instrumentó el yield del writer y se corrigió un falso rechazo W32Time reproducido en Windows. Se rechazaron dos remedios que habrían empeorado el sistema: busy-spin y <code>timeBeginPeriod(1)</code>.</p>

<h2>Veredicto de las cuatro premisas</h2>
<div class="grid">
<article class="card"><h3>Timer Windows</h3><p class="warn">Premisa parcialmente obsoleta.</p><p>CPython 3.12 usa un waitable timer de alta resolución para <code>sleep(x&gt;0)</code> en Windows. El scheduler aún puede despertar tarde, pero no existe una cuantización inevitable de 15,6 ms. Se conserva el sleep que libera el GIL, se mide su duración real y se audita p99 ≤ 5 ms.</p></article>
<article class="card"><h3>TOCTOU / pip</h3><p class="pass">Fallo real reproducido y cerrado.</p><p><code>PIP_FIND_LINKS</code> ambiental podía aportar otro wheel y el entorno persistente no autenticaba sus bytes. Ahora requisito, wheel y manifest forman una biyección SHA-256; el bootstrap verifica <code>RECORD</code>, extrae sin pip y sella cada archivo antes de importar.</p></article>
<article class="card"><h3>Decimal / GC</h3><p class="warn">Causa corregida, diagnóstico matizado.</p><p><code>Decimal</code> cuesta memoria/asignación, pero en CPython 3.12 es atómico y no está rastreado por el GC cíclico. La migración a int elimina el cache por libro de hasta 400.000 precios y usa una LRU global de 8192 tokens; no cambia la complejidad de <code>SortedDict</code>.</p></article>
<article class="card"><h3>Locks</h3><p class="pass">Semántica unificada en Windows.</p><p>Un lock <code>msvcrt</code> se libera al morir el proceso aunque quede el nombre físico: el archivo residual no es un lock vivo. Aun así, el bootstrap usa ahora un mutex Win32 nombrado durante toda la captura, más el mutex independiente del supervisor.</p></article>
<article class="card"><h3>Gate W32Time</h3><p class="pass">Falso negativo reproducido y cerrado.</p><p>La versión 2.2.1 comparaba el equipo con <code>time.windows.com</code> aunque su fuente activa era otra. Ahora liga <code>Phase Offset</code> y <code>Source</code> al mismo status, exige ese peer activo y rechaza fuentes discrepantes. El inicio completo elevado se prohíbe; solo un offset auténtico mayor de 50 ms permite <code>System32\\w32tm.exe /resync</code> con UAC y sin cambios de configuración.</p></article>
</div>

<h2>Modelo formal y garantías</h2>
<div class="formula"><code>S = 10^8; encode(x) = x·S</code> solamente si <code>x·S ∈ ℤ ∩ [0, 2^63−1]</code>. Si no, <code>REJECT</code>; nunca <code>round</code>, <code>floor</code> ni <code>float</code>.</div>
<p>Para un evento con M niveles, la conversión es O(M). La mutación de niveles existentes conserva el acceso hash esperado O(1); altas y bajas ordenadas siguen O(log N). El evento completo permanece entre O(M) y O(M log N). El cambio reduce retención; la LRU amortiza el coste con tokens repetidos, pero un parser Python puede costar más CPU ante cantidades únicas. El burst de 511 niveles es por ello un gate explícito. <code>SortedDict</code> no se convierte mágicamente en O(1).</p>
<div class="formula"><code>ρ = λ / μ &lt; 1</code>. Para evitar crecimiento de cola, la tasa de servicio sostenida μ del writer debe superar la llegada λ. Con N=10.001 filas y chunk C=64: <code>K=floor((N−1)/C)=156</code> yields; su piso nominal a 0,5 ms es 78 ms. La evidencia útil es la distribución observada y el high-water, no la resolución nominal del reloj.</div>
<p>Las invariantes causales no cambian: Spot <code>U ≤ L+1 ≤ u</code>; Futures <code>pu = u anterior</code>. La clasificación stale ocurre antes del parseo numérico, el undo log conserva atomicidad y el CSV mantiene los strings exactos recibidos.</p>

<h2>Cadena de confianza</h2>
<table><thead><tr><th>Etapa</th><th>Control</th><th>Fallo cerrado</th></tr></thead><tbody>
<tr><td>Release</td><td>Manifest de todos los archivos + cinco versiones</td><td>Hash, archivo extra o colisión</td></tr>
<tr><td>Wheelhouse</td><td>20 pins exactos ↔ 20 wheels ↔ 20 SHA-256</td><td>Extra, ausente, duplicado o hash distinto</td></tr>
<tr><td>Extracción</td><td><code>RECORD</code> + rutas seguras + cero <code>.pth/.data</code></td><td>Sustitución, traversal o colisión</td></tr>
<tr><td>Runtime</td><td>Inventario completo sellado SHA-256 y revalidado</td><td>Archivo extra, ausente o alterado</td></tr>
<tr><td>Ejecución</td><td>Python global validado, <code>-I -S</code> y rutas explícitas</td><td>Python/.pth/user-site no autenticado</td></tr>
</tbody></table>

<h2>Evidencia offline</h2>
<table><thead><tr><th>Control</th><th>Resultado Linux / Python 3.12.13</th></tr></thead><tbody>
<tr><td>Suite</td><td class="pass">176 PASS + 1 smoke live omitido</td></tr>
<tr><td>book_apply p99</td><td class="pass">PASS — límite 5 ms</td></tr>
<tr><td>burst síncrono 511 niveles p99</td><td class="pass">PASS — límite 5 ms</td></tr>
<tr><td>pipeline p99</td><td class="pass">PASS — límite 5 ms</td></tr>
<tr><td>event-loop lag p99</td><td class="pass">PASS — límite 20 ms</td></tr>
<tr><td>writer yield p99</td><td class="pass">PASS — límite 5 ms</td></tr>
</tbody></table>
<p class="muted">Una ejecución sintética local no certifica Windows. Siguen pendientes la instalación limpia Windows 11/CPython 3.12 x64 con red bloqueada, PowerShell/UAC/NTP y los gates Binance 10/30/120 minutos. La integridad es interna y presupone una carpeta con ACL de escritura restringida; no sustituye una firma externa frente a un actor con la misma identidad del usuario. La escala 10^8 se impuso como se solicitó: cualquier símbolo que necesite más precisión será rechazado de forma explícita; no se afirma compatibilidad universal sin validar exchangeInfo.</p>

<h2>Fuentes primarias</h2>
<ul><li><a href="https://docs.python.org/3.12/library/time.html#time.sleep">Python 3.12 — time.sleep</a></li><li><a href="https://learn.microsoft.com/en-us/windows/win32/api/timeapi/nf-timeapi-timebeginperiod">Microsoft — timeBeginPeriod</a></li><li><a href="https://learn.microsoft.com/en-us/windows-server/networking/windows-time-service/windows-time-service-tools-and-settings">Microsoft — Windows Time Service</a></li><li><a href="https://developers.binance.com/en/docs/products/spot/filters">Binance — PRICE_FILTER y LOT_SIZE</a></li><li><a href="https://docs.python.org/3.12/library/gc.html">Python 3.12 — Garbage Collector</a></li></ul>

<h2>Código completo sustituible</h2>
{_source_sections()}
<p><small>Informe determinista generado desde el árbol controlado JEAN_FLOW 2.2.2.</small></p>
</main><script>
async function copyText(value){{if(navigator.clipboard&&window.isSecureContext){{await navigator.clipboard.writeText(value);return;}}const area=document.createElement('textarea');area.value=value;area.style.position='fixed';area.style.opacity='0';document.body.appendChild(area);area.select();document.execCommand('copy');area.remove();}}
document.querySelectorAll('button[data-copy]').forEach((button)=>{{button.addEventListener('click',async()=>{{const code=document.getElementById(button.dataset.copy).textContent;await copyText(code);const old=button.textContent;button.textContent='Copiado';setTimeout(()=>button.textContent=old,1200);}});}});
</script></body></html>"""
    return document


def main() -> None:
    OUTPUT.write_text(build(), encoding="utf-8", newline="\n")
    print(OUTPUT)


if __name__ == "__main__":
    main()
