# Control temporal de JEAN_FLOW 2.2.2

El usuario normal no ejecuta estos scripts. `555\INICIAR.cmd` delega en el
launcher Python, que realiza preflight y postflight automáticamente.

## Contrato

- Windows PowerShell 5.1, sin perfil.
- Un único disciplinador temporal activo.
- Fuente remota válida; se rechaza Local CMOS Clock.
- W32Time: `abs_phase_offset_ms <= 50`; Phase Offset y Source proceden del
  mismo `status /verbose`, ese peer está activo y, cuando `/query /source` es
  accesible, debe corroborarlo. Si Windows niega esa consulta, queda registrado
  el fallback ligado al mismo status.
- Meinberg: veinte observaciones y `p95_abs_offset_ms <= 50`.
- Perfil público con intervalo no inferior a 1.800 segundos.
- Perfil de 64 segundos solo para una fuente controlada y aprobada.
- Ningún `resync` durante captura.
- Python y el motor permanecen sin elevación.

`INICIAR.cmd` debe abrirse con doble clic normal. Un proceso ya elevado se
rechaza con `ELEVATED_PROCESS_FORBIDDEN`; no use «Ejecutar como administrador».

El launcher no eleva scripts de configuración. Si W32Time está detenido,
deshabilitado o no tiene arranque automático, falla cerrado y conserva el
diagnóstico; los scripts históricos de configuración/restauración son solo para
intervención manual de un administrador. Si un W32Time sano, único y no
administrado tiene un Phase Offset real mayor de 50 ms, se puede ofrecer una
única llamada elevada al `w32tm.exe` de System32 con el argumento fijo
`/resync`. Ese camino no modifica peers, registro, startup, firewall ni GPO. El
usuario confirma antes del UAC y el gate completo se repite después.

El postflight llama únicamente a `Test-ClockSync.ps1`; nunca repara ni ajusta el
reloj después de una captura para fabricar un PASS.

## Scripts internos

| Archivo | Función |
|---|---|
| `Test-TimeSyncAssets.ps1` | Parser e invariantes PowerShell 5.1 |
| `Test-ClockSync.ps1` | Selecciona y ejecuta el verificador del disciplinador activo |
| `Test-W32Time.ps1` | Servicio, fuente, peers, frescura y Phase Offset |
| `Test-MeinbergNtp.ps1` | Diagnóstico read-only de Meinberg |
| `Start-W32TimeRepair.ps1` | Herramienta manual heredada; el launcher no la invoca |
| `Configure-W32Time.ps1` | Configuración manual acotada y respaldada |
| `Restore-W32Time.ps1` | Restauración manual desde respaldo explícito |
| `Diagnose-ClockSync.ps1` | Evidencia de soporte ampliada |

No se instala Meinberg, no se abre UDP/123 entrante y no se desactivan gates de
tiempo para permitir una captura.
