#Requires -Version 5.1

[CmdletBinding()]
param(
    [ValidateSet('PublicInternet', 'ControlledHighAccuracy')]
    [string]$Profile = 'PublicInternet',
    [string[]]$Peers = @(),
    [switch]$ApprovedHighRateSource
)

$ErrorActionPreference = 'Stop'
$configure = Join-Path $PSScriptRoot 'Configure-W32Time.ps1'
$resultPath = Join-Path (
    [IO.Path]::GetTempPath()
) ("jean-flow-w32time-{0}.json" -f [Guid]::NewGuid().ToString('N'))

function ConvertTo-PowerShellLiteral {
    param([string]$Value)
    return "'" + $Value.Replace("'", "''") + "'"
}

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Path -LiteralPath $configure)) {
    [pscustomobject]@{
        pass = $false
        error_code = 'CONFIGURATOR_NOT_FOUND'
        message = "No se encontro $configure"
        exit_code = 2
    } | ConvertTo-Json
    exit 2
}

$parseFailures = @()
foreach ($scriptPath in Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1') {
    $parseTokens = $null
    $parseErrors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile(
        $scriptPath.FullName,
        [ref]$parseTokens,
        [ref]$parseErrors
    )
    foreach ($parseError in @($parseErrors)) {
        $parseFailures += '{0}: linea {1}: {2}' -f `
            $scriptPath.Name, `
            $parseError.Extent.StartLineNumber, `
            $parseError.Message
    }
}
if ($parseFailures.Count -gt 0) {
    [pscustomobject]@{
        pass = $false
        error_code = 'TIME_SYNC_ASSET_PARSE_ERROR'
        message = 'Los scripts NTP no son validos para este Windows PowerShell.'
        details = $parseFailures
        exit_code = 3
    } | ConvertTo-Json -Depth 4
    exit 3
}

if (Test-IsAdministrator) {
    $parameters = @{ Profile = $Profile }
    if ($Peers.Count -gt 0) { $parameters.Peers = $Peers }
    if ($ApprovedHighRateSource) { $parameters.ApprovedHighRateSource = $true }
    & $configure @parameters
    exit $LASTEXITCODE
}

$invocation = '& ' + (ConvertTo-PowerShellLiteral $configure)
$invocation += ' -Profile ' + (ConvertTo-PowerShellLiteral $Profile)
if ($Peers.Count -gt 0) {
    $peerLiterals = @($Peers | ForEach-Object { ConvertTo-PowerShellLiteral $_ })
    $invocation += ' -Peers @(' + ($peerLiterals -join ',') + ')'
}
if ($ApprovedHighRateSource) {
    $invocation += ' -ApprovedHighRateSource'
}
$invocation += ' *> ' + (ConvertTo-PowerShellLiteral $resultPath)
$encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($invocation))

try {
    $process = Start-Process `
        -FilePath (Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe') `
        -Verb RunAs `
        -WorkingDirectory $PSScriptRoot `
        -ArgumentList @(
            '-NoProfile',
            '-ExecutionPolicy', 'Bypass',
            '-EncodedCommand', $encoded
        ) `
        -Wait `
        -PassThru `
        -ErrorAction Stop
    if (Test-Path -LiteralPath $resultPath) {
        Get-Content -LiteralPath $resultPath -Raw
        Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue
    }
    else {
        [pscustomobject]@{
            pass = $false
            error_code = 'REPAIR_RESULT_MISSING'
            message = 'El proceso elevado no devolvio evidencia JSON.'
            child_exit_code = $process.ExitCode
            exit_code = $process.ExitCode
        } | ConvertTo-Json
    }
    exit $process.ExitCode
}
catch [System.ComponentModel.Win32Exception] {
    Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue
    $cancelled = ($_.Exception.NativeErrorCode -eq 1223)
    $errorCode = if ($cancelled) { 'UAC_CANCELLED' } else { 'UAC_FAILED' }
    $message = if ($cancelled) {
        'El usuario cancelo UAC; no se modifico W32Time.'
    }
    else {
        $_.Exception.Message
    }
    [pscustomobject]@{
        pass = $false
        error_code = $errorCode
        message = $message
        exit_code = 30
    } | ConvertTo-Json
    exit 30
}
catch {
    Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue
    [pscustomobject]@{
        pass = $false
        error_code = 'UAC_FAILED'
        message = $_.Exception.Message
        exit_code = 30
    } | ConvertTo-Json
    exit 30
}
