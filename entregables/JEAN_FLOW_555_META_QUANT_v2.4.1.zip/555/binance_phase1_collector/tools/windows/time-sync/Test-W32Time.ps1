#Requires -Version 5.1

[CmdletBinding()]
param(
    [ValidateRange(0.001, 10000)][double]$WarnMs = 50
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'TimeSync-Common.ps1')

try {
    $systemDirectory = [Environment]::SystemDirectory
    $w32tm = Join-Path $systemDirectory 'w32tm.exe'
    if (-not (Test-Path -LiteralPath $w32tm -PathType Leaf)) {
        throw "No existe el binario de sistema esperado: $w32tm"
    }

    $policy = Get-JeanFlowClockPolicyState
    $allServices = @(Get-CimInstance Win32_Service -ErrorAction Stop)
    $inventory = @(Get-JeanFlowTimeServiceInventory -Services $allServices)
    $w32 = @($inventory | Where-Object { $_.kind -eq 'W32Time' })
    $running = @($inventory | Where-Object { $_.running })

    if ($running.Count -gt 1) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'MULTIPLE_TIME_SERVICES' `
            -Message 'Hay mas de un disciplinador de reloj activo.' `
            -ExitCode 14 `
            -Details @{
                domain_joined = $policy.domain_joined
                policy_managed = $policy.policy_managed
                services = $inventory
            }
    }
    if ($w32.Count -eq 0) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'SERVICE_NOT_REGISTERED' `
            -Message 'W32Time no esta registrado. No se ejecutara unregister/register automaticamente.' `
            -ExitCode 10 `
            -Details @{
                domain_joined = $policy.domain_joined
                policy_managed = $policy.policy_managed
                services = $inventory
            }
    }

    $service = $w32[0]
    if (
        ($policy.domain_joined -or $policy.policy_managed) -and
        ($service.start_mode -ne 'Auto' -or -not $service.running)
    ) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'DOMAIN_POLICY' `
            -Message 'El estado o inicio de W32Time debe corregirse mediante la jerarquia de dominio/GPO.' `
            -ExitCode 13 `
            -Details @{
                service = $service
                domain_joined = $policy.domain_joined
                policy_managed = $policy.policy_managed
                services = $inventory
            }
    }
    if ($service.start_mode -eq 'Disabled') {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'SERVICE_DISABLED' `
            -Message 'W32Time esta deshabilitado.' `
            -ExitCode 11 `
            -Details @{
                service = $service
                domain_joined = $policy.domain_joined
                policy_managed = $policy.policy_managed
                services = $inventory
            }
    }
    if (-not $service.running) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'SERVICE_STOPPED' `
            -Message 'W32Time esta detenido; el reloj no esta siendo disciplinado.' `
            -ExitCode 12 `
            -Details @{
                service = $service
                domain_joined = $policy.domain_joined
                policy_managed = $policy.policy_managed
                services = $inventory
            }
    }
    if ($service.start_mode -ne 'Auto') {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'STARTUP_NOT_AUTOMATIC' `
            -Message 'W32Time esta activo, pero su inicio no es Automatic.' `
            -ExitCode 19 `
            -Details @{
                service = $service
                domain_joined = $policy.domain_joined
                policy_managed = $policy.policy_managed
                services = $inventory
            }
    }

    # [W5]: las consultas nativas van por la envoltura que impide que un
    # stderr de w32tm se convierta en error terminante bajo EA='Stop'.
    $sourceQuery = Invoke-JeanFlowNativeQuery -Binary $w32tm -Arguments @('/query', '/source')
    $sourceRaw = $sourceQuery.lines
    $sourceExit = $sourceQuery.exit_code
    $statusQuery = Invoke-JeanFlowNativeQuery -Binary $w32tm -Arguments @('/query', '/status', '/verbose')
    $status = $statusQuery.lines
    $statusExit = $statusQuery.exit_code
    $sourceResolution = Resolve-JeanFlowClockSource `
        -SourceLines $sourceRaw `
        -SourceExitCode $sourceExit `
        -StatusLines $status `
        -StatusExitCode $statusExit
    $source = [string]$sourceResolution.source
    $sourceOrigin = [string]$sourceResolution.evidence
    $peersQuery = Invoke-JeanFlowNativeQuery -Binary $w32tm -Arguments @('/query', '/peers')
    $peers = $peersQuery.lines
    $peersExit = $peersQuery.exit_code
    $parametersKey = 'HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters'
    # [W9]/R6.4: el éxito de la lectura del registro es un hecho propio del
    # payload. 'SilentlyContinue' fundía "clave inexistente" con "acceso
    # denegado" y dejaba source_matches_configured_peer en un True VACUO.
    $registryReadOk = $true
    $parameters = $null
    try {
        $parameters = Get-ItemProperty -LiteralPath $parametersKey -ErrorAction Stop
    }
    catch [System.Management.Automation.ItemNotFoundException] {
        $parameters = $null
    }
    catch {
        $parameters = $null
        $registryReadOk = $false
    }
    $configuredPeerList = if ($null -ne $parameters) {
        [string]$parameters.NtpServer
    }
    else {
        ''
    }
    $syncType = if ($null -ne $parameters) { [string]$parameters.Type } else { '' }
    $statusAccessDenied = Test-JeanFlowAccessDenied `
        -Lines $status `
        -ExitCode $statusExit
    $peersAccessDenied = Test-JeanFlowAccessDenied `
        -Lines $peers `
        -ExitCode $peersExit
    $statusFacts = Get-JeanFlowClockStatusFacts -StatusLines $status
    $phaseOffsetMs = $statusFacts.phase_offset_ms
    $phaseOffsetMsRaw = $statusFacts.phase_offset_ms_raw
    $leapIndicator = $statusFacts.leap_indicator
    $stratum = $statusFacts.stratum
    $lastSyncError = $statusFacts.last_sync_error
    $evidenceState = Get-JeanFlowW32EvidenceState `
        -SourceResolution $sourceResolution `
        -StatusFacts $statusFacts `
        -PeersLines $peers `
        -PeersExitCode $peersExit `
        -SyncType $syncType `
        -ConfiguredPeerList $configuredPeerList
    $hasActivePeer = $evidenceState.active_peer_confirmed
    $sourcePeerActive = $evidenceState.source_peer_active
    $sourceMatchesConfiguredPeer = $evidenceState.source_matches_configured_peer

    if (
        $statusExit -ne 0 -or
        -not $evidenceState.valid
    ) {
        $code = if ($policy.domain_joined -or $policy.policy_managed) {
            'DOMAIN_POLICY'
        }
        elseif (
            $statusAccessDenied -or
            $peersAccessDenied -or
            ($sourceResolution.query_access_denied -and -not $sourceResolution.valid)
        ) {
            'QUERY_ACCESS_DENIED'
        }
        elseif (
            $statusExit -eq 0 -and
            $statusFacts.required_facts_missing
        ) {
            # [W1]/R1.5: PARSE_FAIL != fallo del reloj. Si w32tm respondió
            # (exit 0) pero el parser no reconoce las etiquetas del idioma,
            # el sistema NO PUEDE distinguir "reloj mal" de "idioma no
            # soportado" y no debe afirmar lo primero.
            'STATUS_LOCALE_UNSUPPORTED'
        }
        else {
            'NO_VALID_SOURCE'
        }
        $exitCode = if ($code -eq 'DOMAIN_POLICY') {
            13
        }
        elseif ($code -eq 'QUERY_ACCESS_DENIED') {
            18
        }
        elseif ($code -eq 'STATUS_LOCALE_UNSUPPORTED') {
            21
        }
        else {
            15
        }
        $message = if ($code -eq 'QUERY_ACCESS_DENIED') {
            'Windows nego una consulta obligatoria y status /verbose no pudo aportar evidencia suficiente.'
        }
        elseif ($code -eq 'STATUS_LOCALE_UNSUPPORTED') {
            'El parser no reconoce las etiquetas de w32tm en el idioma de este Windows; NO es un fallo del reloj. El texto crudo va adjunto en status.'
        }
        else {
            'W32Time no tiene una fuente de hora valida y coherente con sus peers.'
        }
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode $code `
            -Message $message `
            -ExitCode $exitCode `
            -Details @{
                service = $service
                source = $source
                source_evidence = $sourceOrigin
                source_from_query = $sourceResolution.source_from_query
                source_from_status = $sourceResolution.source_from_status
                source_query_access_denied = $sourceResolution.query_access_denied
                source_query_exit_code = $sourceExit
                source_query_output = $sourceRaw
                status_query_access_denied = $statusAccessDenied
                peers_query_access_denied = $peersAccessDenied
                sync_type = $syncType
                registry_read_ok = $registryReadOk
                configured_peer_list = $configuredPeerList
                source_matches_configured_peer = $sourceMatchesConfiguredPeer
                active_peer_confirmed = $hasActivePeer
                source_peer_active = $sourcePeerActive
                evidence_state = $evidenceState
                phase_offset_ms = $phaseOffsetMs
                leap_indicator = $leapIndicator
                stratum = $stratum
                last_sync_error = $lastSyncError
                state_machine = $statusFacts.state_machine
                poll_seconds = $statusFacts.poll_seconds
                last_good_sync_age_seconds = $statusFacts.last_good_sync_age_seconds
                required_status_facts_missing = $statusFacts.required_facts_missing
                missing_status_facts = $statusFacts.missing_facts
                last_good_sync_too_old = $statusFacts.last_good_sync_too_old
                domain_joined = $policy.domain_joined
                policy_managed = $policy.policy_managed
                status = $status
                peers = $peers
                services = $inventory
            }
    }

    if ($null -eq $phaseOffsetMsRaw) {
        # [W11d]: [double]$null es 0 en PowerShell; un dato ausente se habría
        # convertido en un offset perfecto de 0 ms.
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'INTERNAL_ERROR' `
            -Message 'phase_offset_ms_raw ausente tras validar la evidencia.' `
            -ExitCode 99
    }

    # `Phase Offset` is W32Time's computed offset between the local clock and
    # the source that is actually disciplining it.  A stripchart against a
    # different public server measures a different path and can reject a
    # healthy clock because of source disagreement or network asymmetry.
    $absolutePhaseOffsetMs = [Math]::Abs([double]$phaseOffsetMsRaw)
    if (-not (Test-JeanFlowPhaseOffsetWithinLimit `
        -PhaseOffsetMs $phaseOffsetMsRaw `
        -WarnMs $WarnMs)) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'OFFSET_OUT_OF_RANGE' `
            -Message 'El Phase Offset de W32Time supera el umbral permitido.' `
            -ExitCode 17 `
            -Details @{
                service = $service
                source = $source
                source_evidence = $sourceOrigin
                source_from_query = $sourceResolution.source_from_query
                source_from_status = $sourceResolution.source_from_status
                source_query_access_denied = $sourceResolution.query_access_denied
                source_query_exit_code = $sourceExit
                offset_method = 'w32time_phase_offset'
                sync_type = $syncType
                registry_read_ok = $registryReadOk
                configured_peer_list = $configuredPeerList
                active_peer_confirmed = $hasActivePeer
                source_peer_active = $sourcePeerActive
                source_matches_configured_peer = $sourceMatchesConfiguredPeer
                offset_observations = 1
                abs_phase_offset_ms = $absolutePhaseOffsetMs
                warn_ms = $WarnMs
                domain_joined = $policy.domain_joined
                policy_managed = $policy.policy_managed
                status = $status
                peers = $peers
                services = $inventory
                phase_offset_ms = $phaseOffsetMs
                phase_offset_ms_raw = $phaseOffsetMsRaw
                leap_indicator = $leapIndicator
                stratum = $stratum
                last_sync_error = $lastSyncError
                state_machine = $statusFacts.state_machine
                poll_seconds = $statusFacts.poll_seconds
                last_good_sync_age_seconds = $statusFacts.last_good_sync_age_seconds
                note = 'Gate calculado contra la fuente activa mediante Phase Offset de W32Time.'
            }
    }

    Write-JeanFlowClockResult -Pass $true `
        -ErrorCode 'PASS' `
        -Message 'W32Time esta activo, tiene fuente valida y su Phase Offset cumple el umbral.' `
        -ExitCode 0 `
        -Details @{
            service = $service
            source = $source
            source_evidence = $sourceOrigin
            source_from_query = $sourceResolution.source_from_query
            source_from_status = $sourceResolution.source_from_status
            source_query_access_denied = $sourceResolution.query_access_denied
            source_query_exit_code = $sourceExit
            offset_method = 'w32time_phase_offset'
            sync_type = $syncType
            registry_read_ok = $registryReadOk
            configured_peer_list = $configuredPeerList
            active_peer_confirmed = $hasActivePeer
            source_peer_active = $sourcePeerActive
            source_matches_configured_peer = $sourceMatchesConfiguredPeer
            offset_observations = 1
            abs_phase_offset_ms = $absolutePhaseOffsetMs
            warn_ms = $WarnMs
            domain_joined = $policy.domain_joined
            policy_managed = $policy.policy_managed
            status = $status
            peers = $peers
            services = $inventory
            phase_offset_ms = $phaseOffsetMs
            phase_offset_ms_raw = $phaseOffsetMsRaw
            leap_indicator = $leapIndicator
            stratum = $stratum
            last_sync_error = $lastSyncError
            state_machine = $statusFacts.state_machine
            poll_seconds = $statusFacts.poll_seconds
            last_good_sync_age_seconds = $statusFacts.last_good_sync_age_seconds
            note = 'Gate calculado contra la fuente activa mediante Phase Offset de W32Time.'
        }
}
catch {
    Write-JeanFlowClockResult -Pass $false `
        -ErrorCode 'INTERNAL_ERROR' `
        -Message $_.Exception.Message `
        -ExitCode 99
}
