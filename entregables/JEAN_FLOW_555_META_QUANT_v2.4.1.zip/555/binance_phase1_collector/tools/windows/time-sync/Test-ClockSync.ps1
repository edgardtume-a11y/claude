#Requires -Version 5.1

[CmdletBinding()]
param(
    [ValidateRange(3, 200)][int]$Samples = 20,
    [ValidateRange(0.001, 10000)][double]$WarnMs = 50
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'TimeSync-Common.ps1')

try {
    $inventory = @(Get-JeanFlowTimeServiceInventory)
    $running = @($inventory | Where-Object { $_.running })
    $w32 = @($inventory | Where-Object { $_.kind -eq 'W32Time' })

    if ($running.Count -gt 1) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'MULTIPLE_TIME_SERVICES' `
            -Message 'Hay mas de un disciplinador de reloj activo.' `
            -ExitCode 14 `
            -Details @{ services = $inventory }
    }

    if ($running.Count -eq 1 -and $running[0].kind -eq 'MeinbergNtp') {
        & (Join-Path $PSScriptRoot 'Test-MeinbergNtp.ps1') `
            -Samples $Samples `
            -WarnMs $WarnMs
        exit $LASTEXITCODE
    }
    if (
        $running.Count -eq 1 -and
        $running[0].kind -ne 'W32Time'
    ) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'UNSUPPORTED_TIME_SERVICE' `
            -Message 'El disciplinador activo fue detectado, pero este paquete no puede validar su offset por CLI.' `
            -ExitCode 18 `
            -Details @{ services = $inventory }
    }

    if ($w32.Count -eq 0) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'SERVICE_NOT_REGISTERED' `
            -Message 'No se encontro W32Time ni un Meinberg ntpd activo.' `
            -ExitCode 10 `
            -Details @{ services = $inventory }
    }

    & (Join-Path $PSScriptRoot 'Test-W32Time.ps1') `
        -WarnMs $WarnMs
    exit $LASTEXITCODE
}
catch {
    Write-JeanFlowClockResult -Pass $false `
        -ErrorCode 'INTERNAL_ERROR' `
        -Message $_.Exception.Message `
        -ExitCode 99
}
