# Pruebas Windows para W32Time y el gate G0

## Pruebas read-only obligatorias

Abra PowerShell normal en la raiz del proyecto. No necesita administrador:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File `
  .\tools\windows\time-sync\Test-TimeSyncAssets.ps1
```

Aceptacion: `pass=true`, sintaxis valida en el parser integrado de Windows
PowerShell 5.1 y todas las invariantes estaticas aprobadas.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File `
  .\tools\windows\time-sync\Diagnose-ClockSync.ps1 | `
  Set-Content -LiteralPath .\diagnostico_reloj_windows.json -Encoding UTF8
```

Aceptacion en W32Time: un solo servicio activo, `state=Running`,
`start_mode=Auto`, fuente no local y peers consultables.

Abra `INICIAR.cmd` con doble clic normal, no como administrador. Un token ya
elevado debe fallar con `ELEVATED_PROCESS_FORBIDDEN` antes del runtime.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File `
  .\tools\windows\time-sync\Test-ClockSync.ps1 -Samples 20 -WarnMs 50
echo $LASTEXITCODE
```

Aceptacion W32Time: `error_code=PASS`,
`offset_method=w32time_phase_offset`, `abs_phase_offset_ms <= 50` y exit code
`0`. En Meinberg se exige `p95_abs_offset_ms <= 50` con 20 observaciones.

## Matriz de casos

| Estado preparado | Resultado obligatorio | Reparacion automatica |
| --- | --- | --- |
| W32Time detenido, PC personal | `SERVICE_STOPPED` | No automática; diagnóstico manual. |
| W32Time deshabilitado, PC personal | `SERVICE_DISABLED` | No automática; diagnóstico manual. |
| W32Time manual, aunque esté activo | `STARTUP_NOT_AUTOMATIC` | No automática; diagnóstico manual. |
| W32Time inexistente | `SERVICE_NOT_REGISTERED` | No; diagnostico manual. |
| Equipo unido a dominio o GPO con problema | `DOMAIN_POLICY` | No; PDC/GPO. |
| W32Time y ntpd activos | `MULTIPLE_TIME_SERVICES` | No; elegir uno. |
| `/query /source` denegado, pero `status /verbose` aporta `Source`/`Origen` válido | Continúa al Phase Offset y registra el fallback | No requiere elevar Python. |
| Consulta obligatoria denegada sin evidencia alternativa | `QUERY_ACCESS_DENIED` | No; revisar permisos/politica. |
| Fuente local o no valida | `NO_VALID_SOURCE` | No se omite el gate. |
| Meinberg sin todas sus observaciones | `NO_SAMPLES` | Revisar ntpq/peer. |
| W32Time Phase Offset mayor de 50 ms, PC personal no administrado | `OFFSET_OUT_OF_RANGE` | Puede ofrecer un único `/resync` con UAC; luego revalida. |
| W32Time Phase Offset mayor de 50 ms, dominio/GPO | `OFFSET_OUT_OF_RANGE` | No; administrar mediante PDC/GPO. |
| Fuente válida y métrica <= 50 ms | `PASS` | Continúa al preflight offline. |

## Casos mutantes solo en una VM de laboratorio

No ejecute estas pruebas durante smoke/soak ni en un equipo de dominio. Guarde
el diagnostico y la configuracion antes de cada caso. Para comprobar el caso
detenido en una VM independiente:

```powershell
Stop-Service W32Time -Force
powershell -NoProfile -ExecutionPolicy Bypass -File `
  .\tools\windows\time-sync\Test-ClockSync.ps1 -Samples 3 -WarnMs 50
```

Debe fallar inmediatamente con `SERVICE_STOPPED`, sin medir offset.
Restaure manualmente W32Time dentro de la VM con el procedimiento administrativo
respaldado y valide de nuevo; el launcher no cambia servicios. No simule
dominio, doble disciplinador o falta de registro en el host de captura.

## Evidencia que debe conservar

- `diagnostico_reloj_windows.json`;
- `clock_preflight.json`;
- `clock_offset_recovery.json`, si hubo un `/resync` por offset;
- `clock_recovery_rechecks.json` y `clock_preflight_after_repair.json`;
- salida de `w32tm /query /configuration`, `/status /verbose`, `/source` y
  `/peers`;
- eventos recientes de `Microsoft-Windows-Time-Service` si algo falla.

Una tanda corta no demuestra estabilidad sub-ms. Conserve series durante el
smoke, soak y al menos 24 horas para caracterizar deriva real.
