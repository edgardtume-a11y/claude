#Requires -Version 5.1
#Requires -RunAsAdministrator

[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'TimeSync-Common.ps1')

$stateDirectory = Join-Path $env:ProgramData 'JEAN_FLOW\time-sync'
$systemDirectory = [Environment]::SystemDirectory
$w32tm = Join-Path $systemDirectory 'w32tm.exe'
$reg = Join-Path $systemDirectory 'reg.exe'
$backupPath = Join-Path $stateDirectory 'w32time-before-jean-flow.reg'
$metadataPath = Join-Path $stateDirectory 'w32time-before-jean-flow.json'
$profilePath = Join-Path $stateDirectory 'active-profile.json'

try {
    if (-not (Test-Path -LiteralPath $backupPath)) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'BACKUP_NOT_FOUND' `
            -Message "No existe el respaldo esperado: $backupPath" `
            -ExitCode 23
    }

    $inventory = @(Get-JeanFlowTimeServiceInventory)
    $external = @($inventory | Where-Object { $_.kind -ne 'W32Time' })
    if ($external.Count -gt 0) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'EXTERNAL_TIME_SERVICE' `
            -Message 'Detenga o desinstale otros disciplinadores antes de restaurar W32Time.' `
            -ExitCode 14 `
            -Details @{ services = $inventory }
    }

    $metadata = $null
    if (Test-Path -LiteralPath $metadataPath) {
        $metadata = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json
    }

    Stop-Service -Name W32Time -Force -ErrorAction SilentlyContinue
    & $reg import $backupPath | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "reg.exe no pudo restaurar W32Time; codigo $LASTEXITCODE."
    }

    # SCM puede conservar en memoria el estado anterior. Se inicia de forma
    # temporal solo para que W32Time recargue la configuracion importada.
    Set-Service -Name W32Time -StartupType Manual
    Start-Service -Name W32Time -ErrorAction Stop
    & $w32tm /config /update | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "w32tm no pudo recargar el respaldo; codigo $LASTEXITCODE."
    }

    $originalState = ''
    $originalStartMode = ''
    if ($null -ne $metadata -and $null -ne $metadata.service) {
        $originalState = [string]$metadata.service.state
        $originalStartMode = [string]$metadata.service.start_mode
    }

    if ($originalState -ne 'Running') {
        Stop-Service -Name W32Time -Force -ErrorAction SilentlyContinue
    }
    switch ($originalStartMode) {
        'Auto' { Set-Service -Name W32Time -StartupType Automatic }
        'Disabled' { Set-Service -Name W32Time -StartupType Disabled }
        default { Set-Service -Name W32Time -StartupType Manual }
    }
    if ($originalState -eq 'Running') {
        Start-Service -Name W32Time -ErrorAction SilentlyContinue
    }

    $historyDirectory = Join-Path $stateDirectory (
        'history\restored-' + (Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss')
    )
    New-Item -ItemType Directory -Path $historyDirectory -Force | Out-Null
    foreach ($path in @($backupPath, $metadataPath, $profilePath)) {
        if (Test-Path -LiteralPath $path) {
            Move-Item -LiteralPath $path -Destination $historyDirectory -Force
        }
    }

    Write-JeanFlowClockResult -Pass $true `
        -ErrorCode 'PASS' `
        -Message 'Configuracion previa restaurada. Reinicie Windows para que SCM recargue completamente los triggers respaldados.' `
        -ExitCode 0 `
        -Details @{
            original_state = $originalState
            original_start_mode = $originalStartMode
            archived_backup = $historyDirectory
            reboot_required = $true
        }
}
catch {
    Write-JeanFlowClockResult -Pass $false `
        -ErrorCode 'RESTORE_FAILED' `
        -Message $_.Exception.Message `
        -ExitCode 99
}
