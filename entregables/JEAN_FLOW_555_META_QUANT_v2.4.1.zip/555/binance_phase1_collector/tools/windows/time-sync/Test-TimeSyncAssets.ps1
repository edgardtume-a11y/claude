#Requires -Version 5.1

[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$checks = 0

function Assert-Condition {
    param(
        [Parameter(Mandatory = $true)][bool]$Condition,
        [Parameter(Mandatory = $true)][AllowEmptyString()][string]$Message
    )
    if (-not $Condition) {
        throw $Message
    }
    $script:checks += 1
}

try {
    $parseFailures = @()
    foreach ($path in Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1') {
        $tokens = $null
        $errors = $null
        [void][System.Management.Automation.Language.Parser]::ParseFile(
            $path.FullName,
            [ref]$tokens,
            [ref]$errors
        )
        foreach ($parseError in @($errors)) {
            $parseFailures += "$($path.Name):$($parseError.Extent.StartLineNumber): $($parseError.Message)"
        }
    }
    $parseFailureMessage = if ($parseFailures.Count -gt 0) {
        $parseFailures -join ' | '
    }
    else {
        'Parser PowerShell 5.1: PASS.'
    }
    Assert-Condition `
        -Condition ($parseFailures.Count -eq 0) `
        -Message $parseFailureMessage

    . (Join-Path $PSScriptRoot 'TimeSync-Common.ps1')

    # Regression: Windows PowerShell 5.1 must bind an empty diagnostic message.
    Assert-Condition -Condition $true -Message ''

    $spanishStatusSource = Get-JeanFlowClockSourceFromStatus -StatusLines @(
        'Origen: 1.pool.ntp.org,0x8'
    )
    $englishStatusSource = Get-JeanFlowClockSourceFromStatus -StatusLines @(
        'Source: time.windows.com,0x8'
    )
    Assert-Condition `
        -Condition (
            $spanishStatusSource -eq '1.pool.ntp.org,0x8' -and
            $englishStatusSource -eq 'time.windows.com,0x8'
        ) `
        -Message 'No se pudo recuperar la fuente desde status /verbose.'

    $spanishFallback = Resolve-JeanFlowClockSource `
        -SourceLines @('Error: Acceso denegado. (0x80070005)') `
        -SourceExitCode 5 `
        -StatusLines @('Origen: 1.pool.ntp.org,0x8') `
        -StatusExitCode 0
    $englishFallback = Resolve-JeanFlowClockSource `
        -SourceLines @('Error: Access is denied. (0x80070005)') `
        -SourceExitCode 5 `
        -StatusLines @('Source: time.windows.com,0x8') `
        -StatusExitCode 0
    Assert-Condition `
        -Condition (
            $spanishFallback.valid -and
            $englishFallback.valid -and
            $spanishFallback.source -eq '1.pool.ntp.org,0x8' -and
            $englishFallback.source -eq 'time.windows.com,0x8' -and
            $spanishFallback.evidence -eq 'status_verbose_access_denied_fallback' -and
            $englishFallback.evidence -eq 'status_verbose_access_denied_fallback'
        ) `
        -Message 'El fallback de source por 0x80070005 fallo en espanol o ingles.'

    $sourceStatusMismatch = Resolve-JeanFlowClockSource `
        -SourceLines @('0.pool.ntp.org,0x8') `
        -SourceExitCode 0 `
        -StatusLines @('Origen: 1.pool.ntp.org,0x8') `
        -StatusExitCode 0
    Assert-Condition `
        -Condition (
            -not $sourceStatusMismatch.valid -and
            $sourceStatusMismatch.source -eq '1.pool.ntp.org,0x8' -and
            $sourceStatusMismatch.evidence -eq 'source_status_mismatch'
        ) `
        -Message 'Source y status discrepantes deben fallar de forma cerrada.'

    $corroboratedSource = Resolve-JeanFlowClockSource `
        -SourceLines @('1.pool.ntp.org,0x8') `
        -SourceExitCode 0 `
        -StatusLines @('Origen: 1.pool.ntp.org,0x8') `
        -StatusExitCode 0
    Assert-Condition `
        -Condition (
            $corroboratedSource.valid -and
            $corroboratedSource.source -eq '1.pool.ntp.org,0x8' -and
            $corroboratedSource.evidence -eq 'status_verbose_corroborated'
        ) `
        -Message 'Source y status coherentes no fueron vinculados.'

    $semanticInvalidQuery = Resolve-JeanFlowClockSource `
        -SourceLines @('Local CMOS Clock') `
        -SourceExitCode 0 `
        -StatusLines @('Source: time.windows.com,0x8') `
        -StatusExitCode 0
    $semanticInvalidFallback = Resolve-JeanFlowClockSource `
        -SourceLines @('Error: Acceso denegado. (0x80070005)') `
        -SourceExitCode 5 `
        -StatusLines @('Origen: Reloj CMOS local') `
        -StatusExitCode 0
    Assert-Condition `
        -Condition (
            -not $semanticInvalidQuery.valid -and
            -not $semanticInvalidFallback.valid
        ) `
        -Message 'CMOS/free-running nunca puede convertirse en una fuente valida.'

    $missingFallback = Resolve-JeanFlowClockSource `
        -SourceLines @('Error: Acceso denegado. (0x80070005)') `
        -SourceExitCode 5 `
        -StatusLines @('Capa: 4') `
        -StatusExitCode 0
    $unrelatedFailure = Resolve-JeanFlowClockSource `
        -SourceLines @('Error: El servicio no esta disponible.') `
        -SourceExitCode 1 `
        -StatusLines @('Origen: 1.pool.ntp.org,0x8') `
        -StatusExitCode 0
    Assert-Condition `
        -Condition (
            -not $missingFallback.valid -and
            -not $unrelatedFailure.valid -and
            -not $unrelatedFailure.query_access_denied
        ) `
        -Message 'El fallback solo puede activarse por acceso denegado y con Source/Origen presente.'

    $spanishStatusFacts = Get-JeanFlowClockStatusFacts -StatusLines @(
        'Indicador de salto: 0(ninguna advertencia)',
        'Capa: 4 (referencia secundaria)',
        'Ultimo error de sincronizacion: 0',
        'Equipo de estado: 1 (En espera)',
        'Intervalo de sondeo: 11 (2048s)',
        'Tiempo desde la ultima sincronizacion de hora correcta: 422.1093676s',
        'Desplazamiento de fase: 0.9365289s'
    )
    $englishStatusFacts = Get-JeanFlowClockStatusFacts -StatusLines @(
        'Leap Indicator: 3(not synchronized)',
        'Stratum: 0 (unspecified)',
        'Last Sync Error: 5',
        'State Machine: 3 (Spike)',
        'Poll Interval: 10 (1024s)',
        'Time since Last Good Sync Time: 10.0s',
        'Phase Offset: -0.1250000s'
    )
    Assert-Condition `
        -Condition (
            -not $spanishStatusFacts.semantically_invalid -and
            $spanishStatusFacts.phase_offset_ms -eq 936.529 -and
            $spanishStatusFacts.stratum -eq 4 -and
            $spanishStatusFacts.state_machine -eq 1 -and
            $spanishStatusFacts.last_good_sync_age_seconds -eq 422.1093676 -and
            $englishStatusFacts.semantically_invalid -and
            $englishStatusFacts.phase_offset_ms -eq -125
        ) `
        -Message 'No se pudieron validar los campos semanticos de status /verbose.'

    $observedWindows11Facts = Get-JeanFlowClockStatusFacts -StatusLines @(
        'Indicador de salto: 0(ninguna advertencia)',
        'Capa: 2 (referencia secundaria)',
        'Ultimo error de sincronizacion: 0',
        'Equipo de estado: 1 (En espera)',
        'Intervalo de sondeo: 11 (2048s)',
        'Tiempo desde la ultima sincronizacion de hora correcta: 291.1540443s',
        'Desplazamiento de fase: 0.0024259s'
    )
    Assert-Condition `
        -Condition (
            -not $observedWindows11Facts.semantically_invalid -and
            $observedWindows11Facts.phase_offset_ms -eq 2.426 -and
            $observedWindows11Facts.phase_offset_ms_raw -eq 2.4259
        ) `
        -Message 'El fixture Windows 11 ES del fallo real no conserva Phase Offset.'

    Assert-Condition `
        -Condition (
            (Test-JeanFlowPhaseOffsetWithinLimit -PhaseOffsetMs 50.0 -WarnMs 50) -and
            (Test-JeanFlowPhaseOffsetWithinLimit -PhaseOffsetMs -50.0 -WarnMs 50) -and
            -not (Test-JeanFlowPhaseOffsetWithinLimit -PhaseOffsetMs 50.000001 -WarnMs 50) -and
            -not (Test-JeanFlowPhaseOffsetWithinLimit -PhaseOffsetMs -50.000001 -WarnMs 50) -and
            -not (Test-JeanFlowPhaseOffsetWithinLimit -PhaseOffsetMs $null -WarnMs 50) -and
            -not (Test-JeanFlowPhaseOffsetWithinLimit -PhaseOffsetMs ([double]::NaN) -WarnMs 50)
        ) `
        -Message 'Los limites exactos del gate Phase Offset no son fail-closed.'

    $truncatedStatusFacts = Get-JeanFlowClockStatusFacts -StatusLines @(
        'Origen: time.windows.com,0x8',
        'Capa: 4'
    )
    Assert-Condition `
        -Condition (
            $truncatedStatusFacts.required_facts_missing -and
            $truncatedStatusFacts.semantically_invalid
        ) `
        -Message 'Un status incompleto debe fallar de forma cerrada.'

    $realLogEvidence = Get-JeanFlowW32EvidenceState `
        -SourceResolution $spanishFallback `
        -StatusFacts $spanishStatusFacts `
        -PeersLines @(
            'Sistema del mismo nivel: 1.pool.ntp.org,0x8',
            'Estado: Activo'
        ) `
        -PeersExitCode 0 `
        -SyncType 'NTP' `
        -ConfiguredPeerList '0.pool.ntp.org,0x8 1.pool.ntp.org,0x8 2.pool.ntp.org,0x8 3.pool.ntp.org,0x8'
    Assert-Condition `
        -Condition (
            $realLogEvidence.valid -and
            $realLogEvidence.active_peer_confirmed -and
            $realLogEvidence.source_peer_active -and
            $realLogEvidence.source_matches_configured_peer -and
            $spanishFallback.query_access_denied
        ) `
        -Message 'El fixture integral 0x80070005 + Origen + peer activo no avanzo al gate Phase Offset.'

    $similarPeerEvidence = Get-JeanFlowW32EvidenceState `
        -SourceResolution $spanishFallback `
        -StatusFacts $spanishStatusFacts `
        -PeersLines @(
            'Sistema del mismo nivel: 1.pool.ntp.org,0x8',
            'Estado: Pendiente',
            'Sistema del mismo nivel: 11.pool.ntp.org,0x8',
            'Estado: Activo'
        ) `
        -PeersExitCode 0 `
        -SyncType 'NTP' `
        -ConfiguredPeerList '1.pool.ntp.org,0x8 11.pool.ntp.org,0x8'
    Assert-Condition `
        -Condition (
            -not $similarPeerEvidence.valid -and
            -not $similarPeerEvidence.source_peer_active
        ) `
        -Message 'Un host parecido no puede suplir al peer exacto de la fuente.'

    $unsafeInterpolations = @()
    foreach ($path in Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1') {
        $source = Get-Content -LiteralPath $path.FullName -Raw
        foreach ($match in [regex]::Matches(
            $source,
            '\$(?!\{)[A-Za-z_][A-Za-z0-9_]*:(?![A-Za-z0-9_])'
        )) {
            $unsafeInterpolations += "$($path.Name):$($match.Value)"
        }
    }
    Assert-Condition `
        -Condition ($unsafeInterpolations.Count -eq 0) `
        -Message ('Variables sin delimitar antes de dos puntos: ' + ($unsafeInterpolations -join ', '))

    $configurePath = Join-Path $PSScriptRoot 'Configure-W32Time.ps1'
    $configure = Get-Content -LiteralPath $configurePath -Raw
    $resyncCount = [regex]::Matches(
        $configure,
        [regex]::Escape('/resync /rediscover')
    ).Count
    Assert-Condition `
        -Condition ($resyncCount -eq 1) `
        -Message 'Configure-W32Time debe contener exactamente un resync.'

    $backupIndex = $configure.IndexOf('& $reg export')
    $automaticIndex = $configure.IndexOf(
        'Set-Service -Name W32Time -StartupType Automatic'
    )
    $startIndex = $configure.IndexOf('Start-Service -Name W32Time')
    $configIndex = $configure.IndexOf(
        'Invoke-W32Time /config "/manualpeerlist:'
    )
    $resyncIndex = $configure.IndexOf('/resync /rediscover')
    Assert-Condition `
        -Condition (
            $backupIndex -ge 0 -and
            $backupIndex -lt $automaticIndex -and
            $automaticIndex -lt $startIndex -and
            $startIndex -lt $configIndex -and
            $configIndex -lt $resyncIndex
        ) `
        -Message 'Orden inseguro en la reparacion W32Time.'

    Assert-Condition `
        -Condition (
            $configure.Contains('{ 6 } else { 11 }') -and
            $configure.Contains('$pollSeconds -lt 1800') -and
            $configure.Contains('"$_,0x8"')
        ) `
        -Message 'Los perfiles de polling no cumplen 64 s controlado / >=1800 s publico.'

    Assert-Condition `
        -Condition (
            $configure.Contains('ApprovedHighRateSource') -and
            $configure.Contains('pool.ntp.org no puede usarse con el perfil de 64 segundos')
        ) `
        -Message 'Falta la proteccion del perfil de alta frecuencia.'

    $w32Test = Get-Content -LiteralPath (
        Join-Path $PSScriptRoot 'Test-W32Time.ps1'
    ) -Raw
    $requiredCodes = @(
        'SERVICE_STOPPED',
        'SERVICE_DISABLED',
        'NO_VALID_SOURCE',
        'QUERY_ACCESS_DENIED',
        'OFFSET_OUT_OF_RANGE',
        'DOMAIN_POLICY',
        'MULTIPLE_TIME_SERVICES'
    )
    $missingCodes = @($requiredCodes | Where-Object { -not $w32Test.Contains($_) })
    Assert-Condition `
        -Condition ($missingCodes.Count -eq 0) `
        -Message "Faltan codigos de diagnostico: $($missingCodes -join ', ')"

    $mutatingScripts = @(
        'Configure-W32Time.ps1',
        'Restore-W32Time.ps1',
        'Start-W32TimeRepair.ps1'
    )
    $mutatingText = ($mutatingScripts | ForEach-Object {
        Get-Content -LiteralPath (Join-Path $PSScriptRoot $_) -Raw
    }) -join [Environment]::NewLine
    Assert-Condition `
        -Condition (
            $mutatingText -notmatch '(?i)w32tm(?:\.exe)?\s+/(?:unregister|register)' -and
            $mutatingText -notmatch '(?i)New-NetFirewallRule|netsh\s+advfirewall'
        ) `
        -Message 'La reparacion no puede registrar a ciegas ni abrir firewall entrante.'

    $projectRoot = Split-Path -Parent (
        Split-Path -Parent (
            Split-Path -Parent $PSScriptRoot
        )
    )
    $launcherPath = Join-Path (
        Split-Path -Parent $projectRoot
    ) 'INICIAR.cmd'
    $launcher = Get-Content -LiteralPath $launcherPath -Raw
    Assert-Condition `
        -Condition (
            $launcher.Contains('jean_flow_launcher.py') -and
            $launcher.Contains('-I -S -B -u') -and
            -not $launcher.Contains('powershell') -and
            -not $launcher.Contains('runas')
        ) `
        -Message 'INICIAR.cmd debe delegar de forma aislada sin elevar el motor.'

    $w32Verifier = Get-Content -LiteralPath (
        Join-Path $PSScriptRoot 'Test-W32Time.ps1'
    ) -Raw
    Assert-Condition `
        -Condition (
            $w32Verifier.Contains('w32time_phase_offset') -and
            $w32Verifier.Contains('abs_phase_offset_ms') -and
            $w32Verifier.Contains('Test-JeanFlowPhaseOffsetWithinLimit') -and
            -not $w32Verifier.Contains('/stripchart')
        ) `
        -Message 'W32Time debe validarse contra su fuente activa, no contra un tercero.'

    [pscustomobject]@{
        pass = $true
        error_code = 'PASS'
        checks = $checks
        powershell = $PSVersionTable.PSVersion.ToString()
        note = 'Prueba read-only: analiza sintaxis e invariantes; no inicia ni configura servicios.'
    } | ConvertTo-Json
    exit 0
}
catch {
    [pscustomobject]@{
        pass = $false
        error_code = 'STATIC_TEST_FAILED'
        checks_completed = $checks
        message = $_.Exception.Message
    } | ConvertTo-Json
    exit 1
}
