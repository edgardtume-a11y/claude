#Requires -Version 5.1
#Requires -RunAsAdministrator

[CmdletBinding()]
param(
    [ValidateSet('PublicInternet', 'ControlledHighAccuracy')]
    [string]$Profile = 'PublicInternet',
    [string[]]$Peers = @(),
    [switch]$ApprovedHighRateSource,
    [ValidateRange(0.001, 10000)][double]$WarnMs = 50
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'TimeSync-Common.ps1')

$systemDirectory = [Environment]::SystemDirectory
$w32tm = Join-Path $systemDirectory 'w32tm.exe'
$reg = Join-Path $systemDirectory 'reg.exe'
$sc = Join-Path $systemDirectory 'sc.exe'
# P1.7a: bajo pwsh 7, $PSHOME no contiene powershell.exe; se resuelve SIEMPRE el Windows PowerShell del sistema.
$powerShell = Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe'
$stateDirectory = Join-Path $env:ProgramData 'JEAN_FLOW\time-sync'
$backupPath = Join-Path $stateDirectory 'w32time-before-jean-flow.reg'
$metadataPath = Join-Path $stateDirectory 'w32time-before-jean-flow.json'
$profilePath = Join-Path $stateDirectory 'active-profile.json'

foreach ($binary in @($w32tm, $reg, $sc)) {
    if (-not (Test-Path -LiteralPath $binary -PathType Leaf)) {
        throw "No existe el binario de sistema esperado: $binary"
    }
}

function Invoke-W32Time {
    param([Parameter(ValueFromRemainingArguments = $true)][string[]]$Arguments)
    $output = @(& $w32tm @Arguments 2>&1)
    if ($LASTEXITCODE -ne 0) {
        throw "w32tm fallo con codigo ${LASTEXITCODE}: $($Arguments -join ' '): $($output -join ' | ')"
    }
    return $output
}

function Wait-ForW32TimeRunning {
    param([ValidateRange(1, 120)][int]$TimeoutSeconds = 20)
    $controller = Get-Service -Name W32Time -ErrorAction Stop
    if ($controller.Status -ne 'Running') {
        $controller.WaitForStatus(
            [System.ServiceProcess.ServiceControllerStatus]::Running,
            [TimeSpan]::FromSeconds($TimeoutSeconds)
        )
        $controller.Refresh()
    }
    if ($controller.Status -ne 'Running') {
        throw 'W32Time no alcanzo el estado Running.'
    }
}

function Stop-Configuration {
    param(
        [string]$ErrorCode,
        [string]$Message,
        [int]$ExitCode,
        [hashtable]$Details = @{}
    )
    Write-JeanFlowClockResult -Pass $false `
        -ErrorCode $ErrorCode `
        -Message $Message `
        -ExitCode $ExitCode `
        -Details $Details
}

try {
    $policy = Get-JeanFlowClockPolicyState
    $allServices = @(Get-CimInstance Win32_Service -ErrorAction Stop)
    $inventory = @(Get-JeanFlowTimeServiceInventory -Services $allServices)
    $w32 = @($inventory | Where-Object { $_.kind -eq 'W32Time' })
    $external = @($inventory | Where-Object { $_.kind -ne 'W32Time' })

    if ($policy.domain_joined -or $policy.policy_managed) {
        Stop-Configuration `
            -ErrorCode 'DOMAIN_POLICY' `
            -Message 'Equipo unido a dominio o administrado por GPO: conserve NT5DS y configure PDC/GPO con su administrador.' `
            -ExitCode 13 `
            -Details @{
                domain_joined = $policy.domain_joined
                domain = $policy.domain
                policy_managed = $policy.policy_managed
            }
    }
    if ($w32.Count -eq 0) {
        Stop-Configuration `
            -ErrorCode 'SERVICE_NOT_REGISTERED' `
            -Message 'W32Time no esta registrado. Ejecute el diagnostico; esta reparacion no usa unregister/register automaticamente.' `
            -ExitCode 10
    }
    if ($external.Count -gt 0) {
        Stop-Configuration `
            -ErrorCode 'EXTERNAL_TIME_SERVICE' `
            -Message 'Se detecto otro cliente de hora instalado. Elija un solo disciplinador antes de configurar W32Time.' `
            -ExitCode 14 `
            -Details @{ services = $inventory }
    }

    if (Test-Path -LiteralPath $profilePath) {
        $activeProfile = Get-Content -LiteralPath $profilePath -Raw | ConvertFrom-Json
        if ($activeProfile.profile -ne $Profile) {
            Stop-Configuration `
                -ErrorCode 'PROFILE_CONFLICT' `
                -Message "Ya esta activo el perfil '$($activeProfile.profile)'. Restaure antes de cambiar de perfil." `
                -ExitCode 21
        }
    }

    if ($Peers.Count -eq 0) {
        if ($Profile -eq 'PublicInternet') {
            $Peers = @(
                '0.pool.ntp.org',
                '1.pool.ntp.org',
                '2.pool.ntp.org',
                '3.pool.ntp.org'
            )
        }
        else {
            Stop-Configuration `
                -ErrorCode 'PEERS_REQUIRED' `
                -Message 'ControlledHighAccuracy exige al menos tres servidores locales, propios o contratados.' `
                -ExitCode 22
        }
    }

    $Peers = @(
        $Peers |
            ForEach-Object { $_.Trim().ToLowerInvariant() } |
            Where-Object { $_ } |
            Sort-Object -Unique
    )
    if (@($Peers | Where-Object { $_ -notmatch '^[a-z0-9.-]+$' }).Count -gt 0) {
        Stop-Configuration `
            -ErrorCode 'INVALID_PEER' `
            -Message 'Peer NTP invalido. Use hostname o IPv4 sin comas, espacios ni flags.' `
            -ExitCode 22
    }

    $isPoolPeer = @(
        $Peers | Where-Object { $_ -match '(^|\.)pool\.ntp\.org$' }
    ).Count -gt 0
    if ($Profile -eq 'ControlledHighAccuracy') {
        if ($Peers.Count -lt 3) {
            Stop-Configuration `
                -ErrorCode 'PEERS_REQUIRED' `
                -Message 'ControlledHighAccuracy exige tres o mas fuentes independientes.' `
                -ExitCode 22
        }
        if (-not $ApprovedHighRateSource) {
            Stop-Configuration `
                -ErrorCode 'HIGH_RATE_NOT_APPROVED' `
                -Message 'Confirme -ApprovedHighRateSource solo para servidores que autoricen polling de 64 segundos.' `
                -ExitCode 22
        }
        if ($isPoolPeer) {
            Stop-Configuration `
                -ErrorCode 'PUBLIC_POOL_RATE_LIMIT' `
                -Message 'pool.ntp.org no puede usarse con el perfil de 64 segundos.' `
                -ExitCode 22
        }
    }

    $pollExponent = if ($Profile -eq 'ControlledHighAccuracy') { 6 } else { 11 }
    $pollSeconds = [int][Math]::Pow(2, $pollExponent)
    if ($Profile -eq 'PublicInternet' -and $pollSeconds -lt 1800) {
        throw 'Invariante rota: PublicInternet debe consultar cada 1800 segundos o mas.'
    }
    $peerList = ($Peers | ForEach-Object { "$_,0x8" }) -join ' '

    New-Item -ItemType Directory -Path $stateDirectory -Force | Out-Null
    if (-not (Test-Path -LiteralPath $backupPath)) {
        & $reg export 'HKLM\SYSTEM\CurrentControlSet\Services\W32Time' $backupPath /y | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw "No se pudo respaldar W32Time. reg.exe termino con $LASTEXITCODE."
        }
    }
    if (-not (Test-Path -LiteralPath $metadataPath)) {
        $serviceConfig = @(& $sc qc W32Time 2>&1)
        $triggerConfig = @(& $sc qtriggerinfo W32Time 2>&1)
        $runtimeConfig = @(& $w32tm /query /configuration 2>&1)
        [pscustomobject]@{
            captured_utc = (Get-Date).ToUniversalTime().ToString('o')
            service = $w32[0]
            sc_qc = $serviceConfig
            sc_qtriggerinfo = $triggerConfig
            w32tm_configuration = $runtimeConfig
        } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $metadataPath -Encoding UTF8
    }

    Set-Service -Name W32Time -StartupType Automatic
    $triggerOutput = @(
        & $sc triggerinfo W32Time start/networkon stop/networkoff 2>&1
    )
    if ($LASTEXITCODE -ne 0) {
        throw "No se pudo configurar el trigger de red de W32Time: $($triggerOutput -join ' | ')"
    }
    $controller = Get-Service -Name W32Time -ErrorAction Stop
    if ($controller.Status -ne 'Running') {
        Start-Service -Name W32Time -ErrorAction Stop
    }
    Wait-ForW32TimeRunning -TimeoutSeconds 20

    $initialConfiguration = @(
        Invoke-W32Time /config "/manualpeerlist:$peerList" /syncfromflags:manual /update
    )

    $clientKey = 'HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpClient'
    $configKey = 'HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config'
    New-ItemProperty -Path $clientKey -Name Enabled -PropertyType DWord -Value 1 -Force | Out-Null
    New-ItemProperty -Path $configKey -Name MinPollInterval -PropertyType DWord -Value $pollExponent -Force | Out-Null
    New-ItemProperty -Path $configKey -Name MaxPollInterval -PropertyType DWord -Value $pollExponent -Force | Out-Null

    if ($Profile -eq 'ControlledHighAccuracy') {
        foreach ($item in (@{
            UpdateInterval = 100
            FrequencyCorrectRate = 2
        }).GetEnumerator()) {
            New-ItemProperty -Path $configKey -Name $item.Key -PropertyType DWord -Value $item.Value -Force | Out-Null
        }
    }

    $configurationUpdate = @(Invoke-W32Time /config /update)
    Restart-Service -Name W32Time -Force -ErrorAction Stop
    Wait-ForW32TimeRunning -TimeoutSeconds 20

    $resync = @(& $w32tm /resync /rediscover 2>&1)
    $resyncExit = $LASTEXITCODE

    $source = ''
    $sourceEvidence = 'unresolved'
    $status = @()
    $peersStatus = @()
    $deadline = (Get-Date).AddSeconds(90)
    do {
        Start-Sleep -Seconds 5
        $sourceRaw = @(& $w32tm /query /source 2>&1)
        $sourceExit = $LASTEXITCODE
        $status = @(& $w32tm /query /status /verbose 2>&1)
        $statusExit = $LASTEXITCODE
        $sourceResolution = Resolve-JeanFlowClockSource `
            -SourceLines $sourceRaw `
            -SourceExitCode $sourceExit `
            -StatusLines $status `
            -StatusExitCode $statusExit
        $source = [string]$sourceResolution.source
        $sourceEvidence = [string]$sourceResolution.evidence
        $statusFacts = Get-JeanFlowClockStatusFacts -StatusLines $status
        $peersStatus = @(& $w32tm /query /peers 2>&1)
        $peersExit = $LASTEXITCODE
        $evidenceState = Get-JeanFlowW32EvidenceState `
            -SourceResolution $sourceResolution `
            -StatusFacts $statusFacts `
            -PeersLines $peersStatus `
            -PeersExitCode $peersExit `
            -SyncType 'NTP' `
            -ConfiguredPeerList $peerList
        $hasActivePeer = $evidenceState.active_peer_confirmed
        $converged = (
            $statusExit -eq 0 -and
            $evidenceState.valid
        )
    } while (-not $converged -and (Get-Date) -lt $deadline)

    if (-not $converged) {
        Stop-Configuration `
            -ErrorCode 'CONVERGENCE_TIMEOUT' `
            -Message 'W32Time arranco, pero no adquirio una fuente valida dentro de 90 segundos.' `
            -ExitCode 20 `
            -Details @{
                source = $source
                source_evidence = $sourceEvidence
                source_query_exit_code = $sourceExit
                source_query_output = $sourceRaw
                status_facts = $statusFacts
                active_peer_confirmed = $hasActivePeer
                evidence_state = $evidenceState
                status = $status
                peers = $peersStatus
                resync_exit_code = $resyncExit
                resync = $resync
            }
    }

    $validationScript = Join-Path $PSScriptRoot 'Test-W32Time.ps1'
    $validationDeadline = (Get-Date).AddSeconds(120)
    $validation = @()
    $validationExit = 99
    $validationAttempt = 0
    $validationErrorCode = ''
    do {
        $validationAttempt += 1
        $validation = @(
            & $powerShell -NoProfile -ExecutionPolicy Bypass -File $validationScript `
                -WarnMs $WarnMs 2>&1
        )
        $validationExit = $LASTEXITCODE
        if ($validationExit -eq 0) {
            break
        }
        $validationErrorCode = ''
        try {
            $validationResult = ($validation -join [Environment]::NewLine) |
                ConvertFrom-Json -ErrorAction Stop
            $validationErrorCode = [string]$validationResult.error_code
        }
        catch {
            $validationErrorCode = 'UNPARSEABLE_VALIDATION'
        }
        $retryable = @(
            'OFFSET_OUT_OF_RANGE',
            'NO_VALID_SOURCE'
        ) -contains $validationErrorCode
        if ($retryable -and (Get-Date) -lt $validationDeadline) {
            Start-Sleep -Seconds 15
        }
    } while ($retryable -and (Get-Date) -lt $validationDeadline)

    if ($validationExit -ne 0) {
        Stop-Configuration `
            -ErrorCode 'CONVERGENCE_VALIDATION_FAILED' `
            -Message 'W32Time tiene fuente, pero la validacion final no cumplio el gate.' `
            -ExitCode 20 `
            -Details @{
                validation_exit_code = $validationExit
                validation_error_code = $validationErrorCode
                validation_attempts = $validationAttempt
                validation = $validation
                resync_exit_code = $resyncExit
                resync = $resync
            }
    }

    [pscustomobject]@{
        profile = $Profile
        peers = $Peers
        peer_flag = '0x8'
        poll_exponent = $pollExponent
        poll_seconds = $pollSeconds
        validation_method = 'w32time_phase_offset'
        configured_utc = (Get-Date).ToUniversalTime().ToString('o')
    } | ConvertTo-Json | Set-Content -LiteralPath $profilePath -Encoding UTF8

    Write-JeanFlowClockResult -Pass $true `
        -ErrorCode 'PASS' `
        -Message 'W32Time fue configurado, iniciado, sincronizado y validado.' `
        -ExitCode 0 `
        -Details @{
            profile = $Profile
            peers = $Peers
            peer_flag = '0x8'
            poll_seconds = $pollSeconds
            source = $source
            startup_mode = 'Automatic'
            service = 'Running'
            resync_exit_code = $resyncExit
            resync = $resync
            validation_attempts = $validationAttempt
            validation = $validation
            note = 'Se ejecuto un solo resync durante la configuracion. No se programa ninguno durante captura.'
        }
}
catch {
    Write-JeanFlowClockResult -Pass $false `
        -ErrorCode 'CONFIGURATION_FAILED' `
        -Message $_.Exception.Message `
        -ExitCode 99
}
