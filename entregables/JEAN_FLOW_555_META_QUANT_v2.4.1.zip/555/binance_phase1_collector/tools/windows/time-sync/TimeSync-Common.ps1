#Requires -Version 5.1

function Invoke-JeanFlowNativeQuery {
    <#
    [W5]: con $ErrorActionPreference='Stop', `cmd 2>&1` convierte cada línea
    de stderr de un comando nativo en un ErrorRecord TERMINANTE en PS 5.1: el
    primer stderr de w32tm saltaba al catch global como INTERNAL_ERROR (99) y
    el camino QUERY_ACCESS_DENIED (18) era código muerto. Esta envoltura baja
    la preferencia a Continue solo durante la invocación y devuelve las
    líneas como texto plano junto con el exit code real.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Binary,
        [string[]]$Arguments = @()
    )

    $previousPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $lines = @(& $Binary @Arguments 2>&1 | ForEach-Object { "$_" })
        return [pscustomobject]@{
            lines = $lines
            exit_code = $LASTEXITCODE
        }
    }
    finally {
        $ErrorActionPreference = $previousPreference
    }
}

function Get-JeanFlowTimeServiceInventory {
    [CmdletBinding()]
    param([object[]]$Services = @())

    if ($Services.Count -eq 0) {
        $Services = @(Get-CimInstance Win32_Service -ErrorAction Stop)
    }

    $inventory = @()
    foreach ($service in $Services) {
        $kind = $null
        if ($service.Name -eq 'W32Time') {
            $kind = 'W32Time'
        }
        elseif (
            $service.PathName -match '(?i)(^|[\\/])ntpd\.exe(?:"|\s|$)' -or
            $service.Name -match '(?i)^ntpd$'
        ) {
            $kind = 'MeinbergNtp'
        }
        elseif (
            $service.PathName -match '(?i)(^|[\\/])nettime(?:service|svc)?\.exe(?:"|\s|$)' -or
            $service.Name -match '(?i)^nettime' -or
            $service.DisplayName -match '(?i)^nettime'
        ) {
            $kind = 'NetTime'
        }
        elseif (
            $service.PathName -match '(?i)(^|[\\/])(chronyd|ptpd|ptp4l|domtimec|ntptime|timesyncservice)\.exe(?:"|\s|$)' -or
            $service.Name -match '(?i)^(chronyd|ptpd|ptp4l|domtime|ntptime|timesyncservice)$'
        ) {
            $kind = 'ExternalTimeService'
        }

        if ($null -ne $kind) {
            $inventory += [pscustomobject]@{
                kind = $kind
                name = [string]$service.Name
                display_name = [string]$service.DisplayName
                state = [string]$service.State
                start_mode = [string]$service.StartMode
                path = [string]$service.PathName
                running = ([string]$service.State -eq 'Running')
            }
        }
    }
    return $inventory
}

function Get-JeanFlowClockPolicyState {
    [CmdletBinding()]
    param()

    $computer = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
    $policyRoot = 'HKLM:\SOFTWARE\Policies\Microsoft\W32Time'
    $policyManaged = $false
    if (Test-Path -LiteralPath $policyRoot) {
        $policyItems = @(
            Get-ChildItem -LiteralPath $policyRoot -Recurse -ErrorAction SilentlyContinue
        )
        $rootValues = @(
            (Get-ItemProperty -LiteralPath $policyRoot -ErrorAction SilentlyContinue).PSObject.Properties |
                Where-Object { $_.Name -notmatch '^PS' }
        )
        $policyManaged = ($policyItems.Count -gt 0 -or $rootValues.Count -gt 0)
    }
    return [pscustomobject]@{
        domain_joined = [bool]$computer.PartOfDomain
        domain = [string]$computer.Domain
        policy_managed = $policyManaged
    }
}

function Test-JeanFlowInvalidClockSource {
    [CmdletBinding()]
    param([AllowEmptyString()][string]$Source)

    if ([string]::IsNullOrWhiteSpace($Source)) {
        return $true
    }
    return $Source -match '(?i)local\s+cmos|cmos\s+local|reloj\s+cmos|free[ -]?running|unspecified|no\s+especificad|unknown|desconocid'
}

function Get-JeanFlowClockSourceFromStatus {
    [CmdletBinding()]
    param([object[]]$StatusLines = @())

    foreach ($line in $StatusLines) {
        $text = [string]$line
        if (
            $text -match '^\s*(?:Source|Origen|Origem|Origine|Quelle|Bron)\s*:\s*(?<value>.+?)\s*$'
        ) {
            return ([string]$Matches.value).Trim()
        }
    }
    return ''
}

function Test-JeanFlowAccessDenied {
    [CmdletBinding()]
    param(
        [object[]]$Lines = @(),
        [int]$ExitCode = 0
    )

    if ($ExitCode -eq 0) {
        return $false
    }
    $text = $Lines -join [Environment]::NewLine
    return $text -match '(?i)0x80070005|access\s+is\s+denied|acceso\s+denegado'
}

function Resolve-JeanFlowClockSource {
    [CmdletBinding()]
    param(
        [object[]]$SourceLines = @(),
        [int]$SourceExitCode = 0,
        [object[]]$StatusLines = @(),
        [int]$StatusExitCode = 0
    )

    $sourceFromQuery = ''
    foreach ($line in $SourceLines) {
        $candidate = "$line".Trim()
        if (-not [string]::IsNullOrWhiteSpace($candidate)) {
            $sourceFromQuery = $candidate
            break
        }
    }
    $sourceFromStatus = Get-JeanFlowClockSourceFromStatus -StatusLines $StatusLines
    $sourceQueryText = $SourceLines -join [Environment]::NewLine
    $queryAccessDenied = Test-JeanFlowAccessDenied `
        -Lines $SourceLines `
        -ExitCode $SourceExitCode
    $queryIsValid = (
        $SourceExitCode -eq 0 -and
        -not [string]::IsNullOrWhiteSpace($sourceFromQuery) -and
        $sourceQueryText -notmatch '(?i)\berror\b|\bfailed\b|\bfallo\b' -and
        -not (Test-JeanFlowInvalidClockSource -Source $sourceFromQuery)
    )

    $statusIsValid = (
        $StatusExitCode -eq 0 -and
        -not (Test-JeanFlowInvalidClockSource -Source $sourceFromStatus)
    )
    $sourceHostFromQuery = (($sourceFromQuery -split ',')[0]).Trim().ToLowerInvariant()
    $sourceHostFromStatus = (($sourceFromStatus -split ',')[0]).Trim().ToLowerInvariant()
    if (
        $queryIsValid -and
        $statusIsValid -and
        $sourceHostFromQuery -ne $sourceHostFromStatus
    ) {
        return [pscustomobject]@{
            valid = $false
            source = $sourceFromStatus
            source_from_query = $sourceFromQuery
            source_from_status = $sourceFromStatus
            evidence = 'source_status_mismatch'
            query_access_denied = $false
        }
    }
    # Phase Offset and Source originate in this same status /verbose snapshot.
    # /query /source is corroboration only and may not override that source.
    if ($statusIsValid -and ($queryIsValid -or $queryAccessDenied)) {
        return [pscustomobject]@{
            valid = $true
            source = $sourceFromStatus
            source_from_query = $sourceFromQuery
            source_from_status = $sourceFromStatus
            evidence = $(
                if ($queryAccessDenied) {
                    'status_verbose_access_denied_fallback'
                }
                else {
                    'status_verbose_corroborated'
                }
            )
            query_access_denied = $queryAccessDenied
        }
    }
    return [pscustomobject]@{
        valid = $false
        source = $(
            if (-not [string]::IsNullOrWhiteSpace($sourceFromQuery)) {
                $sourceFromQuery
            }
            else {
                $sourceFromStatus
            }
        )
        source_from_query = $sourceFromQuery
        source_from_status = $sourceFromStatus
        evidence = 'unresolved'
        query_access_denied = $queryAccessDenied
    }
}

function Get-JeanFlowClockStatusFacts {
    <#
    [W1]: los siete hechos se extraen por coincidencia de etiqueta y las
    etiquetas están LOCALIZADAS. Las alternativas incluyen el inglés, las
    variantes en español observadas ('Estrato' es la traducción real de
    Microsoft para Stratum) y tolerancia a mojibake de hasta 2 caracteres por
    acento (UTF-8 leído como cp1252 convierte 'ó' en 'Ã³'; la tolerancia de
    UN carácter de 2.2.2 rompía exactamente en ese caso, [W11]). Cuando aun
    así falta algún hecho, el llamador emite STATUS_LOCALE_UNSUPPORTED con el
    texto crudo — un problema de PARSER nunca se reporta como fallo del reloj.
    #>
    [CmdletBinding()]
    param([object[]]$StatusLines = @())

    $statusText = $StatusLines -join [Environment]::NewLine
    $phaseOffsetMs = $null
    $phaseOffsetMsRaw = $null
    if (
        $statusText -match '(?im)^\s*(?:Phase Offset|Desplazamiento de fase|Desfase(?: de fase)?)\s*:\s*(?<value>[+-]?\d+(?:[\.,]\d+)?)s\s*$'
    ) {
        $phaseSeconds = [double]::Parse(
            $Matches.value.Replace(',', '.'),
            [Globalization.CultureInfo]::InvariantCulture
        )
        $phaseOffsetMsRaw = $phaseSeconds * 1000
        $phaseOffsetMs = [Math]::Round($phaseOffsetMsRaw, 3)
    }

    $leapIndicator = $null
    if (
        $statusText -match '(?im)^\s*(?:Leap Indicator|Indicador de salto|Indicador de intercalaci.{1,2}n)\s*:\s*(?<value>\d+)'
    ) {
        $leapIndicator = [int]$Matches.value
    }

    $stratum = $null
    if ($statusText -match '(?im)^\s*(?:Stratum|Capa|Estrato)\s*:\s*(?<value>\d+)') {
        $stratum = [int]$Matches.value
    }

    $lastSyncError = $null
    if (
        $statusText -match '(?im)^\s*(?:Last (?:Successful )?Sync Error|.{0,2}ltimo error de sincronizaci.{1,2}n(?: correcta)?)\s*:\s*(?<value>\d+)'
    ) {
        $lastSyncError = [int]$Matches.value
    }

    $stateMachine = $null
    if (
        $statusText -match '(?im)^\s*(?:State Machine|Equipo de estado|M.{1,2}quina de estados?)\s*:\s*(?<value>\d+)'
    ) {
        $stateMachine = [int]$Matches.value
    }

    $pollSeconds = $null
    if (
        $statusText -match '(?im)^\s*(?:Poll Interval|Intervalo de sondeo)\s*:\s*\d+\s*\((?<value>\d+)s\)'
    ) {
        $pollSeconds = [double]$Matches.value
    }

    $lastGoodSyncAgeSeconds = $null
    if (
        $statusText -match '(?im)^\s*(?:Time since Last Good Sync Time|Tiempo (?:desde la|transcurrido desde la) .{0,2}ltima sincronizaci.{1,2}n (?:de hora )?correcta)\s*:\s*(?<value>\d+(?:[\.,]\d+)?)s'
    ) {
        $lastGoodSyncAgeSeconds = [double]::Parse(
            $Matches.value.Replace(',', '.'),
            [Globalization.CultureInfo]::InvariantCulture
        )
    }

    $missingFacts = @()
    if ($null -eq $phaseOffsetMsRaw) { $missingFacts += 'phase_offset' }
    if ($null -eq $leapIndicator) { $missingFacts += 'leap_indicator' }
    if ($null -eq $stratum) { $missingFacts += 'stratum' }
    if ($null -eq $lastSyncError) { $missingFacts += 'last_sync_error' }
    if ($null -eq $stateMachine) { $missingFacts += 'state_machine' }
    if ($null -eq $pollSeconds) { $missingFacts += 'poll_seconds' }
    if ($null -eq $lastGoodSyncAgeSeconds) { $missingFacts += 'last_good_sync_age' }
    $requiredFactsMissing = ($missingFacts.Count -gt 0)
    $lastGoodSyncTooOld = (
        $null -ne $pollSeconds -and
        $null -ne $lastGoodSyncAgeSeconds -and
        $lastGoodSyncAgeSeconds -gt (($pollSeconds * 2) + 60)
    )

    $semanticallyInvalid = (
        $requiredFactsMissing -or
        ($null -ne $leapIndicator -and $leapIndicator -eq 3) -or
        ($null -ne $stratum -and ($stratum -lt 1 -or $stratum -gt 15)) -or
        ($null -ne $lastSyncError -and $lastSyncError -ne 0) -or
        ($null -ne $stateMachine -and $stateMachine -notin @(1, 2)) -or
        $lastGoodSyncTooOld
    )
    return [pscustomobject]@{
        phase_offset_ms = $phaseOffsetMs
        phase_offset_ms_raw = $phaseOffsetMsRaw
        leap_indicator = $leapIndicator
        stratum = $stratum
        last_sync_error = $lastSyncError
        state_machine = $stateMachine
        poll_seconds = $pollSeconds
        last_good_sync_age_seconds = $lastGoodSyncAgeSeconds
        required_facts_missing = $requiredFactsMissing
        missing_facts = $missingFacts
        last_good_sync_too_old = $lastGoodSyncTooOld
        semantically_invalid = $semanticallyInvalid
    }
}

function Get-JeanFlowW32EvidenceState {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][object]$SourceResolution,
        [Parameter(Mandatory = $true)][object]$StatusFacts,
        [object[]]$PeersLines = @(),
        [int]$PeersExitCode = 0,
        [AllowEmptyString()][string]$SyncType = '',
        [AllowEmptyString()][string]$ConfiguredPeerList = ''
    )

    $peerText = $PeersLines -join [Environment]::NewLine
    # [W11a]: el patrón anterior ':\s*0\s*$' coincidía con CUALQUIER línea
    # terminada en ': 0' (p. ej. 'Estrato: 0'); ahora se ancla a la etiqueta
    # del contador de peers.
    $peerCountIsZero = $peerText -match '(?im)^\s*#?\s*(?:Peers|N.{0,3}(?:mero)? de (?:sistemas del mismo nivel|pares|asociados)|Sistemas del mismo nivel|Pares|Asociados)\s*:\s*0\s*$'
    $hasActivePeer = $peerText -match '(?im)^\s*(?:State|Estado|Etat|Status|Stato)\s*:\s*(?:Active|Activo|Activa|Ativo|Actif|Aktiv|Attivo)\b'
    $peerQueryLooksInvalid = (
        [string]::IsNullOrWhiteSpace($peerText) -or
        $peerCountIsZero -or
        -not $hasActivePeer -or
        $peerText -match '(?i)\berror\b|\bfailed\b|\bfallo\b|no se ha iniciado el servicio'
    )
    $manualPeersMissing = (
        $SyncType -match '(?i)^NTP$' -and
        [string]::IsNullOrWhiteSpace($ConfiguredPeerList)
    )
    $configuredPeerHosts = @(
        $ConfiguredPeerList -split '\s+' |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object { (($_ -split ',')[0]).Trim().ToLowerInvariant() }
    )
    $source = [string]$SourceResolution.source
    $sourceHost = (($source -split ',')[0]).Trim().ToLowerInvariant()
    # Parse peer records sequentially and compare the normalized host exactly.
    # Substring matching would confuse e.g. 1.pool.ntp.org with 11.pool.ntp.org,
    # while relying on blank separators would bind state from another record.
    $sourcePeerIsActive = $false
    $currentPeerHost = ''
    foreach ($line in $PeersLines) {
        $text = [string]$line
        if (
            $text -match '^\s*(?:Peer|Sistema del mismo nivel|Par|Pair)\s*:\s*(?<peer>.+?)\s*$'
        ) {
            $currentPeerHost = (
                (($Matches.peer -split ',')[0]).Trim().ToLowerInvariant()
            )
            continue
        }
        if (
            $currentPeerHost -eq $sourceHost -and
            $text -match '^\s*(?:State|Estado|Etat|Status|Stato)\s*:\s*(?:Active|Activo|Activa|Ativo|Actif|Aktiv|Attivo)\b'
        ) {
            $sourcePeerIsActive = $true
        }
    }
    $sourceMatchesConfiguredPeer = (
        $SyncType -notmatch '(?i)^NTP$' -or
        $configuredPeerHosts -contains $sourceHost
    )
    $valid = (
        $SourceResolution.valid -and
        -not (Test-JeanFlowInvalidClockSource -Source $source) -and
        -not $StatusFacts.semantically_invalid -and
        $PeersExitCode -eq 0 -and
        -not $peerQueryLooksInvalid -and
        $sourcePeerIsActive -and
        -not $manualPeersMissing -and
        $sourceMatchesConfiguredPeer
    )
    return [pscustomobject]@{
        valid = $valid
        active_peer_confirmed = $hasActivePeer
        source_peer_active = $sourcePeerIsActive
        peer_query_looks_invalid = $peerQueryLooksInvalid
        manual_peers_missing = $manualPeersMissing
        source_matches_configured_peer = $sourceMatchesConfiguredPeer
        source_host = $sourceHost
        configured_peer_hosts = $configuredPeerHosts
    }
}

function Test-JeanFlowPhaseOffsetWithinLimit {
    [CmdletBinding()]
    param(
        [AllowNull()][object]$PhaseOffsetMs,
        [ValidateRange(0.001, 10000)][double]$WarnMs = 50
    )

    if ($null -eq $PhaseOffsetMs) {
        return $false
    }
    try {
        $numeric = [double]$PhaseOffsetMs
    }
    catch {
        return $false
    }
    if ([double]::IsNaN($numeric) -or [double]::IsInfinity($numeric)) {
        return $false
    }
    return [Math]::Abs($numeric) -le $WarnMs
}

function Write-JeanFlowClockResult {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][bool]$Pass,
        [Parameter(Mandatory = $true)][string]$ErrorCode,
        [Parameter(Mandatory = $true)][AllowEmptyString()][string]$Message,
        [Parameter(Mandatory = $true)][int]$ExitCode,
        [hashtable]$Details = @{}
    )

    if ([string]::IsNullOrWhiteSpace($Message)) {
        $Message = 'Sin detalle adicional.'
    }

    $result = [ordered]@{
        pass = $Pass
        error_code = $ErrorCode
        message = $Message
        exit_code = $ExitCode
        utc = (Get-Date).ToUniversalTime().ToString('o')
    }
    foreach ($key in $Details.Keys) {
        $result[$key] = $Details[$key]
    }
    [pscustomobject]$result | ConvertTo-Json -Depth 8
    exit $ExitCode
}
