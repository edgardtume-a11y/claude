#Requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Installer,
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[0-9A-Fa-f]{64}$')]
    [string]$ExpectedSha256
)

$ErrorActionPreference = 'Stop'
$path = (Resolve-Path -LiteralPath $Installer).Path
$actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToUpperInvariant()
$expected = $ExpectedSha256.ToUpperInvariant()
if ($actual -ne $expected) {
    throw "SHA-256 no coincide. Esperado=$expected Actual=$actual"
}
$signature = Get-AuthenticodeSignature -LiteralPath $path
if ($signature.Status -ne 'Valid') {
    throw "Firma Authenticode invalida: $($signature.Status)"
}
$signer = $signature.SignerCertificate.Subject
if ($signer -notmatch '(?i)Meinberg') {
    throw "La firma es valida, pero el firmante no contiene 'Meinberg': $signer"
}

[pscustomobject]@{
    path = $path
    sha256 = $actual
    signature = "$($signature.Status)"
    signer = $signer
    verified_utc = (Get-Date).ToUniversalTime().ToString('o')
} | Format-List
Write-Host 'Verificado. La instalacion sigue siendo manual y debe ejecutarse como administrador.'

