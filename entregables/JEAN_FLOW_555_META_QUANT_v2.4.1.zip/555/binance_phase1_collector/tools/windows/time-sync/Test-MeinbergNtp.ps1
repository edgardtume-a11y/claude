#Requires -Version 5.1

[CmdletBinding()]
param(
    [ValidateRange(3, 200)][int]$Samples = 20,
    [ValidateRange(0.001, 10000)][double]$WarnMs = 50
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'TimeSync-Common.ps1')

try {
    $inventory = @(Get-JeanFlowTimeServiceInventory)
    $running = @($inventory | Where-Object { $_.running })
    $ntpd = @($inventory | Where-Object { $_.kind -eq 'MeinbergNtp' })

    if ($running.Count -gt 1) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'MULTIPLE_TIME_SERVICES' `
            -Message 'Hay mas de un disciplinador de reloj activo.' `
            -ExitCode 14 `
            -Details @{ services = $inventory }
    }
    if ($ntpd.Count -eq 0) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'SERVICE_NOT_REGISTERED' `
            -Message 'No se encontro el servicio ntpd de Meinberg.' `
            -ExitCode 10 `
            -Details @{ services = $inventory }
    }
    if (-not $ntpd[0].running) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'SERVICE_STOPPED' `
            -Message 'Meinberg ntpd esta instalado, pero detenido.' `
            -ExitCode 12 `
            -Details @{ services = $inventory }
    }

    # Bind ntpq to the directory of the registered ntpd service.  Searching
    # PATH/Program Files would let an unrelated user-controlled executable
    # manufacture clock evidence.
    $serviceCommandLine = [string]($ntpd[0].path)
    if ($serviceCommandLine.Contains('%')) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'QUERY_FAILED' `
            -Message 'La ruta del servicio ntpd contiene variables no confiables.' `
            -ExitCode 18 `
            -Details @{ services = $inventory }
    }
    $serviceExecutable = ''
    if ($serviceCommandLine -match '^\s*"([^"]+\.exe)"(?:\s|$)') {
        $serviceExecutable = $Matches[1]
    }
    elseif ($serviceCommandLine -match '^\s*(\S+\.exe)(?:\s|$)') {
        $serviceExecutable = $Matches[1]
    }
    if (
        -not $serviceExecutable -or
        -not [IO.Path]::IsPathRooted($serviceExecutable)
    ) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'QUERY_FAILED' `
            -Message 'La ruta registrada del servicio ntpd no es valida.' `
            -ExitCode 18 `
            -Details @{ services = $inventory }
    }

    $ntpdPath = [IO.Path]::GetFullPath($serviceExecutable)
    $ntpdItem = Get-Item -LiteralPath $ntpdPath -Force -ErrorAction SilentlyContinue
    if (
        $null -eq $ntpdItem -or
        $ntpdItem.PSIsContainer -or
        (($ntpdItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)
    ) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'QUERY_FAILED' `
            -Message 'El ejecutable registrado de ntpd no es un archivo regular.' `
            -ExitCode 18 `
            -Details @{
                service = $ntpd[0]
                expected_ntpd_path = $ntpdPath
                services = $inventory
            }
    }
    $ntpdPath = $ntpdItem.FullName
    $ntpq = Join-Path (Split-Path -Parent $ntpdPath) 'ntpq.exe'
    $ntpqItem = Get-Item -LiteralPath $ntpq -Force -ErrorAction SilentlyContinue
    if (
        $null -eq $ntpqItem -or
        $ntpqItem.PSIsContainer -or
        (($ntpqItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)
    ) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'QUERY_FAILED' `
            -Message 'No se encontro un ntpq.exe regular junto al servicio ntpd.' `
            -ExitCode 18 `
            -Details @{
                service = $ntpd[0]
                expected_ntpq_path = $ntpq
                services = $inventory
            }
    }

    $ntpq = $ntpqItem.FullName
    $peers = @(& $ntpq -pn 2>&1)
    $peerExit = $LASTEXITCODE
    if ($peerExit -ne 0) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'QUERY_FAILED' `
            -Message 'ntpq no pudo consultar los peers de Meinberg.' `
            -ExitCode 18 `
            -Details @{
                services = $inventory
                ntpq_path = $ntpq
                peers = $peers
            }
    }

    $selected = @($peers | Where-Object { "$_" -match '^\s*\*' })
    if ($selected.Count -eq 0) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'NO_VALID_SOURCE' `
            -Message 'Meinberg todavia no tiene un peer seleccionado.' `
            -ExitCode 15 `
            -Details @{
                services = $inventory
                ntpq_path = $ntpq
                peers = $peers
            }
    }

    $absoluteOffsetsMs = @()
    $runtimeEvidence = @()
    for ($index = 0; $index -lt $Samples; $index++) {
        $runtime = @(& $ntpq -c 'rv 0 offset' 2>&1)
        $runtimeExit = $LASTEXITCODE
        $runtimeText = $runtime -join ' '
        $offsetMatch = [regex]::Match(
            $runtimeText,
            'offset=(?<value>[+-]?\d+(?:\.\d+)?)'
        )
        $runtimeEntry = @{
            sample = $index + 1
            exit_code = $runtimeExit
            output = $runtime
            offset_abs_ms = $null
        }
        if ($runtimeExit -ne 0 -or -not $offsetMatch.Success) {
            $runtimeEvidence += [pscustomobject]$runtimeEntry
            Write-JeanFlowClockResult -Pass $false `
                -ErrorCode 'NO_SAMPLES' `
                -Message 'Meinberg no devolvio todas las muestras de offset requeridas.' `
                -ExitCode 16 `
                -Details @{
                    services = $inventory
                    ntpq_path = $ntpq
                    peers = $peers
                    expected_samples = $Samples
                    received_samples = $absoluteOffsetsMs.Count
                    runtime = $runtimeEvidence
                }
        }
        $offsetMs = [double]::Parse(
            $offsetMatch.Groups['value'].Value,
            [Globalization.CultureInfo]::InvariantCulture
        )
        $absoluteOffsetMs = [Math]::Abs($offsetMs)
        $runtimeEntry.offset_abs_ms = $absoluteOffsetMs
        $runtimeEvidence += [pscustomobject]$runtimeEntry
        $absoluteOffsetsMs += $absoluteOffsetMs
        if ($index + 1 -lt $Samples) {
            Start-Sleep -Milliseconds 100
        }
    }

    $sorted = @($absoluteOffsetsMs | Sort-Object)
    $p95Index = [Math]::Min(
        $sorted.Count - 1,
        [Math]::Max(0, [Math]::Ceiling(0.95 * $sorted.Count) - 1)
    )
    $p95 = [double]$sorted[$p95Index]
    $maximum = [double]$sorted[-1]
    if ($p95 -gt $WarnMs) {
        Write-JeanFlowClockResult -Pass $false `
            -ErrorCode 'OFFSET_OUT_OF_RANGE' `
            -Message 'El p95 absoluto del offset de Meinberg supera el umbral.' `
            -ExitCode 17 `
            -Details @{
                service = $ntpd[0]
                ntpq_path = $ntpq
                selected_peer = ($selected -join ' ')
                samples = $sorted.Count
                p95_abs_offset_ms = [Math]::Round($p95, 6)
                max_abs_offset_ms = [Math]::Round($maximum, 6)
                warn_ms = $WarnMs
                peers = $peers
                services = $inventory
                runtime = $runtimeEvidence
            }
    }

    Write-JeanFlowClockResult -Pass $true `
        -ErrorCode 'PASS' `
        -Message 'Meinberg ntpd esta activo, tiene peer seleccionado y cumple el umbral.' `
        -ExitCode 0 `
        -Details @{
            service = $ntpd[0]
            ntpq_path = $ntpq
            selected_peer = ($selected -join ' ')
            samples = $sorted.Count
            p95_abs_offset_ms = [Math]::Round($p95, 6)
            max_abs_offset_ms = [Math]::Round($maximum, 6)
            warn_ms = $WarnMs
            peers = $peers
            services = $inventory
            runtime = $runtimeEvidence
        }
}
catch {
    Write-JeanFlowClockResult -Pass $false `
        -ErrorCode 'INTERNAL_ERROR' `
        -Message $_.Exception.Message `
        -ExitCode 99
}
