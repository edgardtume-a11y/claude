#Requires -Version 5.1

[CmdletBinding()]
param()

$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'TimeSync-Common.ps1')
$systemDirectory = [Environment]::SystemDirectory
$w32tm = Join-Path $systemDirectory 'w32tm.exe'
$sc = Join-Path $systemDirectory 'sc.exe'

$serviceRaw = Get-Service W32Time -ErrorAction SilentlyContinue
$service = if ($null -ne $serviceRaw) {
    [pscustomobject]@{
        name = $serviceRaw.Name
        display_name = $serviceRaw.DisplayName
        status = "$($serviceRaw.Status)"
    }
}
else {
    $null
}
$serviceConfig = @(& $sc qc W32Time 2>&1)
$triggers = @(& $sc qtriggerinfo W32Time 2>&1)
$computerRaw = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
$computer = if ($null -ne $computerRaw) {
    [pscustomobject]@{
        name = $computerRaw.Name
        part_of_domain = [bool]$computerRaw.PartOfDomain
        domain = $computerRaw.Domain
    }
}
else {
    $null
}
$allServices = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue)
$inventory = @(Get-JeanFlowTimeServiceInventory -Services $allServices)
$configuration = @(& $w32tm /query /configuration 2>&1)
$configurationExit = $LASTEXITCODE
$status = @(& $w32tm /query /status /verbose 2>&1)
$statusExit = $LASTEXITCODE
$source = @(& $w32tm /query /source 2>&1)
$sourceExit = $LASTEXITCODE
$peers = @(& $w32tm /query /peers 2>&1)
$peersExit = $LASTEXITCODE

[pscustomobject]@{
    utc = (Get-Date).ToUniversalTime().ToString('o')
    w32time_service = $service
    sc_qc = $serviceConfig
    sc_qtriggerinfo = $triggers
    computer = $computer
    detected_time_services = $inventory
    w32tm_configuration_exit_code = $configurationExit
    w32tm_configuration = $configuration
    w32tm_status_exit_code = $statusExit
    w32tm_status = $status
    w32tm_source_exit_code = $sourceExit
    w32tm_source = $source
    w32tm_peers_exit_code = $peersExit
    w32tm_peers = $peers
    note = 'Diagnostico read-only: no cambia el reloj, servicios, registro, firewall ni tareas.'
} | ConvertTo-Json -Depth 8
