# Cambios JEAN_FLOW 2.1.1 — reparacion W32Time 0x80070426

El schema CSV permanece en `2.0.0`. Esta release corrige exclusivamente el
preflight y la operacion del reloj Windows; no inicia LightGBM, Fase 2 ni
ejecucion de ordenes.

## Causa raiz

La instalacion Python de la ejecucion aportada termino correctamente. El fallo
ocurrio en G0 porque W32Time estaba `Stopped`. Aunque `stripchart` recibio 20
respuestas de `time.windows.com` con unos 383 ms de offset, el servicio no
disciplinaba el reloj.

El configurador 2.1.0 agravaba el bloqueo por este orden:

1. cambiaba el inicio a Automatic;
2. llamaba `w32tm /config /update` con el servicio aun detenido;
3. abortaba con 0x80070426 antes de llegar a `Restart-Service`.

En equipos de grupo de trabajo habia otro riesgo: Microsoft documenta que el
trigger predeterminado puede volver a detener W32Time incluso si el inicio se
marca Automatic.

## Reparacion aplicada

- diagnostico read-only de servicio, start mode, dominio/GPO, triggers,
  configuracion, fuente, peers y otros disciplinadores;
- respaldo de la rama W32Time, estado SCM y triggers antes de mutar;
- `Set-Service Automatic`, trigger `start/networkon stop/networkoff`,
  `Start-Service` y espera explicita de `Running` antes del primer `/config`;
- perfil publico con flag cliente `0x8` y
  `MinPollInterval=MaxPollInterval=11` (2.048 s, nunca menos de 1.800 s);
- perfil de 64 s separado, con tres fuentes autorizadas y rechazo del Pool;
- exactamente un `/resync /rediscover` durante configuracion, nunca en captura;
- espera de fuente valida y comprobacion de offset antes de guardar el perfil;
- launcher con una sola elevacion UAC y salida determinista ante cancelacion;
- reparacion opcional desde `[3/10]`, preservando el JSON anterior y
  revalidando antes de `[4/10]`;
- errores tipados: servicio detenido/deshabilitado/no registrado, dominio/GPO,
  fuentes o muestras invalidas, offset alto y multiples disciplinadores;
- peer Active obligatorio, quorum completo de muestras y reintentos de
  convergencia de hasta 120 s sin repetir `resync`;
- rechazo de rafagas `stripchart` contra `pool.ntp.org`;
- restauracion del registro y estado anterior con reinicio requerido para que
  SCM recargue por completo los triggers; el baseline consumido se archiva para
  que la siguiente configuracion respalde el estado nuevo.

## Seguridad y limites

- no usa automaticamente `w32tm /unregister` ni `/register`;
- no abre UDP/123 entrante ni instala binarios externos;
- la aplicacion Python continua sin privilegios de administrador;
- el umbral publico inicial es p95 absoluto menor o igual a 50 ms;
- no se promete 1 ms mediante Internet publico;
- `book_apply` y `event_loop_lag` siguen usando reloj monotonico y son
  independientes de W32Time.

## Evidencia offline

- pytest: 93 PASS y 1 smoke live opt-in SKIP;
- `compileall`: PASS;
- benchmark `--enforce`: PASS (`book_apply p99=0,030 ms`, pipeline
  `p99=1,1262 ms`, event-loop lag `p99=18,0586 ms`); la comprobacion Windows
  real de los scripts PowerShell, smoke y soak sigue siendo obligatoria.
