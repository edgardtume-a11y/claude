# Cambios JEAN_FLOW 2.2.2

- Corrige el falso `OFFSET_OUT_OF_RANGE` reproducido en Windows 11. W32Time
  estaba sano y reportaba `Phase Offset=2.426 ms`, pero 2.2.1 ejecutaba un
  `stripchart` contra `time.windows.com`, distinto de la fuente activa
  `1.pool.ntp.org`, y rechazaba p95 de 95.972/103.318 ms.
- `Test-W32Time.ps1` decide ahora contra el `Phase Offset` de la fuente que
  realmente disciplina el reloj. Phase Offset y Source salen del mismo status;
  la consulta separada debe corroborarlo cuando es accesible (si Windows la
  deniega, se conserva el fallback del status) y ese peer debe estar activo. Exige estado
  semántico válido, sincronización reciente, error cero y offset absoluto
  exacto `<= 50 ms`.
- `phase_offset_ms_raw` es obligatorio; la comparación ocurre antes de
  redondear. Los límites `±50.000000` pasan y `±50.000001` fallan.
- Se retira `stripchart` del gate W32Time. Sigue siendo útil como diagnóstico
  de una ruta concreta, pero no prueba por sí solo que el reloj local esté mal.
- Si el offset real supera 50 ms en un W32Time único, sano y no administrado,
  el preflight ofrece una única resincronización autorizada. Se eleva
  directamente `System32\w32tm.exe` con el argumento fijo `/resync`; no se
  eleva un script editable y no se cambian peers, registro, servicios,
  firewall ni GPO.
- La resincronización conserva evidencia, espera su exit code y solo continúa
  si el gate completo converge dentro de 90 segundos. Rechazo, UAC cancelado,
  dominio/GPO, Meinberg, doble disciplinador o evidencia incompleta fallan
  cerrados.
- El launcher deja de invocar la reparación automática de configuración
  W32Time. Elevar un `.ps1` modificable entre su validación y UAC era una ventana
  TOCTOU; servicio detenido/deshabilitado/manual ahora falla cerrado.
- El postflight continúa siendo estrictamente de solo lectura: nunca repara un
  reloj después de capturar para fabricar un PASS.
- El bootstrap y el supervisor rechazan un proceso ya elevado: INICIAR debe
  abrirse con doble clic normal. Solo el `/resync` puntual cruza UAC.
- Se corrige `Test-TimeSyncAssets.ps1`, que aún buscaba el launcher heredado
  inexistente `EJECUTAR_TODO_JEAN_FLOW.cmd`; ahora valida `INICIAR.cmd` y el
  contrato Phase Offset.
- Validación offline: 176 PASS, 1 smoke Binance live opt-in omitido;
  compilación, Ruff crítico y benchmark sintético `--enforce` PASS. El
  empaquetado reproducible se documenta en el informe de implementación.
