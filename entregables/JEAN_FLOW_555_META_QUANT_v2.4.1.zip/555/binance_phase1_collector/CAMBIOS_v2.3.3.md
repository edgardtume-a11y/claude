# CAMBIOS v2.3.3 — Endpoints USDⓈ-M por niveles (reversión de P0.1a con oráculo O=1)

Un solo cambio, mayor. Descubierto por la telemetría nueva del smoke v2.3.2
sobre el host real y confirmado contra la documentación oficial vigente.

## El hecho

En dos validaciones independientes (sin carga concurrente en la segunda),
sobre `wss://fstream.binance.com/stream?streams=`:

- `btcusdt@depth20@100ms` + `btcusdt@depth@100ms`: **100 mensajes en
  13.5 s**, cadena `pu` verificada — perfecto.
- `btcusdt@aggTrade`: **0/100 mensajes en 4 intentos** (~120 s cada uno),
  reproducible y determinista.

Además, la sesión real del motor registró `agg_trade_messages = 0` en
futuros (atribuido erróneamente a la iliquidez de TUTUSDT) con el libro
perfecto — mismo patrón: profundidad sí, trades no.

## La causa (documentación oficial vigente)

Desde el **2026-04-23**, USDⓈ-M segmenta los streams por niveles
(«Important WebSocket Change Notice», developers.binance.com → derivatives
→ usds-margined-futures → websocket-market-streams):

- `wss://fstream.binance.com/public` — alta frecuencia: `@depth@100ms`,
  `@depth<n>@100ms` (raw `/public/ws/...`, combinado
  `/public/stream?streams=...`).
- `wss://fstream.binance.com/market` — datos regulares: `@aggTrade`,
  `@markPrice`, … (`/market/ws/...`, `/market/stream?streams=...`).
- El legado SIN ruta (`/stream`, `/ws`) quedó retirado en esa fecha y desde
  entonces **solo entrega el nivel Public** — exactamente el patrón
  observado: profundidad fluye, aggTrade silencio.

## Nota histórica obligada (honestidad del expediente)

El hallazgo **P0.1a de la auditoría** («/public/stream y /market/stream no
existen en la documentación; el único endpoint combinado es /stream») estaba
**desactualizado** respecto a la migración. La versión 2.2.2 ya apuntaba a
los niveles correctos; la remediación 2.3.0 **regresionó** los endpoints al
legado siguiendo la auditoría, y el criterio de aceptación
(`grep public/stream|market/stream = 0`) consagraba la regresión. La
evidencia O=1 del host real + la documentación vigente revierten ese ítem:
queda marcado SUPERSEDIDO en el informe de cierre.

## El cambio

`config.py::websocket_sources` (USDⓈ-M):

- `usdm_public_depth` → `wss://fstream.binance.com/public/stream?streams=<s>@depth20@100ms/<s>@depth@100ms`
- `usdm_market_trades` → `wss://fstream.binance.com/market/stream?streams=<s>@aggTrade`

La allowlist de endpoints no cambia (valida esquema+host; las rutas son del
mismo host). Spot no cambia (sin migración equivalente). El test
`test_usdm_uses_tiered_combined_stream_endpoints` fija las URLs nuevas y
documenta la reversión. `capture_fixtures`, el smoke y el motor heredan las
URLs de `websocket_sources` sin más cambios.

## Impacto

Sin este cambio, TODA captura de futuros desde 2026-04-23 carecía de trades
(aggTrade) aunque el libro fuera perfecto — el gate de actividad de la
certificación (aggTrade>0 por mercado) lo habría detectado en el modo 2/3.
Con el cambio, el smoke debe completar los CUATRO sockets y la certificación
puede exigir actividad real en todos los streams.

Suite: **219 passed, 2 skipped** (sin cambios de conteo).
