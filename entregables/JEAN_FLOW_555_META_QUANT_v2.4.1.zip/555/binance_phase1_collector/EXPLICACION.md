# JEAN_FLOW — explicación técnica del motor base 2.1.5

> Documento histórico conservado para describir el núcleo causal heredado.
> Las instrucciones vigentes de arranque, READY y certificación están en
> `README.md` y corresponden a JEAN_FLOW 2.2.2.

Este documento explica el código por unidades lógicas. Una operación atómica se
describe junta aunque ocupe varias líneas: separar cada asignación ocultaría la
causalidad que queremos certificar.

## 1. Qué hace y qué no hace

JEAN_FLOW abre dos pipelines read-only para `TUTUSDT`:

- Binance Spot;
- Binance USDⓈ-M Futures.

Cada pipeline recibe trades y profundidad, reconstruye su propio libro L2,
persiste un journal causal y entrega una copia top-N a un servidor local para
DOM y heatmap. No calcula señales, no entrena modelos y no envía órdenes.

```mermaid
flowchart TD
    W["WebSockets"] --> R["Receiver"]
    R --> D["Decode y route"]
    D --> B["Libro L2"]
    B --> J["Journal CSV"]
    B --> H["Hub top-N"]
    H --> V["DOM + heatmap"]
```

La captura y la visualización tienen contratos diferentes:

- el journal conserva todos los eventos aceptados y es la fuente de verdad;
- el dashboard conserva solo la vista más reciente porque un navegador lento no
  debe aplicar backpressure al mercado.

## 2. `config.py`: dos mercados sin contaminación cruzada

`Settings` es un dataclass inmutable con límites de colas, bytes, filas,
timeouts, rotación y reconexión. `from_env()` lee el entorno una vez;
`validated()` rechaza tamaños o tiempos no positivos antes de abrir red/disco.

`Settings.for_market()` crea configuraciones independientes:

| Propiedad | Spot | USDⓈ-M Futures |
| --- | --- | --- |
| REST | `https://api.binance.com` | `https://fapi.binance.com` |
| Snapshot | `/api/v3/depth`, 5.000 | `/fapi/v1/depth`, 1.000 |
| Profundidad WS | combinado Spot | `/public/stream` |
| Trades WS | combinado Spot | `/market/stream` |
| Carpeta | `spot/` | `usdm_futures/` |

`websocket_sources()` devuelve una URL con rol para Spot y dos para Futures. Esto
es deliberado: la API Futures vigente separa market streams y public streams.
Cada URL recibe un task `_receiver`; los mensajes convergen en la cola raw del
mismo mercado, pero nunca cruzan al libro del otro mercado.

## 3. `models.py`: contrato tipado y persistido

Los objetos de evento son inmutables:

- `RawEnvelope`: bytes, timestamps e identidad causal tomados al recibir;
- `DiffDepthEvent`: `U`, `u`, `pu` opcional y cambios bid/ask;
- `PartialDepthEvent`: vista top-20 observada;
- `AggTradeEvent`: trade agregado con IDs, precio, cantidad y lado agresor;
- `DepthSnapshot`: snapshot REST y su `lastUpdateId`;
- `CsvBatch`: header y niveles compactos que pertenecen al mismo evento; las
  filas anchas se materializan de forma lazy en el writer.

`SCHEMA_VERSION = 2.0.0` añade identidad causal transversal. El replay continúa
aceptando journals legacy `1.0.0` y `1.1.0`, pero nunca mezcla un schema legacy
con el causal v2 en una misma reconstrucción. `audit identity` exige una captura
íntegramente `2.0.0`.

`parse_levels()` exige pares `[precio, cantidad]` representados como strings.
La conversión exacta a enteros base `10^8` sucede en el worker de libro, después
de clasificar un evento stale. No se redondea ni se altera el string persistido;
así se preserva el journal y la ruta que recibe sockets permanece pequeña.

## 4. `protocol.py`: parseo fail-closed

`decode_combined()` parsea con `orjson` una sola vez y valida:

1. envoltura `stream` + `data`;
2. tipo de evento;
3. símbolo esperado;
4. tipos exactos de IDs, flags y niveles;
5. `U <= u` para deltas;
6. discriminador Futures `st == 1` cuando corresponde.

Un payload desconocido lanza `ProtocolError`; no se inventan defaults. El
collector corta esa sesión, marca el estado y reconecta desde un nuevo snapshot.

En Spot, `depth20@100ms` contiene `lastUpdateId` y reemplaza la vista top-20.
Sus saltos no prueban pérdida. En Futures, el partial puede transportar más
campos, pero sigue siendo observacional. Solo `depth@100ms` alimenta el libro
canónico.

## 5. `order_book.py`: estado L2 atómico

`LocalOrderBook` mantiene bids y asks en `SortedDict[int, int]`. Un solo
task es dueño del objeto; por tanto no necesita locks en la ruta de aplicación.

### Carga de snapshot

`load_snapshot()` valida todos los niveles en estructuras temporales:

- precio representable exactamente, positivo y dentro de 64 bits;
- cantidad representable exactamente, no negativa y dentro de 64 bits;
- precio único por lado;
- número de niveles dentro del límite;
- libro no cruzado.

Solo al terminar sustituye los mapas y fija `last_update_id`. Un snapshot malo
no deja medio libro cargado.

### Aplicación de un diff

`apply()` sigue este orden:

1. valida el rango y clasifica stale/continuidad según el mercado;
2. convierte los niveles no stale a punto fijo exacto;
3. prepara las mutaciones y un undo log;
4. cantidad cero elimina; positiva reemplaza;
5. valida spread, límites y memoria;
6. solo entonces avanza la secuencia.

Si una validación posterior falla, el undo log revierte todas las mutaciones.
Eso hace que payload y `last_update_id` sean una sola transacción lógica.

### Estado Spot

Con snapshot `L`, `retained_after_snapshot()` elimina `u <= L` y exige que el
primer retenido cubra el siguiente ID requerido: `U <= L+1 <= u`. Por tanto,
`U=L+1` es continuidad exacta valida. La regresion que lo rechazaba convertia
cada snapshot Spot en `bootstrap_gap` hasta saturar el buffer. Ya en vivo, un
rango puede solaparse y debe cubrir `local_u+1`; no se exige `U == esperado`
porque un evento puede cubrir varios IDs.

```text
válido: U <= local_u + 1 <= u
gap:    U >  local_u + 1
stale:  u <= local_u
```

### Estado Futures

El bootstrap exige `U <= L <= u`. Después, la condición decisiva es:

```text
event.pu == previous_event.u
```

`PreviousSequenceGap` separa este error de un gap Spot. Si el puente termina en
`u == L`, devuelve `ANCHORED`: valida el payload y enlaza la cadena `pu`, pero no
lo aplica porque el snapshot ya contiene el estado `L`.

La cadena completa bufferizada se valida antes de declarar el libro listo. Un
anchor correcto seguido por un `pu` incorrecto mantiene el dashboard en
`SYNCING`; no publica un estado intermedio.

## 6. `rest.py`: snapshots controlados

`SnapshotClient` reutiliza una `aiohttp.ClientSession` y serializa requests con
un lock. Aplica intervalo mínimo y backoff con jitter para evitar una tormenta
REST durante fallos repetidos.

Marca UTC y monotónico inmediatamente después de recibir el cuerpo. Respuestas
`429`/`418` respetan `Retry-After`; `5xx` se reintenta de forma acotada; un `4xx`
no recuperable falla temprano.

El path y límite vienen de `Settings`, por lo que Spot no puede usar por error
los parámetros Futures ni al revés.

## 7. `collector.py`: pipeline asíncrono y resincronización

### Receiver: ruta crítica mínima

La secuencia crítica es:

```python
payload = await websocket.recv(decode=False)
receive_monotonic_ns = time.monotonic_ns()
receive_utc_ns = time.time_ns()
payload_bytes = len(payload)
if budget.bytes_inflight + payload_bytes > raw_queue_max_bytes:
    raise PipelineBackpressure
if raw_queue.full():
    raise PipelineBackpressure
ingest_seq = capture_session.ingest_sequencer.next()
envelope = RawEnvelope(..., ingest_seq=ingest_seq, ...)
raw_queue.put_nowait(envelope)
```

No hay `Decimal`, CSV, ordenamiento ni logging por mensaje. `decode=False`
evita una conversión de texto antes de `orjson`. Los dos timestamps son las
primeras operaciones tras `recv`. Antes de consumir el ordinal se comprueba que
la cola y el presupuesto de bytes tienen capacidad; así un payload rechazado no
crea un hueco artificial.

`dual_main.py` crea una sola `CaptureSession` y la comparte con ambos collectors.
Por eso `capture_session_id` identifica la ejecución completa e `ingest_seq`
ordena globalmente la aceptación local de mensajes Spot y Futures, incluidos los
dos sockets físicos de Futures.

`RawQueueBudget` limita tanto objetos como bytes. Si falta capacidad, se lanza
`PipelineBackpressure`; seguir equivaldría a perder un payload en silencio.

### Dispatcher

`_dispatcher()` decodifica una vez y enruta a tres colas acotadas:

- trade;
- partial;
- diff canónico.

Los workers confirman cada evento procesado y el supervisor inspecciona sus
excepciones antes y durante el drenaje. Por eso un `queue.join()` no puede
convertir silenciosamente un fallo del worker en cierre correcto.

Una cola con backlog cambia el comportamiento de `await queue.get()`: completa
sin suspender la tarea. `CooperativeBudget` impone un deadline monotónico de 1 ms
en receiver, dispatcher, trades, partial, bootstrap y libro live; al vencer hace
`await asyncio.sleep(0)`. Es un presupuesto temporal, no un contador fijo de
eventos, por lo que también funciona si cambia el costo por payload.

### Sincronización

`_synchronize()` hace el algoritmo correcto sin detener recepción:

1. mantiene el socket abierto y bufferiza diffs;
2. pide snapshot REST en un task;
3. descarta eventos cubiertos;
4. encuentra el puente del mercado;
5. carga y persiste snapshot;
6. aplica el buffer privado completo;
7. persiste cada disposición;
8. emite `SYNCED` y una única vista final al hub.

Un snapshot demasiado viejo se vuelve a pedir. Un gap invalida la generación,
registra su causa y reinicia el proceso. El request REST en vuelo se cancela si
termina la conexión, evitando tareas huérfanas y consumo de rate limit.

### Shutdown

Al recibir `stop`, el collector:

1. cierra sockets;
2. espera receivers y propaga errores anómalos;
3. inserta sentinel raw;
4. drena dispatcher;
5. drena colas de workers;
6. comprueba excepciones de workers;
7. drena el writer;
8. hace flush, fsync y rename final.

Todo el cierre usa un presupuesto global. Si no puede garantizar completitud,
marca `INCOMPLETE` o conserva `.csv.partial`; no produce un CSV aparentemente
válido con eventos perdidos.

## 8. `normalize.py`: journal causal

Cada fila comparte una identidad estable:

| Campo | Uso |
| --- | --- |
| `schema_version` | Contrato de lectura. |
| `capture_session_id` | Namespace único compartido por ambos mercados durante la ejecución. |
| `ingest_seq` | Orden global de payloads WebSocket aceptados; vacío para REST/estados sintéticos. |
| `source_socket_id` | Socket físico y rol de origen, o `rest:depth`/`collector`. |
| `exchange`, `market`, `symbol` | Impide mezclar feeds. |
| `connection_id` | Frontera de socket. |
| `book_generation` | Frontera snapshot/resync. |
| `local_event_id` | Agrupa las filas de un evento. |
| `row_index`, `level_count` | Detecta duplicación/truncamiento. |
| `sequence_first/last/previous` | `U`, `u`, `pu`. |
| `receive_utc_ns` | Orden UTC aproximado entre fuentes. |
| `receive_monotonic_ns` | Duraciones locales sin saltos NTP. |
| `exchange_transaction_time_ms` | Timestamp `T` de Binance cuando el canal lo entrega. |
| `note` | `applied`, `anchored`, `stale`, `gap`, estados. |

Un snapshot o delta se representa en el event loop como header `row_index=0`
más las tuplas compactas originales. `CsvBatch.iter_rows()` expande un nivel a
la vez dentro del writer. Conserva la unidad causal hasta disco: rotación y cola
nunca parten el evento, pero un snapshot Spot ya no crea miles de diccionarios
ni otra copia completa en la ruta caliente.

Los tipos de registro principales son:

- `CONNECTION`;
- `CAPTURE_STATUS`;
- `BOOK_STATUS`;
- `L2_SNAPSHOT`;
- `L2_DELTA`;
- `L2_PARTIAL`;
- `AGG_TRADE`.

## 9. `writer.py`: disco fuera de asyncio

`CsvJournalWriter` posee un `threading.Thread` y una `queue.Queue` acotada por
batches. Existe además un presupuesto de filas para que un snapshot grande no
burle el límite contando como un solo objeto.

El hilo realiza:

- expansion lazy y `csv.writerows` en fragmentos configurables;
- pausa real de 0,5 ms entre fragmentos grandes para que un snapshot de 10.001
  filas no congele asyncio; `Sleep(0)` no era determinista bajo carga;
- flush periódico;
- fsync;
- rotación por bytes/tiempo;
- rename atómico de `.partial` a `.csv`;
- fsync del directorio.

`submit()` no espera. Si no hay capacidad, el collector falla cerrado. Al
finalizar normalmente, solo un segmento fsyncado cambia a `.csv`. Una cola
incompleta conserva el sufijo `.partial`, que el replay rechaza.

El thread elimina I/O bloqueante del event loop, aunque CPython sigue
compartiendo GIL. Por eso 2.1 combina fragmentos pequeños, intervalo de cambio
de hilo de 1 ms, umbrales GC ajustados y un benchmark/soak obligatorio. Los
ajustes se aplican con `low_latency_runtime()` y se restauran al salir.

## 10. `reconstruct.py`: prueba independiente del estado

`reconstruct()` agrupa filas por
`(capture_session_id, market, connection_id, local_event_id)` en v2 y valida:

- schema compatible;
- identidad causal constante dentro de todas las filas expandidas del evento;
- `ingest_seq` positivo y `source_socket_id` coherente con mercado/canal;
- un solo exchange/mercado/símbolo;
- conexión activa correcta;
- índices y cantidad de filas;
- lados, precios, cantidades y duplicados;
- snapshot antes de deltas;
- generación y secuencia;
- puente/continuidad específica del mercado;
- estados `SYNCED`, `INVALIDATED`, `CLOSED` e `INCOMPLETE`.

Una nueva conexión necesita snapshot propio. Por ello dos ejecuciones o dos
mercados con generaciones que casualmente valen `1` no pueden formar un libro
híbrido.

`canonical_hash()` serializa ambos mapas en orden estable y calcula SHA-256. El
mismo journal debe devolver el mismo estado, secuencia y hash en cualquier
replay.

## 11. `metrics.py` y `audit.py`: evidencia medible

`Metrics` usa un shard por thread y ventanas `deque(maxlen=10000)`. `inc()` y
`observe()` no disputan un lock global; el snapshot copia y combina shards fuera
de la ruta crítica. Se observan:

- mensajes, bytes y throughput;
- tamaño/high-water de cada cola;
- parse;
- `book_apply` exclusivamente para validación/mutación L2;
- `journal_build`, `journal_enqueue`, `dashboard_project` y
  `book_pipeline_total` como etapas separadas;
- snapshot REST;
- exchange→receive;
- receive→writer-start;
- write, flush y fsync;
- event-loop lag;
- gaps, resyncs, reconnects y fallos.

`audit journal` ejecuta replay e inspecciona headers de eventos. Reporta
disposiciones, estados, latencias y SHA-256. `audit identity` combina los globs
Spot y Futures de una misma ejecución y exige schema 2.0.0, una sola sesión,
ambos mercados, sockets identificados y `ingest_seq` global sin conflictos ni
huecos. `audit metrics` lee las ventanas JSONL de ambos mercados, busca
contadores de fallo y aplica guardrails p99.

```bat
REM isolated_entry exige el entorno verificado que publica el bootstrap
REM (JEAN_FLOW_SOURCE_ROOT/RUNTIME_PACKAGES/RELEASE_MANIFEST_SHA256); fuera
REM de una sesión INICIAR.cmd sale con ISOLATED_RUNTIME_ENV_MISSING. Para
REM auditar manualmente una captura ya cerrada use el módulo directamente:
python -I -S -B -u -m binance_collector.audit identity ".\capture_dual_10m_01\spot" ".\capture_dual_10m_01\usdm_futures"
```
(con `src` en `PYTHONPATH` o el paquete instalado; el comando acepta
directorios además de globs desde v2.3.0)

No se resta un timestamp de exchange a `monotonic_ns`: son dominios de reloj
distintos. `exchange_to_receive` usa UTC y depende de NTP; `book_apply`, lag y
demas duraciones internas usan monotónico. Las recetas W32Time/Meinberg viven en
`tools/windows/time-sync` y nunca ejecutan `resync` dentro de la captura.

## 12. `dashboard.py` y `dashboard.html`: DOM/Bookmap read-only

`MarketStateHub` recibe copias top-N, no referencias mutables al libro. Verifica
mercado, símbolo, generación y secuencia antes de reemplazar el frame.

La publicación del libro solo ocurre con `SYNCED`. Durante un bootstrap el hub
mantiene el estado anterior invalidado o `SYNCING`; si toda la cadena pasa,
recibe exactamente una vista final atómica.

El servidor:

- enlaza únicamente `127.0.0.1`;
- expone `/healthz`, `/api/state` y `/ws`;
- valida `Origin`;
- desactiva compresión WebSocket;
- limita clientes;
- usa un mailbox corto por cliente.

Cuando el mailbox visual se llena, reemplaza el frame viejo por el más nuevo y
cuenta el drop. No toca las colas del collector ni el journal.

El navegador presenta:

- DOM con precio, cantidad y acumulado;
- mid, spread, secuencia, epoch y edad;
- historial Canvas de liquidez resting;
- trades agresores;
- basis Futures−Spot cuando ambos libros son comparables.

Al cambiar `generation`, JavaScript limpia el heatmap. De este modo una columna
anterior al gap nunca se interpreta como causalmente continua con la nueva.

## 13. `dual_main.py`: orquestación segura

Construye Spot, Futures, hub y dashboard. Los collectors corren en un
`TaskGroup`, pero cada wrapper captura su error, activa `stop` y permite que el
hermano drene. Solo después de que ambos terminan se vuelve a lanzar el grupo de
errores.

Esto evita el comportamiento normal de `TaskGroup` —cancelar inmediatamente a
los siblings— que sería peligroso para journals en proceso de cierre.

En Windows instala un handler alternativo de señales. `Ctrl+C` activa el evento
de stop en el loop y deja completar el cierre drenado.

## 14. Pruebas que blindan el contrato

La suite cubre, entre otros casos:

- Spot: sucesor exacto `U=L+1`, overlap, stale, delete, gap y rollback;
- Futures: bridge `U <= L <= u`, `pu`, anchor `u == L` y gap de cadena;
- payloads inválidos, duplicados y libro cruzado;
- snapshot antiguo, REST fallido y cancelación sin task huérfano;
- writer lento sin bloquear heartbeat asyncio;
- overflow, captura incompleta y tail `.partial`;
- shutdown con datos pendientes y errores de receiver/worker;
- replay determinista y rechazo de mercado/conexión híbridos;
- orquestación dual sin cancelar el drenaje del sibling;
- dashboard bounded, latest-wins y controles causales;
- bootstrap inválido sin publicación y bootstrap válido con una publicación.
- sesión causal compartida, orden global de ingestión y auditoría de identidad.

El test live está desactivado por defecto porque depende de red. La certificación
operativa se completa con `CERTIFICACION_FASE1.md` en el equipo final.

## 15. Límites honestos

- Es baja latencia en Python sobre Internet público; no es HFT colocada.
- El snapshot inicial está limitado por Binance a 5.000 niveles Spot y 1.000
  Futures.
- `aggTrade` no se rellena por REST tras una reconexión en esta fase; se registra
  la discontinuidad observada.
- El DOM/heatmap muestra top-N y no revela órdenes ocultas ni liquidez ausente
  del feed.
- Un percentil bueno durante una ventana corta no sustituye un soak prolongado.

La validacion operativa avanza por etapas: 10 minutos, luego 30 minutos y por
ultimo el soak. Mientras no pasen, el dictamen correcto es **operación
pendiente**. No debe conectarse todavía Machine Learning ni ejecución.
