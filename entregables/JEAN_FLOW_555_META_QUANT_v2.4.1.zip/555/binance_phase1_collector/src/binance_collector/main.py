from __future__ import annotations

import argparse
import asyncio
import json
import logging
import logging.handlers
import queue
import signal
from datetime import datetime, timezone
from pathlib import Path

from .collector import BinanceCollector
from .config import Settings
from .latency import fine_timer_resolution, low_latency_runtime


class JsonLogFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        # [P12]: la hora es la del EVENTO (record.created), no la del
        # formateo en el hilo del QueueListener, y exc_info ya no se descarta.
        payload = {
            "timestamp": datetime.fromtimestamp(
                record.created, tz=timezone.utc
            ).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info and record.exc_info[0] is not None:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _configure_logging(
    level: str,
    *,
    log_file: Path | None = None,
) -> logging.handlers.QueueListener:
    log_queue: queue.SimpleQueue[logging.LogRecord] = queue.SimpleQueue()
    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(level.upper())
    root.addHandler(logging.handlers.QueueHandler(log_queue))
    sink = logging.StreamHandler()
    sink.setFormatter(JsonLogFormatter())
    sinks: list[logging.Handler] = [sink]
    if log_file is not None:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_sink = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=64 * 1024 * 1024,
            backupCount=5,
            encoding="utf-8",
        )
        file_sink.setFormatter(JsonLogFormatter())
        sinks.append(file_sink)
    listener = logging.handlers.QueueListener(
        log_queue,
        *sinks,
        respect_handler_level=True,
    )
    listener.start()
    return listener


async def _run(args: argparse.Namespace) -> None:
    settings = Settings.from_env().with_overrides(
        symbol=args.symbol,
        output_dir=args.output_dir,
    )
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    fallback_handlers: list[tuple[signal.Signals, object]] = []
    for signal_name in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(signal_name, stop.set)
        except (NotImplementedError, RuntimeError):
            # [P12]: en Windows add_signal_handler lanza NotImplementedError
            # SIEMPRE; el `pass` anterior dejaba la plataforma objetivo sin
            # cierre limpio por señal. Mismo fallback que dual_main.
            try:
                previous = signal.getsignal(signal_name)
                signal.signal(
                    signal_name,
                    lambda *_ignored: loop.call_soon_threadsafe(stop.set),
                )
                fallback_handlers.append((signal_name, previous))
            except (ValueError, OSError, AttributeError):
                pass
    timer: asyncio.Task[None] | None = None
    if args.run_seconds is not None:
        async def stop_later() -> None:
            await asyncio.sleep(args.run_seconds)
            stop.set()

        timer = asyncio.create_task(stop_later(), name="run-timer")
    try:
        await BinanceCollector(settings).run(stop)
    finally:
        if timer is not None:
            timer.cancel()
        for signal_name, previous in fallback_handlers:
            signal.signal(signal_name, previous)  # type: ignore[arg-type]


def main() -> None:
    parser = argparse.ArgumentParser(description="Recolector Binance Spot Fase 1")
    parser.add_argument("--symbol", help="Símbolo Spot, por defecto BINANCE_SYMBOL/TUTUSDT")
    parser.add_argument("--output-dir", type=Path, help="Directorio CSV")
    parser.add_argument("--run-seconds", type=float, help="Finaliza tras N segundos")
    parser.add_argument("--log-level", default="INFO")
    parser.add_argument("--log-file", type=Path, help="Log JSONL rotativo opcional")
    args = parser.parse_args()
    listener = _configure_logging(args.log_level, log_file=args.log_file)
    try:
        # [2.3.6/2.3.7] Ver nota en dual_main: temporizador de 1 ms + QoS de
        # primer plano en Windows.
        with fine_timer_resolution() as fine_timer:
            with low_latency_runtime() as tuning:
                logging.getLogger("jean_flow").info(
                    "low_latency_runtime thread_switch_s=%s gc_thresholds=%s "
                    "fine_timer_1ms=%s foreground_qos=%s "
                    "foreground_qos_error=%s",
                    tuning.thread_switch_interval_s,
                    tuning.gc_thresholds,
                    fine_timer["timer_1ms"],
                    fine_timer["foreground_qos"],
                    fine_timer.get("foreground_qos_error"),
                )
                asyncio.run(_run(args))
    finally:
        listener.stop()


if __name__ == "__main__":
    main()
