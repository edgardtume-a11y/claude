from __future__ import annotations

from functools import lru_cache

FIXED_SCALE_DIGITS = 8
FIXED_SCALE = 10**FIXED_SCALE_DIGITS
MAX_FIXED_VALUE = (1 << 63) - 1
MAX_FIXED_TEXT_LENGTH = 64
FIXED_PARSE_CACHE_SIZE = 8_192


class FixedPointError(ValueError):
    pass


def parse_fixed(value: str) -> int:
    """Parse an unsigned base-10 value exactly at scale 1e8.

    The accepted grammar is deliberately smaller than Python's numeric
    grammar: ASCII digits with at most one decimal point, no sign, exponent,
    whitespace or locale separators.  Fractional digits beyond scale 1e8 are
    accepted only when they are zero, so the conversion never rounds.  A
    small process-wide LRU retains the repeated price/quantity tokens that
    dominate L2 bursts without recreating the former per-book 400k cache.
    """

    if not isinstance(value, str) or not value or len(value) > MAX_FIXED_TEXT_LENGTH:
        raise FixedPointError("texto numérico vacío o demasiado largo")
    return _parse_fixed_cached(value)


@lru_cache(maxsize=FIXED_PARSE_CACHE_SIZE)
def _parse_fixed_cached(value: str) -> int:
    """Cached parser for already type/length-checked text."""

    point = value.find(".")
    if point < 0:
        if not value.isascii() or not value.isdecimal():
            raise FixedPointError("parte entera inválida")
        scaled = int(value) * FIXED_SCALE
    else:
        if point == 0 or point == len(value) - 1 or value.find(".", point + 1) >= 0:
            raise FixedPointError("más de un separador decimal")
        whole_text = value[:point]
        fraction_text = value[point + 1 :]
        digits = whole_text + fraction_text
        if not digits.isascii() or not digits.isdecimal():
            raise FixedPointError("parte decimal inválida")
        fraction_digits = len(fraction_text)
        if fraction_digits > FIXED_SCALE_DIGITS:
            discarded_digits = fraction_digits - FIXED_SCALE_DIGITS
            divisor = 10**discarded_digits
            combined, discarded = divmod(int(digits), divisor)
            if discarded:
                raise FixedPointError(
                    "el valor requiere redondeo por encima de 8 decimales"
                )
            scaled = combined
        else:
            scaled = int(digits) * 10 ** (FIXED_SCALE_DIGITS - fraction_digits)
    if scaled > MAX_FIXED_VALUE:
        raise FixedPointError("valor fuera del dominio fijo de 64 bits")
    return scaled


def format_fixed(value: int) -> str:
    """Return the unique, non-exponential wire representation of a fixed int."""

    if isinstance(value, bool) or not isinstance(value, int):
        raise FixedPointError("el valor escalado debe ser un entero")
    if value < 0 or value > MAX_FIXED_VALUE:
        raise FixedPointError("valor escalado fuera del dominio de 64 bits")
    whole, fraction = divmod(value, FIXED_SCALE)
    if fraction == 0:
        return str(whole)
    return f"{whole}.{fraction:0{FIXED_SCALE_DIGITS}d}".rstrip("0")
