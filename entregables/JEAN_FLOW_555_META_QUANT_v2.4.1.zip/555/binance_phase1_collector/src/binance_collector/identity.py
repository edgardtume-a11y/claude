from __future__ import annotations

import itertools
import re
import threading
import uuid
from dataclasses import dataclass


_CAPTURE_SESSION_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{7,127}$")


def new_capture_session_id() -> str:
    """Return one opaque ID shared by every market in a capture run."""

    return uuid.uuid4().hex


def validate_capture_session_id(value: str) -> str:
    normalized = value.strip()
    if not _CAPTURE_SESSION_ID.fullmatch(normalized):
        raise ValueError(
            "capture_session_id debe tener 8..128 caracteres ASCII seguros"
        )
    return normalized


@dataclass(slots=True)
class IngestSequencer:
    """Thread-safe global ordinal assigned immediately after WebSocket recv()."""

    _counter: itertools.count
    _lock: threading.Lock
    _last: int

    def __init__(self, start: int = 1) -> None:
        if start <= 0:
            raise ValueError("El primer ingest_seq debe ser positivo")
        self._counter = itertools.count(start)
        self._lock = threading.Lock()
        self._last = start - 1

    def next(self) -> int:
        with self._lock:
            self._last = next(self._counter)
            return self._last

    @property
    def last_value(self) -> int:
        with self._lock:
            return self._last


@dataclass(slots=True)
class CaptureSession:
    """One causal namespace shared by Spot, Futures and every WS receiver."""

    capture_session_id: str
    ingest_sequencer: IngestSequencer

    def __post_init__(self) -> None:
        self.capture_session_id = validate_capture_session_id(
            self.capture_session_id
        )

    @classmethod
    def create(cls) -> "CaptureSession":
        return cls(new_capture_session_id(), IngestSequencer())
