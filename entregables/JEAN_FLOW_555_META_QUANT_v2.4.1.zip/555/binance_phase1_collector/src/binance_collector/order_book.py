from __future__ import annotations

from enum import Enum

from sortedcontainers import SortedDict

from .fixed_point import FixedPointError, format_fixed, parse_fixed
from .models import DepthSnapshot, DiffDepthEvent, PartialDepthEvent, PriceLevel


class SequenceGap(RuntimeError):
    def __init__(self, expected: int, received_first: int) -> None:
        super().__init__(f"Gap L2: esperado {expected}, recibido U={received_first}")
        self.expected = expected
        self.received_first = received_first


class PreviousSequenceGap(SequenceGap):
    def __init__(self, expected_previous: int, received_previous: int) -> None:
        RuntimeError.__init__(
            self,
            "Gap L2 Futures: "
            f"esperado pu={expected_previous}, recibido pu={received_previous}",
        )
        self.expected = expected_previous
        self.received_first = received_previous
        self.received_previous = received_previous


class BookInvariantError(RuntimeError):
    pass


class BookBoundaryError(BookInvariantError):
    pass


class BookDomainError(BookInvariantError):
    """Un precio/cantidad del cable no es representable en punto fijo 1e8/2^63.

    La causa es determinista por símbolo: reintentar o resincronizar no puede
    tener éxito (el mismo nivel vuelve en cada snapshot). El colector debe
    tratarla como ABORT (`SYMBOL_OUT_OF_DOMAIN`), nunca como RESYNC
    (auditoría v2.2.2, hallazgo [N1]).
    """


class SequenceOverlap(BookInvariantError):
    """Spot: un diff posterior al anclaje llegó con U < last_update_id + 1.

    El contrato Spot documenta U == u_anterior + 1 estricto tras el primer
    evento aplicado. Antes se aplicaba en silencio (hallazgo [P13]); ahora es
    fail-closed y el colector lo cuenta como `l2_overlap_events`.
    """

    def __init__(self, expected: int, received_first: int) -> None:
        super().__init__(
            f"Solapamiento L2 Spot: esperado U={expected}, recibido U={received_first}"
        )
        self.expected = expected
        self.received_first = received_first


class ApplyResult(str, Enum):
    APPLIED = "applied"
    ANCHORED = "anchored"
    STALE = "stale"


def _fixed_pair(
    level: PriceLevel,
) -> tuple[int, int]:
    try:
        price = parse_fixed(level[0])
        quantity = parse_fixed(level[1])
    except FixedPointError as exc:
        raise BookDomainError(f"Nivel fijo inválido: {level}: {exc}") from exc
    if price <= 0:
        raise BookInvariantError(f"Precio inválido: {level[0]}")
    return price, quantity


class LocalOrderBook:
    def __init__(
        self,
        max_levels_per_side: int,
        *,
        market: str = "spot",
        snapshot_limit: int | None = None,
    ) -> None:
        if market not in {"spot", "usdm_futures"}:
            raise ValueError(f"Mercado de libro no soportado: {market!r}")
        self.bids: SortedDict[int, int] = SortedDict()
        self.asks: SortedDict[int, int] = SortedDict()
        self.last_update_id: int | None = None
        self._max_levels = max_levels_per_side
        self._market = market
        self._snapshot_limit = snapshot_limit or (5_000 if market == "spot" else 1_000)
        self._has_stream_event = False
        self._last_applied_range: tuple[int, int] | None = None
        self._last_applied_payload: (
            tuple[tuple[PriceLevel, ...], tuple[PriceLevel, ...]] | None
        ) = None
        self._snapshot_bid_floor: int | None = None
        self._snapshot_ask_ceiling: int | None = None

    def load_snapshot(self, snapshot: DepthSnapshot) -> None:
        if snapshot.last_update_id < 0:
            raise BookInvariantError("Snapshot contiene lastUpdateId negativo")
        parsed_bids: list[tuple[int, int]] = []
        parsed_asks: list[tuple[int, int]] = []
        seen_bids: set[int] = set()
        seen_asks: set[int] = set()
        for raw in snapshot.bids:
            price, quantity = _fixed_pair(raw)
            if quantity <= 0:
                raise BookInvariantError("Snapshot contiene cantidad bid no positiva")
            if price in seen_bids:
                raise BookInvariantError("Snapshot contiene bids duplicados")
            seen_bids.add(price)
            parsed_bids.append((price, quantity))
        for raw in snapshot.asks:
            price, quantity = _fixed_pair(raw)
            if quantity <= 0:
                raise BookInvariantError("Snapshot contiene cantidad ask no positiva")
            if price in seen_asks:
                raise BookInvariantError("Snapshot contiene asks duplicados")
            seen_asks.add(price)
            parsed_asks.append((price, quantity))
        bids = SortedDict(parsed_bids)
        asks = SortedDict(parsed_asks)
        snapshot_bid_floor = (
            bids.peekitem(0)[0] if len(snapshot.bids) >= self._snapshot_limit else None
        )
        snapshot_ask_ceiling = (
            asks.peekitem(-1)[0] if len(snapshot.asks) >= self._snapshot_limit else None
        )
        previous_state = (
            self.bids,
            self.asks,
            self._snapshot_bid_floor,
            self._snapshot_ask_ceiling,
            self.last_update_id,
            self._last_applied_range,
            self._last_applied_payload,
            self._has_stream_event,
        )
        self.bids = bids
        self.asks = asks
        self._snapshot_bid_floor = snapshot_bid_floor
        self._snapshot_ask_ceiling = snapshot_ask_ceiling
        self.last_update_id = snapshot.last_update_id
        self._last_applied_range = None
        self._last_applied_payload = None
        self._has_stream_event = False
        try:
            self._validate()
        except BookInvariantError:
            (
                self.bids,
                self.asks,
                self._snapshot_bid_floor,
                self._snapshot_ask_ceiling,
                self.last_update_id,
                self._last_applied_range,
                self._last_applied_payload,
                self._has_stream_event,
            ) = previous_state
            raise

    def apply(self, event: DiffDepthEvent) -> ApplyResult:
        if self.last_update_id is None:
            raise BookInvariantError("No se puede aplicar un diff sin snapshot")
        if event.first_update_id < 0 or event.first_update_id > event.final_update_id:
            raise BookInvariantError("Rango de secuencia L2 inválido")
        if self._market == "usdm_futures" and (
            event.previous_final_update_id is None or event.previous_final_update_id < 0
        ):
            raise BookInvariantError("Diff Futures sin pu válido")
        stale_boundary = (
            event.final_update_id < self.last_update_id
            if self._market == "usdm_futures" and not self._has_stream_event
            else event.final_update_id <= self.last_update_id
        )
        if stale_boundary:
            # [N5]/X7: los eventos stale también se persisten en el journal.
            # Validar aquí su gramática numérica garantiza que ninguna fila
            # persistida quede sin validar por ningún camino.
            for side_name, levels in (("bid", event.bids), ("ask", event.asks)):
                seen_stale: set[int] = set()
                for raw in levels:
                    price, _quantity = _fixed_pair(raw)
                    if price in seen_stale:
                        raise BookInvariantError(
                            f"Diff stale contiene nivel duplicado: {side_name} {price}"
                        )
                    seen_stale.add(price)
            if (
                self._last_applied_range
                == (event.first_update_id, event.final_update_id)
                and self._last_applied_payload is not None
                and (
                    self._last_applied_payload[0] != event.bids
                    or self._last_applied_payload[1] != event.asks
                )
            ):
                raise BookInvariantError("Duplicado L2 conflictivo")
            return ApplyResult.STALE
        if self._market == "spot":
            expected = self.last_update_id + 1
            if event.first_update_id > expected:
                raise SequenceGap(expected, event.first_update_id)
            # Contigüidad estricta tras el primer evento aplicado: el contrato
            # Spot exige U == u_anterior + 1. El solapamiento solo es legal en
            # el evento que ancla el snapshot (U <= L+1 <= u).
            if self._has_stream_event and event.first_update_id != expected:
                raise SequenceOverlap(expected, event.first_update_id)
        elif not self._has_stream_event:
            if event.first_update_id > self.last_update_id:
                raise SequenceGap(self.last_update_id, event.first_update_id)
        elif event.previous_final_update_id != self.last_update_id:
            assert event.previous_final_update_id is not None
            raise PreviousSequenceGap(
                self.last_update_id,
                event.previous_final_update_id,
            )
        parsed_updates: list[list[tuple[int, int]]] = [[], []]
        for side_index, (side_name, levels) in enumerate(
            (("bid", event.bids), ("ask", event.asks))
        ):
            seen_updates: set[int] = set()
            target = parsed_updates[side_index]
            for raw in levels:
                price, quantity = _fixed_pair(raw)
                if price in seen_updates:
                    raise BookInvariantError(
                        f"Diff contiene nivel duplicado: {side_name} {price}"
                    )
                seen_updates.add(price)
                target.append((price, quantity))
        if (
            self._market == "usdm_futures"
            and not self._has_stream_event
            and event.final_update_id == self.last_update_id
        ):
            # The REST snapshot already represents state at L. This event is
            # needed to anchor the pu chain, but reapplying its older payload
            # could roll the snapshot back.
            self._has_stream_event = True
            self._last_applied_range = (
                event.first_update_id,
                event.final_update_id,
            )
            self._last_applied_payload = (event.bids, event.asks)
            return ApplyResult.ANCHORED
        undo_bids: list[tuple[int, int | None]] = []
        undo_asks: list[tuple[int, int | None]] = []
        try:
            for side, updates, undo in (
                (self.bids, parsed_updates[0], undo_bids),
                (self.asks, parsed_updates[1], undo_asks),
            ):
                for price, quantity in updates:
                    undo.append((price, side.get(price)))
                    if quantity == 0:
                        side.pop(price, None)
                    else:
                        side[price] = quantity
            self._validate()
        except BookInvariantError:
            for side, undo in ((self.asks, undo_asks), (self.bids, undo_bids)):
                for price, previous in reversed(undo):
                    if previous is None:
                        side.pop(price, None)
                    else:
                        side[price] = previous
            raise
        self.last_update_id = event.final_update_id
        self._has_stream_event = True
        self._last_applied_range = (event.first_update_id, event.final_update_id)
        self._last_applied_payload = (event.bids, event.asks)
        return ApplyResult.APPLIED

    def _validate(self) -> None:
        if len(self.bids) > self._max_levels or len(self.asks) > self._max_levels:
            raise BookInvariantError("Límite de memoria del libro excedido")
        if self.bids and self.asks:
            best_bid = self.bids.peekitem(-1)[0]
            best_ask = self.asks.peekitem(0)[0]
            if best_bid >= best_ask:
                raise BookInvariantError(
                    f"Libro cruzado: best_bid={best_bid}, best_ask={best_ask}"
                )
        if self._snapshot_bid_floor is not None:
            if (
                len(self.bids) < 20
                or self.bids.peekitem(-20)[0] <= self._snapshot_bid_floor
            ):
                raise BookBoundaryError("Top-20 bid alcanzó la frontera conocida")
        if self._snapshot_ask_ceiling is not None:
            if (
                len(self.asks) < 20
                or self.asks.peekitem(19)[0] >= self._snapshot_ask_ceiling
            ):
                raise BookBoundaryError("Top-20 ask alcanzó la frontera conocida")

    def top(
        self, levels: int = 20
    ) -> tuple[list[tuple[str, str]], list[tuple[str, str]]]:
        bids, asks = self.top_wire(levels)
        return list(bids), list(asks)

    def top_wire(
        self, levels: int = 20
    ) -> tuple[tuple[tuple[str, str], ...], tuple[tuple[str, str], ...]]:
        fixed_bids, fixed_asks = self.top_fixed(levels)
        bids = tuple(
            (format_fixed(price), format_fixed(quantity))
            for price, quantity in fixed_bids
        )
        asks = tuple(
            (format_fixed(price), format_fixed(quantity))
            for price, quantity in fixed_asks
        )
        return bids, asks

    def top_fixed(
        self, levels: int = 20
    ) -> tuple[tuple[tuple[int, int], ...], tuple[tuple[int, int], ...]]:
        bids = tuple(reversed(self.bids.items()[-levels:]))
        asks = tuple(self.asks.items()[:levels])
        return bids, asks


def retained_after_snapshot(
    snapshot_id: int,
    buffered: list[DiffDepthEvent],
    *,
    market: str = "spot",
) -> list[DiffDepthEvent]:
    if market == "spot":
        retained = [event for event in buffered if event.final_update_id > snapshot_id]
        if retained and retained[0].first_update_id > snapshot_id + 1:
            # Tras descartar u <= L, el primer diff debe cubrir el siguiente
            # update requerido: U <= L+1 <= u. Un U=L+1 es continuidad valida.
            raise SequenceGap(snapshot_id + 1, retained[0].first_update_id)
        return retained
    if market != "usdm_futures":
        raise ValueError(f"Mercado no soportado: {market!r}")
    retained = [event for event in buffered if event.final_update_id >= snapshot_id]
    if retained and not (
        retained[0].first_update_id <= snapshot_id <= retained[0].final_update_id
    ):
        raise SequenceGap(snapshot_id, retained[0].first_update_id)
    if retained:
        previous = retained[0].final_update_id
        for event in retained[1:]:
            if event.previous_final_update_id != previous:
                received = event.previous_final_update_id
                if received is None:
                    raise BookInvariantError("Diff Futures sin pu en bootstrap")
                raise PreviousSequenceGap(previous, received)
            if event.final_update_id <= previous:
                raise BookInvariantError("La cadena Futures no avanza u")
            previous = event.final_update_id
    return retained


def validate_partial_depth(event: PartialDepthEvent) -> None:
    if len(event.bids) > 20 or len(event.asks) > 20:
        raise BookInvariantError("Partial depth excede 20 niveles")
    parsed_sides: list[list[int]] = []
    for name, levels in (("bids", event.bids), ("asks", event.asks)):
        prices: list[int] = []
        for raw in levels:
            price, quantity = _fixed_pair(raw)
            if quantity <= 0:
                raise BookInvariantError(
                    f"{name} partial contiene cantidad no positiva"
                )
            prices.append(price)
        if len(prices) != len(set(prices)):
            raise BookInvariantError(f"{name} partial contiene precios duplicados")
        parsed_sides.append(prices)
    bids, asks = parsed_sides
    if bids != sorted(bids, reverse=True):
        raise BookInvariantError("Bids partial fuera de orden descendente")
    if asks != sorted(asks):
        raise BookInvariantError("Asks partial fuera de orden ascendente")
    if bids and asks and bids[0] >= asks[0]:
        raise BookInvariantError("Partial depth cruzado")
