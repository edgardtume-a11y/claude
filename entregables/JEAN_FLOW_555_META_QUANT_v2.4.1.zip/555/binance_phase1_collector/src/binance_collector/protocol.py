from __future__ import annotations

from typing import Any, Callable

import orjson

from .models import (
    AggTradeEvent,
    DiffDepthEvent,
    MarketEvent,
    PartialDepthEvent,
    RawEnvelope,
    parse_levels,
    require_dict,
)


class ProtocolError(ValueError):
    pass


class ServerShutdownNotice(RuntimeError):
    pass


def _integer(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ProtocolError(f"{field} debe ser int")
    return value


def _string(value: Any, field: str) -> str:
    if not isinstance(value, str):
        raise ProtocolError(f"{field} debe ser string")
    return value


def _boolean(value: Any, field: str) -> bool:
    if not isinstance(value, bool):
        raise ProtocolError(f"{field} debe ser bool")
    return value


def _validate_usdm_discriminator(data: dict[str, Any]) -> bool:
    """Fail closed only if a present ``st`` identifies a non-USDⓈ-M feed.

    Los payloads documentados de ``aggTrade`` y ``depthUpdate`` en fstream NO
    llevan ``st``; exigirlo rechazaba el 100 % del tráfico Futures real
    (auditoría v2.2.2, hallazgo [P1]/P0.1). El campo se valida solo si llega
    (tolerancia hacia delante): presente y distinto de 1 sigue siendo un
    rechazo fail-closed contra un feed COIN-M fusionado.

    Returns ``True`` cuando el campo estuvo ausente, para que el llamador
    pueda contabilizarlo (`usdm_st_absent`).
    """

    if "st" not in data:
        return True
    symbol_type = _integer(data.get("st"), "st")
    if symbol_type != 1:
        raise ProtocolError(f"Evento no USDⓈ-M recibido: st={symbol_type}")
    return False


def _validate_source_socket(
    *,
    market: str,
    stream: str,
    stream_names: tuple[str, str, str],
    connection_id: str,
    source_socket_id: str,
) -> None:
    if market == "spot":
        role = "spot_combined"
    elif stream == stream_names[0]:
        role = "usdm_market_trades"
    else:
        role = "usdm_public_depth"
    expected = f"{connection_id}:{role}"
    if source_socket_id != expected:
        raise ProtocolError(
            "Stream recibido por socket causal incorrecto: "
            f"stream={stream!r}, esperado={expected!r}, "
            f"recibido={source_socket_id!r}"
        )


def decode_combined(
    envelope: RawEnvelope,
    *,
    symbol: str,
    stream_names: tuple[str, str, str],
    market: str = "spot",
    on_usdm_st_absent: Callable[[], None] | None = None,
) -> MarketEvent:
    try:
        wrapper = require_dict(orjson.loads(envelope.payload), "wrapper")
        stream = _string(wrapper.get("stream"), "stream")
        data = require_dict(wrapper.get("data"), "data")
        if stream == "!serverShutdown" or data.get("e") == "serverShutdown":
            raise ServerShutdownNotice("Binance anunció serverShutdown")
        if market not in {"spot", "usdm_futures"}:
            raise ProtocolError(f"Mercado no soportado: {market!r}")
        _validate_source_socket(
            market=market,
            stream=stream,
            stream_names=stream_names,
            connection_id=envelope.connection_id,
            source_socket_id=envelope.source_socket_id,
        )
        if market == "usdm_futures":
            if _validate_usdm_discriminator(data) and on_usdm_st_absent is not None:
                on_usdm_st_absent()
        if stream == stream_names[0]:
            if _string(data.get("e"), "e") != "aggTrade":
                raise ProtocolError("Tipo de evento inesperado para aggTrade")
            event = AggTradeEvent(
                connection_id=envelope.connection_id,
                event_time_ms=_integer(data.get("E"), "E"),
                trade_time_ms=_integer(data.get("T"), "T"),
                symbol=_string(data.get("s"), "s"),
                aggregate_trade_id=_integer(data.get("a"), "a"),
                first_trade_id=_integer(data.get("f"), "f"),
                last_trade_id=_integer(data.get("l"), "l"),
                price=_string(data.get("p"), "p"),
                quantity=_string(data.get("q"), "q"),
                buyer_is_maker=_boolean(data.get("m"), "m"),
                receive_utc_ns=envelope.receive_utc_ns,
                receive_monotonic_ns=envelope.receive_monotonic_ns,
                payload_bytes=envelope.payload_bytes,
                raw_queue_size=envelope.raw_queue_size,
                capture_session_id=envelope.capture_session_id,
                ingest_seq=envelope.ingest_seq,
                source_socket_id=envelope.source_socket_id,
            )
            if event.symbol != symbol:
                raise ProtocolError(f"Símbolo inesperado: {event.symbol}")
            return event
        if stream == stream_names[1]:
            if market == "spot":
                bids = parse_levels(data.get("bids"), "bids")
                asks = parse_levels(data.get("asks"), "asks")
                last_update_id = _integer(
                    data.get("lastUpdateId"), "lastUpdateId"
                )
                event_time_ms = None
                first_update_id = None
                previous_final_update_id = None
                transaction_time_ms = None
            else:
                if _string(data.get("e"), "e") != "depthUpdate":
                    raise ProtocolError("Tipo inesperado para depth20 Futures")
                received_symbol = _string(data.get("s"), "s")
                if received_symbol != symbol:
                    raise ProtocolError(f"Símbolo inesperado: {received_symbol}")
                bids = parse_levels(data.get("b"), "b")
                asks = parse_levels(data.get("a"), "a")
                event_time_ms = _integer(data.get("E"), "E")
                first_update_id = _integer(data.get("U"), "U")
                last_update_id = _integer(data.get("u"), "u")
                previous_final_update_id = _integer(data.get("pu"), "pu")
                transaction_time_ms = _integer(data.get("T"), "T")
                if first_update_id > last_update_id:
                    raise ProtocolError("U no puede ser mayor que u")
            if len(bids) > 20 or len(asks) > 20:
                raise ProtocolError("depth20 contiene más de 20 niveles por lado")
            return PartialDepthEvent(
                connection_id=envelope.connection_id,
                last_update_id=last_update_id,
                bids=bids,
                asks=asks,
                receive_utc_ns=envelope.receive_utc_ns,
                receive_monotonic_ns=envelope.receive_monotonic_ns,
                payload_bytes=envelope.payload_bytes,
                raw_queue_size=envelope.raw_queue_size,
                capture_session_id=envelope.capture_session_id,
                ingest_seq=envelope.ingest_seq,
                source_socket_id=envelope.source_socket_id,
                event_time_ms=event_time_ms,
                first_update_id=first_update_id,
                previous_final_update_id=previous_final_update_id,
                transaction_time_ms=transaction_time_ms,
            )
        if stream == stream_names[2]:
            if _string(data.get("e"), "e") != "depthUpdate":
                raise ProtocolError("Tipo de evento inesperado para depth diff")
            event = DiffDepthEvent(
                connection_id=envelope.connection_id,
                event_time_ms=_integer(data.get("E"), "E"),
                symbol=_string(data.get("s"), "s"),
                first_update_id=_integer(data.get("U"), "U"),
                final_update_id=_integer(data.get("u"), "u"),
                bids=parse_levels(data.get("b"), "b"),
                asks=parse_levels(data.get("a"), "a"),
                receive_utc_ns=envelope.receive_utc_ns,
                receive_monotonic_ns=envelope.receive_monotonic_ns,
                payload_bytes=envelope.payload_bytes,
                raw_queue_size=envelope.raw_queue_size,
                capture_session_id=envelope.capture_session_id,
                ingest_seq=envelope.ingest_seq,
                source_socket_id=envelope.source_socket_id,
                previous_final_update_id=(
                    _integer(data.get("pu"), "pu")
                    if market == "usdm_futures"
                    else None
                ),
                transaction_time_ms=(
                    _integer(data.get("T"), "T")
                    if market == "usdm_futures"
                    else None
                ),
            )
            if event.symbol != symbol:
                raise ProtocolError(f"Símbolo inesperado: {event.symbol}")
            if event.first_update_id > event.final_update_id:
                raise ProtocolError("U no puede ser mayor que u")
            return event
        raise ProtocolError(f"Stream combinado inesperado: {stream}")
    except (KeyError, TypeError, ValueError, orjson.JSONDecodeError) as exc:
        if isinstance(exc, ProtocolError):
            raise
        raise ProtocolError(str(exc)) from exc
