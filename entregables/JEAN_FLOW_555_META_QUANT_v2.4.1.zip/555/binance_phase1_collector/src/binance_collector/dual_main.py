from __future__ import annotations

import argparse
import asyncio
import hashlib
import logging
import os
import signal
import time
import webbrowser
from contextlib import suppress
from pathlib import Path
from typing import Any

from . import __version__
from .collector import BinanceCollector
from .config import Settings
from .dashboard import DashboardServer, MarketStateHub
from .identity import CaptureSession, IngestSequencer
from .latency import fine_timer_resolution, low_latency_runtime
from .main import _configure_logging
from .models import SCHEMA_VERSION
from .runtime import (
    READY_PROTOCOL_VERSION,
    RuntimeContractError,
    SessionManifest,
    atomic_write_json,
    default_runtime_identity,
    read_json_object,
)


LOGGER = logging.getLogger("jean_flow")
HEARTBEAT_MAX_AGE_NS = 5_000_000_000
# [2.3.2] Tope duro del estancamiento tolerado del heartbeat del launcher
# MIENTRAS su PID siga vivo. Evidencia de campo (sesión 45896a2c99aa,
# Windows 11 + HDD USB): una escritura del heartbeat bloqueada >5 s por E/S
# lenta (antivirus/spin-up) mató un motor SYNCED con exit 20 aunque el
# launcher seguía vivo — el archivo se actualizó 52 ms DESPUÉS del suicidio.
# La pérdida real del launcher (PID muerto) sigue siendo fatal en <=5 s.
HEARTBEAT_STALL_HARD_CAP_NS = 60_000_000_000


class ReadyTimeout(RuntimeContractError):
    def __init__(self, health: dict[str, Any]) -> None:
        reasons = health.get("rejection_reasons") or ["sin detalle"]
        super().__init__(
            "READY_TIMEOUT",
            "Spot y Futures no alcanzaron READY: " + "; ".join(map(str, reasons)),
        )


def _argument(args: argparse.Namespace, name: str, default: Any = None) -> Any:
    return getattr(args, name, default)


def _ready_payload(health: dict[str, Any]) -> dict[str, Any]:
    if health.get("operational_ready") is not True:
        raise RuntimeContractError(
            "READY_INVALID", "No se publica READY con mercados no sincronizados"
        )
    payload = dict(health)
    payload.update(
        {
            "ready": True,
            "ready_protocol_version": READY_PROTOCOL_VERSION,
            "ready_published_utc_ns": time.time_ns(),
        }
    )
    return payload


def _validate_stop_request(
    path: Path,
    *,
    capture_session_id: str,
    launcher_pid: int | None,
    process_start_utc_ns: int,
) -> None:
    try:
        payload = read_json_object(path)
    except RuntimeContractError as exc:
        raise RuntimeContractError("STOP_INVALID", str(exc)) from exc
    if payload.get("capture_session_id") != capture_session_id:
        raise RuntimeContractError("STOP_INVALID", "STOP pertenece a otra sesión")
    if launcher_pid is None or payload.get("requested_by_pid") != launcher_pid:
        raise RuntimeContractError("STOP_INVALID", "STOP no pertenece al launcher")
    requested_utc_ns = payload.get("requested_utc_ns")
    if (
        not isinstance(requested_utc_ns, int)
        or isinstance(requested_utc_ns, bool)
        or requested_utc_ns < process_start_utc_ns
        or requested_utc_ns > time.time_ns() + 5_000_000_000
    ):
        raise RuntimeContractError("STOP_INVALID", "Timestamp STOP inválido")
    if payload.get("reason") != "launcher_shutdown":
        raise RuntimeContractError("STOP_INVALID", "Motivo STOP no permitido")


def _capture_commitment(
    output_dir: Path,
    collectors: dict[str, BinanceCollector],
    *,
    capture_session_id: str,
    last_ingest_seq: int,
) -> dict[str, Any]:
    markets: dict[str, Any] = {}
    for market, collector in collectors.items():
        expected_parent = (output_dir / market).resolve()
        entries: list[dict[str, Any]] = []
        for path in sorted(collector.writer.finalized_files):
            resolved = path.resolve()
            if (
                not resolved.is_file()
                or resolved.is_symlink()
                or not resolved.is_relative_to(expected_parent)
                or resolved.suffix.lower() != ".csv"
            ):
                raise RuntimeContractError(
                    "JOURNAL_COMMITMENT_INVALID", f"Segmento inseguro: {resolved}"
                )
            digest = hashlib.sha256()
            with resolved.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(chunk)
            entries.append(
                {
                    "path": resolved.relative_to(output_dir).as_posix(),
                    "size_bytes": resolved.stat().st_size,
                    "sha256": digest.hexdigest(),
                }
            )
        if not entries:
            raise RuntimeContractError(
                "JOURNAL_COMMITMENT_INVALID", f"{market} no finalizó ningún CSV"
            )
        markets[market] = {
            "files": entries,
            "file_count": len(entries),
            "total_bytes": sum(int(entry["size_bytes"]) for entry in entries),
        }
    if set(markets) != {"spot", "usdm_futures"} or last_ingest_seq <= 0:
        raise RuntimeContractError(
            "JOURNAL_COMMITMENT_INVALID", "Mercados o secuencia final incompletos"
        )
    return {
        "capture_session_id": capture_session_id,
        "last_ingest_seq": last_ingest_seq,
        "markets": markets,
        "committed_utc_ns": time.time_ns(),
    }


def _validate_launcher_heartbeat(
    path: Path,
    *,
    capture_session_id: str,
    launcher_pid: int | None,
) -> None:
    """P0.3: distingue lectura transitoria de identidad/frescura fatales.

    ``PARENT_HEARTBEAT_UNREADABLE``: el archivo no se pudo leer/parsear en
    este tick (en Windows la reescritura atómica del launcher colisiona de
    forma rutinaria con la lectura). ``PARENT_HEARTBEAT_STALE`` [2.3.2]:
    contenido de ESTA sesión pero con frescura expirada o timestamps
    incoherentes — típico de una escritura bloqueada por E/S lenta o de un
    salto de reloj; el monitor decide con ``_heartbeat_failure_action`` si
    lo tolera (PID del launcher vivo, dentro del tope duro) o lo escala.
    ``PARENT_HEARTBEAT_LOST``: contenido válido pero de otra sesión/otro
    launcher — fatal inmediato, sin tolerancia.
    """

    try:
        payload = read_json_object(path)
    except RuntimeContractError as exc:
        raise RuntimeContractError("PARENT_HEARTBEAT_UNREADABLE", str(exc)) from exc
    now = time.time_ns()
    started = payload.get("started_utc_ns")
    updated = payload.get("updated_utc_ns")
    if (
        payload.get("capture_session_id") != capture_session_id
        or launcher_pid is None
        or payload.get("launcher_pid") != launcher_pid
    ):
        raise RuntimeContractError(
            "PARENT_HEARTBEAT_LOST", "Heartbeat de otra sesión u otro launcher"
        )
    if (
        not isinstance(started, int)
        or isinstance(started, bool)
        or not isinstance(updated, int)
        or isinstance(updated, bool)
        or updated < started
        or updated > now + HEARTBEAT_MAX_AGE_NS
        or now - updated > HEARTBEAT_MAX_AGE_NS
    ):
        raise RuntimeContractError(
            "PARENT_HEARTBEAT_STALE", "Heartbeat obsoleto o con timestamps inválidos"
        )


def _pid_alive(pid: object) -> bool:
    """¿Sigue existiendo el proceso `pid`? Sin dependencias externas.

    Segundo factor del watchdog [2.3.2]: un heartbeat estancado con launcher
    VIVO es un disco lento, no un huérfano. En Windows usa OpenProcess con
    PROCESS_QUERY_LIMITED_INFORMATION; ERROR_ACCESS_DENIED implica que el
    proceso existe. En POSIX usa kill(pid, 0). Ante un fallo no clasificable
    devuelve False (fail-closed: sin evidencia de vida no se extiende la
    tolerancia).
    """

    if not isinstance(pid, int) or isinstance(pid, bool) or pid <= 0:
        return False
    if os.name == "nt":
        import ctypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        process_query_limited_information = 0x1000
        error_access_denied = 5
        still_active = 259
        handle = kernel32.OpenProcess(
            process_query_limited_information, False, pid
        )
        if not handle:
            return ctypes.get_last_error() == error_access_denied
        try:
            exit_code = ctypes.c_ulong()
            if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                return True
            return exit_code.value == still_active
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _heartbeat_failure_action(
    code: str, *, since_valid_ns: int, pid_alive: bool
) -> str:
    """Política pura del monitor ante un heartbeat fallido: tolerate|fatal.

    - Identidad ajena (``PARENT_HEARTBEAT_LOST``): fatal siempre.
    - Ilegible o estancado dentro de ``HEARTBEAT_MAX_AGE_NS`` desde la última
      lectura válida: tolerado (comportamiento P0.3 previo).
    - Más allá de eso, SOLO se tolera si el PID del launcher sigue vivo y no
      se superó ``HEARTBEAT_STALL_HARD_CAP_NS`` — cubre estancamientos de E/S
      reales sin renunciar al cierre fail-closed del huérfano: con launcher
      muerto se cae en <=``HEARTBEAT_MAX_AGE_NS``; con PID reutilizado, el
      tope duro acota la vida extra a 60 s.
    """

    if code not in ("PARENT_HEARTBEAT_UNREADABLE", "PARENT_HEARTBEAT_STALE"):
        return "fatal"
    if since_valid_ns <= HEARTBEAT_MAX_AGE_NS:
        return "tolerate"
    if pid_alive and since_valid_ns <= HEARTBEAT_STALL_HARD_CAP_NS:
        return "tolerate"
    return "fatal"


async def _run(args: argparse.Namespace) -> None:
    run_seconds = _argument(args, "run_seconds")
    healthy_seconds = _argument(args, "healthy_seconds")
    ready_timeout = _argument(args, "ready_timeout", 180.0)
    if run_seconds is not None and run_seconds <= 0:
        raise ValueError("--run-seconds debe ser positivo")
    if healthy_seconds is not None and healthy_seconds <= 0:
        raise ValueError("--healthy-seconds debe ser positivo")
    if ready_timeout is not None and ready_timeout <= 0:
        raise ValueError("--ready-timeout debe ser positivo")

    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    fallback_signal_handlers: list[tuple[signal.Signals, object]] = []
    for signal_name in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(signal_name, stop.set)
        except (NotImplementedError, RuntimeError):
            try:
                previous = signal.getsignal(signal_name)
                signal.signal(
                    signal_name,
                    lambda *_ignored: loop.call_soon_threadsafe(stop.set),
                )
                fallback_signal_handlers.append((signal_name, previous))
            except (ValueError, OSError, AttributeError):
                pass

    base_output: Path = args.output_dir.resolve()
    base_output.mkdir(parents=True, exist_ok=True)
    spot_settings = Settings.for_market(
        "spot",
        symbol=args.symbol,
        output_dir=base_output / "spot",
    )
    futures_settings = Settings.for_market(
        "usdm_futures",
        symbol=args.symbol,
        output_dir=base_output / "usdm_futures",
    )
    session_id = _argument(args, "session_id")
    capture_session = (
        CaptureSession(session_id, IngestSequencer())
        if session_id
        else CaptureSession.create()
    )
    control_dir = base_output / "control"
    session_file = Path(
        _argument(args, "session_file") or control_dir / "session.json"
    ).resolve()
    ready_file = Path(_argument(args, "ready_file") or control_dir / "READY.json").resolve()
    stop_file_value = _argument(args, "stop_file")
    stop_file = Path(stop_file_value).resolve() if stop_file_value else None
    heartbeat_file_value = _argument(args, "heartbeat_file")
    heartbeat_file = (
        Path(heartbeat_file_value).resolve() if heartbeat_file_value else None
    )
    if ready_file.exists():
        raise RuntimeContractError(
            "READY_FILE_EXISTS", f"No se reutiliza un READY anterior: {ready_file}"
        )

    project_root = Path(__file__).resolve().parents[2]
    process_start_utc_ns = time.time_ns()
    identity = default_runtime_identity(
        engine_version=__version__,
        data_schema_version=SCHEMA_VERSION,
        capture_session_id=capture_session.capture_session_id,
        launcher_pid=_argument(args, "parent_pid"),
        process_start_utc_ns=process_start_utc_ns,
        symbol=spot_settings.symbol,
        project_root=project_root,
        output_dir=base_output,
        package_file=Path(__file__).resolve(),
        endpoints=(
            ("spot", spot_settings.ws_base_url, spot_settings.rest_base_url),
            (
                "usdm_futures",
                futures_settings.ws_base_url,
                futures_settings.rest_base_url,
            ),
        ),
    )
    manifest = SessionManifest.attach_or_create(
        session_file,
        capture_session_id=capture_session.capture_session_id,
        launcher_pid=identity.launcher_pid,
        project_root=project_root,
        output_dir=base_output,
    )
    manifest.transition("STARTING", identity=identity)

    hub = MarketStateHub(top_levels=args.dom_levels)
    dashboard = DashboardServer(
        hub,
        host="127.0.0.1",
        port=args.dashboard_port,
        identity=identity,
    )
    wall_timer: asyncio.Task[None] | None = None
    collector_errors: list[Exception] = []
    monitor_errors: list[RuntimeContractError] = []
    ready_published = False
    healthy_duration_completed = healthy_seconds is None
    healthy_started_monotonic_ns: int | None = None
    healthy_completed_monotonic_ns: int | None = None
    healthy_resets = 0
    completed = False
    if run_seconds is not None:

        async def stop_later() -> None:
            await asyncio.sleep(run_seconds)
            stop.set()

        wall_timer = asyncio.create_task(stop_later(), name="dual-run-timer")

    try:
        async with dashboard:
            identity = identity.with_bound_port(dashboard.port)
            dashboard.set_identity(identity)
            initial_health = dashboard.health_payload()
            manifest.transition(
                "IDENTITY_READY", identity=identity, health=initial_health
            )
            LOGGER.info(
                "IDENTITY_READY url=%s symbol=%s markets=spot,usdm_futures "
                "capture_session_id=%s pid=%s",
                dashboard.url,
                spot_settings.symbol,
                capture_session.capture_session_id,
                os.getpid(),
            )

            async def run_fail_stop(collector: BinanceCollector) -> None:
                try:
                    await collector.run(stop)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    collector_errors.append(exc)
                    stop.set()

            async def monitor_readiness() -> None:
                nonlocal ready_published, healthy_duration_completed
                nonlocal healthy_started_monotonic_ns, healthy_completed_monotonic_ns
                nonlocal healthy_resets
                started_ns = time.monotonic_ns()
                healthy_since_ns: int | None = None
                browser_attempted = False
                last_operational: bool | None = None
                last_valid_heartbeat_ns = time.monotonic_ns()
                last_ready_refresh_ns = 0
                while not stop.is_set():
                    if heartbeat_file is not None:
                        try:
                            _validate_launcher_heartbeat(
                                heartbeat_file,
                                capture_session_id=capture_session.capture_session_id,
                                launcher_pid=identity.launcher_pid,
                            )
                            last_valid_heartbeat_ns = time.monotonic_ns()
                        except RuntimeContractError as exc:
                            # P0.3 + [2.3.2]: una lectura fallida o un
                            # heartbeat estancado no son pérdida del launcher
                            # mientras su PID siga vivo y no se supere el tope
                            # duro; la identidad ajena sigue siendo fatal.
                            since_valid_ns = (
                                time.monotonic_ns() - last_valid_heartbeat_ns
                            )
                            action = _heartbeat_failure_action(
                                exc.code,
                                since_valid_ns=since_valid_ns,
                                pid_alive=_pid_alive(identity.launcher_pid),
                            )
                            if action == "tolerate":
                                LOGGER.warning(
                                    "HEARTBEAT_READ_TRANSIENT code=%s "
                                    "age_s=%.1f detail=%s",
                                    exc.code,
                                    since_valid_ns / 1e9,
                                    exc,
                                )
                            else:
                                if exc.code != "PARENT_HEARTBEAT_LOST":
                                    exc = RuntimeContractError(
                                        "PARENT_HEARTBEAT_LOST",
                                        "Frescura del heartbeat expirada sin "
                                        f"launcher vivo ({exc.code}, "
                                        f"{since_valid_ns / 1e9:.1f}s): {exc}",
                                    )
                                monitor_errors.append(exc)
                                stop.set()
                                break
                    if stop_file is not None and stop_file.exists():
                        try:
                            _validate_stop_request(
                                stop_file,
                                capture_session_id=capture_session.capture_session_id,
                                launcher_pid=identity.launcher_pid,
                                process_start_utc_ns=process_start_utc_ns,
                            )
                        except RuntimeContractError as exc:
                            # P2.4: fail-closed se conserva (cualquier STOP
                            # detiene), pero un STOP inválido queda registrado
                            # con un código propio para distinguir sabotaje o
                            # basura de un cierre legítimo del launcher.
                            monitor_errors.append(
                                RuntimeContractError(
                                    "STOP_TAMPERED",
                                    f"STOP inválido detiene la captura: {exc}",
                                )
                            )
                        LOGGER.info("STOP_REQUESTED path=%s", stop_file)
                        stop.set()
                        break
                    health = dashboard.health_payload()
                    operational = health.get("operational_ready") is True
                    if operational:
                        if healthy_since_ns is None:
                            healthy_since_ns = time.monotonic_ns()
                            healthy_started_monotonic_ns = healthy_since_ns
                        if not ready_published:
                            ready = _ready_payload(health)
                            atomic_write_json(ready_file, ready)
                            last_ready_refresh_ns = time.monotonic_ns()
                            manifest.transition(
                                "CAPTURING", identity=identity, health=health
                            )
                            ready_published = True
                            LOGGER.info(
                                "READY_VALID url=%s session=%s pid=%s",
                                dashboard.url,
                                capture_session.capture_session_id,
                                os.getpid(),
                            )
                        elif (
                            time.monotonic_ns() - last_ready_refresh_ns
                            >= 5_000_000_000
                        ):
                            # [P11]: READY se publicaba UNA vez y caducaba a
                            # los 15 s; un launcher momentáneamente lento lo
                            # encontraba obsoleto de forma terminal. Mientras
                            # ambos mercados sigan operativos se refresca el
                            # mismo contenido con timestamp nuevo.
                            try:
                                atomic_write_json(
                                    ready_file,
                                    _ready_payload(health),
                                    replace_retries=5,
                                )
                                last_ready_refresh_ns = time.monotonic_ns()
                            except RuntimeContractError as exc:
                                LOGGER.warning(
                                    "READY_REFRESH_FAILED detail=%s", exc
                                )
                        # [2.4.1] Segunda puerta del panel. El launcher
                        # supervisado ya pasa --no-browser, pero este módulo
                        # es también un entry point público (`jean-flow`):
                        # invocado a mano con --healthy-seconds abriría el
                        # navegador en plena etapa certificable, le quitaría
                        # el primer plano a la captura y Windows la
                        # degradaría (EcoQoS). Una etapa con duración sana
                        # exigida NO abre el panel por ningún camino.
                        if not args.no_browser and not browser_attempted:
                            browser_attempted = True
                            if healthy_seconds is not None:
                                LOGGER.info(
                                    "BROWSER_SKIPPED reason=%s url=%s",
                                    "CERTIFICATION_FOREGROUND_PROTECTION",
                                    dashboard.url,
                                )
                            else:
                                try:
                                    opened = await asyncio.to_thread(
                                        webbrowser.open, dashboard.url
                                    )
                                except Exception as exc:
                                    LOGGER.warning(
                                        "BROWSER_OPEN_FAILED url=%s error=%s",
                                        dashboard.url,
                                        exc,
                                    )
                                else:
                                    if not opened:
                                        LOGGER.warning(
                                            "BROWSER_OPEN_FAILED url=%s result=false",
                                            dashboard.url,
                                        )
                        if healthy_seconds is not None and healthy_since_ns is not None:
                            healthy_elapsed = (
                                time.monotonic_ns() - healthy_since_ns
                            ) / 1_000_000_000
                            if healthy_elapsed >= healthy_seconds:
                                healthy_duration_completed = True
                                healthy_completed_monotonic_ns = time.monotonic_ns()
                                LOGGER.info(
                                    "HEALTHY_DURATION_COMPLETE seconds=%s",
                                    healthy_seconds,
                                )
                                stop.set()
                                break
                    else:
                        if healthy_since_ns is not None:
                            healthy_resets += 1
                        healthy_since_ns = None
                        if ready_published and last_operational is True:
                            manifest.transition(
                                "CAPTURING", identity=identity, health=health
                            )
                            LOGGER.warning(
                                "READY_DEGRADED reasons=%s",
                                health.get("rejection_reasons"),
                            )

                    if (
                        not ready_published
                        and ready_timeout is not None
                        and (time.monotonic_ns() - started_ns) / 1_000_000_000
                        >= ready_timeout
                    ):
                        monitor_errors.append(ReadyTimeout(health))
                        stop.set()
                        break
                    last_operational = operational
                    try:
                        await asyncio.wait_for(stop.wait(), timeout=0.1)
                    except TimeoutError:
                        pass

            collectors = {
                "spot": BinanceCollector(
                    spot_settings,
                    dashboard_hub=hub,
                    capture_session=capture_session,
                ),
                "usdm_futures": BinanceCollector(
                    futures_settings,
                    dashboard_hub=hub,
                    capture_session=capture_session,
                ),
            }
            async with asyncio.TaskGroup() as group:
                group.create_task(
                    run_fail_stop(collectors["spot"]),
                    name="collector-spot",
                )
                group.create_task(
                    run_fail_stop(collectors["usdm_futures"]),
                    name="collector-usdm-futures",
                )
                group.create_task(monitor_readiness(), name="runtime-readiness")

            if collector_errors:
                raise ExceptionGroup("Falló la captura dual", collector_errors)
            if monitor_errors:
                raise monitor_errors[0]
            if not ready_published:
                raise RuntimeContractError(
                    "READY_NOT_REACHED", "La ejecución terminó antes de publicar READY"
                )
            if not healthy_duration_completed:
                raise RuntimeContractError(
                    "HEALTHY_DURATION_INCOMPLETE",
                    "La etapa terminó antes de completar su ventana saludable",
                )
            commitment = await asyncio.to_thread(
                _capture_commitment,
                base_output,
                collectors,
                capture_session_id=capture_session.capture_session_id,
                last_ingest_seq=capture_session.ingest_sequencer.last_value,
            )
            manifest.transition(
                "STOPPING", identity=identity, health=dashboard.health_payload()
            )
        manifest.transition(
            "COMPLETED",
            identity=identity,
            result={
                "code": "ENGINE_COMPLETED",
                "completed_utc_ns": time.time_ns(),
                "ready_published": ready_file.exists(),
                "required_healthy_seconds": healthy_seconds,
                "healthy_duration_completed": healthy_duration_completed,
                "healthy_started_monotonic_ns": healthy_started_monotonic_ns,
                "healthy_completed_monotonic_ns": healthy_completed_monotonic_ns,
                "healthy_resets": healthy_resets,
                "capture_commitment": commitment,
            },
        )
        completed = True
    except BaseException as exc:
        if not completed:
            code = exc.code if isinstance(exc, RuntimeContractError) else "ENGINE_FAILED"
            with suppress(RuntimeContractError):
                manifest.transition(
                    "FAILED",
                    identity=identity,
                    error_code=code,
                    error_message=str(exc),
                )
        raise
    finally:
        stop.set()
        if wall_timer is not None:
            wall_timer.cancel()
            with suppress(asyncio.CancelledError):
                await wall_timer
        for signal_name, previous in fallback_signal_handlers:
            signal.signal(signal_name, previous)  # type: ignore[arg-type]


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "JEAN_FLOW Fase 1: Binance Spot + USDⓈ-M, identidad READY y captura causal"
        )
    )
    parser.add_argument("--symbol", default="TUTUSDT", help="Símbolo, por defecto TUTUSDT")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("data_dual"),
        help="Raíz de journals; crea spot/ y usdm_futures/",
    )
    parser.add_argument(
        "--dashboard-port",
        type=int,
        default=0,
        help="Puerto local; 0 hace que el motor reserve uno sin carrera",
    )
    parser.add_argument(
        "--dom-levels",
        type=int,
        default=100,
        help="Top-N niveles publicados al monitor, 1..500",
    )
    parser.add_argument("--run-seconds", type=float, help="Finaliza tras N segundos de reloj")
    parser.add_argument(
        "--healthy-seconds",
        type=float,
        help="Finaliza tras N segundos consecutivos con ambos libros READY",
    )
    parser.add_argument(
        "--ready-timeout",
        type=float,
        default=180.0,
        help="Máximo para sincronizar ambos mercados",
    )
    parser.add_argument("--session-id", help="Identidad impuesta por el launcher")
    parser.add_argument("--parent-pid", type=int, help="PID del launcher supervisor")
    parser.add_argument("--session-file", type=Path, help="Manifest atómico de sesión")
    parser.add_argument("--ready-file", type=Path, help="READY atómico")
    parser.add_argument("--stop-file", type=Path, help="Solicitud de cierre del launcher")
    parser.add_argument(
        "--heartbeat-file",
        type=Path,
        help="Heartbeat del launcher; evita que el motor quede huérfano",
    )
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="El launcher abrirá el navegador después de validar READY",
    )
    parser.add_argument("--log-level", default="INFO")
    parser.add_argument(
        "--log-file",
        type=Path,
        help="Log JSONL; default <output-dir>/jean_flow_metrics.jsonl",
    )
    args = parser.parse_args()
    log_file = args.log_file or args.output_dir / "jean_flow_metrics.jsonl"
    listener = _configure_logging(args.log_level, log_file=log_file)
    exit_code = 0
    try:
        # [2.3.6/2.3.7] Temporizador fino de 1 ms + exención de EcoQoS y de
        # la coalescencia de Windows 11 durante toda la captura (evidencia:
        # sesiones 5ebb3efde620 y dda44a52ff1f). Se restaura al salir.
        with fine_timer_resolution() as fine_timer:
            with low_latency_runtime() as tuning:
                LOGGER.info(
                    "low_latency_runtime thread_switch_s=%s gc_thresholds=%s "
                    "fine_timer_1ms=%s foreground_qos=%s "
                    "foreground_qos_error=%s",
                    tuning.thread_switch_interval_s,
                    tuning.gc_thresholds,
                    fine_timer["timer_1ms"],
                    fine_timer["foreground_qos"],
                    fine_timer.get("foreground_qos_error"),
                )
                asyncio.run(_run(args))
    except RuntimeContractError as exc:
        LOGGER.error("%s: %s", exc.code, exc)
        exit_code = 20
    except Exception:
        LOGGER.exception("ENGINE_FAILED")
        exit_code = 1
    finally:
        listener.stop()
    if exit_code:
        raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
