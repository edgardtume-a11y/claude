from __future__ import annotations

import argparse
import csv
import glob
import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from .fixed_point import FixedPointError, format_fixed, parse_fixed
from .identity import validate_capture_session_id
from .models import CAUSAL_IDENTITY_SCHEMA_VERSION, SUPPORTED_SCHEMA_VERSIONS


class ReplayError(RuntimeError):
    pass


@dataclass(slots=True)
class ReplayState:
    """Estado del replay en punto fijo escala 1e8 (X5: A_live = A_replay).

    Hasta 2.2.2 el replay usaba Decimal: aceptaba '1E+2', '0.000000005' o
    '100000000000' que el libro vivo rechaza, y su forma canónica
    ('0.09865000') divergía de la del libro vivo ('0.09865'), de modo que los
    hashes vivo↔replay jamás podían compararse ([N2]/[N3]). Ahora ambos lados
    usan la misma gramática (`parse_fixed`) y la misma forma canónica
    (`format_fixed`); el hash canónico es la versión 2.
    """

    CANONICAL_HASH_VERSION = 2

    bids: dict[int, int] = field(default_factory=dict)
    asks: dict[int, int] = field(default_factory=dict)
    generation: int | None = None
    last_update_id: int | None = None
    valid: bool = False
    snapshots: int = 0
    deltas: int = 0
    symbol: str | None = None
    exchange: str | None = None
    market: str | None = None
    active_connection_id: str | None = None
    stream_event_seen: bool = False
    capture_session_id: str | None = None
    causal_identity_version: str | None = None
    ingest_seq_min: int | None = None
    ingest_seq_max: int | None = None
    ingest_unique_count: int = 0
    ingest_duplicate_identical: int = 0
    ingest_conflicts: int = 0
    _ingest_fingerprints: dict[int, int] = field(default_factory=dict)
    source_socket_ids: set[str] = field(default_factory=set)

    def canonical_hash(self) -> str:
        document = {
            "canonical_hash_version": self.CANONICAL_HASH_VERSION,
            "exchange": self.exchange,
            "market": self.market,
            "symbol": self.symbol,
            "generation": self.generation,
            "last_update_id": self.last_update_id,
            "bids": [
                (format_fixed(price), format_fixed(self.bids[price]))
                for price in sorted(self.bids)
            ],
            "asks": [
                (format_fixed(price), format_fixed(self.asks[price]))
                for price in sorted(self.asks)
            ],
        }
        encoded = json.dumps(document, separators=(",", ":"), sort_keys=True).encode()
        return hashlib.sha256(encoded).hexdigest()


def _integer(value: str, field_name: str) -> int:
    if value == "":
        raise ReplayError(f"Falta {field_name}")
    return int(value)


def _validated_levels(
    rows: list[dict[str, str]],
    *,
    expected_record_type: str,
    snapshot: bool,
) -> list[tuple[str, int, int]]:
    """Valida el TEXTO con la gramática estricta del libro vivo (X5).

    `parse_fixed` rechaza signo, exponente, espacios, separadores de locale,
    dígitos Unicode y cualquier valor que requiera redondeo o desborde el
    dominio de 64 bits: exactamente lo mismo que rechaza la captura viva.
    """

    parsed: list[tuple[str, int, int]] = []
    seen: set[tuple[str, int]] = set()
    for row in rows:
        if row["record_type"] != expected_record_type:
            raise ReplayError(f"Tipo de fila de nivel inesperado: {row['record_type']}")
        side = row["side"]
        if side not in {"bid", "ask"}:
            raise ReplayError(f"Side inválido: {side}")
        try:
            price = parse_fixed(row["price"])
            quantity = parse_fixed(row["quantity"])
        except FixedPointError as exc:
            raise ReplayError(
                "Precio/cantidad fuera de la gramática del libro vivo: "
                f"{row['price']!r}/{row['quantity']!r}: {exc}"
            ) from exc
        if price <= 0:
            raise ReplayError(f"Precio inválido: {row['price']!r}")
        if snapshot and quantity == 0:
            raise ReplayError(f"Cantidad inválida: {row['quantity']!r}")
        key = (side, price)
        if key in seen:
            raise ReplayError(
                f"Nivel duplicado dentro del evento: {side} {format_fixed(price)}"
            )
        seen.add(key)
        parsed.append((side, price, quantity))
    return parsed


def _validate_level_row_structure(
    rows: list[dict[str, str]], expected_record_type: str
) -> None:
    for row in rows:
        if row["record_type"] != expected_record_type:
            raise ReplayError(f"Tipo de fila de nivel inesperado: {row['record_type']}")
        if row["side"] not in {"bid", "ask"}:
            raise ReplayError(f"Side inválido: {row['side']}")


def _apply_levels(
    state: ReplayState,
    levels: list[tuple[str, int, int]],
    *,
    snapshot: bool,
) -> None:
    if snapshot:
        state.bids.clear()
        state.asks.clear()
    for side_name, price, quantity in levels:
        side = state.bids if side_name == "bid" else state.asks
        if quantity == 0:
            side.pop(price, None)
        else:
            side[price] = quantity
    if state.bids and state.asks and max(state.bids) >= min(state.asks):
        raise ReplayError("Libro cruzado durante replay")


def _validate_group_identity(rows: list[dict[str, str]]) -> None:
    if not rows:
        raise ReplayError("Grupo CSV vacío")
    event_id = rows[0]["local_event_id"]
    connection_id = rows[0]["connection_id"]
    schema_version = rows[0]["schema_version"]
    capture_session_id = rows[0].get("capture_session_id", "")
    ingest_seq = rows[0].get("ingest_seq", "")
    source_socket_id = rows[0].get("source_socket_id", "")
    for index, row in enumerate(rows):
        if row["schema_version"] not in SUPPORTED_SCHEMA_VERSIONS:
            raise ReplayError(f"Schema no soportado: {row['schema_version']}")
        if row["schema_version"] != schema_version:
            raise ReplayError("Schema cambia dentro del evento")
        if row["local_event_id"] != event_id or row["connection_id"] != connection_id:
            raise ReplayError("Identidad inconsistente dentro del evento")
        if (
            row.get("capture_session_id", "") != capture_session_id
            or row.get("ingest_seq", "") != ingest_seq
            or row.get("source_socket_id", "") != source_socket_id
        ):
            raise ReplayError("Identidad causal v2 cambia dentro del evento")
        if (
            row["exchange"] != rows[0]["exchange"]
            or row["market"] != rows[0]["market"]
            or row["symbol"] != rows[0]["symbol"]
        ):
            raise ReplayError("Exchange/mercado/símbolo cambia dentro del evento")
        if _integer(row["row_index"], "row_index") != index:
            raise ReplayError(f"row_index no contiguo en evento {event_id}")
    if schema_version == CAUSAL_IDENTITY_SCHEMA_VERSION:
        try:
            validate_capture_session_id(capture_session_id)
        except ValueError as exc:
            raise ReplayError(str(exc)) from exc
        if not source_socket_id:
            raise ReplayError("Falta source_socket_id en schema causal v2")
        websocket_record = rows[0]["record_type"] in {
            "AGG_TRADE",
            "L2_PARTIAL",
            "L2_DELTA",
        }
        if websocket_record:
            if _integer(ingest_seq, "ingest_seq") <= 0:
                raise ReplayError("ingest_seq WebSocket debe ser positivo")
            market = rows[0]["market"]
            if market == "spot":
                expected_source_socket_id = f"{connection_id}:spot_combined"
            elif rows[0]["record_type"] == "AGG_TRADE":
                expected_source_socket_id = (
                    f"{connection_id}:usdm_market_trades"
                )
            else:
                expected_source_socket_id = (
                    f"{connection_id}:usdm_public_depth"
                )
            if source_socket_id != expected_source_socket_id:
                raise ReplayError(
                    "source_socket_id no coincide con mercado/canal/conexión: "
                    f"esperado={expected_source_socket_id!r}, "
                    f"recibido={source_socket_id!r}"
                )
        elif ingest_seq != "":
            raise ReplayError(
                "Un registro sintético/REST no debe inventar ingest_seq"
            )
        else:
            expected_source = (
                "rest:depth"
                if rows[0]["record_type"] == "L2_SNAPSHOT"
                else "collector"
            )
            if source_socket_id != expected_source:
                raise ReplayError(
                    "source_socket_id sintético/REST inválido: "
                    f"esperado={expected_source!r}, "
                    f"recibido={source_socket_id!r}"
                )


def _register_causal_identity(
    state: ReplayState,
    header: dict[str, str],
) -> None:
    schema_version = header["schema_version"]
    is_v2 = schema_version == CAUSAL_IDENTITY_SCHEMA_VERSION
    mode = "v2" if is_v2 else "legacy"
    if state.causal_identity_version is None:
        state.causal_identity_version = mode
    elif state.causal_identity_version != mode:
        raise ReplayError("El replay mezcla schemas legacy y causal v2")
    if not is_v2:
        return
    capture_session_id = header["capture_session_id"]
    if state.capture_session_id is None:
        state.capture_session_id = capture_session_id
    elif state.capture_session_id != capture_session_id:
        raise ReplayError(
            "El replay mezcla capture_session_id diferentes: "
            f"{state.capture_session_id} y {capture_session_id}"
        )
    ingest_seq_text = header["ingest_seq"]
    if ingest_seq_text:
        ingest_seq = _integer(ingest_seq_text, "ingest_seq")
        state.ingest_seq_min = (
            ingest_seq
            if state.ingest_seq_min is None
            else min(state.ingest_seq_min, ingest_seq)
        )
        state.ingest_seq_max = (
            ingest_seq
            if state.ingest_seq_max is None
            else max(state.ingest_seq_max, ingest_seq)
        )
        state.source_socket_ids.add(header["source_socket_id"])
        # R4.2/K1: un ingest_seq solo puede repetirse si referencia el MISMO
        # evento del cable (re-journal legítimo durante un resync). Dos
        # payloads distintos bajo el mismo ordinal es una violación de
        # unicidad y el replay falla-cerrado. Antes, un journal con
        # 1→999999→999999 devolvía valid=True y deltas=3 ([P3]).
        fingerprint = hash(
            (
                header.get("record_type", ""),
                header.get("sequence_first", ""),
                header.get("sequence_last", ""),
                header.get("receive_time_utc_ns", ""),
                header.get("exchange_event_time_ms", ""),
                header.get("payload_bytes", ""),
            )
        )
        previous = state._ingest_fingerprints.get(ingest_seq)
        if previous is None:
            state._ingest_fingerprints[ingest_seq] = fingerprint
            state.ingest_unique_count += 1
        elif previous == fingerprint:
            state.ingest_duplicate_identical += 1
        else:
            state.ingest_conflicts += 1
            raise ReplayError(
                f"K1 violada: ingest_seq={ingest_seq} referencia dos payloads "
                "distintos dentro del journal"
            )


def _process_group(state: ReplayState, rows: list[dict[str, str]]) -> None:
    _validate_group_identity(rows)
    header = rows[0]
    _register_causal_identity(state, header)
    record_type = header["record_type"]
    symbol = header["symbol"]
    exchange = header["exchange"]
    market = header["market"]
    if not symbol:
        raise ReplayError("Falta symbol")
    if exchange != "binance":
        raise ReplayError(f"Exchange no soportado: {exchange!r}")
    if market not in {"spot", "usdm_futures"}:
        raise ReplayError(f"Mercado no soportado: {market!r}")
    if state.exchange is None:
        state.exchange = exchange
        state.market = market
    elif state.exchange != exchange or state.market != market:
        raise ReplayError(
            "El replay mezcla mercados: "
            f"{state.exchange}/{state.market} y {exchange}/{market}"
        )
    if state.symbol is None:
        state.symbol = symbol
    elif state.symbol != symbol:
        raise ReplayError(
            f"El replay mezcla símbolos: {state.symbol} y {symbol}"
        )
    if record_type == "CONNECTION":
        if len(rows) != 1:
            raise ReplayError("CONNECTION debe tener una sola fila")
        connection_id = header["connection_id"]
        if header["note"] == "OPEN":
            state.bids.clear()
            state.asks.clear()
            state.generation = None
            state.last_update_id = None
            state.stream_event_seen = False
            state.valid = False
            state.active_connection_id = None
            state.active_connection_id = connection_id
        elif header["note"] == "CLOSED":
            if (
                state.active_connection_id is not None
                and state.active_connection_id != connection_id
            ):
                raise ReplayError("Cierre de una conexión que no está activa")
            state.valid = False
        return
    if record_type == "CAPTURE_STATUS":
        if len(rows) != 1:
            raise ReplayError("CAPTURE_STATUS debe tener una sola fila")
        if header["note"].startswith("INCOMPLETE"):
            state.valid = False
        return
    if record_type not in {"L2_SNAPSHOT", "L2_DELTA", "BOOK_STATUS"}:
        return
    connection_id = header["connection_id"]
    if record_type == "L2_SNAPSHOT":
        if (
            state.active_connection_id is not None
            and state.active_connection_id != connection_id
        ):
            raise ReplayError("Snapshot pertenece a otra conexión")
        state.active_connection_id = connection_id
    elif state.active_connection_id != connection_id:
        raise ReplayError("Evento L2 sin snapshot de su conexión activa")
    if record_type == "BOOK_STATUS":
        if len(rows) != 1:
            raise ReplayError("BOOK_STATUS debe tener una sola fila")
        note = header["note"]
        if note == "SYNCED":
            if state.generation != _integer(header["book_generation"], "book_generation"):
                raise ReplayError("SYNCED pertenece a otra generación")
            status_sequence = _integer(header["sequence_last"], "sequence_last")
            if state.last_update_id != status_sequence:
                raise ReplayError(
                    "SYNCED no coincide con la secuencia reconstruida: "
                    f"estado={state.last_update_id}, status={status_sequence}"
                )
            state.valid = True
        elif note.startswith("SYNCING") or note.startswith("INVALIDATED"):
            state.valid = False
        return
    expected_levels = _integer(header["level_count"], "level_count")
    levels = rows[1:]
    if len(levels) != expected_levels:
        raise ReplayError(
            f"Evento {header['local_event_id']} truncado: "
            f"esperaba {expected_levels} niveles, recibió {len(levels)}"
        )
    generation = _integer(header["book_generation"], "book_generation")
    if record_type == "L2_SNAPSHOT":
        _validate_level_row_structure(levels, "L2_SNAPSHOT_LEVEL")
        parsed_levels = _validated_levels(
            levels,
            expected_record_type="L2_SNAPSHOT_LEVEL",
            snapshot=True,
        )
        state.generation = generation
        state.last_update_id = _integer(header["sequence_last"], "sequence_last")
        state.stream_event_seen = False
        state.valid = False
        _apply_levels(state, parsed_levels, snapshot=True)
        state.snapshots += 1
        return
    if generation != state.generation or state.last_update_id is None:
        raise ReplayError("Delta sin snapshot de su generación")
    _validate_level_row_structure(levels, "L2_DELTA_LEVEL")
    note = header["note"]
    first = _integer(header["sequence_first"], "sequence_first")
    final = _integer(header["sequence_last"], "sequence_last")
    if first > final:
        raise ReplayError("Rango U/u inválido durante replay")
    if note in {"gap", "invalid", "buffered_after_gap", "buffered_after_invalid"}:
        # X7: estas filas se persisten; ningún camino las validaba jamás.
        # `invalid` puede contener por diseño un payload que el libro vivo
        # rechazó (p. ej. fuera de dominio), así que solo se exige estructura.
        _validate_level_row_structure(levels, "L2_DELTA_LEVEL")
        state.valid = False
        return
    stale = (
        final < state.last_update_id
        if state.market == "usdm_futures" and not state.stream_event_seen
        else final <= state.last_update_id
    )
    if stale:
        if note != "stale":
            raise ReplayError("Delta viejo no está marcado como stale")
        # X7/[N5]: los eventos stale quedan en el CSV para siempre; desde
        # v2.3.0 el libro vivo los valida al clasificarlos y el replay ejerce
        # aquí la misma gramática, de modo que ninguna fila queda sin validar.
        _validated_levels(
            levels,
            expected_record_type="L2_DELTA_LEVEL",
            snapshot=False,
        )
        return
    if note == "stale":
        raise ReplayError("Delta nuevo marcado incorrectamente como stale")
    if state.market == "spot":
        if first > state.last_update_id + 1:
            raise ReplayError(
                f"Gap durante replay: esperado {state.last_update_id + 1}, recibió {first}"
            )
    elif not state.stream_event_seen:
        if not first <= state.last_update_id <= final:
            raise ReplayError(
                "Bridge Futures inválido: "
                f"U={first}, snapshot={state.last_update_id}, u={final}"
            )
        if note == "anchored":
            if final != state.last_update_id:
                raise ReplayError("Anchor Futures debe terminar exactamente en snapshot L")
            state.stream_event_seen = True
            return
        if note != "applied":
            raise ReplayError(f"Disposición bridge Futures inválida: {note!r}")
    else:
        previous_text = header.get("sequence_previous", "")
        previous = _integer(previous_text, "sequence_previous")
        if previous != state.last_update_id:
            raise ReplayError(
                "Gap pu Futures durante replay: "
                f"esperado {state.last_update_id}, recibió {previous}"
            )
        if note != "applied":
            raise ReplayError(f"Disposición Futures viva inválida: {note!r}")
    parsed_levels = _validated_levels(
        levels,
        expected_record_type="L2_DELTA_LEVEL",
        snapshot=False,
    )
    _apply_levels(state, parsed_levels, snapshot=False)
    state.last_update_id = final
    state.stream_event_seen = True
    state.deltas += 1


def reconstruct(paths: Iterable[Path]) -> ReplayState:
    resolved_paths = sorted(Path(path) for path in paths)
    partials = sorted(
        {
            partial
            for parent in {path.parent for path in resolved_paths}
            for partial in parent.glob("*.csv.partial")
        }
    )
    if partials:
        names = ", ".join(path.name for path in partials[:3])
        raise ReplayError(f"La captura contiene segmentos parciales: {names}")
    state = ReplayState()
    current_id: tuple[str, str, str, str] | None = None
    group: list[dict[str, str]] = []
    for path in resolved_paths:
        with path.open("r", encoding="utf-8", newline="") as handle:
            for row in csv.DictReader(handle):
                event_id = (
                    row.get("capture_session_id", "legacy"),
                    row["market"],
                    row["connection_id"],
                    row["local_event_id"],
                )
                if current_id is not None and event_id != current_id:
                    _process_group(state, group)
                    group = []
                current_id = event_id
                group.append(row)
    if group:
        _process_group(state, group)
    return state


def _resolve_patterns(patterns: list[str]) -> list[Path]:
    resolved: set[Path] = set()
    for pattern in patterns:
        candidate = Path(pattern)
        if candidate.is_dir():
            resolved.update(
                path
                for path in candidate.glob("*.csv")
                if not path.name.endswith(".partial")
            )
            continue
        matches = glob.glob(pattern)
        if not matches and candidate.is_file():
            matches = [pattern]
        resolved.update(Path(match) for match in matches if not match.endswith(".partial"))
    if not resolved:
        raise ReplayError("No se encontraron CSV finalizados")
    return sorted(resolved)


def main() -> None:
    parser = argparse.ArgumentParser(description="Reconstruye el último libro desde CSV")
    parser.add_argument("paths", nargs="+", help="Archivos o globs CSV")
    args = parser.parse_args()
    state = reconstruct(_resolve_patterns(args.paths))
    best_bid = max(state.bids) if state.bids else None
    best_ask = min(state.asks) if state.asks else None
    print(
        json.dumps(
            {
                "valid": state.valid,
                "exchange": state.exchange,
                "market": state.market,
                "symbol": state.symbol,
                "capture_session_id": state.capture_session_id,
                "causal_identity_version": state.causal_identity_version,
                "ingest_seq_min": state.ingest_seq_min,
                "ingest_seq_max": state.ingest_seq_max,
                "source_socket_ids": sorted(state.source_socket_ids),
                "generation": state.generation,
                "last_update_id": state.last_update_id,
                "bid_levels": len(state.bids),
                "ask_levels": len(state.asks),
                "best_bid": format_fixed(best_bid) if best_bid is not None else None,
                "best_ask": format_fixed(best_ask) if best_ask is not None else None,
                "snapshots": state.snapshots,
                "deltas": state.deltas,
                "ingest_unique_count": state.ingest_unique_count,
                "ingest_duplicate_identical": state.ingest_duplicate_identical,
                "ingest_conflicts": state.ingest_conflicts,
                "canonical_hash_version": state.CANONICAL_HASH_VERSION,
                "sha256": state.canonical_hash(),
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
