from __future__ import annotations

import base64
import binascii
import csv
import hashlib
import io
import re
import unicodedata
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

_REQUIREMENT = re.compile(
    r"^([A-Za-z0-9][A-Za-z0-9._-]*)"
    r"==([A-Za-z0-9][A-Za-z0-9.!+_-]*)"
    r" --hash=sha256:([0-9a-fA-F]{64})$"
)
# [S6]/R5.4: cotas de descompresión. El wheel real más grande del release
# descomprime ~8 MiB; una bomba de 1,5 MiB → 1,5 GiB moría en MemoryError NO
# tipado (salida 70) después de mover el runtime del usuario. Se comprueba el
# tamaño DECLARADO antes de leer un solo byte.
_MAX_MEMBER_UNCOMPRESSED = 64 * 1024 * 1024
_MAX_WHEEL_UNCOMPRESSED = 256 * 1024 * 1024
# [N7]: la especificación de wheel permite que RECORD.jws/RECORD.p7s no
# aparezcan en RECORD (o aparezcan con hash/tamaño vacíos). Su contenido queda
# autenticado igualmente por el SHA-256 del wheel completo del lock.
_SIGNATURE_BASENAMES = frozenset({"RECORD.jws", "RECORD.p7s"})


class SupplyChainError(RuntimeError):
    pass


def _is_signature_entry(name: str) -> bool:
    pure = PurePosixPath(name)
    return (
        pure.name in _SIGNATURE_BASENAMES
        and pure.parent.name.endswith(".dist-info")
    )


def sha256_file(path: Path) -> str:
    """Única implementación de hash de fichero del producto (P1.8c)."""

    return _sha256(path)


@dataclass(frozen=True, slots=True)
class WheelPlanEntry:
    distribution: str
    version: str
    path: Path
    sha256: str

    @property
    def direct_url(self) -> str:
        return f"{self.path.resolve().as_uri()}#sha256={self.sha256}"


def _canonical_name(value: str) -> str:
    return re.sub(r"[-_.]+", "-", value).lower()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _wheel_identity(filename: str) -> tuple[str, str]:
    if not filename.endswith(".whl") or Path(filename).name != filename:
        raise SupplyChainError(f"Nombre de wheel inválido: {filename!r}")
    fields = filename[:-4].split("-")
    if len(fields) < 5 or not fields[0] or not fields[1]:
        raise SupplyChainError(f"Nombre de wheel inválido: {filename!r}")
    return _canonical_name(fields[0]), fields[1]


def verified_wheel_plan(project_root: Path) -> tuple[WheelPlanEntry, ...]:
    """Return an exact, hash-verified dependency plan using only stdlib.

    The function enforces a bijection among exact requirements, manifest
    entries and wheel files. The returned SHA values bind the extraction plan;
    the bootstrap then verifies the wheel again and validates every RECORD row.
    """

    project = project_root.resolve()
    requirements_path = project / "requirements.lock"
    wheelhouse = project / "wheelhouse"
    manifest_path = wheelhouse / "WHEELHOUSE_MANIFEST.sha256"
    if not requirements_path.is_file() or not manifest_path.is_file():
        raise SupplyChainError("Falta requirements.lock o WHEELHOUSE_MANIFEST.sha256")

    requirements: list[tuple[str, str, str, str]] = []
    required_keys: set[tuple[str, str]] = set()
    try:
        requirement_lines = requirements_path.read_text(encoding="ascii").splitlines()
    except (OSError, UnicodeError) as exc:
        raise SupplyChainError(f"No se pudo leer requirements.lock: {exc}") from exc
    for line_number, line in enumerate(requirement_lines, start=1):
        stripped = line.strip()
        # [S14]: el parser de 2.2.0 toleraba líneas vacías y comentarios; su
        # desaparición hacía que un comentario '#' publicara un release que no
        # arranca con un mensaje que no mencionaba la línea.
        if not stripped or stripped.startswith("#"):
            continue
        match = _REQUIREMENT.fullmatch(line)
        if match is None:
            raise SupplyChainError(
                f"Requisito no exacto/hashado en línea {line_number}: {line!r}"
            )
        distribution, version, digest = match.groups()
        digest = digest.lower()
        key = (_canonical_name(distribution), version)
        if key in required_keys:
            raise SupplyChainError(f"Requisito duplicado: {distribution}=={version}")
        required_keys.add(key)
        requirements.append((key[0], distribution, version, digest))
    if not requirements:
        raise SupplyChainError("requirements.lock está vacío")

    manifest: dict[str, str] = {}
    try:
        manifest_lines = manifest_path.read_text(encoding="ascii").splitlines()
    except (OSError, UnicodeError) as exc:
        raise SupplyChainError(
            f"No se pudo leer el manifest del wheelhouse: {exc}"
        ) from exc
    for line_number, line in enumerate(manifest_lines, start=1):
        parts = line.split("  ", 1)
        if (
            len(parts) != 2
            or not re.fullmatch(r"[0-9a-f]{64}", parts[0])
            or not parts[1].endswith(".whl")
            or Path(parts[1]).name != parts[1]
            or parts[1] in manifest
        ):
            raise SupplyChainError(
                f"Manifest wheelhouse inválido en línea {line_number}: {line!r}"
            )
        manifest[parts[1]] = parts[0]

    actual = {path.name for path in wheelhouse.glob("*.whl") if path.is_file()}
    if not manifest or actual != set(manifest):
        raise SupplyChainError("Wheels presentes y manifest no coinciden exactamente")

    wheels_by_key: dict[tuple[str, str], tuple[Path, str]] = {}
    for filename, expected_digest in manifest.items():
        path = wheelhouse / filename
        if path.is_symlink():
            raise SupplyChainError(f"No se admite un wheel symlink: {filename}")
        actual_digest = _sha256(path)
        if actual_digest != expected_digest:
            raise SupplyChainError(f"SHA-256 inválido para wheel {filename}")
        key = _wheel_identity(filename)
        if key in wheels_by_key:
            raise SupplyChainError(f"Más de un wheel satisface {key[0]}=={key[1]}")
        wheels_by_key[key] = (path, expected_digest)

    plan: list[WheelPlanEntry] = []
    used_keys: set[tuple[str, str]] = set()
    for canonical, distribution, version, locked_digest in requirements:
        key = (canonical, version)
        wheel = wheels_by_key.get(key)
        if wheel is None:
            raise SupplyChainError(f"Falta wheel para {distribution}=={version}")
        path, manifest_digest = wheel
        if locked_digest != manifest_digest:
            raise SupplyChainError(
                f"Hash lock/manifest no coincide para {distribution}=={version}"
            )
        used_keys.add(key)
        plan.append(WheelPlanEntry(distribution, version, path, locked_digest))
    if used_keys != set(wheels_by_key):
        extras = sorted(set(wheels_by_key) - used_keys)
        raise SupplyChainError(f"Wheels sin requisito exacto: {extras!r}")
    return tuple(plan)


def _wheel_record(
    archive: zipfile.ZipFile,
    record_name: str,
) -> dict[str, tuple[str, int]]:
    try:
        text = archive.read(record_name).decode("utf-8")
        rows = list(csv.reader(io.StringIO(text, newline=""), strict=True))
    except (KeyError, UnicodeError, csv.Error) as exc:
        raise SupplyChainError("RECORD ausente o inválido") from exc
    record: dict[str, tuple[str, int]] = {}
    for fields in rows:
        if len(fields) != 3 or not fields[0] or fields[0] in record:
            raise SupplyChainError("RECORD contiene fila/ruta inválida")
        name, hash_field, size_text = fields
        if "\\" in name:
            raise SupplyChainError("RECORD contiene separador no canónico")
        if not hash_field:
            # [N7]: además del propio RECORD, la especificación permite filas
            # sin hash/tamaño para las firmas RECORD.jws / RECORD.p7s. Antes
            # un wheel FIRMADO era ininstalable.
            if name != record_name and not _is_signature_entry(name):
                raise SupplyChainError("RECORD omite un hash obligatorio")
            if size_text and not size_text.isdecimal():
                raise SupplyChainError("RECORD usa hash/tamaño no soportado")
            record[name] = ("", int(size_text) if size_text else 0)
            continue
        algorithm, separator, encoded = hash_field.partition("=")
        if separator != "=" or algorithm != "sha256" or not size_text.isdecimal():
            raise SupplyChainError("RECORD usa hash/tamaño no soportado")
        try:
            digest = base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)).hex()
        except (ValueError, binascii.Error) as exc:
            raise SupplyChainError("RECORD contiene base64 inválido") from exc
        if len(digest) != 64:
            raise SupplyChainError("RECORD contiene SHA-256 de longitud inválida")
        record[name] = (digest, int(size_text))
    return record


def verified_wheel_payloads(entry: WheelPlanEntry) -> dict[str, bytes]:
    """Read one wheel once and authenticate every installable byte."""

    try:
        wheel_bytes = entry.path.read_bytes()
    except OSError as exc:
        raise SupplyChainError(f"No se pudo leer {entry.path.name}: {exc}") from exc
    if hashlib.sha256(wheel_bytes).hexdigest() != entry.sha256:
        raise SupplyChainError(f"Wheel cambió después del plan: {entry.path.name}")
    try:
        with zipfile.ZipFile(io.BytesIO(wheel_bytes)) as archive:
            infos = archive.infolist()
            names = [info.filename for info in infos if not info.is_dir()]
            if len(names) != len(set(names)):
                raise SupplyChainError("Wheel contiene entradas duplicadas")
            records = [name for name in names if name.endswith(".dist-info/RECORD")]
            if len(records) != 1:
                raise SupplyChainError("Wheel requiere exactamente un RECORD")
            record = _wheel_record(archive, records[0])
            uncovered = set(names) - set(record)
            if any(not _is_signature_entry(name) for name in uncovered):
                raise SupplyChainError("RECORD no cubre exactamente el wheel")
            ghosts = set(record) - set(names)
            if ghosts:
                raise SupplyChainError("RECORD no cubre exactamente el wheel")
            payloads: dict[str, bytes] = {}
            declared_total = 0
            for info in infos:
                name = info.filename
                path = PurePosixPath(name)
                if (
                    not name
                    or name.startswith("/")
                    # [S11]/I7: ':' cubre 'C:evil.py' y 'C:/evil.py'
                    # (rutas drive-relative que PurePosixPath no considera
                    # absolutas). Dos caracteres ilegales en nombres de
                    # entrada de wheel portables.
                    or ":" in name
                    or "\\" in name
                    or path.is_absolute()
                    or any(part in {"", ".", ".."} for part in path.parts)
                    or any(part.endswith(".data") for part in path.parts)
                    or name.endswith((".pth", ".pyc", ".pyo"))
                    or (info.external_attr >> 16) & 0o170000 == 0o120000
                ):
                    raise SupplyChainError(f"Entrada wheel no admitida: {name!r}")
                if info.is_dir():
                    continue
                # [S6]: cotas ANTES de leer. El tamaño esperado ya está en el
                # header del ZIP y en RECORD; leer sin límite convertía una
                # bomba en un MemoryError sin tipar.
                if info.file_size > _MAX_MEMBER_UNCOMPRESSED:
                    raise SupplyChainError(
                        f"Entrada excede el límite de descompresión: {name!r} "
                        f"({info.file_size} bytes)"
                    )
                declared_total += info.file_size
                if declared_total > _MAX_WHEEL_UNCOMPRESSED:
                    raise SupplyChainError(
                        f"Wheel excede el límite total de descompresión: "
                        f"{entry.path.name}"
                    )
                recorded = record.get(name)
                if (
                    recorded is not None
                    and name != records[0]
                    and recorded[0]
                    and info.file_size != recorded[1]
                ):
                    raise SupplyChainError(
                        f"Tamaño declarado no coincide con RECORD: {name!r}"
                    )
                payload = archive.read(info)
                if recorded is not None and name != records[0] and recorded[0]:
                    digest, size = recorded
                    if (
                        len(payload) != size
                        or hashlib.sha256(payload).hexdigest() != digest
                    ):
                        raise SupplyChainError(f"RECORD no coincide para {name!r}")
                payloads[name] = payload
            return payloads
    except MemoryError as exc:
        raise SupplyChainError(
            f"Descompresión agotó la memoria (posible bomba): {entry.path.name}"
        ) from exc
    except zipfile.BadZipFile as exc:
        raise SupplyChainError(f"Wheel ZIP inválido: {entry.path.name}") from exc


def expected_runtime_inventory(
    plan: tuple[WheelPlanEntry, ...],
) -> dict[str, str]:
    expected: dict[str, str] = {}
    # [S5]/R1.4: misma normalización NFC+casefold que release_integrity. En un
    # sistema de archivos que ignora mayúsculas, 'Shared/x.py' y 'shared/x.py'
    # se funden en un solo fichero: el sellado fallaba con un mensaje sobre
    # "imports/versiones" y cada arranque reconstruía y preservaba otro
    # runtime. El error se detecta al construir el PLAN y nombra la colisión.
    casefold_map: dict[str, str] = {}
    for entry in plan:
        for relative, payload in verified_wheel_payloads(entry).items():
            digest = hashlib.sha256(payload).hexdigest()
            key = unicodedata.normalize("NFC", relative).casefold()
            previous_name = casefold_map.get(key)
            if previous_name is not None and previous_name != relative:
                raise SupplyChainError(
                    "WHEEL_CASE_COLLISION: "
                    f"{previous_name!r} y {relative!r} colisionan en un "
                    "sistema de archivos que ignora mayúsculas; el plan de "
                    "instalación se rechaza antes de extraer nada"
                )
            casefold_map[key] = relative
            previous = expected.get(relative)
            if previous is not None and previous != digest:
                raise SupplyChainError(f"Colisión wheel no idéntica: {relative!r}")
            expected[relative] = digest
    return expected


def verify_runtime_tree(
    project_root: Path, runtime_packages: Path
) -> dict[str, object]:
    """Prove that the extracted runtime is byte-identical to the pinned wheels."""

    project = project_root.resolve()
    expected_path = project / ".runtime" / "packages"
    candidate = runtime_packages.absolute()
    if candidate != project and not candidate.is_relative_to(project):
        raise SupplyChainError("Ruta runtime fuera del proyecto")
    current = project
    for part in candidate.relative_to(project).parts:
        current = current / part
        if current.exists() and (
            current.is_symlink()
            or (hasattr(current, "is_junction") and current.is_junction())
        ):
            raise SupplyChainError("Runtime contiene enlace/reparse point")
    runtime = candidate.resolve()
    if runtime != expected_path.resolve() or not runtime.is_dir():
        raise SupplyChainError("Ruta del runtime inesperada o ausente")
    expected = expected_runtime_inventory(verified_wheel_plan(project))
    actual: dict[str, Path] = {}
    for path in runtime.rglob("*"):
        if (
            path.is_symlink()
            or (hasattr(path, "is_junction") and path.is_junction())
            or (not path.is_file() and not path.is_dir())
        ):
            raise SupplyChainError("Runtime contiene un objeto inseguro")
        if path.is_file():
            actual[path.relative_to(runtime).as_posix()] = path
    if set(actual) != set(expected):
        raise SupplyChainError("Inventario runtime no coincide con los wheels")
    for relative, digest in expected.items():
        if _sha256(actual[relative]) != digest:
            raise SupplyChainError(f"Hash runtime inválido: {relative}")
    inventory_digest = hashlib.sha256(
        "".join(f"{expected[name]}  {name}\n" for name in sorted(expected)).encode(
            "utf-8"
        )
    ).hexdigest()
    return {
        "pass": True,
        "file_count": len(expected),
        "wheel_count": len(verified_wheel_plan(project)),
        "inventory_sha256": inventory_digest,
    }
