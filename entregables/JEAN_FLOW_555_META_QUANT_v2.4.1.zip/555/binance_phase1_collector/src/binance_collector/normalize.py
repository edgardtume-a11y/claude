from __future__ import annotations

import itertools
import threading
import time
from dataclasses import dataclass

from .identity import new_capture_session_id, validate_capture_session_id
from .models import (
    SCHEMA_VERSION,
    AggTradeEvent,
    CsvBatch,
    CsvRow,
    DepthSnapshot,
    DiffDepthEvent,
    PartialDepthEvent,
)


@dataclass(slots=True)
class EventSequencer:
    capture_session_id: str
    _counter: itertools.count
    _lock: threading.Lock

    def __init__(self, capture_session_id: str | None = None) -> None:
        self.capture_session_id = validate_capture_session_id(
            capture_session_id or new_capture_session_id()
        )
        self._counter = itertools.count(1)
        self._lock = threading.Lock()

    def next(self) -> int:
        with self._lock:
            return next(self._counter)


def _base_row(
    *,
    capture_session_id: str,
    ingest_seq: int | None,
    source_socket_id: str,
    event_id: int,
    row_index: int,
    record_type: str,
    symbol: str,
    channel: str,
    connection_id: str,
    receive_utc_ns: int,
    receive_monotonic_ns: int,
    payload_bytes: int,
    raw_queue_size: int,
    exchange_event_time_ms: int | None = None,
    exchange_transaction_time_ms: int | None = None,
    book_generation: int | None = None,
    market: str = "spot",
) -> CsvRow:
    exchange_latency = (
        receive_utc_ns - exchange_event_time_ms * 1_000_000
        if exchange_event_time_ms is not None
        else None
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "capture_session_id": capture_session_id,
        "ingest_seq": ingest_seq,
        "source_socket_id": source_socket_id,
        "local_event_id": event_id,
        "row_index": row_index,
        "record_type": record_type,
        "exchange": "binance",
        "market": market,
        "symbol": symbol,
        "channel": channel,
        "connection_id": connection_id,
        "book_generation": book_generation,
        "exchange_event_time_ms": exchange_event_time_ms,
        "exchange_trade_time_ms": None,
        "exchange_transaction_time_ms": exchange_transaction_time_ms,
        "receive_time_utc_ns": receive_utc_ns,
        "receive_time_monotonic_ns": receive_monotonic_ns,
        "writer_start_time_utc_ns": None,
        "writer_start_time_monotonic_ns": None,
        "exchange_to_receive_ns": exchange_latency,
        "receive_to_writer_start_ns": None,
        "sequence_first": None,
        "sequence_last": None,
        "sequence_previous": None,
        "level_count": None,
        "side": None,
        "price": None,
        "quantity": None,
        "aggregate_trade_id": None,
        "first_trade_id": None,
        "last_trade_id": None,
        "buyer_is_maker": None,
        "payload_bytes": payload_bytes,
        "raw_queue_size": raw_queue_size,
        "note": None,
    }


def _event_identity(
    event: AggTradeEvent | DiffDepthEvent | PartialDepthEvent,
    sequencer: EventSequencer,
) -> tuple[str, int, str]:
    capture_session_id = validate_capture_session_id(event.capture_session_id)
    if capture_session_id != sequencer.capture_session_id:
        raise ValueError(
            "El evento y el journal pertenecen a capture_session_id diferentes"
        )
    if event.ingest_seq <= 0:
        raise ValueError("ingest_seq WebSocket debe ser positivo")
    source_socket_id = event.source_socket_id.strip()
    if not source_socket_id:
        raise ValueError("Falta source_socket_id WebSocket")
    return capture_session_id, event.ingest_seq, source_socket_id


def trade_batch(
    event: AggTradeEvent,
    sequencer: EventSequencer,
    note: str | None,
    *,
    market: str = "spot",
) -> CsvBatch:
    capture_session_id, ingest_seq, source_socket_id = _event_identity(
        event, sequencer
    )
    row = _base_row(
        capture_session_id=capture_session_id,
        ingest_seq=ingest_seq,
        source_socket_id=source_socket_id,
        event_id=sequencer.next(),
        row_index=0,
        record_type="AGG_TRADE",
        symbol=event.symbol,
        channel="aggTrade",
        connection_id=event.connection_id,
        receive_utc_ns=event.receive_utc_ns,
        receive_monotonic_ns=event.receive_monotonic_ns,
        payload_bytes=event.payload_bytes,
        raw_queue_size=event.raw_queue_size,
        exchange_event_time_ms=event.event_time_ms,
        market=market,
    )
    row.update(
        {
            "exchange_trade_time_ms": event.trade_time_ms,
            "price": event.price,
            "quantity": event.quantity,
            "aggregate_trade_id": event.aggregate_trade_id,
            "first_trade_id": event.first_trade_id,
            "last_trade_id": event.last_trade_id,
            "buyer_is_maker": event.buyer_is_maker,
            "note": note,
        }
    )
    return CsvBatch((row,), event.receive_monotonic_ns)


def partial_depth_batch(
    event: PartialDepthEvent,
    symbol: str,
    sequencer: EventSequencer,
    note: str | None,
    *,
    market: str = "spot",
) -> CsvBatch:
    capture_session_id, ingest_seq, source_socket_id = _event_identity(
        event, sequencer
    )
    header = _base_row(
        capture_session_id=capture_session_id,
        ingest_seq=ingest_seq,
        source_socket_id=source_socket_id,
        event_id=sequencer.next(),
        row_index=0,
        record_type="L2_PARTIAL",
        symbol=symbol,
        channel="depth20@100ms",
        connection_id=event.connection_id,
        receive_utc_ns=event.receive_utc_ns,
        receive_monotonic_ns=event.receive_monotonic_ns,
        payload_bytes=event.payload_bytes,
        raw_queue_size=event.raw_queue_size,
        exchange_event_time_ms=event.event_time_ms,
        exchange_transaction_time_ms=event.transaction_time_ms,
        market=market,
    )
    header["sequence_first"] = event.first_update_id
    header["sequence_last"] = event.last_update_id
    header["sequence_previous"] = event.previous_final_update_id
    header["level_count"] = len(event.bids) + len(event.asks)
    header["note"] = note
    return CsvBatch.with_levels(
        header,
        event.bids,
        event.asks,
        "L2_PARTIAL_LEVEL",
        event.receive_monotonic_ns,
    )


def snapshot_batch(
    snapshot: DepthSnapshot,
    symbol: str,
    connection_id: str,
    generation: int,
    sequencer: EventSequencer,
    *,
    market: str = "spot",
) -> CsvBatch:
    header = _base_row(
        capture_session_id=sequencer.capture_session_id,
        ingest_seq=None,
        source_socket_id="rest:depth",
        event_id=sequencer.next(),
        row_index=0,
        record_type="L2_SNAPSHOT",
        symbol=symbol,
        channel="rest_depth",
        connection_id=connection_id,
        receive_utc_ns=snapshot.receive_utc_ns,
        receive_monotonic_ns=snapshot.receive_monotonic_ns,
        payload_bytes=snapshot.payload_bytes,
        raw_queue_size=0,
        book_generation=generation,
        market=market,
    )
    header["sequence_first"] = snapshot.last_update_id
    header["sequence_last"] = snapshot.last_update_id
    header["level_count"] = len(snapshot.bids) + len(snapshot.asks)
    return CsvBatch.with_levels(
        header,
        snapshot.bids,
        snapshot.asks,
        "L2_SNAPSHOT_LEVEL",
        snapshot.receive_monotonic_ns,
    )


def delta_batch(
    event: DiffDepthEvent,
    generation: int,
    sequencer: EventSequencer,
    note: str = "applied",
    *,
    market: str = "spot",
) -> CsvBatch:
    capture_session_id, ingest_seq, source_socket_id = _event_identity(
        event, sequencer
    )
    header = _base_row(
        capture_session_id=capture_session_id,
        ingest_seq=ingest_seq,
        source_socket_id=source_socket_id,
        event_id=sequencer.next(),
        row_index=0,
        record_type="L2_DELTA",
        symbol=event.symbol,
        channel="depth@100ms",
        connection_id=event.connection_id,
        receive_utc_ns=event.receive_utc_ns,
        receive_monotonic_ns=event.receive_monotonic_ns,
        payload_bytes=event.payload_bytes,
        raw_queue_size=event.raw_queue_size,
        exchange_event_time_ms=event.event_time_ms,
        exchange_transaction_time_ms=event.transaction_time_ms,
        book_generation=generation,
        market=market,
    )
    header["sequence_first"] = event.first_update_id
    header["sequence_last"] = event.final_update_id
    header["sequence_previous"] = event.previous_final_update_id
    header["level_count"] = len(event.bids) + len(event.asks)
    header["note"] = note
    return CsvBatch.with_levels(
        header,
        event.bids,
        event.asks,
        "L2_DELTA_LEVEL",
        event.receive_monotonic_ns,
    )


def status_batch(
    *,
    symbol: str,
    connection_id: str,
    generation: int | None,
    status: str,
    sequencer: EventSequencer,
    sequence: int | None = None,
    market: str = "spot",
) -> CsvBatch:
    now_utc_ns = time.time_ns()
    now_monotonic_ns = time.monotonic_ns()
    row = _base_row(
        capture_session_id=sequencer.capture_session_id,
        ingest_seq=None,
        source_socket_id="collector",
        event_id=sequencer.next(),
        row_index=0,
        record_type="BOOK_STATUS",
        symbol=symbol,
        channel="depth@100ms",
        connection_id=connection_id,
        receive_utc_ns=now_utc_ns,
        receive_monotonic_ns=now_monotonic_ns,
        payload_bytes=0,
        raw_queue_size=0,
        book_generation=generation,
        market=market,
    )
    row["sequence_last"] = sequence
    row["note"] = status
    return CsvBatch((row,), now_monotonic_ns)


def connection_batch(
    *,
    symbol: str,
    connection_id: str,
    state: str,
    sequencer: EventSequencer,
    market: str = "spot",
) -> CsvBatch:
    now_utc_ns = time.time_ns()
    now_monotonic_ns = time.monotonic_ns()
    row = _base_row(
        capture_session_id=sequencer.capture_session_id,
        ingest_seq=None,
        source_socket_id="collector",
        event_id=sequencer.next(),
        row_index=0,
        record_type="CONNECTION",
        symbol=symbol,
        channel="combined",
        connection_id=connection_id,
        receive_utc_ns=now_utc_ns,
        receive_monotonic_ns=now_monotonic_ns,
        payload_bytes=0,
        raw_queue_size=0,
        market=market,
    )
    row["note"] = state
    return CsvBatch((row,), now_monotonic_ns)


def capture_status_batch(
    *,
    symbol: str,
    status: str,
    sequencer: EventSequencer,
    market: str = "spot",
) -> CsvBatch:
    now_utc_ns = time.time_ns()
    now_monotonic_ns = time.monotonic_ns()
    row = _base_row(
        capture_session_id=sequencer.capture_session_id,
        ingest_seq=None,
        source_socket_id="collector",
        event_id=sequencer.next(),
        row_index=0,
        record_type="CAPTURE_STATUS",
        symbol=symbol,
        channel="collector",
        connection_id="capture",
        receive_utc_ns=now_utc_ns,
        receive_monotonic_ns=now_monotonic_ns,
        payload_bytes=0,
        raw_queue_size=0,
        market=market,
    )
    row["note"] = status
    return CsvBatch((row,), now_monotonic_ns)
