from __future__ import annotations

import hashlib
import re
import time
import tomllib
import unicodedata
from pathlib import Path, PurePosixPath
from typing import Any


MANIFEST_NAME = "RELEASE_MANIFEST.sha256"
ARCHIVE_ROOT = "555"
_HASH_LINE = re.compile(r"^([0-9a-f]{64})  (555/.+)$")
_EXCLUDED_PARTS = frozenset(
    {
        ".git",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        ".venv",
        ".runtime",
        ".runtime_building",
        "__pycache__",
        "build",
        "data",
        "data_dual",
        "dist",
        "runs",
    }
)
_VERSION_FILES = {
    "jean_flow_launcher.py": re.compile(
        r"(?m)^LAUNCHER_VERSION\s*=\s*['\"]([^'\"]+)['\"]\s*$"
    ),
    "binance_phase1_collector/src/binance_collector/__init__.py": re.compile(
        r"(?m)^__version__\s*=\s*['\"]([^'\"]+)['\"]\s*$"
    ),
    "binance_phase1_collector/src/binance_collector/launcher.py": re.compile(
        r"(?m)^LAUNCHER_VERSION\s*=\s*['\"]([^'\"]+)['\"]\s*$"
    ),
    "binance_phase1_collector/tools/build_release.py": re.compile(
        r"(?m)^RELEASE_VERSION\s*=\s*['\"]([^'\"]+)['\"]\s*$"
    ),
}


class ReleaseIntegrityError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _path_key(value: str) -> str:
    return unicodedata.normalize("NFC", value).casefold()


def _is_runtime_path(relative: Path) -> bool:
    return (
        any(
            part in _EXCLUDED_PARTS
            or part.endswith(".egg-info")
            or part.startswith(".venv_preserved_")
            or part.startswith(".runtime_preserved_")
            for part in relative.parts
        )
        or relative.name
        in {
            MANIFEST_NAME,
            ".jean_flow_launcher.lock",
            ".jean_flow_bootstrap.lock",
        }
        or relative.name.endswith((".pyc", ".pyo"))
    )


def _controlled_files(root: Path) -> dict[str, Path]:
    files: dict[str, Path] = {}
    for path in root.rglob("*"):
        relative = path.relative_to(root)
        if _is_runtime_path(relative):
            continue
        if path.is_symlink():
            raise ReleaseIntegrityError(
                "RELEASE_PATH_UNSAFE", f"No se permiten enlaces: {relative.as_posix()}"
            )
        if not path.is_file():
            continue
        name = relative.as_posix()
        key = _path_key(name)
        if key in files:
            raise ReleaseIntegrityError(
                "RELEASE_PATH_COLLISION", f"Colisión de rutas: {name}"
            )
        files[key] = path
    return files


def _parse_manifest(path: Path) -> tuple[dict[str, str], str]:
    if not path.is_file() or path.is_symlink():
        raise ReleaseIntegrityError("RELEASE_MANIFEST_MISSING", str(path))
    if path.stat().st_size <= 0 or path.stat().st_size > 8 * 1024 * 1024:
        raise ReleaseIntegrityError("RELEASE_MANIFEST_INVALID", "Tamaño inválido")
    expected: dict[str, str] = {}
    try:
        lines = path.read_text(encoding="ascii").splitlines()
    except (OSError, UnicodeError) as exc:
        raise ReleaseIntegrityError("RELEASE_MANIFEST_INVALID", str(exc)) from exc
    for line_number, line in enumerate(lines, start=1):
        match = _HASH_LINE.fullmatch(line)
        if match is None:
            raise ReleaseIntegrityError(
                "RELEASE_MANIFEST_INVALID", f"Línea {line_number} inválida"
            )
        digest, archived = match.groups()
        relative = archived.removeprefix(f"{ARCHIVE_ROOT}/")
        pure = PurePosixPath(relative)
        if (
            not relative
            or pure.is_absolute()
            or any(part in {"", ".", ".."} for part in pure.parts)
            or "\\" in relative
            or relative == MANIFEST_NAME
        ):
            raise ReleaseIntegrityError(
                "RELEASE_MANIFEST_INVALID", f"Ruta insegura: {archived!r}"
            )
        key = _path_key(relative)
        if key in expected:
            raise ReleaseIntegrityError(
                "RELEASE_MANIFEST_INVALID", f"Ruta duplicada: {archived!r}"
            )
        expected[key] = digest
    if not expected:
        raise ReleaseIntegrityError("RELEASE_MANIFEST_INVALID", "Manifest vacío")
    return expected, _sha256(path)


def _verify_versions(root: Path, expected_version: str) -> dict[str, str]:
    versions: dict[str, str] = {}
    project_file = root / "binance_phase1_collector" / "pyproject.toml"
    try:
        project = tomllib.loads(project_file.read_text(encoding="utf-8"))["project"]
        project_version = project["version"]
    except (OSError, UnicodeError, KeyError, TypeError, tomllib.TOMLDecodeError) as exc:
        raise ReleaseIntegrityError("RELEASE_VERSION_INVALID", str(exc)) from exc
    if not isinstance(project_version, str):
        raise ReleaseIntegrityError(
            "RELEASE_VERSION_INVALID", "project.version inválido"
        )
    versions["pyproject"] = project_version
    for relative, pattern in _VERSION_FILES.items():
        try:
            text = (root / relative).read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            raise ReleaseIntegrityError("RELEASE_VERSION_INVALID", str(exc)) from exc
        match = pattern.search(text)
        if match is None:
            raise ReleaseIntegrityError(
                "RELEASE_VERSION_INVALID", f"Versión no encontrada en {relative}"
            )
        versions[relative] = match.group(1)
    mismatches = {
        name: version
        for name, version in versions.items()
        if version != expected_version
    }
    if mismatches:
        raise ReleaseIntegrityError(
            "RELEASE_VERSION_MISMATCH",
            f"Esperado {expected_version}; discrepancias={mismatches!r}",
        )
    return versions


def verify_release_tree(root: Path, *, expected_version: str) -> dict[str, Any]:
    root = root.resolve()
    if not root.is_dir():
        raise ReleaseIntegrityError("RELEASE_ROOT_INVALID", str(root))
    expected, manifest_sha256 = _parse_manifest(root / MANIFEST_NAME)
    actual = _controlled_files(root)
    missing = sorted(set(expected).difference(actual))
    unexpected = sorted(set(actual).difference(expected))
    if missing or unexpected:
        raise ReleaseIntegrityError(
            "RELEASE_MANIFEST_MISMATCH",
            f"faltan={missing[:20]!r}; inesperados={unexpected[:20]!r}",
        )
    mismatched: list[str] = []
    for key, expected_digest in sorted(expected.items()):
        if _sha256(actual[key]) != expected_digest:
            mismatched.append(actual[key].relative_to(root).as_posix())
    if mismatched:
        raise ReleaseIntegrityError(
            "RELEASE_HASH_MISMATCH", f"Hash inválido: {mismatched[:20]!r}"
        )
    versions = _verify_versions(root, expected_version)
    return {
        "pass": True,
        "release_root": str(root),
        "release_version": expected_version,
        "manifest_path": str(root / MANIFEST_NAME),
        "manifest_sha256": manifest_sha256,
        "covered_files": len(expected),
        "versions": versions,
        "verified_utc_ns": time.time_ns(),
    }
