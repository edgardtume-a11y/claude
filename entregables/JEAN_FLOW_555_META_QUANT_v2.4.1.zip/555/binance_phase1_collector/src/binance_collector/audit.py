from __future__ import annotations

import argparse
import csv
import glob
import hashlib
import json
import math
import random
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .identity import validate_capture_session_id
from .metrics import _percentile
from .models import CAUSAL_IDENTITY_SCHEMA_VERSION
from .reconstruct import ReplayError, reconstruct

_METRICS_MESSAGE = re.compile(
    r"^metrics(?: market=(?P<market>[a-z_]+))? (?P<payload>\{.*\})$"
)
_FAILURE_COUNTERS = frozenset(
    {
        "writer_failures",
        "writer_queue_overflows",
        "writer_row_budget_overflows",
        "raw_queue_overflows",
        "raw_byte_budget_overflows",
        "route_queue_overflows",
        "protocol_errors",
        "book_invariant_failures",
    }
)
_CAUSAL_RECORD_TYPES = frozenset({"AGG_TRADE", "L2_PARTIAL", "L2_DELTA"})
_REQUIRED_IDENTITY_MARKETS = frozenset({"spot", "usdm_futures"})
_IDENTITY_COLUMNS = frozenset(
    {
        "schema_version",
        "capture_session_id",
        "ingest_seq",
        "source_socket_id",
        "row_index",
        "record_type",
        "market",
        "connection_id",
    }
)
# Deliberately excludes processing fields (local_event_id, book_generation, note and
# writer timestamps). The same wire payload can legitimately be referenced again by
# the book state machine during bootstrap/resynchronization.
_PAYLOAD_FINGERPRINT_FIELDS = (
    "capture_session_id",
    "record_type",
    "exchange",
    "market",
    "symbol",
    "channel",
    "connection_id",
    "source_socket_id",
    "exchange_event_time_ms",
    "exchange_trade_time_ms",
    "exchange_transaction_time_ms",
    "receive_time_utc_ns",
    "receive_time_monotonic_ns",
    "sequence_first",
    "sequence_last",
    "sequence_previous",
    "level_count",
    "price",
    "quantity",
    "aggregate_trade_id",
    "first_trade_id",
    "last_trade_id",
    "buyer_is_maker",
    "payload_bytes",
    "raw_queue_size",
)
_MAX_REPORTED_CONFLICTS = 100
_MAX_REPORTED_GAP_RANGES = 1_000
_CAPACITY_GATES = {
    "raw_queue": ("raw_queue_high_water", "raw_queue_capacity"),
    "raw_bytes": ("raw_bytes_high_water", "raw_bytes_capacity"),
    "book_queue": ("book_queue_high_water", "route_queue_capacity"),
    "trade_queue": ("trade_queue_high_water", "route_queue_capacity"),
    "partial_queue": ("partial_queue_high_water", "route_queue_capacity"),
    "writer_queue": ("writer_queue_high_water", "writer_queue_capacity"),
    "writer_rows": ("writer_rows_high_water", "writer_rows_capacity"),
}


@dataclass(slots=True)
class _Sample:
    limit: int = 500_000
    total: int = 0
    values: list[float] = field(default_factory=list)
    _rng: random.Random = field(default_factory=lambda: random.Random(0))

    def add(self, value: float) -> None:
        self.total += 1
        if len(self.values) < self.limit:
            self.values.append(value)
            return
        replacement = self._rng.randrange(self.total)
        if replacement < self.limit:
            self.values[replacement] = value

    def summary(self) -> dict[str, int | float | bool]:
        return {
            "count": self.total,
            "sample_count": len(self.values),
            "approximate": self.total > len(self.values),
            "p50": _percentile(self.values, 0.50),
            "p95": _percentile(self.values, 0.95),
            "p99": _percentile(self.values, 0.99),
            "max_sampled": round(max(self.values), 3) if self.values else 0.0,
        }


def resolve_csv_patterns(patterns: Iterable[str]) -> list[Path]:
    resolved: set[Path] = set()
    for pattern in patterns:
        candidate = Path(pattern)
        if candidate.is_dir():
            # P1.1: aceptar directorios evita construir globs sobre rutas con
            # metacaracteres ('D:\proyectos[2026]\555' rompía glob.glob).
            resolved.update(
                path
                for path in candidate.glob("*.csv")
                if not path.name.endswith(".csv.partial")
            )
            continue
        matches = glob.glob(pattern)
        if not matches and candidate.is_file():
            matches = [pattern]
        resolved.update(
            Path(match)
            for match in matches
            if match.endswith(".csv") and not match.endswith(".csv.partial")
        )
    if not resolved:
        raise ReplayError("No se encontraron CSV finalizados")
    return sorted(resolved)


def _related_partial_files(paths: Iterable[Path]) -> list[Path]:
    resolved = tuple(Path(path) for path in paths)
    parents = {path.parent for path in resolved}
    partials = {
        candidate for parent in parents for candidate in parent.glob("*.csv.partial")
    }
    partials.update(path for path in resolved if path.name.endswith(".csv.partial"))
    return sorted(partials)


def _payload_fingerprint(row: dict[str, str]) -> str:
    identity = [
        (field_name, row.get(field_name, ""))
        for field_name in _PAYLOAD_FINGERPRINT_FIELDS
    ]
    encoded = json.dumps(
        identity,
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _expected_source_socket_id(row: dict[str, str]) -> str:
    record_type = row.get("record_type", "")
    if record_type == "L2_SNAPSHOT":
        return "rest:depth"
    if record_type not in _CAUSAL_RECORD_TYPES:
        return "collector"
    connection_id = row.get("connection_id", "")
    if row.get("market") == "spot":
        role = "spot_combined"
    elif record_type == "AGG_TRADE":
        role = "usdm_market_trades"
    else:
        role = "usdm_public_depth"
    return f"{connection_id}:{role}"


def _extend_payload_fingerprint(
    digest: Any,
    row: dict[str, str],
) -> None:
    """Hash only wire-level content copied into an expanded level row."""

    encoded = json.dumps(
        (
            row.get("schema_version", ""),
            row.get("capture_session_id", ""),
            row.get("ingest_seq", ""),
            row.get("source_socket_id", ""),
            row.get("exchange", ""),
            row.get("market", ""),
            row.get("symbol", ""),
            row.get("channel", ""),
            row.get("connection_id", ""),
            row.get("row_index", ""),
            row.get("record_type", ""),
            row.get("side", ""),
            row.get("price", ""),
            row.get("quantity", ""),
        ),
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")
    digest.update(b"\x1e")
    digest.update(encoded)


def _positive_integer(value: str) -> int | None:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


def _gap_summary(sequences: Iterable[int]) -> tuple[int, list[dict[str, int]], bool]:
    ordered = sorted(sequences)
    missing_count = 0
    ranges: list[dict[str, int]] = []
    truncated = False
    for previous, current in zip(ordered, ordered[1:]):
        if current <= previous + 1:
            continue
        count = current - previous - 1
        missing_count += count
        if len(ranges) < _MAX_REPORTED_GAP_RANGES:
            ranges.append(
                {
                    "first": previous + 1,
                    "last": current - 1,
                    "count": count,
                }
            )
        else:
            truncated = True
    return missing_count, ranges, truncated


def audit_causal_identity(paths: Iterable[Path]) -> dict[str, object]:
    """Certify the session-wide v2 identity across Spot and USD-M journals.

    Headers identify a wire event and its expanded levels extend the fingerprint
    incrementally. Memory therefore stays proportional to wire events, not rows.
    """

    resolved = sorted(Path(path) for path in paths)
    partials = _related_partial_files(resolved)
    errors: list[str] = []
    schema_versions: set[str] = set()
    capture_session_ids: set[str] = set()
    markets: set[str] = set()
    source_socket_ids: set[str] = set()
    payload_markets: Counter[str] = Counter()
    files_without_headers: list[str] = []
    missing_capture_session_headers = 0
    invalid_capture_session_headers = 0
    missing_source_socket_headers = 0
    invalid_source_socket_headers = 0
    invalid_source_socket_examples: list[dict[str, object]] = []
    invalid_ingest_references = 0
    invalid_ingest_examples: list[dict[str, object]] = []
    payload_references = 0
    duplicate_references = 0
    conflict_count = 0
    conflicts: list[dict[str, object]] = []
    # ingest_seq -> (fingerprint, file, CSV line). Fingerprints avoid retaining all
    # string columns for long soak captures.
    payloads: dict[int, tuple[str, str, int]] = {}

    if not resolved:
        errors.append("No se encontraron CSV finalizados")

    def register_payload(
        ingest_seq: int,
        digest: object,
        path: Path,
        line_number: int,
    ) -> None:
        nonlocal duplicate_references, conflict_count
        fingerprint = digest.hexdigest()  # type: ignore[attr-defined]
        previous = payloads.get(ingest_seq)
        if previous is None:
            payloads[ingest_seq] = (fingerprint, str(path), line_number)
        elif previous[0] == fingerprint:
            duplicate_references += 1
        else:
            conflict_count += 1
            if len(conflicts) < _MAX_REPORTED_CONFLICTS:
                conflicts.append(
                    {
                        "ingest_seq": ingest_seq,
                        "first": {
                            "file": previous[1],
                            "line": previous[2],
                            "fingerprint": previous[0],
                        },
                        "conflicting": {
                            "file": str(path),
                            "line": line_number,
                            "fingerprint": fingerprint,
                        },
                    }
                )

    for path in resolved:
        header_count = 0
        current_payload: tuple[int, object, int] | None = None

        def finish_current_payload() -> None:
            nonlocal current_payload
            if current_payload is None:
                return
            ingest_seq, digest, header_line = current_payload
            register_payload(ingest_seq, digest, path, header_line)
            current_payload = None

        with path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            fieldnames = frozenset(reader.fieldnames or ())
            missing_columns = sorted(_IDENTITY_COLUMNS.difference(fieldnames))
            if missing_columns:
                errors.append(
                    f"{path}: faltan columnas v2: {', '.join(missing_columns)}"
                )
            for line_number, row in enumerate(reader, start=2):
                if row.get("row_index") != "0":
                    if current_payload is not None:
                        _extend_payload_fingerprint(current_payload[1], row)
                    continue
                finish_current_payload()
                header_count += 1
                schema = row.get("schema_version", "")
                schema_versions.add(schema or "<missing>")
                session_id = row.get("capture_session_id", "").strip()
                if session_id:
                    capture_session_ids.add(session_id)
                    try:
                        validate_capture_session_id(session_id)
                    except ValueError:
                        invalid_capture_session_headers += 1
                else:
                    missing_capture_session_headers += 1
                market = row.get("market", "").strip()
                if market:
                    markets.add(market)
                source_socket_id = row.get("source_socket_id", "").strip()
                if source_socket_id:
                    source_socket_ids.add(source_socket_id)
                else:
                    missing_source_socket_headers += 1

                record_type = row.get("record_type", "")
                if schema == CAUSAL_IDENTITY_SCHEMA_VERSION and source_socket_id:
                    expected_source_socket_id = _expected_source_socket_id(row)
                    if source_socket_id != expected_source_socket_id:
                        invalid_source_socket_headers += 1
                        if (
                            len(invalid_source_socket_examples)
                            < _MAX_REPORTED_CONFLICTS
                        ):
                            invalid_source_socket_examples.append(
                                {
                                    "file": str(path),
                                    "line": line_number,
                                    "record_type": record_type,
                                    "expected": expected_source_socket_id,
                                    "received": source_socket_id,
                                }
                            )
                if record_type not in _CAUSAL_RECORD_TYPES:
                    continue
                payload_references += 1
                if market:
                    payload_markets[market] += 1
                ingest_seq = _positive_integer(row.get("ingest_seq", ""))
                if ingest_seq is None:
                    invalid_ingest_references += 1
                    if len(invalid_ingest_examples) < _MAX_REPORTED_CONFLICTS:
                        invalid_ingest_examples.append(
                            {
                                "file": str(path),
                                "line": line_number,
                                "value": row.get("ingest_seq", ""),
                                "record_type": record_type,
                            }
                        )
                    continue
                digest = hashlib.sha256()
                digest.update(_payload_fingerprint(row).encode("ascii"))
                current_payload = (ingest_seq, digest, line_number)
            finish_current_payload()
        if header_count == 0:
            files_without_headers.append(str(path))

    if partials:
        errors.append("Existen segmentos .csv.partial relacionados")
    if files_without_headers:
        errors.append("Hay CSV finalizados sin headers de evento")
    if schema_versions != {CAUSAL_IDENTITY_SCHEMA_VERSION}:
        errors.append(
            f"Todos los headers deben usar schema {CAUSAL_IDENTITY_SCHEMA_VERSION}"
        )
    if missing_capture_session_headers:
        errors.append("Hay headers sin capture_session_id")
    if invalid_capture_session_headers:
        errors.append("Hay headers con capture_session_id inválido")
    if len(capture_session_ids) != 1:
        errors.append("La auditoría exige exactamente una capture_session_id")
    if missing_source_socket_headers:
        errors.append("Hay headers sin source_socket_id")
    if invalid_source_socket_headers:
        errors.append("Hay headers con source_socket_id incompatible")
    if markets != _REQUIRED_IDENTITY_MARKETS:
        errors.append("La auditoría exige exactamente los mercados spot y usdm_futures")
    if frozenset(payload_markets) != _REQUIRED_IDENTITY_MARKETS:
        errors.append("Spot y usdm_futures deben contener eventos causales WebSocket")
    if invalid_ingest_references:
        errors.append(
            "Hay eventos WebSocket con ingest_seq vacío, inválido o no positivo"
        )
    if not payloads:
        errors.append("No se encontraron eventos causales con ingest_seq válido")
    if conflict_count:
        errors.append("Un ingest_seq referencia más de una identidad de payload")

    missing_count, missing_ranges, gaps_truncated = _gap_summary(payloads)
    if missing_count:
        errors.append("Hay huecos globales de ingest_seq entre el mínimo y el máximo")

    minimum = min(payloads) if payloads else None
    maximum = max(payloads) if payloads else None
    if minimum is not None and minimum != 1:
        errors.append("La secuencia global debe comenzar exactamente en ingest_seq=1")
    certification = "PASS" if not errors else "FAIL"
    return {
        "certification": certification,
        "schema_version_required": CAUSAL_IDENTITY_SCHEMA_VERSION,
        "files": [str(path) for path in resolved],
        "partial_files": [str(path) for path in partials],
        "files_without_event_headers": files_without_headers,
        "capture_session_id": (
            next(iter(capture_session_ids)) if len(capture_session_ids) == 1 else None
        ),
        "capture_session_ids": sorted(capture_session_ids),
        "schema_versions": sorted(schema_versions),
        "markets": sorted(markets),
        "required_markets": sorted(_REQUIRED_IDENTITY_MARKETS),
        "payload_references_by_market": dict(sorted(payload_markets.items())),
        "source_socket_ids": sorted(source_socket_ids),
        "payload_references": payload_references,
        "unique_payloads": len(payloads),
        "duplicate_identical_references": duplicate_references,
        "invalid_ingest_references": invalid_ingest_references,
        "invalid_ingest_examples": invalid_ingest_examples,
        "conflict_count": conflict_count,
        "conflicts": conflicts,
        "ingest_seq": {
            "min": minimum,
            "max": maximum,
            "unique_count": len(payloads),
            "missing_count": missing_count,
            "missing_ranges": missing_ranges,
            "missing_ranges_truncated": gaps_truncated,
        },
        # C_ing = |set(S_obs)| / max(S_obs); certifica ⟺ C_ing = 1 exactamente
        # (K1-K3 sobre la unión de journals). K4 (max == last_ingest_seq del
        # commitment) lo cierra el launcher en _verify_capture_commitment.
        "completeness": {
            "numerator_unique_ingest": len(payloads),
            "denominator_max_ingest": maximum,
            "ratio": (len(payloads) / maximum) if maximum else None,
            "complete": bool(
                payloads and minimum == 1 and len(payloads) == maximum
            ),
        },
        "missing_capture_session_headers": missing_capture_session_headers,
        "invalid_capture_session_headers": invalid_capture_session_headers,
        "missing_source_socket_headers": missing_source_socket_headers,
        "invalid_source_socket_headers": invalid_source_socket_headers,
        "invalid_source_socket_examples": invalid_source_socket_examples,
        "errors": errors,
        "fingerprint_scope": (
            "header row_index=0 más niveles expandidos; permite referencias "
            "repetidas solo si todo el payload normalizado coincide"
        ),
    }


def audit_journal(paths: Iterable[Path]) -> dict[str, object]:
    resolved = sorted(Path(path) for path in paths)
    state = reconstruct(resolved)
    event_counts: Counter[str] = Counter()
    dispositions: Counter[str] = Counter()
    book_statuses: Counter[str] = Counter()
    markets: set[str] = set()
    schema_versions: set[str] = set()
    capture_session_ids: set[str] = set()
    source_socket_ids: set[str] = set()
    causal_ingest_sequences: set[int] = set()
    invalid_causal_ingest_headers = 0
    incomplete_markers: list[str] = []
    latency_samples = {
        "receive_to_writer_start": _Sample(),
        "exchange_to_receive": _Sample(),
    }

    for path in resolved:
        with path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                if row.get("row_index") != "0":
                    continue
                record_type = row.get("record_type", "")
                note = row.get("note", "")
                schema_versions.add(row.get("schema_version", "") or "<missing>")
                capture_session_id = row.get("capture_session_id", "").strip()
                if capture_session_id:
                    capture_session_ids.add(capture_session_id)
                source_socket_id = row.get("source_socket_id", "").strip()
                if source_socket_id:
                    source_socket_ids.add(source_socket_id)
                if record_type in _CAUSAL_RECORD_TYPES:
                    ingest_seq = _positive_integer(row.get("ingest_seq", ""))
                    if ingest_seq is None:
                        invalid_causal_ingest_headers += 1
                    else:
                        causal_ingest_sequences.add(ingest_seq)
                event_counts[record_type] += 1
                markets.add(row.get("market", ""))
                if record_type == "L2_DELTA":
                    dispositions[note] += 1
                elif record_type == "BOOK_STATUS":
                    book_statuses[note] += 1
                elif record_type == "CAPTURE_STATUS" and note.startswith("INCOMPLETE"):
                    incomplete_markers.append(note)
                for field_name, metric_name in (
                    ("receive_to_writer_start_ns", "receive_to_writer_start"),
                    ("exchange_to_receive_ns", "exchange_to_receive"),
                ):
                    raw = row.get(field_name, "")
                    if raw:
                        latency_samples[metric_name].add(int(raw) / 1_000_000)

    integrity_pass = not incomplete_markers and len(markets) == 1
    # R0.1: causal_replay era un literal "PASS" fijo desde 2.2.0. Ahora es un
    # predicado computado sobre lo que el replay realmente verificó: schema
    # causal uniforme, una única sesión, cero headers causales inválidos y
    # cero conflictos/duplicados de ingest_seq detectados por reconstruct()
    # (que ahora falla-cerrado ante K1 dentro del journal).
    causal_replay_errors: list[str] = []
    if schema_versions != {CAUSAL_IDENTITY_SCHEMA_VERSION}:
        causal_replay_errors.append(
            f"schema_versions={sorted(schema_versions)} != "
            f"{{{CAUSAL_IDENTITY_SCHEMA_VERSION!r}}}"
        )
    if len(capture_session_ids) != 1:
        causal_replay_errors.append(
            f"capture_session_ids={len(capture_session_ids)} != 1"
        )
    if invalid_causal_ingest_headers:
        causal_replay_errors.append(
            f"invalid_causal_ingest_headers={invalid_causal_ingest_headers}"
        )
    if state.ingest_conflicts:
        causal_replay_errors.append(f"ingest_conflicts={state.ingest_conflicts}")
    if not causal_ingest_sequences:
        causal_replay_errors.append("sin eventos causales con ingest_seq")
    causal_replay_pass = not causal_replay_errors
    return {
        "certification": {
            "journal_integrity": "PASS" if integrity_pass else "FAIL",
            "causal_replay": "PASS" if causal_replay_pass else "FAIL",
            "causal_replay_errors": causal_replay_errors,
            "safe_for_visual_replay": integrity_pass and causal_replay_pass,
            "note": (
                "valid=false al final es normal después de CONNECTION CLOSED; "
                "cada gap/resync debe dibujarse como frontera de epoch. "
                "causal_replay solo certifica invariantes evaluables por "
                "journal; la contigüidad global K3 exige la unión de mercados "
                "(comando identity)."
            ),
        },
        "files": [str(path) for path in resolved],
        "markets": sorted(markets),
        "events": dict(sorted(event_counts.items())),
        "delta_dispositions": dict(sorted(dispositions.items())),
        "book_statuses": dict(sorted(book_statuses.items())),
        "incomplete_markers": incomplete_markers,
        "causal_identity": {
            "schema_versions": sorted(schema_versions),
            "capture_session_ids": sorted(capture_session_ids),
            "source_socket_ids": sorted(source_socket_ids),
            "ingest_seq_min": (
                min(causal_ingest_sequences) if causal_ingest_sequences else None
            ),
            "ingest_seq_max": (
                max(causal_ingest_sequences) if causal_ingest_sequences else None
            ),
            "unique_ingest_seq_count": len(causal_ingest_sequences),
            "invalid_causal_ingest_headers": invalid_causal_ingest_headers,
        },
        "latency_ms_from_journal_headers": {
            name: sample.summary() for name, sample in latency_samples.items()
        },
        "replay": {
            "exchange": state.exchange,
            "market": state.market,
            "symbol": state.symbol,
            "valid_live_state": state.valid,
            "generation": state.generation,
            "last_update_id": state.last_update_id,
            "bid_levels": len(state.bids),
            "ask_levels": len(state.asks),
            "snapshots": state.snapshots,
            "deltas_applied": state.deltas,
            "ingest_unique_count": state.ingest_unique_count,
            "ingest_duplicate_identical": state.ingest_duplicate_identical,
            "ingest_conflicts": state.ingest_conflicts,
            "canonical_hash_version": state.CANONICAL_HASH_VERSION,
            "sha256": state.canonical_hash(),
        },
    }


def _eviction_series_covers_all_samples(
    series: list[tuple[int, int]],
) -> tuple[bool, str]:
    """[2.3.2] ¿Toda muestra fue visible en alguna ventana emitida?

    ``series`` es la sucesión (count_total, count) de una métrica en orden de
    emisión. La base certificada del gate es worst-p99 sobre TODAS las
    ventanas; cubre el soak completo sii entre snapshots consecutivos no
    llegaron más muestras de las que retiene la ventana que las publica
    (Δcount_total <= count actual) y la serie es coherente (count <=
    count_total, count_total no decreciente). Devuelve (ok, razón).
    """

    previous_total = 0
    for index, (count_total, count) in enumerate(series):
        if count < 0 or count_total < 0 or count > count_total:
            return False, (
                f"snapshot {index}: count={count} > count_total={count_total}"
            )
        if count_total < previous_total:
            return False, (
                f"snapshot {index}: count_total decreciente "
                f"({count_total} < {previous_total})"
            )
        if count_total - previous_total > count:
            return False, (
                f"snapshot {index}: llegaron {count_total - previous_total} "
                f"muestras entre snapshots pero la ventana solo retiene "
                f"{count}: hay muestras que ninguna ventana emitida vio"
            )
        previous_total = count_total
    return True, "ok"


# [2.3.4] REVISIÓN EXPLÍCITA DE CRITERIO — event_loop_lag_p99: 20 ms → 40 ms.
#
# El límite de 20 ms era un criterio de grado servidor (Linux con timer de
# alta resolución). En Windows de escritorio el cuanto del temporizador es
# 15.625 ms (64 Hz) y el colector, por diseño, NO fuerza timeBeginPeriod(1)
# (ver README «Reloj y scheduler»): cualquier espera del event loop se
# redondea al múltiplo del cuanto, así que la cola de la distribución vive en
# {15.6, 31.25} ms por construcción del sistema operativo, no por atasco del
# colector.
#
# Evidencia de campo (host de referencia Windows 11, laptop del operador):
# - benchmark --enforce ocioso: p99 = 16 ms (1 cuanto);
# - sesión 99a0f0a51142400a97b4e064dfd62fab (etapa 10 min certificación,
#   BTCUSDT, 2026-08-14): captura SANA completa (HEALTHY_DURATION_COMPLETE,
#   0 overflows, aggTrade en ambos mercados, libros SYNCED) con
#   event_loop_lag p99 clavado en 21-22 ms durante toda la etapa — 1 cuanto
#   + despacho — y máximos aislados que no mueven el p99. Único gate FAIL de
#   la sesión; con 20 ms el examen era estructuralmente inaprobable en
#   Windows aunque la captura fuera íntegra.
#
# Nuevo límite = ceil(2 cuantos = 31.25 ms) + margen de despacho ≈ 40 ms.
# Sigue condenando atascos reales (GC/paginación/E/S sostenidos aparecen
# como p99 de 100 ms o más sobre ventanas de 10 000 muestras) y deja de
# condenar la resolución nativa del reloj del sistema operativo anfitrión.
# La métrica se sigue registrando y publicando SIN recorte; solo cambia la
# línea de corte del gate. Cambio documentado también en
# CERTIFICACION_FASE1.md, README y CAMBIOS_v2.3.4.md — nunca silencioso.
EVENT_LOOP_P99_LIMIT_MS = 40.0

# [2.3.9] Exclusión de CALENTAMIENTO explícita del gate de p99. Evidencia de
# campo (sesión b977be885902, 10 min SANOS en Windows real): el arranque del
# proceso (import, sincronización inicial, primer snapshot REST, actividad
# del host en los primeros segundos) dejó ~3 muestras de writer_yield de
# 9.5-13.7 ms dentro de la ventana deslizante; con solo ~200 muestras
# acumuladas el estimador p99 devolvió esos picos hasta el segundo ~70 y el
# gate (worst_p99 sobre TODAS las ventanas) vetó una captura cuyo estado
# estacionario fue 2.8-3.2 ms durante los 530 s restantes. El gate certifica
# salud SOSTENIDA de captura, no el costo fijo de arranque, así que el basis
# pasa a ser worst_p99 sobre las ventanas emitidas DESPUÉS de los primeros
# METRICS_WARMUP_EXCLUSION_S segundos (referencia: primera ventana de
# métricas del mercado). Honestidad del cambio (regla de oro: nunca
# silencioso): AMBOS valores se publican siempre (con y sin calentamiento),
# el informe declara cuántas ventanas se excluyeron, y si el log no alcanza
# el corte (p. ej. pruebas cortas) se evalúan TODAS las ventanas como hasta
# 2.3.8 — la exclusión solo puede aplicarse cuando existe estado
# estacionario que evaluar. Un problema SOSTENIDO sigue vetando: sus picos
# aparecen también después del corte. Documentado en CERTIFICACION_FASE1.md,
# README y CAMBIOS_v2.3.9.md.
METRICS_WARMUP_EXCLUSION_S = 120.0


def _parse_metrics_timestamp(value: object) -> datetime | None:
    """Timestamp ISO-8601 del log de métricas, normalizado a UTC-aware.

    Devuelve None si no es interpretable: esa ventana se trata como fuera
    del calentamiento (se evalúa en el gate), el camino conservador.
    """

    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def audit_metrics_logs(
    paths: Iterable[Path],
    *,
    parse_p99_limit_ms: float = 5.0,
    book_p99_limit_ms: float = 5.0,
    book_pipeline_p99_limit_ms: float = 5.0,
    event_loop_p99_limit_ms: float = EVENT_LOOP_P99_LIMIT_MS,
    writer_yield_p99_limit_ms: float = 5.0,
    min_latency_samples: int = 100,
    required_markets: Iterable[str] = (),
    require_activity: bool = False,
    enforce_thresholds: bool = True,
    warmup_exclusion_s: float = METRICS_WARMUP_EXCLUSION_S,
) -> dict[str, object]:
    limits = (
        parse_p99_limit_ms,
        book_p99_limit_ms,
        book_pipeline_p99_limit_ms,
        event_loop_p99_limit_ms,
        writer_yield_p99_limit_ms,
    )
    if min_latency_samples <= 0 or any(
        not math.isfinite(limit) or limit < 0 for limit in limits
    ):
        raise ValueError("Límites de métricas/muestras inválidos")
    if not math.isfinite(warmup_exclusion_s) or warmup_exclusion_s < 0:
        raise ValueError("Exclusión de calentamiento inválida")
    latest: dict[str, tuple[str, dict[str, object]]] = {}
    terminal_candidates: defaultdict[str, list[tuple[str, dict[str, object]]]] = (
        defaultdict(list)
    )
    windows: Counter[str] = Counter()
    worst_p99: defaultdict[str, dict[str, float]] = defaultdict(dict)
    worst_max: defaultdict[str, dict[str, float]] = defaultdict(dict)
    # [2.3.9] Serie por ventana (timestamp, métrica, p99, max) para separar
    # calentamiento de estado estacionario TRAS conocer la primera ventana.
    window_series: defaultdict[
        str, list[tuple[datetime | None, str, float, float | None]]
    ] = defaultdict(list)
    window_timestamps: defaultdict[str, list[datetime | None]] = defaultdict(list)
    evicted_totals: defaultdict[str, dict[str, int]] = defaultdict(dict)
    eviction_reported: defaultdict[str, set[str]] = defaultdict(set)
    # [2.3.2] Serie (count_total, count) por métrica en orden de emisión para
    # verificar la COBERTURA de la ventana deslizante (ver
    # _eviction_series_covers_all_samples).
    eviction_series: defaultdict[str, dict[str, list[tuple[int, int]]]] = (
        defaultdict(lambda: defaultdict(list))
    )
    metric_errors: defaultdict[str, list[str]] = defaultdict(list)
    malformed_lines = 0
    for path in paths:
        with Path(path).open("r", encoding="utf-8") as handle:
            for raw_line in handle:
                try:
                    outer = json.loads(raw_line)
                except json.JSONDecodeError:
                    malformed_lines += 1
                    continue
                message = outer.get("message")
                if not isinstance(message, str):
                    continue
                match = _METRICS_MESSAGE.match(message)
                if match is None:
                    continue
                market = match.group("market") or "spot"
                try:
                    payload = json.loads(match.group("payload"))
                except json.JSONDecodeError:
                    malformed_lines += 1
                    continue
                timestamp = str(outer.get("timestamp", ""))
                parsed_timestamp = _parse_metrics_timestamp(outer.get("timestamp"))
                windows[market] += 1
                window_timestamps[market].append(parsed_timestamp)
                if market not in latest or timestamp >= latest[market][0]:
                    latest[market] = (timestamp, payload)
                counters_payload = payload.get("counters", {})
                if (
                    isinstance(counters_payload, dict)
                    and int(counters_payload.get("terminal_metric_snapshots", 0) or 0)
                    == 1
                ):
                    terminal_candidates[market].append((timestamp, payload))
                for metric, values in payload.get("latency_ms", {}).items():
                    try:
                        p99 = float(values["p99"])
                        count = int(values["count"])
                    except (KeyError, TypeError, ValueError):
                        metric_errors[market].append(f"{metric}: resumen incompleto")
                        continue
                    if not math.isfinite(p99) or p99 < 0 or count < 0:
                        metric_errors[market].append(
                            f"{metric}: valor no finito/inválido"
                        )
                        continue
                    worst_p99[market][metric] = max(
                        worst_p99[market].get(metric, p99),
                        p99,
                    )
                    maximum_value = values.get("max")
                    window_max: float | None = None
                    if isinstance(maximum_value, (int, float)) and math.isfinite(
                        float(maximum_value)
                    ):
                        window_max = float(maximum_value)
                        worst_max[market][metric] = max(
                            worst_max[market].get(metric, window_max),
                            window_max,
                        )
                    window_series[market].append(
                        (parsed_timestamp, metric, p99, window_max)
                    )
                    evicted_value = values.get("evicted")
                    if isinstance(evicted_value, int) and not isinstance(
                        evicted_value, bool
                    ):
                        eviction_reported[market].add(metric)
                        evicted_totals[market][metric] = max(
                            evicted_totals[market].get(metric, 0), evicted_value
                        )
                    total_value = values.get("count_total")
                    if isinstance(total_value, int) and not isinstance(
                        total_value, bool
                    ):
                        eviction_series[market][metric].append(
                            (total_value, count)
                        )

    # [2.3.9] Clasificación calentamiento/estado estacionario por mercado.
    # Referencia: la PRIMERA ventana de métricas del mercado (timestamp
    # mínimo interpretable). Una ventana sin timestamp interpretable nunca
    # se excluye: se evalúa en el gate (camino conservador).
    warmup_reference: dict[str, datetime] = {}
    steady_p99: defaultdict[str, dict[str, float]] = defaultdict(dict)
    steady_max: defaultdict[str, dict[str, float]] = defaultdict(dict)
    warmup_excluded_windows: Counter[str] = Counter()
    warmup_evaluated_windows: Counter[str] = Counter()
    for market, stamps in window_timestamps.items():
        parseable = [stamp for stamp in stamps if stamp is not None]
        if parseable:
            warmup_reference[market] = min(parseable)

    def _is_warmup_window(market: str, stamp: datetime | None) -> bool:
        reference = warmup_reference.get(market)
        if warmup_exclusion_s <= 0 or stamp is None or reference is None:
            return False
        return (stamp - reference).total_seconds() < warmup_exclusion_s

    for market, stamps in window_timestamps.items():
        for stamp in stamps:
            if _is_warmup_window(market, stamp):
                warmup_excluded_windows[market] += 1
            else:
                warmup_evaluated_windows[market] += 1
    for market, entries in window_series.items():
        for stamp, metric, p99, window_max in entries:
            if _is_warmup_window(market, stamp):
                continue
            steady_p99[market][metric] = max(
                steady_p99[market].get(metric, p99), p99
            )
            if window_max is not None:
                steady_max[market][metric] = max(
                    steady_max[market].get(metric, window_max), window_max
                )

    required = frozenset(required_markets)
    missing_markets = sorted(required.difference(latest))
    markets: dict[str, object] = {}
    overall_pass = bool(latest) and malformed_lines == 0 and not missing_markets
    # P2.3: la "última ventana" por timestamp era no determinista ante empate.
    # La ventana terminal es la que lleva terminal_metric_snapshots == 1; si
    # hay varias o ninguna, se marca ambigüedad explícita en vez de elegir por
    # orden de lectura.
    terminal_ambiguous: dict[str, int] = {}
    for market, candidates in terminal_candidates.items():
        if len(candidates) == 1:
            latest[market] = candidates[0]
        elif len(candidates) > 1:
            terminal_ambiguous[market] = len(candidates)
    for market, (timestamp, snapshot) in sorted(latest.items()):
        counters = snapshot.get("counters", {})
        gauges = snapshot.get("gauges", {})
        latencies = snapshot.get("latency_ms", {})
        failures = {
            name: int(counters.get(name, 0))
            for name in sorted(_FAILURE_COUNTERS)
            if int(counters.get(name, 0)) > 0
        }
        writer_yield_required = int(counters.get("writer_gil_yields", 0)) > 0
        # M5: cada gate declara su dominio de reloj. Solo métricas monotónicas
        # llevan umbral; exchange_to_receive es cross-clock y se publica con
        # la banda θ̂/δ del arranque, nunca como gate sin banda.
        # [2.3.2] Con enforce_thresholds=False (uso normal, no certificación)
        # los p99 y su cobertura se PUBLICAN igual pero no condenan la sesión;
        # la integridad estructural (malformed, pérdidas, terminal, capacidad,
        # cobertura de ventana declarada) se exige en ambos casos.
        threshold_sources = {
            "parse_p99": (
                "parse",
                parse_p99_limit_ms,
                min_latency_samples,
                enforce_thresholds,
            ),
            "book_apply_p99": (
                "book_apply",
                book_p99_limit_ms,
                min_latency_samples,
                enforce_thresholds,
            ),
            "book_pipeline_p99": (
                "book_pipeline_total",
                book_pipeline_p99_limit_ms,
                min_latency_samples,
                enforce_thresholds,
            ),
            "event_loop_lag_p99": (
                "event_loop_lag",
                event_loop_p99_limit_ms,
                min_latency_samples,
                enforce_thresholds,
            ),
            "writer_yield_p99": (
                "writer_cooperative_yield",
                writer_yield_p99_limit_ms,
                min_latency_samples,
                writer_yield_required and enforce_thresholds,
            ),
        }
        thresholds: dict[str, dict[str, object]] = {}
        for name, (
            metric,
            limit,
            minimum,
            required_metric,
        ) in threshold_sources.items():
            summary = latencies.get(metric)
            present = isinstance(summary, dict) and metric in worst_p99[market]
            try:
                latest_value = (
                    float(summary["p99"]) if isinstance(summary, dict) else None
                )
                sample_count = int(summary["count"]) if isinstance(summary, dict) else 0
            except (KeyError, TypeError, ValueError):
                latest_value = None
                sample_count = 0
                present = False
            finite = (
                latest_value is not None
                and math.isfinite(latest_value)
                and latest_value >= 0
            )
            worst_value_all = worst_p99[market].get(metric)
            worst_value = worst_value_all
            basis = "worst_p99"
            # [2.3.9] Si el mercado tiene estado estacionario (ventanas tras
            # el corte de calentamiento) y la métrica aparece en él, el gate
            # evalúa SOLO esas ventanas. Si no (log corto, pruebas, métrica
            # ausente tras el corte), se evalúan TODAS como hasta 2.3.8. El
            # valor con calentamiento se publica SIEMPRE al lado.
            if metric in steady_p99[market] and warmup_excluded_windows[market] > 0:
                worst_value = steady_p99[market][metric]
                basis = "worst_p99_post_warmup"
            small_sample_fallback = (
                name == "writer_yield_p99"
                and required_metric
                and present
                and 0 < sample_count < min_latency_samples
            )
            if small_sample_fallback:
                # P0.4b: un p99 con n<100 puede ocultar el outlier (con n=67
                # el estimador antiguo ignoraba un pico de 50 ms). Con muestra
                # pequeña se evalúa el MAX observado: conservador y honesto.
                # [2.3.9] El MAX no se recorta por calentamiento: con muestra
                # pequeña no hay dilución que separe arranque de estado
                # estacionario, así que se mantiene el peor caso absoluto.
                basis = "max_fallback_small_n"
                worst_value = worst_max[market].get(metric, worst_value_all)
                minimum = 1
            threshold_pass = bool(
                not required_metric
                or (
                    present
                    and finite
                    and sample_count >= minimum
                    and worst_value is not None
                    and worst_value <= limit
                )
            )
            thresholds[name] = {
                "required": required_metric,
                "present": present,
                "latest_value_ms": latest_value,
                "worst_value_ms": worst_value,
                "worst_value_ms_incl_warmup": worst_value_all,
                "limit_ms": limit,
                "sample_count": sample_count,
                "min_samples": minimum,
                "basis": basis,
                "clock_domain": "monotonic",
                "pass": threshold_pass,
            }
        # P0.4/eviction [2.3.2]: el gate certifica que NINGUNA muestra quedó
        # fuera de toda ventana emitida, no que la ventana nunca desalojara.
        # Evidencia de campo (sesión 45896a2c99aa, 3.7 min SANOS en Windows
        # real): event_loop_lag desalojó 10 muestras y el gate antiguo
        # (evicted == 0) condenaba la sesión; en un soak de 2 h CUALQUIER
        # métrica continua desaloja por construcción (ventana deslizante de
        # 10 000 con snapshots cada 5 s). La base certificada es worst-p99
        # SOBRE TODAS las ventanas emitidas: cubre el soak completo siempre
        # que cada muestra haya sido visible en alguna ventana, es decir,
        # que entre snapshots consecutivos no llegaran más muestras de las
        # que la ventana retiene (Δcount_total <= count del snapshot que las
        # publica). Eso exige tasa < ~2000 muestras/s sostenidas — un orden
        # de magnitud sobre lo observado — y sigue condenando la truncación
        # NO declarada o incoherente (count > count_total, serie decreciente,
        # evicción sin serie verificable).
        eviction_checks: dict[str, dict[str, object]] = {}
        for gate_name, (metric, _limit, _min, required_metric) in (
            threshold_sources.items()
        ):
            reported = metric in eviction_reported[market]
            evicted = evicted_totals[market].get(metric, 0)
            series = eviction_series[market].get(metric, [])
            coverage_ok, coverage_reason = _eviction_series_covers_all_samples(
                series
            )
            if not required_metric or not reported:
                eviction_pass = True
            elif evicted == 0:
                eviction_pass = not series or coverage_ok
            else:
                eviction_pass = bool(series) and coverage_ok
            # La cobertura violada es deshonestidad de emisión: es error
            # SIEMPRE, también con enforce_thresholds=False.
            if reported and series and not coverage_ok:
                metric_errors[market].append(
                    f"{metric}: cobertura de ventana violada ({coverage_reason})"
                )
            eviction_checks[gate_name] = {
                "metric": metric,
                "evicted_reported": reported,
                "max_evicted": evicted if reported else None,
                "window_snapshots": len(series),
                "coverage_ok": coverage_ok if series else None,
                "pass": eviction_pass,
            }
        activity = {
            name: int(counters.get(name, 0))
            for name in (
                "rest_snapshots",
                "book_syncs",
                "depth_diff_messages",
                "agg_trade_messages",
            )
        }
        activity_pass = not require_activity or all(
            value > 0 for value in activity.values()
        )
        terminal_snapshots = int(counters.get("terminal_metric_snapshots", 0))
        ambiguous_count = terminal_ambiguous.get(market, 0)
        terminal_pass = terminal_snapshots == 1 and ambiguous_count == 0
        if ambiguous_count:
            metric_errors[market].append(
                f"TERMINAL_SNAPSHOT_AMBIGUOUS: {ambiguous_count} ventanas "
                "declaran ser la terminal"
            )
        capacity_checks: dict[str, dict[str, object]] = {}
        overflow_counter_names = {
            "raw_queue": "raw_queue_overflows",
            "raw_bytes": "raw_byte_budget_overflows",
            "book_queue": "route_queue_overflows",
            "trade_queue": "route_queue_overflows",
            "partial_queue": "route_queue_overflows",
            "writer_queue": "writer_queue_overflows",
            "writer_rows": "writer_row_budget_overflows",
        }
        for name, (high_water_name, capacity_name) in _CAPACITY_GATES.items():
            try:
                high_water = int(gauges[high_water_name])
                capacity = int(gauges[capacity_name])
            except (KeyError, TypeError, ValueError):
                high_water = None
                capacity = None
            # P0.4d: high_water == capacity sin overflow es un estado legal
            # del writer; la pérdida real la cuentan los contadores de
            # overflow (que ya forman parte de _FAILURE_COUNTERS).
            capacity_pass = bool(
                high_water is not None
                and capacity is not None
                and 0 <= high_water <= capacity
            )
            capacity_checks[name] = {
                "high_water": high_water,
                "capacity": capacity,
                "overflows": int(
                    counters.get(overflow_counter_names.get(name, ""), 0)
                ),
                "pass": capacity_pass,
            }
        market_pass = (
            not failures
            and not metric_errors[market]
            and activity_pass
            and terminal_pass
            and all(check["pass"] for check in capacity_checks.values())
            and all(bool(threshold["pass"]) for threshold in thresholds.values())
            and all(bool(check["pass"]) for check in eviction_checks.values())
        )
        overall_pass = overall_pass and market_pass
        markets[market] = {
            "status": "PASS" if market_pass else "FAIL",
            "latest_timestamp": timestamp,
            "windows": windows[market],
            "failure_counters": failures,
            "activity_counters": activity,
            "activity_pass": activity_pass,
            "terminal_metric_snapshots": terminal_snapshots,
            "terminal_snapshot_pass": terminal_pass,
            "terminal_snapshot_ambiguous": ambiguous_count,
            "capacity_checks": capacity_checks,
            "thresholds": thresholds,
            "eviction_checks": eviction_checks,
            "metric_errors": metric_errors[market],
            "worst_p99_ms_across_windows": dict(sorted(worst_p99[market].items())),
            "worst_p99_ms_post_warmup": dict(sorted(steady_p99[market].items())),
            "warmup_exclusion": {
                "seconds": warmup_exclusion_s,
                "reference_timestamp": (
                    warmup_reference[market].isoformat()
                    if market in warmup_reference
                    else None
                ),
                "windows_total": windows[market],
                "windows_excluded": warmup_excluded_windows[market],
                "windows_evaluated": warmup_evaluated_windows[market],
                "applied": bool(
                    warmup_excluded_windows[market] > 0
                    and warmup_evaluated_windows[market] > 0
                ),
            },
            "latest": snapshot,
        }
    return {
        "certification": "PASS" if overall_pass else "FAIL",
        "malformed_json_lines": malformed_lines,
        "required_markets": sorted(required),
        "missing_markets": missing_markets,
        "markets": markets,
        "clock_domains": {
            "monotonic": [
                "parse",
                "book_apply",
                "book_pipeline_total",
                "event_loop_lag",
                "writer_cooperative_yield",
                "receive_to_writer_start",
                "csv_write",
                "csv_fsync",
                "journal_build",
            ],
            "cross_clock": [
                "exchange_to_receive_depth",
                "exchange_to_receive_trade",
                "trade_time_to_receive",
            ],
        },
        "clock_note": (
            "exchange_to_receive usa reloj UTC/NTP (cross_clock): debe leerse "
            "con la banda θ̂±δ/2 publicada en el arranque "
            "(clock_offset_theta_hat_ns / clock_offset_delta_ns) y NUNCA "
            "usarse como gate sin banda; parse, book_apply, writer y "
            "event_loop_lag usan duraciones locales monotónicas"
        ),
    }


def _force_utf8_stdio() -> None:
    """[2.3.5] Los informes de auditoría viajan por stdout y contienen texto
    no-ASCII (θ̂, "después", "más", "contigüidad"). En Windows es-ES un stdout
    redirigido a archivo/pipe usa cp1252: 'é' se escribe como 0xE9 — el
    verificador lo relee como UTF-8 estricto y veta con "invalid continuation
    byte" en posición fija (700/767, sesiones 87fa5a61d019 y d64fea5560ac) —
    y 'θ̂' ni siquiera es representable (UnicodeEncodeError al imprimir el
    informe de métricas). Se fuerza UTF-8 dentro del propio proceso porque
    con -I las variables PYTHONUTF8/PYTHONIOENCODING se ignoran; complementa
    el flag -X utf8 que añade el launcher. Nunca toca el contenido auditado:
    solo el canal por el que viaja el informe.
    """

    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8")
            except (OSError, ValueError):  # pragma: no cover - mejor esfuerzo
                pass


def main() -> None:
    _force_utf8_stdio()
    parser = argparse.ArgumentParser(
        description="Auditor reproducible de journals y métricas JEAN_FLOW"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    journal = subparsers.add_parser("journal", help="Replay + integridad CSV")
    journal.add_argument("paths", nargs="+", help="CSV o globs de un solo mercado")
    identity = subparsers.add_parser(
        "identity",
        help="Audita identidad causal v2 combinando Spot y USD-M",
    )
    identity.add_argument(
        "paths",
        nargs="+",
        help="CSV o globs de los journals Spot y USD-M de una captura",
    )
    metrics = subparsers.add_parser("metrics", help="Audita logs JSONL de métricas")
    metrics.add_argument("paths", nargs="+", type=Path)
    metrics.add_argument("--parse-p99-ms", type=float, default=5.0)
    metrics.add_argument("--book-p99-ms", type=float, default=5.0)
    metrics.add_argument("--book-pipeline-p99-ms", type=float, default=5.0)
    # [2.3.4] default revisado 20→40 ms (cuanto de timer Windows; ver
    # EVENT_LOOP_P99_LIMIT_MS arriba para el fundamento completo).
    metrics.add_argument(
        "--event-loop-p99-ms", type=float, default=EVENT_LOOP_P99_LIMIT_MS
    )
    metrics.add_argument("--writer-yield-p99-ms", type=float, default=5.0)
    metrics.add_argument("--min-latency-samples", type=int, default=100)
    # [2.3.9] Exclusión de calentamiento explícita (ver
    # METRICS_WARMUP_EXCLUSION_S). 0 = evaluar todas las ventanas (2.3.8).
    metrics.add_argument(
        "--warmup-exclusion-s",
        type=float,
        default=METRICS_WARMUP_EXCLUSION_S,
        help=(
            "[2.3.9] Segundos de calentamiento excluidos del basis worst_p99 "
            "(desde la primera ventana de métricas del mercado); ambos "
            "valores se publican siempre y un log más corto que el corte se "
            "evalúa completo. 0 desactiva la exclusión."
        ),
    )
    metrics.add_argument(
        "--required-market",
        action="append",
        choices=("spot", "usdm_futures"),
        dest="required_markets",
        help=("Mercado obligatorio; repetible. Por defecto exige Spot y Futures."),
    )
    metrics.add_argument(
        "--no-activity-check",
        action="store_true",
        help="Diagnóstico: no exige snapshot, sync, depth y trades positivos",
    )
    metrics.add_argument(
        "--no-threshold-check",
        action="store_true",
        help=(
            "[2.3.2] Uso normal: publica los p99 y su cobertura sin exigir "
            "los límites de certificación (la integridad estructural — "
            "líneas malformadas, contadores de pérdida, snapshot terminal, "
            "capacidad y cobertura de ventana — se exige siempre)"
        ),
    )
    args = parser.parse_args()
    try:
        if args.command == "journal":
            result = audit_journal(resolve_csv_patterns(args.paths))
            certification = result["certification"]
            failed = (
                certification["journal_integrity"] != "PASS"  # type: ignore[index]
                or certification["causal_replay"] != "PASS"  # type: ignore[index]
            )
        elif args.command == "metrics":
            result = audit_metrics_logs(
                args.paths,
                parse_p99_limit_ms=args.parse_p99_ms,
                book_p99_limit_ms=args.book_p99_ms,
                book_pipeline_p99_limit_ms=args.book_pipeline_p99_ms,
                event_loop_p99_limit_ms=args.event_loop_p99_ms,
                writer_yield_p99_limit_ms=args.writer_yield_p99_ms,
                min_latency_samples=args.min_latency_samples,
                required_markets=(
                    args.required_markets
                    if args.required_markets is not None
                    else ("spot", "usdm_futures")
                ),
                require_activity=not args.no_activity_check,
                enforce_thresholds=not args.no_threshold_check,
                warmup_exclusion_s=args.warmup_exclusion_s,
            )
            failed = result["certification"] != "PASS"
        else:
            result = audit_causal_identity(resolve_csv_patterns(args.paths))
            failed = result["certification"] != "PASS"
    except (OSError, ValueError, csv.Error, ReplayError) as exc:
        if args.command == "identity":
            result = {
                "certification": "FAIL",
                "errors": [str(exc)],
            }
            print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
            raise SystemExit(2) from exc
        parser.exit(2, f"AUDIT FAIL: {exc}\n")
    print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
    if failed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
