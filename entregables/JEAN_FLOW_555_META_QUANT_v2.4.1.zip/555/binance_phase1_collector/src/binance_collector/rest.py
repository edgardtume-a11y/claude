from __future__ import annotations

import asyncio
import math
import random
import time
from typing import Any

import aiohttp
import orjson

from .metrics import Metrics
from .models import DepthSnapshot, parse_levels, require_dict


def _parse_retry_after(value: str | None) -> float | None:
    if value is None:
        return None
    try:
        parsed = float(value)
    except ValueError:
        return None
    if not math.isfinite(parsed) or parsed < 0:
        return None
    return parsed


class SnapshotError(RuntimeError):
    pass


class RestBanError(SnapshotError):
    """HTTP 418: la IP fue baneada por exceso de peso.

    Reintentar es destructivo (F2): cada intento consume presupuesto y
    prolonga el ban. Se propaga como fallo terminal con retirada TOTAL.
    """

    def __init__(self, retry_after_s: float | None) -> None:
        detail = (
            f"; Retry-After={retry_after_s:.0f}s" if retry_after_s is not None else ""
        )
        super().__init__(
            "REST_IP_BANNED: Binance devolvió 418 (ban de IP por peso). "
            f"No se reintenta{detail}. Espere el periodo indicado antes de "
            "volver a arrancar."
        )
        self.retry_after_s = retry_after_s


_MAX_RETRY_AFTER_S = 60.0


class SnapshotClient:
    def __init__(
        self,
        *,
        session: aiohttp.ClientSession,
        base_url: str,
        depth_path: str = "/api/v3/depth",
        symbol: str,
        limit: int,
        timeout_s: float,
        retries: int,
        min_interval_s: float,
        metrics: Metrics,
    ) -> None:
        self._session = session
        if not depth_path.startswith("/"):
            raise ValueError("depth_path debe comenzar por /")
        self._depth_path = depth_path
        self._base_url = base_url.rstrip("/")
        self._url = f"{self._base_url}{depth_path}"
        self._symbol = symbol
        self._limit = limit
        self._timeout = aiohttp.ClientTimeout(total=timeout_s)
        self._retries = retries
        self._min_interval_s = min_interval_s
        self._metrics = metrics
        self._request_lock = asyncio.Lock()
        self._last_request_monotonic = 0.0

    async def fetch(self) -> DepthSnapshot:
        async with self._request_lock:
            for attempt in range(self._retries):
                elapsed = time.monotonic() - self._last_request_monotonic
                if elapsed < self._min_interval_s:
                    await asyncio.sleep(self._min_interval_s - elapsed)
                self._last_request_monotonic = time.monotonic()
                started = time.monotonic_ns()
                try:
                    async with self._session.get(
                        self._url,
                        params={"symbol": self._symbol, "limit": self._limit},
                        timeout=self._timeout,
                    ) as response:
                        payload = await response.read()
                        receive_monotonic_ns = time.monotonic_ns()
                        receive_utc_ns = time.time_ns()
                        if response.status == 200:
                            # [2.3.6] Duración local con perf_counter_ns; el
                            # dato receive_monotonic_ns y la métrica
                            # rest_snapshot (dominio del reloj de datos)
                            # conservan monotonic_ns.
                            decode_started = time.perf_counter_ns()
                            snapshot = await asyncio.to_thread(
                                self._decode,
                                payload,
                                receive_utc_ns=receive_utc_ns,
                                receive_monotonic_ns=receive_monotonic_ns,
                            )
                            self._metrics.observe(
                                "rest_snapshot_decode",
                                (time.perf_counter_ns() - decode_started)
                                / 1_000_000,
                            )
                            self._metrics.inc("rest_snapshots")
                            self._metrics.observe(
                                "rest_snapshot",
                                (receive_monotonic_ns - started) / 1_000_000,
                            )
                            return snapshot
                        self._observe_used_weight(response.headers)
                        retry_after = response.headers.get("Retry-After")
                        detail = payload[:256].decode("utf-8", errors="replace")
                        if response.status == 418:
                            # [P10]/F2: el 418 es un ban de IP. Reintentar
                            # prolonga el ban y quema el presupuesto. Terminal.
                            self._metrics.inc("rest_ip_bans")
                            raise RestBanError(_parse_retry_after(retry_after))
                        if response.status != 429 and response.status < 500:
                            raise SnapshotError(
                                f"REST depth HTTP {response.status}: {detail}"
                            )
                        self._metrics.inc("rest_retryable_status")
                        if attempt + 1 >= self._retries:
                            raise SnapshotError(
                                "Se agotaron los reintentos de snapshot REST "
                                f"(último HTTP {response.status})"
                            )
                        delay = self._retry_delay(attempt, retry_after)
                except SnapshotError:
                    raise
                except (aiohttp.ClientError, asyncio.TimeoutError, orjson.JSONDecodeError) as exc:
                    self._metrics.inc("rest_snapshot_failures")
                    if attempt + 1 >= self._retries:
                        raise SnapshotError("No se pudo obtener snapshot REST") from exc
                    delay = self._retry_delay(attempt, None)
                await asyncio.sleep(delay)
        raise SnapshotError("Se agotaron los reintentos de snapshot REST")

    def _observe_used_weight(self, headers: Any) -> None:
        used_weight = headers.get("X-MBX-USED-WEIGHT-1M") or headers.get(
            "X-MBX-USED-WEIGHT"
        )
        if used_weight is None:
            return
        try:
            self._metrics.set_gauge("rest_used_weight_1m", int(used_weight))
        except (TypeError, ValueError):
            pass

    @staticmethod
    def _retry_delay(attempt: int, retry_after: str | None) -> float:
        parsed = _parse_retry_after(retry_after)
        if parsed is not None:
            # P1.3: sin tope, un Retry-After de 7200/1e12/'inf' dormía para
            # siempre con el lock de snapshots tomado.
            return min(_MAX_RETRY_AFTER_S, max(0.25, parsed))
        ceiling = min(8.0, 0.25 * (2**attempt))
        return random.uniform(ceiling / 2, ceiling)

    async def fetch_exchange_info(
        self,
        *,
        exchange_info_path: str,
    ) -> dict[str, Any]:
        """Fetch /exchangeInfo once for the startup admissibility gate (X2)."""

        if not exchange_info_path.startswith("/"):
            raise ValueError("exchange_info_path debe comenzar por /")
        url = f"{self._base_url}{exchange_info_path}"
        params = (
            {"symbol": self._symbol}
            if exchange_info_path.startswith("/api/")
            else None
        )
        try:
            async with self._session.get(
                url,
                params=params,
                timeout=self._timeout,
            ) as response:
                payload = await response.read()
                self._observe_used_weight(response.headers)
                if response.status == 418:
                    self._metrics.inc("rest_ip_bans")
                    raise RestBanError(
                        _parse_retry_after(response.headers.get("Retry-After"))
                    )
                if response.status != 200:
                    detail = payload[:256].decode("utf-8", errors="replace")
                    raise SnapshotError(
                        f"REST exchangeInfo HTTP {response.status}: {detail}"
                    )
                return require_dict(orjson.loads(payload), "exchangeInfo REST")
        except (
            aiohttp.ClientError,
            asyncio.TimeoutError,
            orjson.JSONDecodeError,
            ValueError,
        ) as exc:
            if isinstance(exc, SnapshotError):
                raise
            raise SnapshotError(f"exchangeInfo REST inválido: {exc}") from exc

    async def fetch_server_time(
        self,
        *,
        server_time_path: str,
    ) -> dict[str, int]:
        """Four-mark clock offset estimate against /time (M3).

        Devuelve theta_hat_ns (offset estimado local-servidor), delta_ns
        (incertidumbre = RTT) y server_time_ms.  |θ − θ̂| ≤ δ/2.
        """

        if not server_time_path.startswith("/"):
            raise ValueError("server_time_path debe comenzar por /")
        url = f"{self._base_url}{server_time_path}"
        t1_ns = time.time_ns()
        try:
            async with self._session.get(url, timeout=self._timeout) as response:
                payload = await response.read()
                t4_ns = time.time_ns()
                self._observe_used_weight(response.headers)
                if response.status != 200:
                    detail = payload[:256].decode("utf-8", errors="replace")
                    raise SnapshotError(
                        f"REST time HTTP {response.status}: {detail}"
                    )
                data = require_dict(orjson.loads(payload), "server time REST")
                server_time_ms = data.get("serverTime")
                if (
                    isinstance(server_time_ms, bool)
                    or not isinstance(server_time_ms, int)
                    or server_time_ms <= 0
                ):
                    raise SnapshotError("serverTime REST inválido")
        except (
            aiohttp.ClientError,
            asyncio.TimeoutError,
            orjson.JSONDecodeError,
            ValueError,
        ) as exc:
            if isinstance(exc, SnapshotError):
                raise
            raise SnapshotError(f"server time REST inválido: {exc}") from exc
        server_ns = server_time_ms * 1_000_000
        # T2 = T3 = serverTime: θ̂ = ((T2−T1)+(T3−T4))/2, δ = T4−T1.
        theta_hat_ns = ((server_ns - t1_ns) + (server_ns - t4_ns)) // 2
        return {
            "theta_hat_ns": theta_hat_ns,
            "delta_ns": t4_ns - t1_ns,
            "server_time_ms": server_time_ms,
            "t1_utc_ns": t1_ns,
            "t4_utc_ns": t4_ns,
        }

    @staticmethod
    def _decode(
        payload: bytes,
        *,
        receive_utc_ns: int,
        receive_monotonic_ns: int,
    ) -> DepthSnapshot:
        try:
            data: dict[str, Any] = require_dict(orjson.loads(payload), "snapshot REST")
            last_update_id = data.get("lastUpdateId")
            if (
                isinstance(last_update_id, bool)
                or not isinstance(last_update_id, int)
                or last_update_id < 0
            ):
                raise SnapshotError("lastUpdateId REST inválido")
            return DepthSnapshot(
                last_update_id=last_update_id,
                bids=parse_levels(data.get("bids"), "bids REST"),
                asks=parse_levels(data.get("asks"), "asks REST"),
                receive_utc_ns=receive_utc_ns,
                receive_monotonic_ns=receive_monotonic_ns,
                payload_bytes=len(payload),
            )
        except (ValueError, TypeError, orjson.JSONDecodeError) as exc:
            if isinstance(exc, SnapshotError):
                raise
            raise SnapshotError(f"Snapshot REST inválido: {exc}") from exc
