from __future__ import annotations

import asyncio
import logging
import random
import time
import uuid
from contextlib import AsyncExitStack, suppress
from dataclasses import dataclass

import aiohttp
import orjson
from websockets.asyncio.client import ClientConnection, connect
from websockets.exceptions import ConnectionClosedOK

from .config import Settings
from .dashboard import MarketStateHub
from .identity import CaptureSession
from .latency import CooperativeBudget
from .metrics import Metrics
from .models import (
    AggTradeEvent,
    CsvBatch,
    DepthSnapshot,
    DiffDepthEvent,
    MarketEvent,
    PartialDepthEvent,
    RawEnvelope,
)
from .normalize import (
    EventSequencer,
    capture_status_batch,
    connection_batch,
    delta_batch,
    partial_depth_batch,
    snapshot_batch,
    status_batch,
    trade_batch,
)
from .admissibility import SymbolNotAdmissible, evaluate_symbol_admissibility
from .order_book import (
    ApplyResult,
    BookDomainError,
    BookInvariantError,
    LocalOrderBook,
    SequenceGap,
    SequenceOverlap,
    retained_after_snapshot,
    validate_partial_depth,
)
from .protocol import ProtocolError, ServerShutdownNotice, decode_combined
from .rest import RestBanError, SnapshotClient, SnapshotError
from .writer import CsvJournalWriter, WriterFailed

LOGGER = logging.getLogger("binance_collector")
_RAW_SENTINEL = object()
_MAX_CONSECUTIVE_SNAPSHOT_INVARIANT_FAILURES = 3


class ConnectionEnded(RuntimeError):
    pass


class PipelineBackpressure(RuntimeError):
    pass


class PersistenceBackpressure(RuntimeError):
    pass


class CaptureIncomplete(RuntimeError):
    pass


class SymbolOutOfDomain(CaptureIncomplete):
    """ABORT terminal [N1]: un valor del cable no cabe en el punto fijo.

    La causa es determinista (el mismo nivel volvería en cada snapshot), así
    que reintentar tiene P(éxito)=0 y cada intento cuesta 250 de peso REST.
    Un solo snapshot, un código accionable, cero bucles.
    """

    def __init__(self, symbol: str, market: str, detail: str) -> None:
        super().__init__(
            f"SYMBOL_OUT_OF_DOMAIN: {symbol} ({market}) contiene un valor no "
            f"representable en escala 10^8 con dominio 2^63−1: {detail}. "
            "El símbolo no es capturable con esta build; la captura se "
            "aborta sin reintentos."
        )
        self.code = "SYMBOL_OUT_OF_DOMAIN"


@dataclass(slots=True)
class GenerationSequencer:
    value: int = 0

    def next(self) -> int:
        self.value += 1
        return self.value


@dataclass(slots=True)
class RawQueueBudget:
    bytes_inflight: int = 0


class BinanceCollector:
    def __init__(
        self,
        settings: Settings,
        *,
        dashboard_hub: MarketStateHub | None = None,
        capture_session: CaptureSession | None = None,
    ) -> None:
        self.settings = settings.validated()
        self.dashboard_hub = dashboard_hub
        self.capture_session = capture_session or CaptureSession.create()
        self.metrics = Metrics()
        for name, value in (
            ("raw_queue_capacity", self.settings.raw_queue_size),
            ("raw_bytes_capacity", self.settings.raw_queue_max_bytes),
            ("route_queue_capacity", self.settings.route_queue_size),
            ("writer_queue_capacity", self.settings.writer_queue_size),
            ("writer_rows_capacity", self.settings.writer_queue_max_rows),
        ):
            self.metrics.set_gauge(name, value)
        for name in (
            "raw_queue_high_water",
            "raw_bytes_high_water",
            "book_queue_high_water",
            "trade_queue_high_water",
            "partial_queue_high_water",
            "writer_queue_high_water",
            "writer_rows_high_water",
        ):
            self.metrics.set_max_gauge(name, 0)
        self.sequencer = EventSequencer(self.capture_session.capture_session_id)
        self.generations = GenerationSequencer()
        self._last_agg_trade_id: int | None = None
        self._snapshot_invariant_failures = 0
        self._st_absent_callback = (
            (lambda: self.metrics.inc("usdm_st_absent"))
            if self.settings.market == "usdm_futures"
            else None
        )
        self.writer = CsvJournalWriter(
            output_dir=self.settings.output_dir,
            queue_size=self.settings.writer_queue_size,
            max_queued_rows=self.settings.writer_queue_max_rows,
            batch_rows=self.settings.writer_batch_rows,
            flush_interval_s=self.settings.flush_interval_s,
            rotation_bytes=self.settings.rotation_bytes,
            rotation_seconds=self.settings.rotation_seconds,
            metrics=self.metrics,
            write_chunk_rows=self.settings.writer_chunk_rows,
            yield_sleep_s=self.settings.writer_yield_sleep_s,
            fsync_interval_s=self.settings.fsync_interval_s,
        )

    async def run(self, stop: asyncio.Event) -> None:
        LOGGER.info(
            "capture_session_started market=%s capture_session_id=%s",
            self.settings.market,
            self.capture_session.capture_session_id,
        )
        self.writer.start()
        metrics_task = asyncio.create_task(self._metrics_loop(stop), name="metrics")
        lag_probe_task = asyncio.create_task(
            self._event_loop_lag_probe(stop), name="event-loop-lag-probe"
        )
        timeout = aiohttp.ClientTimeout(total=self.settings.snapshot_timeout_s)
        connector = aiohttp.TCPConnector(limit=4, ttl_dns_cache=300)
        reconnect_delay = self.settings.reconnect_initial_s
        incomplete_reason: str | None = None
        finalize_journal = True
        try:
            # [P5]: trust_env=False — un HTTPS_PROXY ambiental podía desviar
            # el snapshot REST sin dejar rastro en la evidencia.
            async with aiohttp.ClientSession(
                timeout=timeout,
                connector=connector,
                trust_env=False,
            ) as session:
                snapshot_client = SnapshotClient(
                    session=session,
                    base_url=self.settings.rest_base_url,
                    depth_path=self.settings.rest_depth_path,
                    symbol=self.settings.symbol,
                    limit=self.settings.snapshot_limit,
                    timeout_s=self.settings.snapshot_timeout_s,
                    retries=self.settings.snapshot_retries,
                    min_interval_s=self.settings.snapshot_min_interval_s,
                    metrics=self.metrics,
                )
                await self._startup_gates(snapshot_client, stop)
                while not stop.is_set():
                    try:
                        await self._run_connection(stop, snapshot_client)
                        reconnect_delay = self.settings.reconnect_initial_s
                    except (PersistenceBackpressure, CaptureIncomplete):
                        raise
                    except (
                        PipelineBackpressure,
                        ProtocolError,
                        ServerShutdownNotice,
                    ) as exc:
                        raise CaptureIncomplete(f"{type(exc).__name__}:{exc}") from exc
                    except WriterFailed:
                        finalize_journal = False
                        raise
                    except asyncio.CancelledError:
                        raise
                    except Exception as exc:
                        self.metrics.inc("reconnections")
                        self._submit(
                            capture_status_batch(
                                symbol=self.settings.symbol,
                                status=f"SEGMENT_INTERRUPTED:{type(exc).__name__}",
                                sequencer=self.sequencer,
                                market=self.settings.market,
                            )
                        )
                        LOGGER.warning(
                            "reconnect type=%s detail=%s",
                            type(exc).__name__,
                            str(exc),
                        )
                        if stop.is_set():
                            break
                        delay = random.uniform(reconnect_delay / 2, reconnect_delay)
                        try:
                            await asyncio.wait_for(stop.wait(), timeout=delay)
                        except asyncio.TimeoutError:
                            pass
                        reconnect_delay = min(
                            self.settings.reconnect_max_s,
                            reconnect_delay * 2,
                        )
        except PersistenceBackpressure as exc:
            incomplete_reason = f"INCOMPLETE:persistence_backpressure:{exc}"
            raise
        except CaptureIncomplete as exc:
            incomplete_reason = f"INCOMPLETE:capture:{exc}"
            raise
        finally:
            stop.set()
            metrics_task.cancel()
            lag_probe_task.cancel()
            await asyncio.gather(
                metrics_task,
                lag_probe_task,
                return_exceptions=True,
            )
            if incomplete_reason is not None and self.writer.fatal_error is None:
                try:
                    marker = capture_status_batch(
                        symbol=self.settings.symbol,
                        status=incomplete_reason,
                        sequencer=self.sequencer,
                        market=self.settings.market,
                    )
                    await asyncio.to_thread(self.writer.submit_blocking, marker)
                except Exception as exc:
                    finalize_journal = False
                    LOGGER.error("incomplete_marker_failed detail=%r", exc)
            await asyncio.to_thread(self.writer.close, finalize=finalize_journal)
            self.metrics.inc("terminal_metric_snapshots")
            await self._emit_metrics()

    async def _startup_gates(
        self,
        snapshot_client: SnapshotClient,
        stop: asyncio.Event,
    ) -> None:
        """REFUSE en arranque (X2/X3) + estimación θ̂ (M3), antes de un socket.

        Un símbolo cuyo maxPrice/maxQty no cabe en 10^8/2^63 se rechaza aquí
        con CERO conexiones WebSocket y una única petición REST; antes producía
        un bucle infinito de reconexión que baneaba la IP en ~72 s ([N1]/F2).
        """

        fetch_info = getattr(snapshot_client, "fetch_exchange_info", None)
        if fetch_info is None:
            # Doble de prueba sin la API: se registra de forma visible.
            self.metrics.inc("admissibility_gate_skipped")
            LOGGER.warning(
                "admissibility_gate_skipped market=%s motivo=cliente sin "
                "fetch_exchange_info",
                self.settings.market,
            )
            return
        payload: dict[str, object] | None = None
        last_error: Exception | None = None
        for attempt in range(3):
            if stop.is_set():
                return
            try:
                payload = await fetch_info(
                    exchange_info_path=self.settings.rest_exchange_info_path
                )
                break
            except RestBanError:
                raise
            except SnapshotError as exc:
                last_error = exc
                await asyncio.sleep(min(2.0**attempt, 4.0))
        if payload is None:
            raise CaptureIncomplete(
                f"EXCHANGE_INFO_UNAVAILABLE:{last_error}"
            ) from last_error
        report = evaluate_symbol_admissibility(
            payload,
            symbol=self.settings.symbol,
            market=self.settings.market,
        )
        self.metrics.set_gauge(
            "symbol_admissibility_margin_x100", int(report.margin * 100)
        )
        if report.margin_warning:
            self.metrics.inc("symbol_admissibility_margin_warnings")
            LOGGER.warning(
                "symbol_margin_low market=%s symbol=%s margin=%.2f "
                "(exigido >= 10): un aumento de maxQty por el exchange puede "
                "dejar el símbolo fuera del dominio fijo",
                self.settings.market,
                self.settings.symbol,
                report.margin,
            )
        LOGGER.info(
            "symbol_admissible market=%s %s",
            self.settings.market,
            report.as_payload(),
        )
        fetch_time = getattr(snapshot_client, "fetch_server_time", None)
        if fetch_time is None:
            return
        try:
            clock = await fetch_time(
                server_time_path=self.settings.rest_server_time_path
            )
        except SnapshotError as exc:
            # La estimación θ̂ es evidencia, no un gate: su ausencia se
            # registra y no impide capturar.
            self.metrics.inc("clock_offset_estimate_failures")
            LOGGER.warning(
                "clock_offset_estimate_failed market=%s detail=%s",
                self.settings.market,
                exc,
            )
            return
        self.metrics.set_gauge("clock_offset_theta_hat_ns", clock["theta_hat_ns"])
        self.metrics.set_gauge("clock_offset_delta_ns", clock["delta_ns"])
        LOGGER.info(
            "clock_offset_estimate market=%s theta_hat_ns=%s delta_ns=%s "
            "(|θ−θ̂| <= δ/2; métricas cross-clock deben leerse con esta banda)",
            self.settings.market,
            clock["theta_hat_ns"],
            clock["delta_ns"],
        )

    async def _run_connection(
        self,
        stop: asyncio.Event,
        snapshot_client: SnapshotClient,
    ) -> None:
        connection_id = uuid.uuid4().hex
        self._publish_status("CONNECTING", clear_book=True)
        self._submit(
            connection_batch(
                symbol=self.settings.symbol,
                connection_id=connection_id,
                state="OPEN",
                sequencer=self.sequencer,
                market=self.settings.market,
            )
        )
        raw_queue: asyncio.Queue[RawEnvelope | object] = asyncio.Queue(
            maxsize=self.settings.raw_queue_size
        )
        raw_budget = RawQueueBudget()
        book_queue: asyncio.Queue[DiffDepthEvent] = asyncio.Queue(
            maxsize=self.settings.route_queue_size
        )
        trade_queue: asyncio.Queue[AggTradeEvent] = asyncio.Queue(
            maxsize=self.settings.route_queue_size
        )
        partial_queue: asyncio.Queue[PartialDepthEvent] = asyncio.Queue(
            maxsize=self.settings.route_queue_size
        )
        tasks: set[asyncio.Task[None]] = set()
        try:
            async with AsyncExitStack() as stack:
                websockets: list[ClientConnection] = []
                source_roles: list[str] = []
                for source_role, websocket_url in self.settings.websocket_sources:
                    websocket = await stack.enter_async_context(
                        connect(
                            websocket_url,
                            compression=None,
                            max_queue=16,
                            max_size=2 * 1024 * 1024,
                            open_timeout=10,
                            close_timeout=5,
                            ping_interval=20,
                            ping_timeout=60,
                        )
                    )
                    websockets.append(websocket)
                    source_roles.append(source_role)
                receiver_tasks = tuple(
                    asyncio.create_task(
                        self._receiver(
                            websocket,
                            connection_id,
                            f"{connection_id}:{source_role}",
                            raw_queue,
                            raw_budget,
                        ),
                        name=f"receiver-{index}",
                    )
                    for index, (websocket, source_role) in enumerate(
                        zip(websockets, source_roles, strict=True)
                    )
                )
                dispatcher_task = asyncio.create_task(
                    self._dispatcher(
                        raw_queue,
                        raw_budget,
                        book_queue,
                        trade_queue,
                        partial_queue,
                    ),
                    name="dispatcher",
                )
                book_task = asyncio.create_task(
                    self._book_worker(book_queue, snapshot_client, connection_id),
                    name="book",
                )
                trade_task = asyncio.create_task(
                    self._trade_worker(trade_queue), name="trades"
                )
                partial_task = asyncio.create_task(
                    self._partial_worker(partial_queue), name="partial"
                )
                tasks = {
                    *receiver_tasks,
                    dispatcher_task,
                    book_task,
                    trade_task,
                    partial_task,
                }
                stop_task = asyncio.create_task(stop.wait(), name="stop-wait")
                done, pending = await asyncio.wait(
                    tasks | {stop_task}, return_when=asyncio.FIRST_COMPLETED
                )
                if stop_task in done:
                    try:
                        await self._drain_connection(
                            websockets=tuple(websockets),
                            receiver_tasks=receiver_tasks,
                            dispatcher_task=dispatcher_task,
                            worker_tasks=(book_task, trade_task, partial_task),
                            raw_queue=raw_queue,
                            book_queue=book_queue,
                            trade_queue=trade_queue,
                            partial_queue=partial_queue,
                        )
                    except Exception as exc:
                        raise CaptureIncomplete(
                            "No se pudo drenar el pipeline"
                        ) from exc
                    return
                stop_task.cancel()
                with suppress(asyncio.CancelledError):
                    await stop_task
                completed_session_tasks = done.difference({stop_task})
                if completed_session_tasks and all(
                    task.get_name().startswith("receiver-")
                    for task in completed_session_tasks
                ):
                    # A remote close ends this socket generation, but payloads
                    # already accepted by any receiver still belong in the
                    # journal. Close the sibling sockets and drain before the
                    # reconnect path observes the receiver exception.
                    await self._drain_connection(
                        websockets=tuple(websockets),
                        receiver_tasks=receiver_tasks,
                        dispatcher_task=dispatcher_task,
                        worker_tasks=(book_task, trade_task, partial_task),
                        raw_queue=raw_queue,
                        book_queue=book_queue,
                        trade_queue=trade_queue,
                        partial_queue=partial_queue,
                    )
                    raise ConnectionEnded("WebSocket terminó; pipeline drenado")
                for task in done:
                    exception = task.exception()
                    if exception is not None:
                        raise exception
                raise ConnectionEnded("Una tarea de sesión terminó inesperadamente")
        finally:
            task_list = list(tasks)
            for task in task_list:
                task.cancel()
            results: list[object] = []
            if task_list:
                results = list(await asyncio.gather(*task_list, return_exceptions=True))
            pipeline_error: BaseException | None = None
            for task, result in zip(task_list, results, strict=True):
                if (
                    (
                        task.get_name().startswith("receiver-")
                        or task.get_name()
                        in {"dispatcher", "book", "trades", "partial"}
                    )
                    and isinstance(result, BaseException)
                    and not isinstance(result, asyncio.CancelledError)
                    and not (
                        task.get_name().startswith("receiver-")
                        and isinstance(result, ConnectionClosedOK)
                    )
                ):
                    pipeline_error = result
                    break
            self._submit(
                connection_batch(
                    symbol=self.settings.symbol,
                    connection_id=connection_id,
                    state="CLOSED",
                    sequencer=self.sequencer,
                    market=self.settings.market,
                )
            )
            self._publish_status("DISCONNECTED", clear_book=True)
            if pipeline_error is not None:
                if isinstance(
                    pipeline_error,
                    (PersistenceBackpressure, WriterFailed),
                ):
                    raise pipeline_error
                if stop.is_set():
                    raise CaptureIncomplete(
                        "Un worker falló mientras se cerraba la conexión"
                    ) from pipeline_error

    async def _drain_connection(
        self,
        *,
        dispatcher_task: asyncio.Task[None],
        worker_tasks: tuple[asyncio.Task[None], ...],
        raw_queue: asyncio.Queue[RawEnvelope | object],
        book_queue: asyncio.Queue[DiffDepthEvent],
        trade_queue: asyncio.Queue[AggTradeEvent],
        partial_queue: asyncio.Queue[PartialDepthEvent],
        websockets: tuple[ClientConnection, ...] | None = None,
        receiver_tasks: tuple[asyncio.Task[None], ...] | None = None,
        websocket: ClientConnection | None = None,
        receiver_task: asyncio.Task[None] | None = None,
    ) -> None:
        if websockets is None:
            if websocket is None:
                raise ValueError("Falta websocket para el drenaje")
            websockets = (websocket,)
        if receiver_tasks is None:
            if receiver_task is None:
                raise ValueError("Falta receiver_task para el drenaje")
            receiver_tasks = (receiver_task,)

        def raise_worker_failure() -> None:
            for task in worker_tasks:
                if not task.done():
                    continue
                if task.cancelled():
                    raise CaptureIncomplete(
                        f"Worker {task.get_name()} cancelado antes del drenaje"
                    )
                exception = task.exception()
                if exception is not None:
                    raise exception
                raise CaptureIncomplete(
                    f"Worker {task.get_name()} terminó antes del drenaje"
                )

        async with asyncio.timeout(self.settings.shutdown_timeout_s):
            raise_worker_failure()
            if dispatcher_task.done():
                exception = dispatcher_task.exception()
                if exception is not None:
                    raise exception
                raise CaptureIncomplete("Dispatcher terminó antes del sentinel")
            await asyncio.gather(*(websocket.close() for websocket in websockets))
            receiver_results = await asyncio.gather(
                *receiver_tasks,
                return_exceptions=True,
            )
            receiver_failure: BaseException | None = None
            for receiver_result in receiver_results:
                if isinstance(receiver_result, BaseException) and not isinstance(
                    receiver_result, ConnectionClosedOK
                ):
                    receiver_failure = receiver_failure or receiver_result
            raise_worker_failure()
            await raw_queue.put(_RAW_SENTINEL)
            await dispatcher_task
            raise_worker_failure()
            await asyncio.gather(
                book_queue.join(),
                trade_queue.join(),
                partial_queue.join(),
            )
            raise_worker_failure()
            if receiver_failure is not None:
                raise receiver_failure

    async def _receiver(
        self,
        websocket: ClientConnection,
        connection_id: str,
        source_socket_id: str,
        output: asyncio.Queue[RawEnvelope | object],
        budget: RawQueueBudget,
    ) -> None:
        cpu_budget = CooperativeBudget(self.settings.cooperative_yield_budget_ms)
        while True:
            payload = await websocket.recv(decode=False)
            receive_monotonic_ns = time.monotonic_ns()
            receive_utc_ns = time.time_ns()
            payload_bytes = len(payload)
            if (
                budget.bytes_inflight + payload_bytes
                > self.settings.raw_queue_max_bytes
            ):
                self.metrics.inc("raw_byte_budget_overflows")
                raise PipelineBackpressure("Presupuesto de bytes raw agotado")
            if output.full():
                self.metrics.inc("raw_queue_overflows")
                raise PipelineBackpressure("Cola raw saturada")
            ingest_seq = self.capture_session.ingest_sequencer.next()
            envelope = RawEnvelope(
                connection_id=connection_id,
                payload=payload,
                receive_utc_ns=receive_utc_ns,
                receive_monotonic_ns=receive_monotonic_ns,
                payload_bytes=payload_bytes,
                raw_queue_size=output.qsize(),
                capture_session_id=self.capture_session.capture_session_id,
                ingest_seq=ingest_seq,
                source_socket_id=source_socket_id,
            )
            try:
                output.put_nowait(envelope)
            except asyncio.QueueFull as exc:
                self.metrics.inc("raw_queue_overflows")
                raise PipelineBackpressure("Cola raw saturada") from exc
            budget.bytes_inflight += payload_bytes
            self.metrics.inc("websocket_messages")
            self.metrics.inc("websocket_bytes", payload_bytes)
            self.metrics.set_gauge("raw_queue_size", output.qsize())
            self.metrics.set_max_gauge("raw_queue_high_water", output.qsize())
            self.metrics.set_gauge("raw_bytes_inflight", budget.bytes_inflight)
            self.metrics.set_max_gauge("raw_bytes_high_water", budget.bytes_inflight)
            self.metrics.set_gauge("last_ingest_seq", ingest_seq)
            if cpu_budget.expired():
                await asyncio.sleep(0)
                cpu_budget.reset()
                self.metrics.inc("cooperative_yields_receiver")

    async def _dispatcher(
        self,
        raw_queue: asyncio.Queue[RawEnvelope | object],
        budget: RawQueueBudget,
        book_queue: asyncio.Queue[DiffDepthEvent],
        trade_queue: asyncio.Queue[AggTradeEvent],
        partial_queue: asyncio.Queue[PartialDepthEvent],
    ) -> None:
        cpu_budget = CooperativeBudget(self.settings.cooperative_yield_budget_ms)
        while True:
            envelope = await raw_queue.get()
            if envelope is _RAW_SENTINEL:
                raw_queue.task_done()
                return
            assert isinstance(envelope, RawEnvelope)
            # [2.3.6] Duraciones locales con perf_counter_ns: en Windows +
            # Python 3.12, monotonic_ns() usa GetTickCount64 (tic de 15.625
            # ms) y las duraciones sub-ms salían 0.0 o 15/16 clavados
            # (evidencia: sesión 5ebb3efde620). Los campos de DATOS
            # (receive_monotonic_ns y derivados) conservan monotonic_ns.
            started = time.perf_counter_ns()
            try:
                event = decode_combined(
                    envelope,
                    symbol=self.settings.symbol,
                    stream_names=self.settings.stream_names,
                    market=self.settings.market,
                    on_usdm_st_absent=self._st_absent_callback,
                )
            except ServerShutdownNotice:
                self.metrics.inc("server_shutdown_notices")
                raise
            except ProtocolError:
                self.metrics.inc("protocol_errors")
                raise
            finally:
                budget.bytes_inflight = max(
                    0, budget.bytes_inflight - envelope.payload_bytes
                )
                self.metrics.set_gauge("raw_bytes_inflight", budget.bytes_inflight)
                self.metrics.set_gauge("raw_queue_size", raw_queue.qsize())
                raw_queue.task_done()
            self.metrics.observe(
                "parse", (time.perf_counter_ns() - started) / 1_000_000
            )
            destination: asyncio.Queue[MarketEvent]
            if isinstance(event, DiffDepthEvent):
                destination = book_queue
                queue_name = "book_queue"
                self.metrics.inc("depth_diff_messages")
            elif isinstance(event, AggTradeEvent):
                destination = trade_queue
                queue_name = "trade_queue"
                self.metrics.inc("agg_trade_messages")
            else:
                destination = partial_queue
                queue_name = "partial_queue"
                self.metrics.inc("partial_depth_messages")
            try:
                destination.put_nowait(event)
            except asyncio.QueueFull as exc:
                self.metrics.inc("route_queue_overflows")
                raise PipelineBackpressure("Cola de canal saturada") from exc
            self.metrics.set_gauge(f"{queue_name}_size", destination.qsize())
            self.metrics.set_max_gauge(f"{queue_name}_high_water", destination.qsize())
            if cpu_budget.expired():
                await asyncio.sleep(0)
                cpu_budget.reset()
                self.metrics.inc("cooperative_yields_dispatcher")

    async def _trade_worker(self, queue: asyncio.Queue[AggTradeEvent]) -> None:
        cpu_budget = CooperativeBudget(self.settings.cooperative_yield_budget_ms)
        while True:
            event = await queue.get()
            note: str | None = None
            if self._last_agg_trade_id is not None:
                if event.aggregate_trade_id <= self._last_agg_trade_id:
                    note = "non_monotonic_id"
                    self.metrics.inc("agg_trade_non_monotonic")
                elif event.aggregate_trade_id > self._last_agg_trade_id + 1:
                    note = "id_jump_unverified"
                    self.metrics.inc("agg_trade_id_jumps")
            self._last_agg_trade_id = max(
                self._last_agg_trade_id or event.aggregate_trade_id,
                event.aggregate_trade_id,
            )
            self._submit(
                trade_batch(
                    event,
                    self.sequencer,
                    note,
                    market=self.settings.market,
                )
            )
            if self.dashboard_hub is not None:
                self.dashboard_hub.publish_trade(
                    market=self.settings.market,
                    symbol=event.symbol,
                    aggregate_trade_id=event.aggregate_trade_id,
                    price=event.price,
                    quantity=event.quantity,
                    buyer_is_maker=event.buyer_is_maker,
                    exchange_trade_time_ms=event.trade_time_ms,
                    receive_utc_ns=event.receive_utc_ns,
                )
            self.metrics.observe(
                "exchange_to_receive_trade",
                (event.receive_utc_ns - event.event_time_ms * 1_000_000) / 1_000_000,
            )
            self.metrics.observe(
                "trade_time_to_receive",
                (event.receive_utc_ns - event.trade_time_ms * 1_000_000) / 1_000_000,
            )
            queue.task_done()
            self.metrics.set_gauge("trade_queue_size", queue.qsize())
            if cpu_budget.expired():
                await asyncio.sleep(0)
                cpu_budget.reset()
                self.metrics.inc("cooperative_yields_trade")

    async def _partial_worker(self, queue: asyncio.Queue[PartialDepthEvent]) -> None:
        last_update_id: int | None = None
        cpu_budget = CooperativeBudget(self.settings.cooperative_yield_budget_ms)
        while True:
            event = await queue.get()
            # [2.3.6] perf_counter_ns: duración local (ver nota en _parse).
            started = time.perf_counter_ns()
            validate_partial_depth(event)
            note: str | None = "full_top20_replacement"
            if last_update_id is not None and event.last_update_id < last_update_id:
                note = "regressive_last_update_id"
                self.metrics.inc("partial_depth_regressions")
            elif last_update_id == event.last_update_id:
                note = "repeated_last_update_id"
                self.metrics.inc("partial_depth_repeats")
            last_update_id = max(
                last_update_id or event.last_update_id, event.last_update_id
            )
            self._submit(
                partial_depth_batch(
                    event,
                    self.settings.symbol,
                    self.sequencer,
                    note,
                    market=self.settings.market,
                )
            )
            self.metrics.observe(
                "partial_validation",
                (time.perf_counter_ns() - started) / 1_000_000,
            )
            queue.task_done()
            self.metrics.set_gauge("partial_queue_size", queue.qsize())
            if cpu_budget.expired():
                await asyncio.sleep(0)
                cpu_budget.reset()
                self.metrics.inc("cooperative_yields_partial")

    async def _book_worker(
        self,
        queue: asyncio.Queue[DiffDepthEvent],
        snapshots: SnapshotClient,
        connection_id: str,
    ) -> None:
        seed: list[DiffDepthEvent] | None = None
        generation: int | None = None
        last_sequence: int | None = None
        try:
            while True:
                generation = self.generations.next()
                self._submit(
                    status_batch(
                        symbol=self.settings.symbol,
                        connection_id=connection_id,
                        generation=generation,
                        status="SYNCING",
                        sequencer=self.sequencer,
                        market=self.settings.market,
                    )
                )
                self._publish_status("SYNCING", clear_book=True)
                snapshot, buffered, consumed_count = await self._synchronize(
                    queue, snapshots, seed
                )
                seed = None
                book = LocalOrderBook(
                    self.settings.max_levels_per_side,
                    market=self.settings.market,
                    snapshot_limit=self.settings.snapshot_limit,
                )
                # [N1]/R1.2: este await estaba FUERA de todo try. Un snapshot
                # con un nivel fuera de dominio mataba la tarea, provocaba una
                # reconexión y el siguiente snapshot repetía el mismo error:
                # bucle infinito + ban de IP en ~72 s. Ahora se clasifica:
                #   BookDomainError (determinista)  -> ABORT SYMBOL_OUT_OF_DOMAIN
                #   BookInvariantError (transitorio)-> RESYNC acotado
                try:
                    await asyncio.to_thread(book.load_snapshot, snapshot)
                    self._snapshot_invariant_failures = 0
                except BookDomainError as exc:
                    self.metrics.inc("symbol_domain_aborts")
                    for _ in range(consumed_count):
                        queue.task_done()
                    raise SymbolOutOfDomain(
                        self.settings.symbol, self.settings.market, str(exc)
                    ) from exc
                except BookInvariantError as exc:
                    self._snapshot_invariant_failures += 1
                    self.metrics.inc("snapshot_invariant_failures")
                    for trailing in buffered:
                        self._submit(
                            delta_batch(
                                trailing,
                                generation,
                                self.sequencer,
                                "buffered_after_invalid",
                                market=self.settings.market,
                            )
                        )
                    for _ in range(consumed_count):
                        queue.task_done()
                    self._submit(
                        status_batch(
                            symbol=self.settings.symbol,
                            connection_id=connection_id,
                            generation=generation,
                            status="INVALIDATED:snapshot",
                            sequencer=self.sequencer,
                            market=self.settings.market,
                        )
                    )
                    self._publish_status("INVALIDATED:snapshot", clear_book=True)
                    if (
                        self._snapshot_invariant_failures
                        >= _MAX_CONSECUTIVE_SNAPSHOT_INVARIANT_FAILURES
                    ):
                        raise CaptureIncomplete(
                            "SNAPSHOT_INVARIANT_PERSISTENT: "
                            f"{self._snapshot_invariant_failures} snapshots "
                            f"consecutivos inválidos; último error: {exc}"
                        ) from exc
                    continue
                self._submit(
                    await asyncio.to_thread(
                        snapshot_batch,
                        snapshot,
                        self.settings.symbol,
                        connection_id,
                        generation,
                        self.sequencer,
                        market=self.settings.market,
                    )
                )
                resync = False
                last_dashboard_event: DiffDepthEvent | None = None
                bootstrap_budget = CooperativeBudget(
                    self.settings.cooperative_yield_budget_ms
                )
                try:
                    for index, event in enumerate(buffered):
                        try:
                            result = await self._apply_book_event(
                                book,
                                event,
                                generation,
                                publish_dashboard=False,
                            )
                            if result is not ApplyResult.STALE:
                                last_dashboard_event = event
                        except SequenceGap:
                            self.metrics.inc("book_gaps")
                            self._submit(
                                delta_batch(
                                    event,
                                    generation,
                                    self.sequencer,
                                    "gap",
                                    market=self.settings.market,
                                )
                            )
                            for trailing in buffered[index + 1 :]:
                                self._submit(
                                    delta_batch(
                                        trailing,
                                        generation,
                                        self.sequencer,
                                        "buffered_after_gap",
                                        market=self.settings.market,
                                    )
                                )
                            seed = buffered[index:]
                            resync = True
                            break
                        except BookDomainError as exc:
                            self.metrics.inc("symbol_domain_aborts")
                            self._submit(
                                delta_batch(
                                    event,
                                    generation,
                                    self.sequencer,
                                    "invalid",
                                    market=self.settings.market,
                                )
                            )
                            raise SymbolOutOfDomain(
                                self.settings.symbol,
                                self.settings.market,
                                str(exc),
                            ) from exc
                        except BookInvariantError as invariant_exc:
                            if isinstance(invariant_exc, SequenceOverlap):
                                self.metrics.inc("l2_overlap_events")
                            self.metrics.inc("book_invariant_failures")
                            self._submit(
                                delta_batch(
                                    event,
                                    generation,
                                    self.sequencer,
                                    "invalid",
                                    market=self.settings.market,
                                )
                            )
                            for trailing in buffered[index + 1 :]:
                                self._submit(
                                    delta_batch(
                                        trailing,
                                        generation,
                                        self.sequencer,
                                        "buffered_after_invalid",
                                        market=self.settings.market,
                                    )
                                )
                            seed = buffered[index + 1 :] or None
                            resync = True
                            break
                        if bootstrap_budget.expired():
                            await asyncio.sleep(0)
                            bootstrap_budget.reset()
                            self.metrics.inc("cooperative_yields_book_bootstrap")
                finally:
                    for _ in range(consumed_count):
                        queue.task_done()
                if resync:
                    last_sequence = book.last_update_id
                    self._submit(
                        status_batch(
                            symbol=self.settings.symbol,
                            connection_id=connection_id,
                            generation=generation,
                            status="INVALIDATED:bootstrap",
                            sequence=last_sequence,
                            sequencer=self.sequencer,
                            market=self.settings.market,
                        )
                    )
                    self._publish_status(
                        "INVALIDATED:bootstrap",
                        clear_book=True,
                    )
                    continue
                last_sequence = book.last_update_id
                if last_dashboard_event is not None:
                    self._publish_book_view(
                        book,
                        last_dashboard_event,
                        generation,
                    )
                self._submit(
                    status_batch(
                        symbol=self.settings.symbol,
                        connection_id=connection_id,
                        generation=generation,
                        status="SYNCED",
                        sequence=last_sequence,
                        sequencer=self.sequencer,
                        market=self.settings.market,
                    )
                )
                self._publish_status("SYNCED", clear_book=False)
                self.metrics.inc("book_syncs")
                live_budget = CooperativeBudget(
                    self.settings.cooperative_yield_budget_ms
                )
                while True:
                    event = await queue.get()
                    try:
                        await self._apply_book_event(book, event, generation)
                        last_sequence = book.last_update_id
                    except SequenceGap:
                        self.metrics.inc("book_gaps")
                        self._submit(
                            delta_batch(
                                event,
                                generation,
                                self.sequencer,
                                "gap",
                                market=self.settings.market,
                            )
                        )
                        self._submit(
                            status_batch(
                                symbol=self.settings.symbol,
                                connection_id=connection_id,
                                generation=generation,
                                status="INVALIDATED:gap",
                                sequence=book.last_update_id,
                                sequencer=self.sequencer,
                                market=self.settings.market,
                            )
                        )
                        self._publish_status("INVALIDATED:gap", clear_book=True)
                        seed = [event]
                        break
                    except BookDomainError as exc:
                        self.metrics.inc("symbol_domain_aborts")
                        self._submit(
                            delta_batch(
                                event,
                                generation,
                                self.sequencer,
                                "invalid",
                                market=self.settings.market,
                            )
                        )
                        raise SymbolOutOfDomain(
                            self.settings.symbol,
                            self.settings.market,
                            str(exc),
                        ) from exc
                    except BookInvariantError as invariant_exc:
                        if isinstance(invariant_exc, SequenceOverlap):
                            self.metrics.inc("l2_overlap_events")
                        self.metrics.inc("book_invariant_failures")
                        self._submit(
                            delta_batch(
                                event,
                                generation,
                                self.sequencer,
                                "invalid",
                                market=self.settings.market,
                            )
                        )
                        self._submit(
                            status_batch(
                                symbol=self.settings.symbol,
                                connection_id=connection_id,
                                generation=generation,
                                status="INVALIDATED:invariant",
                                sequence=book.last_update_id,
                                sequencer=self.sequencer,
                                market=self.settings.market,
                            )
                        )
                        self._publish_status(
                            "INVALIDATED:invariant",
                            clear_book=True,
                        )
                        seed = None
                        break
                    finally:
                        queue.task_done()
                        self.metrics.set_gauge("book_queue_size", queue.qsize())
                    if live_budget.expired():
                        await asyncio.sleep(0)
                        live_budget.reset()
                        self.metrics.inc("cooperative_yields_book")
        finally:
            if generation is not None:
                self._submit(
                    status_batch(
                        symbol=self.settings.symbol,
                        connection_id=connection_id,
                        generation=generation,
                        status="INVALIDATED:connection_end",
                        sequence=last_sequence,
                        sequencer=self.sequencer,
                        market=self.settings.market,
                    )
                )
                self._publish_status(
                    "INVALIDATED:connection_end",
                    clear_book=True,
                )

    async def _synchronize(
        self,
        queue: asyncio.Queue[DiffDepthEvent],
        snapshots: SnapshotClient,
        seed: list[DiffDepthEvent] | None,
    ) -> tuple[DepthSnapshot, list[DiffDepthEvent], int]:
        buffered = list(seed or ())
        buffered_bytes = sum(event.payload_bytes for event in buffered)
        consumed_counter = [0]
        try:
            return await self._synchronize_inner(
                queue, snapshots, buffered, buffered_bytes, consumed_counter
            )
        except BaseException:
            # [P16] fuga de task_done: si la sincronización falla, el caller
            # nunca recibe consumed_count y el drenaje colgaría en join().
            for _ in range(consumed_counter[0]):
                queue.task_done()
            raise

    async def _synchronize_inner(
        self,
        queue: asyncio.Queue[DiffDepthEvent],
        snapshots: SnapshotClient,
        buffered: list[DiffDepthEvent],
        buffered_bytes: int,
        consumed_counter: list[int],
    ) -> tuple[DepthSnapshot, list[DiffDepthEvent], int]:
        def consumed(event: DiffDepthEvent) -> int:
            nonlocal buffered_bytes
            buffered.append(event)
            consumed_counter[0] += 1
            buffered_bytes += event.payload_bytes
            return buffered_bytes

        cpu_budget = CooperativeBudget(self.settings.cooperative_yield_budget_ms)
        if not buffered:
            consumed(await queue.get())
        while True:
            snapshot_task = asyncio.create_task(snapshots.fetch())
            getter: asyncio.Task[DiffDepthEvent] | None = None
            try:
                # [P16]: antes se despertaba 100 veces/s con wait_for(0.01).
                # Ahora se espera a la vez el snapshot y el siguiente evento.
                while not snapshot_task.done():
                    if getter is None:
                        getter = asyncio.create_task(queue.get())
                    done, _pending = await asyncio.wait(
                        {getter, snapshot_task},
                        return_when=asyncio.FIRST_COMPLETED,
                    )
                    if getter in done:
                        consumed(getter.result())
                        getter = None
                        if (
                            len(buffered) > self.settings.sync_buffer_size
                            or buffered_bytes > self.settings.sync_buffer_max_bytes
                        ):
                            raise PipelineBackpressure(
                                "Buffer de bootstrap L2 saturado"
                            )
                        if cpu_budget.expired():
                            await asyncio.sleep(0)
                            cpu_budget.reset()
                            self.metrics.inc("cooperative_yields_synchronize")
                snapshot = await snapshot_task
            except BaseException:
                if not snapshot_task.done():
                    snapshot_task.cancel()
                    with suppress(asyncio.CancelledError):
                        await snapshot_task
                raise
            finally:
                if getter is not None and not getter.done():
                    getter.cancel()
                    with suppress(asyncio.CancelledError):
                        await getter
                elif getter is not None and getter.done() and not getter.cancelled():
                    exception = getter.exception()
                    if exception is None:
                        consumed(getter.result())
            # Spot puede enlazar un snapshot L con el sucesor exacto U=L+1.
            # Futures necesita que el snapshot quede dentro del bridge U..u.
            snapshot_floor = (
                buffered[0].first_update_id - 1
                if self.settings.market == "spot"
                else buffered[0].first_update_id
            )
            if snapshot.last_update_id < snapshot_floor:
                self.metrics.inc("snapshot_too_old")
                continue
            while True:
                try:
                    retained = retained_after_snapshot(
                        snapshot.last_update_id,
                        buffered,
                        market=self.settings.market,
                    )
                except SequenceGap:
                    self.metrics.inc("bootstrap_gaps")
                    break
                if retained:
                    return snapshot, buffered, consumed_counter[0]
                event = await queue.get()
                consumed(event)
                if (
                    len(buffered) > self.settings.sync_buffer_size
                    or buffered_bytes > self.settings.sync_buffer_max_bytes
                ):
                    raise PipelineBackpressure("Buffer de bootstrap L2 saturado")
                if cpu_budget.expired():
                    await asyncio.sleep(0)
                    cpu_budget.reset()
                    self.metrics.inc("cooperative_yields_synchronize")
            continue

    async def _apply_book_event(
        self,
        book: LocalOrderBook,
        event: DiffDepthEvent,
        generation: int,
        *,
        publish_dashboard: bool = True,
    ) -> ApplyResult:
        # [2.3.6] Toda la tubería del libro se mide con perf_counter_ns
        # (duraciones locales; ver nota en _parse). Los gates de 5 ms ya no
        # quedan por debajo de la resolución del reloj.
        pipeline_started = time.perf_counter_ns()
        level_count = len(event.bids) + len(event.asks)
        apply_started = pipeline_started
        if level_count >= self.settings.book_apply_offload_levels:
            result = await asyncio.to_thread(book.apply, event)
            self.metrics.inc("book_apply_offloaded")
        else:
            result = book.apply(event)
        apply_finished = time.perf_counter_ns()
        self.metrics.observe("book_apply", (apply_finished - apply_started) / 1_000_000)
        if result is ApplyResult.APPLIED:
            note = "applied"
        elif result is ApplyResult.ANCHORED:
            note = "anchored"
        else:
            note = "stale"
        journal_started = time.perf_counter_ns()
        journal_batch = delta_batch(
            event,
            generation,
            self.sequencer,
            note,
            market=self.settings.market,
        )
        self.metrics.observe(
            "journal_build",
            (time.perf_counter_ns() - journal_started) / 1_000_000,
        )
        enqueue_started = time.perf_counter_ns()
        self._submit(journal_batch)
        self.metrics.observe(
            "journal_enqueue",
            (time.perf_counter_ns() - enqueue_started) / 1_000_000,
        )
        if result is ApplyResult.STALE:
            self.metrics.inc("depth_stale_events")
        else:
            if result is ApplyResult.ANCHORED:
                self.metrics.inc("depth_anchor_events")
            else:
                self.metrics.inc("depth_applied_events")
            if publish_dashboard:
                dashboard_started = time.perf_counter_ns()
                self._publish_book_view(book, event, generation)
                self.metrics.observe(
                    "dashboard_project",
                    (time.perf_counter_ns() - dashboard_started) / 1_000_000,
                )
        self.metrics.set_gauge("book_last_update_id", book.last_update_id or 0)
        self.metrics.set_gauge("book_bid_levels", len(book.bids))
        self.metrics.set_gauge("book_ask_levels", len(book.asks))
        self.metrics.observe(
            "book_pipeline_total",
            (time.perf_counter_ns() - pipeline_started) / 1_000_000,
        )
        self.metrics.observe(
            "exchange_to_receive_depth",
            (event.receive_utc_ns - event.event_time_ms * 1_000_000) / 1_000_000,
        )
        return result

    def _publish_book_view(
        self,
        book: LocalOrderBook,
        event: DiffDepthEvent,
        generation: int,
    ) -> None:
        if self.dashboard_hub is None:
            return
        # El hub de produccion puede omitir una segunda validacion/sort porque
        # LocalOrderBook ya garantiza esos invariantes. Los dobles de prueba y
        # extensiones conservan el contrato publico ``publish_book``.
        if type(self.dashboard_hub) is MarketStateHub:
            bids, asks = book.top_fixed(self.dashboard_hub.top_levels)
            publish_book = self.dashboard_hub.publish_trusted_fixed_book
        else:
            bids, asks = book.top_wire(self.dashboard_hub.top_levels)
            publish_book = self.dashboard_hub.publish_book
        publish_book(  # type: ignore[arg-type]
            market=self.settings.market,
            symbol=event.symbol,
            generation=generation,
            sequence=book.last_update_id or event.final_update_id,
            bids=bids,
            asks=asks,
            receive_utc_ns=event.receive_utc_ns,
            receive_monotonic_ns=event.receive_monotonic_ns,
            exchange_event_time_ms=event.event_time_ms,
        )

    def _submit(self, batch: CsvBatch) -> None:
        if not self.writer.submit(batch):
            raise PersistenceBackpressure("Cola de persistencia saturada; fail-stop")

    def _publish_status(
        self,
        status: str,
        *,
        clear_book: bool,
    ) -> None:
        if self.dashboard_hub is None:
            return
        self.dashboard_hub.publish_status(
            market=self.settings.market,
            status=status,
            clear_book=clear_book,
        )

    async def _metrics_loop(self, stop: asyncio.Event) -> None:
        while not stop.is_set():
            try:
                await asyncio.wait_for(
                    stop.wait(),
                    timeout=self.settings.metrics_interval_s,
                )
            except asyncio.TimeoutError:
                fatal = self.writer.fatal_error
                if fatal is not None:
                    LOGGER.error("writer_failed detail=%r", fatal)
                    stop.set()
                    return
                await self._emit_metrics()

    async def _emit_metrics(self) -> None:
        metrics_snapshot = await asyncio.to_thread(self.metrics.snapshot)
        metrics_payload = await asyncio.to_thread(orjson.dumps, metrics_snapshot)
        LOGGER.info(
            "metrics market=%s %s",
            self.settings.market,
            metrics_payload.decode("utf-8"),
        )

    async def _event_loop_lag_probe(self, stop: asyncio.Event) -> None:
        """Watchdog independiente; no mezcla el tick con serializacion/logging."""

        interval = self.settings.event_loop_probe_interval_s
        loop = asyncio.get_running_loop()
        deadline = loop.time() + interval
        while not stop.is_set():
            await asyncio.sleep(max(0.0, deadline - loop.time()))
            now = loop.time()
            lag_s = max(0.0, now - deadline)
            self.metrics.observe("event_loop_lag", lag_s * 1_000)
            if lag_s >= interval:
                self.metrics.inc(
                    "event_loop_probe_missed_ticks",
                    max(1, int(lag_s / interval)),
                )
            deadline += interval
            if deadline <= now:
                # No hacemos un spin para "recuperar" ticks perdidos: una sola
                # muestra conserva el retraso real y el siguiente deadline parte
                # del presente.
                deadline = now + interval
