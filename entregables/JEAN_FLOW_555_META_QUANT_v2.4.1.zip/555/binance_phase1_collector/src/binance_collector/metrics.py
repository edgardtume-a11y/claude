from __future__ import annotations

import itertools
import math
import threading
from collections import defaultdict, deque
from typing import Any


def _percentile(values: list[float], fraction: float) -> float:
    """Percentil nearest-rank: index = ceil(f·n) − 1.

    El estimador anterior usaba round((n−1)·f) con redondeo bancario: con
    n=67 y un outlier de 50 ms reportaba p99 = 0.1 ms (P0.4b). Nearest-rank
    nunca infra-reporta el rango del cuantil. Única implementación del
    proyecto: audit.py la importa de aquí.
    """

    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, math.ceil(fraction * len(ordered)) - 1))
    return round(ordered[index], 3)


class _MetricShard:
    __slots__ = ("counters", "gauges", "max_gauges", "observations", "observed_totals")

    def __init__(self, latency_window: int) -> None:
        self.counters: defaultdict[str, int] = defaultdict(int)
        self.gauges: dict[str, tuple[int, int | float]] = {}
        self.max_gauges: dict[str, int | float] = {}
        self.observations: defaultdict[str, deque[float]] = defaultdict(
            lambda: deque(maxlen=latency_window)
        )
        self.observed_totals: defaultdict[str, int] = defaultdict(int)


class Metrics:
    """Metricas por shard de thread sin un lock global en la ruta caliente.

    El collector/event loop y cada writer tienen shards distintos. Las
    mutaciones quedan protegidas por el GIL de CPython y nunca compiten entre
    productores. Solo el alta infrecuente de un shard usa un lock; ``snapshot``
    copia y combina los shards en el worker de metricas.
    """

    def __init__(self, latency_window: int = 10_000) -> None:
        if latency_window <= 0:
            raise ValueError("latency_window debe ser positivo")
        self._latency_window = latency_window
        self._local = threading.local()
        self._registry_lock = threading.Lock()
        self._shards: list[_MetricShard] = []
        self._gauge_sequence = itertools.count(1)

    def _shard(self) -> _MetricShard:
        shard = getattr(self._local, "metric_shard", None)
        if shard is not None:
            return shard
        shard = _MetricShard(self._latency_window)
        with self._registry_lock:
            self._shards.append(shard)
        self._local.metric_shard = shard
        return shard

    def inc(self, name: str, value: int = 1) -> None:
        self._shard().counters[name] += value

    def set_gauge(self, name: str, value: int | float) -> None:
        self._shard().gauges[name] = (next(self._gauge_sequence), value)

    def set_max_gauge(self, name: str, value: int | float) -> None:
        shard = self._shard()
        shard.max_gauges[name] = max(shard.max_gauges.get(name, value), value)

    def observe(self, name: str, value: float) -> None:
        # [2.3.6] El total se incrementa ANTES de anexar: así toda muestra
        # visible en una foto tiene su incremento ya contado y el invariante
        # count <= count_total se sostiene bajo cualquier intercalado.
        # Evidencia de campo (sesión 5ebb3efde620): "cobertura de ventana
        # violada (snapshot 76: count=9304 > count_total=9303)" en 3 métricas
        # del mismo shard, off-by-one exacto del orden anterior.
        shard = self._shard()
        shard.observed_totals[name] += 1
        shard.observations[name].append(value)

    def snapshot(self) -> dict[str, Any]:
        with self._registry_lock:
            shards = tuple(self._shards)

        counters: defaultdict[str, int] = defaultdict(int)
        gauge_versions: dict[str, tuple[int, int | float]] = {}
        max_gauges: dict[str, int | float] = {}
        observations: defaultdict[str, list[float]] = defaultdict(list)
        observed_totals: defaultdict[str, int] = defaultdict(int)

        for shard in shards:
            # ``dict.copy`` y ``list(deque)`` se ejecutan en C bajo el GIL. Eso
            # entrega una foto coherente sin poner locks en cada inc/observe y
            # evita iteradores que fallen si el writer crea una metrica nueva.
            # [2.3.6] El CONTENIDO de cada deque se congela AQUÍ y los totales
            # se copian DESPUÉS. Antes se copiaba el dict (referencias a los
            # deques vivos), luego los totales, y el contenido recién se leía
            # al final: una muestra anexada en medio aparecía en la ventana
            # pero no en el total (count > count_total, snapshot 76 de la
            # sesión 5ebb3efde620). Con el orden total-antes-de-anexar de
            # ``observe`` más contenido-antes-que-totales aquí, toda muestra
            # visible tiene su incremento contado: count <= count_total.
            shard_counters = shard.counters.copy()
            shard_gauges = shard.gauges.copy()
            shard_max_gauges = shard.max_gauges.copy()
            shard_observations = {
                name: list(values)
                for name, values in shard.observations.copy().items()
            }
            shard_totals = shard.observed_totals.copy()
            for name, value in shard_counters.items():
                counters[name] += value
            for name, versioned in shard_gauges.items():
                current = gauge_versions.get(name)
                if current is None or versioned[0] > current[0]:
                    gauge_versions[name] = versioned
            for name, value in shard_max_gauges.items():
                max_gauges[name] = max(max_gauges.get(name, value), value)
            for name, values in shard_observations.items():
                observations[name].extend(values)
            for name, total in shard_totals.items():
                observed_totals[name] += total

        gauges = {name: value for name, (_, value) in gauge_versions.items()}
        gauges.update(max_gauges)
        bounded_observations = {
            name: values[-self._latency_window :]
            for name, values in observations.items()
        }
        # P0.4a: la ventana deslizante descartaba muestras SIN contador. Cada
        # métrica publica count_total (acumulado) y evicted (descartadas de la
        # ventana); el auditor puede exigir evicted == 0 en métricas de gate.
        latencies = {
            name: {
                "count": len(values),
                "count_total": observed_totals.get(name, len(values)),
                "evicted": max(
                    0, observed_totals.get(name, len(values)) - len(values)
                ),
                "p50": _percentile(values, 0.50),
                "p95": _percentile(values, 0.95),
                "p99": _percentile(values, 0.99),
                "max": round(max(values), 3) if values else 0.0,
            }
            for name, values in bounded_observations.items()
        }
        return {
            "counters": dict(counters),
            "gauges": gauges,
            "latency_ms": latencies,
        }
