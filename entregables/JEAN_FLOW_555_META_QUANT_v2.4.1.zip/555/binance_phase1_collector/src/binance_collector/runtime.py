from __future__ import annotations

import json
import math
import os
import sys
import time
import uuid
from contextlib import suppress
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Mapping

from .identity import validate_capture_session_id


PRODUCT_NAME = "JEAN_FLOW"
READY_PROTOCOL_VERSION = "1.0.0"
SESSION_MANIFEST_VERSION = "1.0.0"
EXPECTED_MARKETS = ("spot", "usdm_futures")
RUNTIME_STATES = frozenset(
    {"STARTING", "IDENTITY_READY", "CAPTURING", "STOPPING", "COMPLETED", "FAILED"}
)
_STATE_TRANSITIONS = {
    "STARTING": frozenset({"STARTING", "IDENTITY_READY", "FAILED"}),
    "IDENTITY_READY": frozenset(
        {"IDENTITY_READY", "CAPTURING", "STOPPING", "FAILED"}
    ),
    "CAPTURING": frozenset({"CAPTURING", "STOPPING", "FAILED"}),
    "STOPPING": frozenset({"STOPPING", "COMPLETED", "FAILED"}),
    "COMPLETED": frozenset({"COMPLETED"}),
    "FAILED": frozenset({"FAILED"}),
}


class RuntimeContractError(RuntimeError):
    """Typed failure in the launcher/engine runtime contract."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"Constante JSON no finita: {value}")


def read_json_object(path: Path, *, max_bytes: int = 256 * 1024) -> dict[str, Any]:
    """Read one strict, bounded JSON object from disk."""

    try:
        size = path.stat().st_size
    except OSError as exc:
        raise RuntimeContractError("RUNTIME_FILE_READ_FAILED", str(exc)) from exc
    if size <= 0 or size > max_bytes:
        raise RuntimeContractError(
            "RUNTIME_FILE_INVALID", f"Tamaño JSON inválido: {size} bytes"
        )
    try:
        raw = path.read_text(encoding="utf-8")
        value = json.loads(raw, parse_constant=_reject_json_constant)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
        raise RuntimeContractError("RUNTIME_FILE_INVALID", str(exc)) from exc
    if not isinstance(value, dict):
        raise RuntimeContractError("RUNTIME_FILE_INVALID", "Se esperaba un objeto JSON")
    return value


def _encode_json(payload: Mapping[str, Any]) -> bytes:
    try:
        return (
            json.dumps(
                dict(payload),
                ensure_ascii=False,
                allow_nan=False,
                sort_keys=True,
                separators=(",", ":"),
            )
            + "\n"
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise RuntimeContractError("RUNTIME_JSON_INVALID", str(exc)) from exc


def _fsync_parent(path: Path) -> None:
    if os.name == "nt":
        return
    directory_fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def exclusive_write_json(path: Path, payload: Mapping[str, Any]) -> None:
    """Create a new durable JSON file without ever replacing an existing one."""

    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = _encode_json(payload)
    try:
        descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise RuntimeContractError("RUNTIME_FILE_EXISTS", str(path)) from exc
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        _fsync_parent(path)
    except OSError as exc:
        with suppress(OSError):
            path.unlink(missing_ok=True)
        raise RuntimeContractError("RUNTIME_FILE_WRITE_FAILED", str(exc)) from exc


def atomic_write_json(
    path: Path,
    payload: Mapping[str, Any],
    *,
    durable: bool = True,
    replace_retries: int = 0,
    replace_retry_delay_s: float = 0.025,
) -> None:
    """Durably replace *path* with one finite JSON object.

    The temporary file lives beside the destination, so ``os.replace`` remains
    atomic on Windows and POSIX.  A unique name prevents two sessions from
    sharing a temporary file accidentally.

    P0.3: en Windows, CPython abre sin FILE_SHARE_DELETE; si el lector tiene
    el archivo abierto en el instante del ``os.replace`` se produce una
    sharing violation transitoria. ``replace_retries`` reintenta ese replace
    con una espera corta antes de rendirse (por defecto 0: comportamiento
    histórico). ``durable=False`` omite fsync de archivo y directorio para
    escrituras cuyo valor es la frescura, no la durabilidad (heartbeat).
    """

    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    # Nombre temporal CORTO: 12 hex aleatorios bastan para unicidad entre
    # procesos. El sufijo anterior (pid + uuid completo, ~58 caracteres)
    # empujaba rutas profundas por encima de MAX_PATH=260 en Windows y el
    # heartbeat moría con un Errno 2 verificado en el host real.
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex[:12]}.tmp")
    encoded = _encode_json(payload)
    try:
        descriptor = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(encoded)
            stream.flush()
            if durable:
                os.fsync(stream.fileno())
        attempts = max(0, int(replace_retries)) + 1
        for attempt in range(attempts):
            try:
                os.replace(temporary, path)
                break
            except OSError:
                if os.name != "nt" or attempt + 1 >= attempts:
                    raise
                time.sleep(replace_retry_delay_s)
        if durable:
            _fsync_parent(path)
    except OSError as exc:
        with suppress(OSError):
            temporary.unlink(missing_ok=True)
        raise RuntimeContractError("RUNTIME_FILE_WRITE_FAILED", str(exc)) from exc


@dataclass(frozen=True, slots=True)
class RuntimeIdentity:
    engine_version: str
    data_schema_version: str
    capture_session_id: str
    pid: int
    launcher_pid: int | None
    process_start_utc_ns: int
    symbol: str
    markets: tuple[str, ...]
    host: str
    port: int
    project_root: Path
    output_dir: Path
    python_executable: Path
    package_file: Path
    # P1.6: endpoints EFECTIVOS por mercado ((market, ws, rest), ...); quedan
    # registrados en READY/session/RESULT para que un override BINANCE_* del
    # entorno no pueda producir un certificado sin procedencia.
    endpoints: tuple[tuple[str, str, str], ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "capture_session_id",
            validate_capture_session_id(self.capture_session_id),
        )
        symbol = self.symbol.strip().upper()
        if not symbol or not symbol.isalnum():
            raise ValueError("symbol debe ser alfanumérico")
        object.__setattr__(self, "symbol", symbol)
        if self.markets != EXPECTED_MARKETS:
            raise ValueError(f"markets debe ser exactamente {EXPECTED_MARKETS!r}")
        if self.pid <= 0 or (self.launcher_pid is not None and self.launcher_pid <= 0):
            raise ValueError("PID de motor/launcher inválido")
        if self.process_start_utc_ns <= 0:
            raise ValueError("process_start_utc_ns debe ser positivo")
        if self.host != "127.0.0.1":
            raise ValueError("El runtime solo admite 127.0.0.1")
        if not 0 <= self.port <= 65_535:
            raise ValueError("Puerto fuera de rango")
        if not self.engine_version or not self.data_schema_version:
            raise ValueError("Versiones de motor/esquema no pueden estar vacías")
        for name in ("project_root", "output_dir", "python_executable", "package_file"):
            object.__setattr__(self, name, Path(getattr(self, name)).resolve())

    @property
    def url(self) -> str | None:
        if self.port == 0:
            return None
        return f"http://{self.host}:{self.port}"

    def with_bound_port(self, port: int) -> "RuntimeIdentity":
        if not 1 <= port <= 65_535:
            raise ValueError("El servidor no publicó un puerto válido")
        return replace(self, port=port)

    def public_payload(self) -> dict[str, Any]:
        return {
            "protocol_version": READY_PROTOCOL_VERSION,
            "product": PRODUCT_NAME,
            "engine_version": self.engine_version,
            "data_schema_version": self.data_schema_version,
            "capture_session_id": self.capture_session_id,
            "pid": self.pid,
            "launcher_pid": self.launcher_pid,
            "process_start_utc_ns": self.process_start_utc_ns,
            "symbol": self.symbol,
            "markets": list(self.markets),
            "host": self.host,
            "port": self.port,
            "url": self.url,
            "project_root": str(self.project_root),
            "output_dir": str(self.output_dir),
            "python_executable": str(self.python_executable),
            "package_file": str(self.package_file),
            "endpoints": {
                market: {"ws": ws, "rest": rest}
                for market, ws, rest in self.endpoints
            },
        }


class SessionManifest:
    """Atomic state machine shared by one launcher and one engine.

    The launcher creates ``STARTING``.  The engine attaches only when the
    session ID matches, then becomes the sole writer until it exits.
    """

    def __init__(self, path: Path, payload: dict[str, Any]) -> None:
        self.path = path.resolve()
        self.payload = payload

    @property
    def session_id(self) -> str:
        return str(self.payload["capture_session_id"])

    @classmethod
    def create(
        cls,
        path: Path,
        *,
        capture_session_id: str,
        launcher_pid: int,
        project_root: Path,
        output_dir: Path,
    ) -> "SessionManifest":
        path = path.resolve()
        now_utc_ns = time.time_ns()
        payload: dict[str, Any] = {
            "manifest_version": SESSION_MANIFEST_VERSION,
            "capture_session_id": validate_capture_session_id(capture_session_id),
            "state": "STARTING",
            "launcher_pid": launcher_pid,
            "engine_pid": None,
            "created_utc_ns": now_utc_ns,
            "updated_utc_ns": now_utc_ns,
            "update_index": 0,
            "project_root": str(project_root.resolve()),
            "output_dir": str(output_dir.resolve()),
            "identity": None,
            "health": None,
            "result": None,
            "error": None,
        }
        try:
            exclusive_write_json(path, payload)
        except RuntimeContractError as exc:
            if exc.code == "RUNTIME_FILE_EXISTS":
                raise RuntimeContractError(
                    "SESSION_FILE_EXISTS",
                    f"No se reutiliza la sesión existente: {path}",
                ) from exc
            raise
        return cls(path, payload)

    @classmethod
    def attach_or_create(
        cls,
        path: Path,
        *,
        capture_session_id: str,
        launcher_pid: int | None,
        project_root: Path,
        output_dir: Path,
    ) -> "SessionManifest":
        path = path.resolve()
        if not path.exists():
            return cls.create(
                path,
                capture_session_id=capture_session_id,
                launcher_pid=launcher_pid or os.getppid(),
                project_root=project_root,
                output_dir=output_dir,
            )
        payload = read_json_object(path)
        if payload.get("manifest_version") != SESSION_MANIFEST_VERSION:
            raise RuntimeContractError(
                "SESSION_MANIFEST_VERSION_MISMATCH", "Versión de manifest no soportada"
            )
        expected = validate_capture_session_id(capture_session_id)
        if payload.get("capture_session_id") != expected:
            raise RuntimeContractError(
                "SESSION_ID_MISMATCH", "El manifest pertenece a otra sesión"
            )
        if payload.get("state") != "STARTING":
            raise RuntimeContractError(
                "SESSION_STATE_INVALID", "El motor solo se adjunta a STARTING"
            )
        if launcher_pid is not None and payload.get("launcher_pid") != launcher_pid:
            raise RuntimeContractError(
                "LAUNCHER_PID_MISMATCH", "El manifest pertenece a otro launcher"
            )
        if payload.get("project_root") != str(project_root.resolve()):
            raise RuntimeContractError(
                "PROJECT_ROOT_MISMATCH", "El manifest pertenece a otro proyecto"
            )
        if payload.get("output_dir") != str(output_dir.resolve()):
            raise RuntimeContractError(
                "OUTPUT_DIR_MISMATCH", "El manifest pertenece a otra salida"
            )
        return cls(path, payload)

    def transition(
        self,
        state: str,
        *,
        identity: RuntimeIdentity | None = None,
        health: Mapping[str, Any] | None = None,
        result: Mapping[str, Any] | None = None,
        error_code: str | None = None,
        error_message: str | None = None,
    ) -> None:
        normalized = state.strip().upper()
        if normalized not in RUNTIME_STATES:
            raise RuntimeContractError(
                "SESSION_STATE_INVALID", f"Estado no soportado: {normalized}"
            )
        current = str(self.payload.get("state", ""))
        allowed = _STATE_TRANSITIONS.get(current, frozenset())
        if normalized not in allowed:
            raise RuntimeContractError(
                "SESSION_STATE_TRANSITION_INVALID",
                f"Transición de {current!r} a {normalized!r} no permitida",
            )
        candidate = dict(self.payload)
        candidate["state"] = normalized
        candidate["updated_utc_ns"] = time.time_ns()
        candidate["update_index"] = int(candidate.get("update_index", 0)) + 1
        if identity is not None:
            candidate["engine_pid"] = identity.pid
            candidate["identity"] = identity.public_payload()
        if health is not None:
            candidate["health"] = dict(health)
        if result is not None:
            candidate["result"] = dict(result)
        if error_code is not None or error_message is not None:
            candidate["error"] = {
                "code": error_code or "ENGINE_FAILED",
                "message": error_message or "Fallo sin detalle",
            }
        atomic_write_json(self.path, candidate)
        self.payload = candidate


def finite_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def default_runtime_identity(
    *,
    engine_version: str,
    data_schema_version: str,
    capture_session_id: str,
    launcher_pid: int | None,
    process_start_utc_ns: int,
    symbol: str,
    project_root: Path,
    output_dir: Path,
    package_file: Path,
    endpoints: tuple[tuple[str, str, str], ...] = (),
) -> RuntimeIdentity:
    return RuntimeIdentity(
        engine_version=engine_version,
        data_schema_version=data_schema_version,
        capture_session_id=capture_session_id,
        pid=os.getpid(),
        launcher_pid=launcher_pid,
        process_start_utc_ns=process_start_utc_ns,
        symbol=symbol,
        markets=EXPECTED_MARKETS,
        host="127.0.0.1",
        port=0,
        project_root=project_root,
        output_dir=output_dir,
        python_executable=Path(sys.executable),
        package_file=package_file,
        endpoints=endpoints,
    )
