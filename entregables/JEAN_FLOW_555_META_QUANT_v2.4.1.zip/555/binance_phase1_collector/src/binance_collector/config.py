from __future__ import annotations

import os
import urllib.parse
from dataclasses import dataclass, replace
from pathlib import Path


_MARKETS = frozenset({"spot", "usdm_futures"})
# [P5]/R3.3: allowlist de esquema+host. Un BINANCE_WS_BASE_URL=ws://127.0.0.1
# ambiental producía un certificado PASS sobre datos sintéticos sin dejar
# rastro. El override exige la bandera explícita del launcher (que lo registra
# en la evidencia) vía JEAN_FLOW_ALLOW_ENDPOINT_OVERRIDE=1.
_ALLOWED_WS_HOSTS = frozenset({"stream.binance.com", "fstream.binance.com"})
_ALLOWED_REST_HOSTS = frozenset({"api.binance.com", "fapi.binance.com"})
_ENDPOINT_OVERRIDE_FLAG = "JEAN_FLOW_ALLOW_ENDPOINT_OVERRIDE"


def _validate_endpoint(
    url: str,
    *,
    field: str,
    scheme: str,
    allowed_hosts: frozenset[str],
) -> None:
    if os.getenv(_ENDPOINT_OVERRIDE_FLAG) == "1":
        return
    parsed = urllib.parse.urlsplit(url)
    if (
        parsed.scheme != scheme
        or parsed.hostname is None
        or parsed.hostname.lower() not in allowed_hosts
        or parsed.username is not None
        or parsed.password is not None
    ):
        raise ValueError(
            f"{field}={url!r} no está en la allowlist "
            f"({scheme}://{{{', '.join(sorted(allowed_hosts))}}}). "
            f"Para desarrollo exporte {_ENDPOINT_OVERRIDE_FLAG}=1; la captura "
            "quedará marcada como no certificable contra Binance real."
        )
_REQUIRED_SNAPSHOT_LIMITS = {"spot": 5_000, "usdm_futures": 1_000}
_DEFAULT_WS_BASE_URLS = {
    "spot": "wss://stream.binance.com:9443",
    "usdm_futures": "wss://fstream.binance.com",
}
_DEFAULT_REST_BASE_URLS = {
    "spot": "https://api.binance.com",
    "usdm_futures": "https://fapi.binance.com",
}


def _env_int(name: str, default: int) -> int:
    return int(os.getenv(name, str(default)))


def _env_float(name: str, default: float) -> float:
    return float(os.getenv(name, str(default)))


@dataclass(frozen=True, slots=True)
class Settings:
    symbol: str = "TUTUSDT"
    market: str = "spot"
    output_dir: Path = Path("data")
    ws_base_url: str = "wss://stream.binance.com:9443"
    rest_base_url: str = "https://api.binance.com"
    snapshot_limit: int = 5_000
    snapshot_timeout_s: float = 5.0
    snapshot_retries: int = 5
    snapshot_min_interval_s: float = 3.0
    raw_queue_size: int = 8_192
    raw_queue_max_bytes: int = 64 * 1024 * 1024
    route_queue_size: int = 4_096
    writer_queue_size: int = 4_096
    writer_queue_max_rows: int = 250_000
    sync_buffer_size: int = 8_192
    sync_buffer_max_bytes: int = 64 * 1024 * 1024
    max_levels_per_side: int = 200_000
    writer_batch_rows: int = 8_192
    writer_chunk_rows: int = 64
    writer_yield_sleep_s: float = 0.0005
    flush_interval_s: float = 0.25
    fsync_interval_s: float = 5.0
    rotation_bytes: int = 512 * 1024 * 1024
    rotation_seconds: float = 3_600.0
    metrics_interval_s: float = 5.0
    event_loop_probe_interval_s: float = 0.02
    cooperative_yield_budget_ms: float = 1.0
    book_apply_offload_levels: int = 512
    shutdown_timeout_s: float = 15.0
    reconnect_initial_s: float = 0.25
    reconnect_max_s: float = 10.0

    @classmethod
    def from_env(cls) -> "Settings":
        market = os.getenv("BINANCE_MARKET", "spot").strip().lower()
        if market not in _MARKETS:
            raise ValueError(f"BINANCE_MARKET no soportado: {market!r}")
        ws_env = (
            "BINANCE_WS_BASE_URL"
            if market == "spot"
            else "BINANCE_FUTURES_WS_BASE_URL"
        )
        rest_env = (
            "BINANCE_REST_BASE_URL"
            if market == "spot"
            else "BINANCE_FUTURES_REST_BASE_URL"
        )
        settings = cls(
            symbol=os.getenv("BINANCE_SYMBOL", "TUTUSDT"),
            market=market,
            output_dir=Path(os.getenv("OUTPUT_DIR", "data")),
            ws_base_url=os.getenv(ws_env, _DEFAULT_WS_BASE_URLS[market]),
            rest_base_url=os.getenv(rest_env, _DEFAULT_REST_BASE_URLS[market]),
            snapshot_limit=_env_int(
                "SNAPSHOT_LIMIT", _REQUIRED_SNAPSHOT_LIMITS[market]
            ),
            snapshot_timeout_s=_env_float("SNAPSHOT_TIMEOUT_S", 5.0),
            snapshot_retries=_env_int("SNAPSHOT_RETRIES", 5),
            snapshot_min_interval_s=_env_float("SNAPSHOT_MIN_INTERVAL_S", 3.0),
            raw_queue_size=_env_int("RAW_QUEUE_SIZE", 8_192),
            raw_queue_max_bytes=_env_int("RAW_QUEUE_MAX_BYTES", 64 * 1024 * 1024),
            route_queue_size=_env_int("ROUTE_QUEUE_SIZE", 4_096),
            writer_queue_size=_env_int("WRITER_QUEUE_SIZE", 4_096),
            writer_queue_max_rows=_env_int("WRITER_QUEUE_MAX_ROWS", 250_000),
            sync_buffer_size=_env_int("SYNC_BUFFER_SIZE", 8_192),
            sync_buffer_max_bytes=_env_int(
                "SYNC_BUFFER_MAX_BYTES", 64 * 1024 * 1024
            ),
            max_levels_per_side=_env_int("MAX_LEVELS_PER_SIDE", 200_000),
            writer_batch_rows=_env_int("WRITER_BATCH_ROWS", 8_192),
            writer_chunk_rows=_env_int("WRITER_CHUNK_ROWS", 64),
            writer_yield_sleep_s=_env_float("WRITER_YIELD_SLEEP_S", 0.0005),
            flush_interval_s=_env_float("FLUSH_INTERVAL_S", 0.25),
            fsync_interval_s=_env_float("FSYNC_INTERVAL_S", 5.0),
            rotation_bytes=_env_int("ROTATION_BYTES", 512 * 1024 * 1024),
            rotation_seconds=_env_float("ROTATION_SECONDS", 3_600.0),
            metrics_interval_s=_env_float("METRICS_INTERVAL_S", 5.0),
            event_loop_probe_interval_s=_env_float(
                "EVENT_LOOP_PROBE_INTERVAL_S", 0.02
            ),
            cooperative_yield_budget_ms=_env_float(
                "COOPERATIVE_YIELD_BUDGET_MS", 1.0
            ),
            book_apply_offload_levels=_env_int("BOOK_APPLY_OFFLOAD_LEVELS", 512),
            shutdown_timeout_s=_env_float("SHUTDOWN_TIMEOUT_S", 15.0),
            reconnect_initial_s=_env_float("RECONNECT_INITIAL_S", 0.25),
            reconnect_max_s=_env_float("RECONNECT_MAX_S", 10.0),
        )
        return settings.validated()

    @classmethod
    def for_market(
        cls,
        market: str,
        *,
        symbol: str = "TUTUSDT",
        output_dir: Path = Path("data"),
    ) -> "Settings":
        """Build isolated Spot or USDⓈ-M settings for the dual collector.

        Generic queue/timing environment variables still apply to both. Endpoint
        overrides are market-specific so a Spot override can never redirect the
        Futures feed by accident.
        """

        normalized = market.strip().lower()
        if normalized not in _MARKETS:
            raise ValueError(f"Mercado no soportado: {market!r}")
        settings = cls.from_env()
        ws_env = (
            "BINANCE_WS_BASE_URL"
            if normalized == "spot"
            else "BINANCE_FUTURES_WS_BASE_URL"
        )
        rest_env = (
            "BINANCE_REST_BASE_URL"
            if normalized == "spot"
            else "BINANCE_FUTURES_REST_BASE_URL"
        )
        return replace(
            settings,
            market=normalized,
            symbol=symbol,
            output_dir=output_dir,
            ws_base_url=os.getenv(ws_env, _DEFAULT_WS_BASE_URLS[normalized]),
            rest_base_url=os.getenv(rest_env, _DEFAULT_REST_BASE_URLS[normalized]),
            snapshot_limit=_REQUIRED_SNAPSHOT_LIMITS[normalized],
        ).validated()

    def with_overrides(
        self,
        *,
        symbol: str | None = None,
        output_dir: Path | None = None,
    ) -> "Settings":
        return replace(
            self,
            symbol=symbol or self.symbol,
            output_dir=output_dir or self.output_dir,
        ).validated()

    def validated(self) -> "Settings":
        symbol = self.symbol.strip().upper()
        market = self.market.strip().lower()
        # `str.isalnum()` acepta dígitos y letras Unicode ('ＴＵＴＵＳＤＴ',
        # 'TUT٢', 'ⅣUSDT'). Los símbolos de Binance son ASCII A-Z/0-9.
        if not symbol or not all("A" <= ch <= "Z" or "0" <= ch <= "9" for ch in symbol):
            raise ValueError("BINANCE_SYMBOL debe ser ASCII alfanumérico (A-Z, 0-9)")
        if market not in _MARKETS:
            raise ValueError(f"Mercado no soportado: {market!r}")
        required_snapshot_limit = _REQUIRED_SNAPSHOT_LIMITS[market]
        if self.snapshot_limit != required_snapshot_limit:
            raise ValueError(
                "SNAPSHOT_LIMIT debe ser "
                f"{required_snapshot_limit} para la garantía de libro {market}"
            )
        positive_ints = {
            "raw_queue_size": self.raw_queue_size,
            "raw_queue_max_bytes": self.raw_queue_max_bytes,
            "route_queue_size": self.route_queue_size,
            "writer_queue_size": self.writer_queue_size,
            "writer_queue_max_rows": self.writer_queue_max_rows,
            "sync_buffer_size": self.sync_buffer_size,
            "sync_buffer_max_bytes": self.sync_buffer_max_bytes,
            "max_levels_per_side": self.max_levels_per_side,
            "writer_batch_rows": self.writer_batch_rows,
            "writer_chunk_rows": self.writer_chunk_rows,
            "book_apply_offload_levels": self.book_apply_offload_levels,
            "rotation_bytes": self.rotation_bytes,
        }
        if any(value <= 0 for value in positive_ints.values()):
            raise ValueError(f"Los tamaños deben ser positivos: {positive_ints}")
        positive_scalars = {
            "snapshot_timeout_s": self.snapshot_timeout_s,
            "snapshot_retries": self.snapshot_retries,
            "snapshot_min_interval_s": self.snapshot_min_interval_s,
            "flush_interval_s": self.flush_interval_s,
            "fsync_interval_s": self.fsync_interval_s,
            "rotation_seconds": self.rotation_seconds,
            "metrics_interval_s": self.metrics_interval_s,
            "event_loop_probe_interval_s": self.event_loop_probe_interval_s,
            "cooperative_yield_budget_ms": self.cooperative_yield_budget_ms,
            "writer_yield_sleep_s": self.writer_yield_sleep_s,
            "shutdown_timeout_s": self.shutdown_timeout_s,
            "reconnect_initial_s": self.reconnect_initial_s,
            "reconnect_max_s": self.reconnect_max_s,
        }
        if any(value <= 0 for value in positive_scalars.values()):
            raise ValueError(f"Timeouts/reintentos deben ser positivos: {positive_scalars}")
        _validate_endpoint(
            self.ws_base_url,
            field="ws_base_url",
            scheme="wss",
            allowed_hosts=_ALLOWED_WS_HOSTS,
        )
        _validate_endpoint(
            self.rest_base_url,
            field="rest_base_url",
            scheme="https",
            allowed_hosts=_ALLOWED_REST_HOSTS,
        )
        if self.reconnect_initial_s > self.reconnect_max_s:
            raise ValueError("RECONNECT_INITIAL_S no puede superar RECONNECT_MAX_S")
        if self.event_loop_probe_interval_s > 1.0:
            raise ValueError("EVENT_LOOP_PROBE_INTERVAL_S no puede superar 1 segundo")
        if self.cooperative_yield_budget_ms > 20.0:
            raise ValueError("COOPERATIVE_YIELD_BUDGET_MS no puede superar 20 ms")
        if self.writer_chunk_rows > 1_024:
            raise ValueError(
                "WRITER_CHUNK_ROWS no puede superar 1024 en modo baja latencia"
            )
        if not 0.0001 <= self.writer_yield_sleep_s <= 0.01:
            raise ValueError(
                "WRITER_YIELD_SLEEP_S debe estar entre 0.0001 y 0.01"
            )
        return replace(
            self,
            symbol=symbol,
            market=market,
            output_dir=self.output_dir.expanduser(),
        )

    @property
    def stream_symbol(self) -> str:
        return self.symbol.lower()

    @property
    def stream_names(self) -> tuple[str, str, str]:
        symbol = self.stream_symbol
        return (
            f"{symbol}@aggTrade",
            f"{symbol}@depth20@100ms",
            f"{symbol}@depth@100ms",
        )

    @property
    def websocket_url(self) -> str:
        if self.market != "spot":
            raise ValueError(
                "USDⓈ-M usa dos endpoints separados; consulte websocket_urls"
            )
        streams = "/".join(self.stream_names)
        return f"{self.ws_base_url.rstrip('/')}/stream?streams={streams}"

    @property
    def websocket_sources(self) -> tuple[tuple[str, str], ...]:
        if self.market == "spot":
            return (("spot_combined", self.websocket_url),)
        # [2.3.3] USDⓈ-M segmenta el tráfico por niveles desde 2026-04-23
        # ("Important WebSocket Change Notice", developers.binance.com →
        # derivatives → usds-margined-futures → websocket-market-streams):
        # profundidad (@depth@100ms / @depth20@100ms, alta frecuencia) va en
        # wss://fstream.binance.com/public y aggTrade va en /market; el
        # legado sin ruta (/stream) quedó retirado y desde entonces solo
        # entrega el nivel Public. Evidencia de campo (2026-08-14, host
        # objetivo): con el endpoint legado btcusdt@depth* fluía (100
        # mensajes en 13.5 s) y btcusdt@aggTrade quedó en silencio absoluto
        # (0/100 en 4 intentos), igual que agg_trade_messages=0 en la sesión
        # del motor. NOTA HISTÓRICA: el hallazgo P0.1a de la auditoría
        # ("/public/stream y /market/stream no existen") estaba
        # desactualizado; 2.2.2 ya usaba los niveles correctos y la
        # remediación 2.3.0 regresionó al legado siguiendo la auditoría.
        # Se conservan DOS sockets para mantener la separación causal
        # depth/trades, cada uno en su nivel documentado.
        symbol = self.stream_symbol
        public_streams = "/".join(
            (f"{symbol}@depth20@100ms", f"{symbol}@depth@100ms")
        )
        base = self.ws_base_url.rstrip("/")
        return (
            (
                "usdm_public_depth",
                f"{base}/public/stream?streams={public_streams}",
            ),
            (
                "usdm_market_trades",
                f"{base}/market/stream?streams={symbol}@aggTrade",
            ),
        )

    @property
    def websocket_urls(self) -> tuple[str, ...]:
        return tuple(url for _role, url in self.websocket_sources)

    @property
    def rest_depth_path(self) -> str:
        return "/api/v3/depth" if self.market == "spot" else "/fapi/v1/depth"

    @property
    def rest_exchange_info_path(self) -> str:
        return (
            "/api/v3/exchangeInfo"
            if self.market == "spot"
            else "/fapi/v1/exchangeInfo"
        )

    @property
    def rest_server_time_path(self) -> str:
        return "/api/v3/time" if self.market == "spot" else "/fapi/v1/time"
