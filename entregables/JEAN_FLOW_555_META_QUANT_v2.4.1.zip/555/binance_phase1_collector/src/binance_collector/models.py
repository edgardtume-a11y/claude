from __future__ import annotations

from dataclasses import dataclass
from collections.abc import Iterator
from typing import Any, TypeAlias


SCHEMA_VERSION = "2.0.0"
CAUSAL_IDENTITY_SCHEMA_VERSION = SCHEMA_VERSION
# R4.3/[P15]: 1.0.0/1.1.0 permitían a un CSV legado esquivar TODA la
# validación causal en el camino de certificación. El colector nunca produjo
# esos esquemas en esta rama; el replay solo acepta el esquema causal actual.
SUPPORTED_SCHEMA_VERSIONS = frozenset({SCHEMA_VERSION})
CSV_FIELDS = (
    "schema_version",
    "capture_session_id",
    "ingest_seq",
    "source_socket_id",
    "local_event_id",
    "row_index",
    "record_type",
    "exchange",
    "market",
    "symbol",
    "channel",
    "connection_id",
    "book_generation",
    "exchange_event_time_ms",
    "exchange_trade_time_ms",
    "exchange_transaction_time_ms",
    "receive_time_utc_ns",
    "receive_time_monotonic_ns",
    "writer_start_time_utc_ns",
    "writer_start_time_monotonic_ns",
    "exchange_to_receive_ns",
    "receive_to_writer_start_ns",
    "sequence_first",
    "sequence_last",
    "sequence_previous",
    "level_count",
    "side",
    "price",
    "quantity",
    "aggregate_trade_id",
    "first_trade_id",
    "last_trade_id",
    "buyer_is_maker",
    "payload_bytes",
    "raw_queue_size",
    "note",
)

CsvValue: TypeAlias = str | int | bool | None
CsvRow: TypeAlias = dict[str, CsvValue]
PriceLevel: TypeAlias = tuple[str, str]


@dataclass(frozen=True, slots=True)
class RawEnvelope:
    connection_id: str
    payload: str | bytes
    receive_utc_ns: int
    receive_monotonic_ns: int
    payload_bytes: int
    raw_queue_size: int
    capture_session_id: str
    ingest_seq: int
    source_socket_id: str


@dataclass(frozen=True, slots=True)
class DiffDepthEvent:
    connection_id: str
    event_time_ms: int
    symbol: str
    first_update_id: int
    final_update_id: int
    bids: tuple[PriceLevel, ...]
    asks: tuple[PriceLevel, ...]
    receive_utc_ns: int
    receive_monotonic_ns: int
    payload_bytes: int
    raw_queue_size: int
    capture_session_id: str
    ingest_seq: int
    source_socket_id: str
    previous_final_update_id: int | None = None
    transaction_time_ms: int | None = None


@dataclass(frozen=True, slots=True)
class PartialDepthEvent:
    connection_id: str
    last_update_id: int
    bids: tuple[PriceLevel, ...]
    asks: tuple[PriceLevel, ...]
    receive_utc_ns: int
    receive_monotonic_ns: int
    payload_bytes: int
    raw_queue_size: int
    capture_session_id: str
    ingest_seq: int
    source_socket_id: str
    event_time_ms: int | None = None
    first_update_id: int | None = None
    previous_final_update_id: int | None = None
    transaction_time_ms: int | None = None


@dataclass(frozen=True, slots=True)
class AggTradeEvent:
    connection_id: str
    event_time_ms: int
    trade_time_ms: int
    symbol: str
    aggregate_trade_id: int
    first_trade_id: int
    last_trade_id: int
    price: str
    quantity: str
    buyer_is_maker: bool
    receive_utc_ns: int
    receive_monotonic_ns: int
    payload_bytes: int
    raw_queue_size: int
    capture_session_id: str
    ingest_seq: int
    source_socket_id: str


@dataclass(frozen=True, slots=True)
class DepthSnapshot:
    last_update_id: int
    bids: tuple[PriceLevel, ...]
    asks: tuple[PriceLevel, ...]
    receive_utc_ns: int
    receive_monotonic_ns: int
    payload_bytes: int


MarketEvent: TypeAlias = DiffDepthEvent | PartialDepthEvent | AggTradeEvent


class CsvBatch:
    """Lote persistible con expansion de niveles diferida al writer.

    La ruta caliente conserva solo el header y las tuplas compactas que ya
    pertenecen al evento.  ``rows`` sigue disponible por compatibilidad y
    materializa/cacha la representacion completa solo cuando un consumidor la
    solicita (por ejemplo, una prueba).  El writer usa ``iter_rows`` y evita
    crear miles de diccionarios dentro del event loop.
    """

    __slots__ = (
        "_asks",
        "_bids",
        "_header",
        "_level_record_type",
        "_rows",
        "critical",
        "receive_monotonic_ns",
    )

    def __init__(
        self,
        rows: tuple[CsvRow, ...],
        receive_monotonic_ns: int,
        critical: bool = True,
    ) -> None:
        self._rows: tuple[CsvRow, ...] | None = rows
        self._header: CsvRow | None = None
        self._bids: tuple[PriceLevel, ...] = ()
        self._asks: tuple[PriceLevel, ...] = ()
        self._level_record_type: str | None = None
        self.receive_monotonic_ns = receive_monotonic_ns
        self.critical = critical

    @classmethod
    def with_levels(
        cls,
        header: CsvRow,
        bids: tuple[PriceLevel, ...],
        asks: tuple[PriceLevel, ...],
        level_record_type: str,
        receive_monotonic_ns: int,
        *,
        critical: bool = True,
    ) -> "CsvBatch":
        batch = cls.__new__(cls)
        batch._rows = None
        batch._header = header
        batch._bids = bids
        batch._asks = asks
        batch._level_record_type = level_record_type
        batch.receive_monotonic_ns = receive_monotonic_ns
        batch.critical = critical
        return batch

    @property
    def row_count(self) -> int:
        if self._rows is not None:
            return len(self._rows)
        return 1 + len(self._bids) + len(self._asks)

    @property
    def rows(self) -> tuple[CsvRow, ...]:
        if self._rows is None:
            self._rows = tuple(self.iter_rows())
        return self._rows

    def iter_rows(self) -> Iterator[CsvRow]:
        """Itera filas; expande niveles de uno en uno fuera del event loop."""

        if self._rows is not None:
            yield from self._rows
            return
        header = self._header
        record_type = self._level_record_type
        assert header is not None and record_type is not None
        yield header
        row_index = 1
        for side, levels in (("bid", self._bids), ("ask", self._asks)):
            for price, quantity in levels:
                row = dict(header)
                row["row_index"] = row_index
                row["record_type"] = record_type
                row["side"] = side
                row["price"] = price
                row["quantity"] = quantity
                yield row
                row_index += 1


def require_dict(value: Any, context: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{context} debe ser un objeto JSON")
    return value


def parse_levels(value: Any, context: str) -> tuple[PriceLevel, ...]:
    if not isinstance(value, list):
        raise ValueError(f"{context} debe ser una lista")
    levels: list[PriceLevel] = []
    for index, level in enumerate(value):
        if not isinstance(level, list) or len(level) != 2:
            raise ValueError(f"{context}[{index}] debe ser [precio, cantidad]")
        price, quantity = level
        if not isinstance(price, str) or not isinstance(quantity, str):
            raise ValueError(f"{context}[{index}] debe contener strings")
        levels.append((price, quantity))
    return tuple(levels)
