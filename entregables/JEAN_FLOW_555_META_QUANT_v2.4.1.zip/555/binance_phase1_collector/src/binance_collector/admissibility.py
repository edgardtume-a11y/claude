"""Admisibilidad del símbolo contra /exchangeInfo antes de abrir un socket.

Modelo formal (auditoría v2.2.2, X2/X3):

    S = 10^8;  D = [0, 2^63 - 1]
    ADMISIBLE(s) ⟺ P_max·S ≤ 2^63−1 ∧ Q_max·S ≤ 2^63−1 ∧ t·S ∈ ℤ ∧ q·S ∈ ℤ
    m(s) = X_max / max(P_max, Q_max)   con exigencia m(s) ≥ 10 (aviso si no)

Decisión X4 (documentada aquí, no solo en el changelog): se MANTIENE el
dominio de 64 bits. Es una garantía de portabilidad a un backend nativo
(C/numpy/Rust) y una cota explícita de memoria. El coste (símbolos con
maxPrice/maxQty ≥ 9,22·10^10 no son capturables) queda pagado con este gate:
el rechazo ocurre en el ARRANQUE, con un mensaje que nombra símbolo, valor y
límite, y con CERO peticiones REST posteriores — nunca más el bucle de
reconexión que baneaba la IP en 72 s ([N1]/F2).
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any

from .fixed_point import FIXED_SCALE, MAX_FIXED_VALUE

_MIN_MARGIN = Decimal(10)
_MAX_FIXED_DECIMAL = Decimal(MAX_FIXED_VALUE) / Decimal(FIXED_SCALE)


class SymbolNotAdmissible(RuntimeError):
    """REFUSE de arranque: el símbolo no cabe en el dominio fijo 1e8/2^63."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


@dataclass(frozen=True, slots=True)
class AdmissibilityReport:
    symbol: str
    market: str
    max_price: str
    max_qty: str
    tick_size: str
    step_size: str
    margin: float
    margin_warning: bool

    def as_payload(self) -> dict[str, Any]:
        return {
            "symbol": self.symbol,
            "market": self.market,
            "max_price": self.max_price,
            "max_qty": self.max_qty,
            "tick_size": self.tick_size,
            "step_size": self.step_size,
            "domain_max": str(_MAX_FIXED_DECIMAL),
            "margin": self.margin,
            "margin_warning": self.margin_warning,
            "min_margin_required": float(_MIN_MARGIN),
        }


def _decimal(value: Any, field: str, symbol: str) -> Decimal:
    if not isinstance(value, str) or not value:
        raise SymbolNotAdmissible(
            "SYMBOL_FILTERS_INVALID",
            f"{symbol}: filtro {field} ausente o no textual en exchangeInfo",
        )
    try:
        parsed = Decimal(value)
    except InvalidOperation as exc:
        raise SymbolNotAdmissible(
            "SYMBOL_FILTERS_INVALID",
            f"{symbol}: filtro {field}={value!r} no es decimal",
        ) from exc
    if not parsed.is_finite() or parsed < 0:
        raise SymbolNotAdmissible(
            "SYMBOL_FILTERS_INVALID",
            f"{symbol}: filtro {field}={value!r} fuera de rango",
        )
    return parsed


def _scaled_is_integral(value: Decimal) -> bool:
    scaled = value * FIXED_SCALE
    return scaled == scaled.to_integral_value()


def _symbol_entry(payload: dict[str, Any], symbol: str, market: str) -> dict[str, Any]:
    symbols = payload.get("symbols")
    if not isinstance(symbols, list):
        raise SymbolNotAdmissible(
            "EXCHANGE_INFO_INVALID",
            f"{symbol}: exchangeInfo sin lista de símbolos",
        )
    for entry in symbols:
        if isinstance(entry, dict) and entry.get("symbol") == symbol:
            return entry
    raise SymbolNotAdmissible(
        "SYMBOL_UNKNOWN",
        f"{symbol}: no existe en exchangeInfo de {market}; "
        "verifique el símbolo y el mercado",
    )


def evaluate_symbol_admissibility(
    payload: dict[str, Any],
    *,
    symbol: str,
    market: str,
) -> AdmissibilityReport:
    """Evalúa X2/X3 sobre un payload de /exchangeInfo. REFUSE si no cabe."""

    entry = _symbol_entry(payload, symbol, market)
    status = entry.get("status")
    if status not in {"TRADING", None}:
        raise SymbolNotAdmissible(
            "SYMBOL_NOT_TRADING",
            f"{symbol}: estado {status!r} en {market}; no está en TRADING",
        )
    filters = entry.get("filters")
    if not isinstance(filters, list):
        raise SymbolNotAdmissible(
            "SYMBOL_FILTERS_INVALID", f"{symbol}: exchangeInfo sin filtros"
        )
    by_type: dict[str, dict[str, Any]] = {}
    for item in filters:
        if isinstance(item, dict) and isinstance(item.get("filterType"), str):
            by_type[item["filterType"]] = item
    price_filter = by_type.get("PRICE_FILTER")
    lot_filter = by_type.get("LOT_SIZE")
    if price_filter is None or lot_filter is None:
        raise SymbolNotAdmissible(
            "SYMBOL_FILTERS_INVALID",
            f"{symbol}: faltan PRICE_FILTER o LOT_SIZE en exchangeInfo",
        )
    max_price = _decimal(price_filter.get("maxPrice"), "PRICE_FILTER.maxPrice", symbol)
    tick_size = _decimal(price_filter.get("tickSize"), "PRICE_FILTER.tickSize", symbol)
    max_qty = _decimal(lot_filter.get("maxQty"), "LOT_SIZE.maxQty", symbol)
    step_size = _decimal(lot_filter.get("stepSize"), "LOT_SIZE.stepSize", symbol)
    market_lot = by_type.get("MARKET_LOT_SIZE")
    if market_lot is not None and isinstance(market_lot.get("maxQty"), str):
        market_max_qty = _decimal(
            market_lot.get("maxQty"), "MARKET_LOT_SIZE.maxQty", symbol
        )
        max_qty = max(max_qty, market_max_qty)

    for name, value in (("maxPrice", max_price), ("maxQty", max_qty)):
        if value > _MAX_FIXED_DECIMAL:
            raise SymbolNotAdmissible(
                "SYMBOL_OUT_OF_DOMAIN",
                f"{symbol} ({market}): {name}={value} excede el máximo "
                f"representable {_MAX_FIXED_DECIMAL} del dominio fijo "
                "10^8/2^63. El símbolo no es capturable con esta build; "
                "no se abrirá ningún socket ni se consumirá peso REST.",
            )
    for name, value in (("tickSize", tick_size), ("stepSize", step_size)):
        if value > 0 and not _scaled_is_integral(value):
            raise SymbolNotAdmissible(
                "SYMBOL_OUT_OF_DOMAIN",
                f"{symbol} ({market}): {name}={value} requiere más de 8 "
                "decimales; la escala fija 10^8 no puede representarlo "
                "de forma exacta. El símbolo no es capturable con esta build.",
            )
    reference = max(max_price, max_qty)
    margin = (
        float(_MAX_FIXED_DECIMAL / reference) if reference > 0 else float("inf")
    )
    margin_warning = reference > 0 and (_MAX_FIXED_DECIMAL / reference) < _MIN_MARGIN
    return AdmissibilityReport(
        symbol=symbol,
        market=market,
        max_price=str(max_price),
        max_qty=str(max_qty),
        tick_size=str(tick_size),
        step_size=str(step_size),
        margin=margin,
        margin_warning=margin_warning,
    )
