from __future__ import annotations

import asyncio
import ipaddress
import math
import threading
import time
from collections import deque
from dataclasses import dataclass
from importlib import resources
from typing import TYPE_CHECKING, Any, Iterable, Literal, TypeAlias

import orjson
from aiohttp import WSCloseCode, WSMsgType, web

from .fixed_point import (
    FIXED_SCALE,
    MAX_FIXED_VALUE,
    FixedPointError,
    format_fixed,
    parse_fixed,
)

if TYPE_CHECKING:
    from .runtime import RuntimeIdentity


MarketName: TypeAlias = Literal["spot", "usdm_futures"]
WireLevel: TypeAlias = tuple[str, str]
FixedLevel: TypeAlias = tuple[int, int]

_MARKETS: tuple[MarketName, MarketName] = ("spot", "usdm_futures")
_VALID_BOOK_STATUSES = frozenset(
    {"UNKNOWN", "CONNECTING", "SYNCING", "SYNCED", "STALE", "DISCONNECTED"}
)


class DashboardDataError(ValueError):
    """Raised when an invalid state would be exposed to the local dashboard."""


@dataclass(frozen=True, slots=True)
class BookView:
    symbol: str
    generation: int
    sequence: int
    bids: tuple[FixedLevel, ...]
    asks: tuple[FixedLevel, ...]
    receive_utc_ns: int
    receive_monotonic_ns: int
    exchange_event_time_ms: int | None


@dataclass(frozen=True, slots=True)
class TradeView:
    symbol: str
    aggregate_trade_id: int
    price: str
    quantity: str
    aggressor: Literal["BUY", "SELL"]
    exchange_trade_time_ms: int
    receive_utc_ns: int


@dataclass(slots=True)
class _MarketState:
    status: str = "UNKNOWN"
    status_reason: str | None = None
    symbol: str | None = None
    book: BookView | None = None
    trades: deque[TradeView] | None = None
    last_generation: int | None = None
    last_sequence: int | None = None


def _market(value: str) -> MarketName:
    if value not in _MARKETS:
        raise DashboardDataError(f"Mercado no soportado para dashboard: {value!r}")
    return value  # type: ignore[return-value]


def _symbol(value: str) -> str:
    normalized = value.strip().upper()
    # [P14]: isalnum() aceptaba dígitos/letras Unicode; ASCII estricto.
    if not normalized or not all(
        "A" <= ch <= "Z" or "0" <= ch <= "9" for ch in normalized
    ):
        raise DashboardDataError("El símbolo debe ser ASCII alfanumérico")
    return normalized


def _positive_fixed(value: str, field: str, *, allow_zero: bool = False) -> int:
    try:
        parsed = parse_fixed(value)
    except (FixedPointError, TypeError) as exc:
        raise DashboardDataError(f"{field} fuera de dominio: {value!r}") from exc
    if not allow_zero and parsed == 0:
        raise DashboardDataError(f"{field} fuera de dominio: {value!r}")
    return parsed


def _format_half_fixed(total_scaled: int) -> str:
    """Format ``total_scaled / (2 * 1e8)`` without binary-float rounding."""

    scale_9 = FIXED_SCALE * 10
    scaled_9 = total_scaled * 5
    whole, fraction = divmod(scaled_9, scale_9)
    if fraction == 0:
        return str(whole)
    return f"{whole}.{fraction:09d}".rstrip("0")


def _copy_levels(
    levels: Iterable[tuple[str, str]],
    *,
    side: Literal["bid", "ask"],
    limit: int,
) -> tuple[FixedLevel, ...]:
    copied: list[FixedLevel] = []
    previous_price: int | None = None
    for index, raw in enumerate(levels):
        if index >= limit:
            break
        if not isinstance(raw, (tuple, list)) or len(raw) != 2:
            raise DashboardDataError(f"Nivel {side} inválido en posición {index}")
        price_text, quantity_text = raw
        if not isinstance(price_text, str) or not isinstance(quantity_text, str):
            raise DashboardDataError("Precio y cantidad deben llegar como strings")
        price = _positive_fixed(price_text, f"{side}.price")
        quantity = _positive_fixed(quantity_text, f"{side}.quantity")
        if previous_price is not None and (
            (side == "bid" and price >= previous_price)
            or (side == "ask" and price <= previous_price)
        ):
            raise DashboardDataError(f"Niveles {side} desordenados o duplicados")
        copied.append((price, quantity))
        previous_price = price
    return tuple(copied)


def _copy_fixed_levels(
    levels: Iterable[tuple[int, int]],
    *,
    side: Literal["bid", "ask"],
    limit: int,
) -> tuple[FixedLevel, ...]:
    copied: list[FixedLevel] = []
    previous_price: int | None = None
    for index, raw in enumerate(levels):
        if index >= limit:
            break
        if not isinstance(raw, (tuple, list)) or len(raw) != 2:
            raise DashboardDataError(f"Nivel fijo {side} inválido en posición {index}")
        price, quantity = raw
        if (
            isinstance(price, bool)
            or not isinstance(price, int)
            or isinstance(quantity, bool)
            or not isinstance(quantity, int)
            or not 0 < price <= MAX_FIXED_VALUE
            or not 0 < quantity <= MAX_FIXED_VALUE
        ):
            raise DashboardDataError(f"Nivel fijo {side} fuera de dominio")
        if previous_price is not None and (
            (side == "bid" and price >= previous_price)
            or (side == "ask" and price <= previous_price)
        ):
            raise DashboardDataError(f"Niveles fijos {side} desordenados o duplicados")
        copied.append((price, quantity))
        previous_price = price
    return tuple(copied)


class MarketStateHub:
    """Read-only, bounded projection of validated books for UI consumers.

    ``publish_book`` copies only the configured top-N levels and swaps one frozen
    ``BookView`` atomically.  The UI therefore never receives a reference to the
    mutable ``LocalOrderBook`` owned by a collector worker.
    """

    def __init__(
        self,
        *,
        top_levels: int = 100,
        trade_history: int = 512,
        trade_frame_limit: int = 256,
        stale_after_s: float = 3.0,
    ) -> None:
        if not 1 <= top_levels <= 500:
            raise ValueError("top_levels debe estar entre 1 y 500")
        if trade_history <= 0 or trade_frame_limit <= 0:
            raise ValueError("Los límites de trades deben ser positivos")
        if trade_frame_limit > trade_history:
            raise ValueError("trade_frame_limit no puede superar trade_history")
        if stale_after_s <= 0:
            raise ValueError("stale_after_s debe ser positivo")
        self.top_levels = top_levels
        self.trade_frame_limit = trade_frame_limit
        self.stale_after_ns = int(stale_after_s * 1_000_000_000)
        self._lock = threading.RLock()
        self._states = {
            market: _MarketState(trades=deque(maxlen=trade_history))
            for market in _MARKETS
        }
        self._frame_sequence = 0
        self._client_frame_drops = 0

    @property
    def frame_sequence(self) -> int:
        with self._lock:
            return self._frame_sequence

    def publish_status(
        self,
        *,
        market: str,
        status: str,
        reason: str | None = None,
        clear_book: bool | None = None,
    ) -> None:
        market_name = _market(market)
        normalized = status.strip().upper()
        if normalized.startswith("INVALIDATED"):
            wire_status = "SYNCING"
            reason = reason or normalized
        elif normalized in _VALID_BOOK_STATUSES:
            wire_status = normalized
        else:
            raise DashboardDataError(f"Estado de libro no soportado: {status!r}")
        should_clear = wire_status != "SYNCED" if clear_book is None else clear_book
        with self._lock:
            state = self._states[market_name]
            state.status = wire_status
            state.status_reason = reason
            if should_clear:
                state.book = None
            self._frame_sequence += 1

    def publish_book(
        self,
        *,
        market: str,
        symbol: str,
        generation: int,
        sequence: int,
        bids: Iterable[tuple[str, str]],
        asks: Iterable[tuple[str, str]],
        receive_utc_ns: int,
        receive_monotonic_ns: int,
        exchange_event_time_ms: int | None = None,
    ) -> None:
        market_name = _market(market)
        normalized_symbol = _symbol(symbol)
        if generation <= 0 or sequence < 0:
            raise DashboardDataError("Generación/secuencia de libro inválida")
        if receive_utc_ns <= 0 or receive_monotonic_ns <= 0:
            raise DashboardDataError("Timestamps de recepción inválidos")
        copied_bids = _copy_levels(bids, side="bid", limit=self.top_levels)
        copied_asks = _copy_levels(asks, side="ask", limit=self.top_levels)
        if not copied_bids or not copied_asks:
            raise DashboardDataError("El DOM requiere al menos un bid y un ask")
        if copied_bids[0][0] >= copied_asks[0][0]:
            raise DashboardDataError("No se publica un libro cruzado en el dashboard")
        view = BookView(
            symbol=normalized_symbol,
            generation=generation,
            sequence=sequence,
            bids=copied_bids,
            asks=copied_asks,
            receive_utc_ns=receive_utc_ns,
            receive_monotonic_ns=receive_monotonic_ns,
            exchange_event_time_ms=exchange_event_time_ms,
        )
        self._commit_book_view(market_name, normalized_symbol, view)

    def publish_trusted_book(
        self,
        *,
        market: str,
        symbol: str,
        generation: int,
        sequence: int,
        bids: Iterable[tuple[str, str]],
        asks: Iterable[tuple[str, str]],
        receive_utc_ns: int,
        receive_monotonic_ns: int,
        exchange_event_time_ms: int | None = None,
    ) -> None:
        """Bounded fast path for a book that was already validated by the engine.

        The engine owns full-depth invariants.  This boundary still validates the
        displayed top-N levels before it is allowed to set the public state to
        ``SYNCED``; a malformed extension can therefore never manufacture READY.
        """

        market_name = _market(market)
        normalized_symbol = _symbol(symbol)
        if generation <= 0 or sequence < 0:
            raise DashboardDataError("Generación/secuencia de libro inválida")
        if receive_utc_ns <= 0 or receive_monotonic_ns <= 0:
            raise DashboardDataError("Timestamps de recepción inválidos")
        copied_bids = _copy_levels(bids, side="bid", limit=self.top_levels)
        copied_asks = _copy_levels(asks, side="ask", limit=self.top_levels)
        if not copied_bids or not copied_asks:
            raise DashboardDataError("El DOM requiere al menos un bid y un ask")
        if copied_bids[0][0] >= copied_asks[0][0]:
            raise DashboardDataError("No se publica un libro cruzado en el dashboard")
        view = BookView(
            symbol=normalized_symbol,
            generation=generation,
            sequence=sequence,
            bids=copied_bids,
            asks=copied_asks,
            receive_utc_ns=receive_utc_ns,
            receive_monotonic_ns=receive_monotonic_ns,
            exchange_event_time_ms=exchange_event_time_ms,
        )
        self._commit_book_view(market_name, normalized_symbol, view)

    def publish_trusted_fixed_book(
        self,
        *,
        market: str,
        symbol: str,
        generation: int,
        sequence: int,
        bids: Iterable[tuple[int, int]],
        asks: Iterable[tuple[int, int]],
        receive_utc_ns: int,
        receive_monotonic_ns: int,
        exchange_event_time_ms: int | None = None,
    ) -> None:
        """O(N) boundary for the engine's already validated fixed-point top-N."""

        market_name = _market(market)
        normalized_symbol = _symbol(symbol)
        if generation <= 0 or sequence < 0:
            raise DashboardDataError("Generación/secuencia de libro inválida")
        if receive_utc_ns <= 0 or receive_monotonic_ns <= 0:
            raise DashboardDataError("Timestamps de recepción inválidos")
        copied_bids = _copy_fixed_levels(bids, side="bid", limit=self.top_levels)
        copied_asks = _copy_fixed_levels(asks, side="ask", limit=self.top_levels)
        if not copied_bids or not copied_asks:
            raise DashboardDataError("El DOM requiere al menos un bid y un ask")
        if copied_bids[0][0] >= copied_asks[0][0]:
            raise DashboardDataError("No se publica un libro cruzado en el dashboard")
        self._commit_book_view(
            market_name,
            normalized_symbol,
            BookView(
                symbol=normalized_symbol,
                generation=generation,
                sequence=sequence,
                bids=copied_bids,
                asks=copied_asks,
                receive_utc_ns=receive_utc_ns,
                receive_monotonic_ns=receive_monotonic_ns,
                exchange_event_time_ms=exchange_event_time_ms,
            ),
        )

    def _commit_book_view(
        self,
        market_name: MarketName,
        normalized_symbol: str,
        view: BookView,
    ) -> None:
        with self._lock:
            state = self._states[market_name]
            if state.symbol is not None and state.symbol != normalized_symbol:
                raise DashboardDataError(
                    f"Símbolo {normalized_symbol} no coincide con {state.symbol} en {market_name}"
                )
            if state.last_generation is not None:
                if view.generation < state.last_generation:
                    raise DashboardDataError("Regresión de generación en dashboard")
                if (
                    view.generation == state.last_generation
                    and state.last_sequence is not None
                    and view.sequence <= state.last_sequence
                ):
                    raise DashboardDataError(
                        "Regresión/repetición de secuencia en dashboard"
                    )
            state.symbol = normalized_symbol
            state.book = view
            state.last_generation = view.generation
            state.last_sequence = view.sequence
            state.status = "SYNCED"
            state.status_reason = None
            self._frame_sequence += 1

    def publish_trade(
        self,
        *,
        market: str,
        symbol: str,
        aggregate_trade_id: int,
        price: str,
        quantity: str,
        buyer_is_maker: bool,
        exchange_trade_time_ms: int,
        receive_utc_ns: int,
    ) -> None:
        market_name = _market(market)
        normalized_symbol = _symbol(symbol)
        if aggregate_trade_id < 0 or exchange_trade_time_ms <= 0 or receive_utc_ns <= 0:
            raise DashboardDataError("ID/timestamps de trade inválidos")
        _positive_fixed(price, "trade.price")
        _positive_fixed(quantity, "trade.quantity")
        if not isinstance(buyer_is_maker, bool):
            raise DashboardDataError("buyer_is_maker debe ser bool")
        view = TradeView(
            symbol=normalized_symbol,
            aggregate_trade_id=aggregate_trade_id,
            price=price,
            quantity=quantity,
            aggressor="SELL" if buyer_is_maker else "BUY",
            exchange_trade_time_ms=exchange_trade_time_ms,
            receive_utc_ns=receive_utc_ns,
        )
        with self._lock:
            state = self._states[market_name]
            if state.symbol is not None and state.symbol != normalized_symbol:
                raise DashboardDataError(
                    f"Trade {normalized_symbol} no coincide con {state.symbol} en {market_name}"
                )
            state.symbol = normalized_symbol
            trades = state.trades
            assert trades is not None
            trades.append(view)
            self._frame_sequence += 1

    def mark_client_frame_drop(self) -> None:
        with self._lock:
            self._client_frame_drops += 1

    def snapshot(self, *, now_monotonic_ns: int | None = None) -> dict[str, object]:
        now_ns = time.monotonic_ns() if now_monotonic_ns is None else now_monotonic_ns
        with self._lock:
            frame_sequence = self._frame_sequence
            client_frame_drops = self._client_frame_drops
            states = tuple(
                (
                    market,
                    state.status,
                    state.status_reason,
                    state.book,
                    tuple(state.trades or ())[-self.trade_frame_limit :],
                )
                for market, state in self._states.items()
            )

        markets: dict[str, object] = {}
        mids: dict[str, int] = {}
        for market, raw_status, reason, book, trades in states:
            status = raw_status
            age_ms: float | None = None
            book_wire: dict[str, object] | None = None
            if book is not None:
                age_ns = max(0, now_ns - book.receive_monotonic_ns)
                age_ms = round(age_ns / 1_000_000, 3)
                if raw_status == "SYNCED" and age_ns > self.stale_after_ns:
                    status = "STALE"
                    reason = "Sin actualización L2 dentro del umbral"
                best_bid = book.bids[0][0]
                best_ask = book.asks[0][0]
                mid_sum = best_bid + best_ask
                if status == "SYNCED":
                    mids[market] = mid_sum
                book_wire = {
                    "symbol": book.symbol,
                    "generation": book.generation,
                    "sequence": book.sequence,
                    "bids": tuple(
                        (format_fixed(price), format_fixed(quantity))
                        for price, quantity in book.bids
                    ),
                    "asks": tuple(
                        (format_fixed(price), format_fixed(quantity))
                        for price, quantity in book.asks
                    ),
                    "best_bid": format_fixed(best_bid),
                    "best_ask": format_fixed(best_ask),
                    "mid": _format_half_fixed(mid_sum),
                    "spread": format_fixed(best_ask - best_bid),
                    "receive_utc_ns": book.receive_utc_ns,
                    "exchange_event_time_ms": book.exchange_event_time_ms,
                    "age_ms": age_ms,
                }
            markets[market] = {
                "status": status,
                "reason": reason,
                "book": book_wire,
                "trades": [
                    {
                        "symbol": trade.symbol,
                        "id": trade.aggregate_trade_id,
                        "price": trade.price,
                        "quantity": trade.quantity,
                        "aggressor": trade.aggressor,
                        "trade_time_ms": trade.exchange_trade_time_ms,
                        "receive_utc_ns": trade.receive_utc_ns,
                    }
                    for trade in trades
                ],
            }

        basis_bps: float | None = None
        state_symbols = {
            market: book.symbol for market, _, _, book, _ in states if book is not None
        }
        symbols_match = state_symbols.get("spot") is not None and state_symbols.get(
            "spot"
        ) == state_symbols.get("usdm_futures")
        if (
            symbols_match
            and "spot" in mids
            and "usdm_futures" in mids
            and mids["spot"] != 0
        ):
            basis_bps = float((mids["usdm_futures"] / mids["spot"] - 1) * 10_000)
            if not math.isfinite(basis_bps):
                basis_bps = None
        return {
            "type": "market_frame",
            "frame_sequence": frame_sequence,
            "server_time_utc_ns": time.time_ns(),
            "markets": markets,
            "basis_bps": round(basis_bps, 4) if basis_bps is not None else None,
            "ui_metrics": {"client_frame_drops": client_frame_drops},
        }

    def readiness(
        self,
        *,
        expected_symbol: str,
        now_monotonic_ns: int | None = None,
    ) -> dict[str, object]:
        """Return an O(1) readiness summary without copying DOM levels/trades."""

        normalized_symbol = _symbol(expected_symbol)
        now_ns = time.monotonic_ns() if now_monotonic_ns is None else now_monotonic_ns
        with self._lock:
            states = tuple(
                (market, state.status, state.status_reason, state.book)
                for market, state in self._states.items()
            )

        markets: dict[str, object] = {}
        all_ready = True
        rejection_reasons: list[str] = []
        for market, raw_status, status_reason, book in states:
            status = raw_status
            age_ms: float | None = None
            has_bids = bool(book and book.bids)
            has_asks = bool(book and book.asks)
            symbol = book.symbol if book is not None else None
            sequence = book.sequence if book is not None else None
            generation = book.generation if book is not None else None
            reason = status_reason
            if book is not None:
                age_ns = max(0, now_ns - book.receive_monotonic_ns)
                age_ms = round(age_ns / 1_000_000, 3)
                if status == "SYNCED" and age_ns > self.stale_after_ns:
                    status = "STALE"
                    reason = "Sin actualización L2 dentro del umbral"

            checks = {
                "status_synced": status == "SYNCED",
                "symbol_matches": symbol == normalized_symbol,
                "has_bids": has_bids,
                "has_asks": has_asks,
                "sequence_valid": isinstance(sequence, int) and sequence >= 0,
                "fresh": age_ms is not None
                and age_ms <= self.stale_after_ns / 1_000_000,
            }
            ready = all(checks.values())
            if not ready:
                all_ready = False
                failed = [name for name, passed in checks.items() if not passed]
                rejection_reasons.append(f"{market}:{','.join(failed)}")
            markets[market] = {
                "ready": ready,
                "status": status,
                "reason": reason,
                "symbol": symbol,
                "generation": generation,
                "sequence": sequence,
                "age_ms": age_ms,
                "has_bids": has_bids,
                "has_asks": has_asks,
                "checks": checks,
            }
        return {
            "operational_ready": all_ready,
            "expected_symbol": normalized_symbol,
            "markets": markets,
            "rejection_reasons": rejection_reasons,
            "checked_monotonic_ns": now_ns,
        }


class _ClientMailbox:
    """A bounded latest-frame-wins queue for one browser connection."""

    def __init__(self, hub: MarketStateHub, size: int = 2) -> None:
        self._hub = hub
        self.queue: asyncio.Queue[bytes] = asyncio.Queue(maxsize=size)

    def offer(self, payload: bytes) -> None:
        if self.queue.full():
            try:
                self.queue.get_nowait()
            except asyncio.QueueEmpty:
                pass
            else:
                self._hub.mark_client_frame_drop()
        try:
            self.queue.put_nowait(payload)
        except asyncio.QueueFull:
            # Only possible if another producer ran between get and put.
            self._hub.mark_client_frame_drop()


class DashboardServer:
    """Local read-only HTTP/WebSocket server for the DOM and liquidity heatmap."""

    def __init__(
        self,
        hub: MarketStateHub,
        *,
        host: str = "127.0.0.1",
        port: int = 8765,
        publish_interval_s: float = 0.1,
        idle_heartbeat_s: float = 1.0,
        max_clients: int = 8,
        identity: RuntimeIdentity | None = None,
    ) -> None:
        try:
            if not ipaddress.ip_address(host).is_loopback:
                raise ValueError("El dashboard solo puede enlazarse a una IP loopback")
        except ValueError as exc:
            if "solo puede" in str(exc):
                raise
            raise ValueError("host debe ser una IP loopback explícita") from exc
        if not 0 <= port <= 65_535:
            raise ValueError("port fuera de rango")
        if publish_interval_s <= 0 or idle_heartbeat_s <= 0:
            raise ValueError("Intervalos del dashboard deben ser positivos")
        if max_clients <= 0:
            raise ValueError("max_clients debe ser positivo")
        self.hub = hub
        self.host = host
        self.port = port
        self.publish_interval_s = publish_interval_s
        self.idle_heartbeat_s = idle_heartbeat_s
        self.max_clients = max_clients
        self.identity = identity
        self._clients: set[_ClientMailbox] = set()
        self._active_websockets: set[web.WebSocketResponse] = set()
        self._runner: web.AppRunner | None = None
        self._site: web.TCPSite | None = None
        self._broadcast_task: asyncio.Task[None] | None = None
        self._stopping = asyncio.Event()
        self._dashboard_html: bytes | None = None
        self._cached_payload: bytes | None = None

    @property
    def url(self) -> str:
        return f"http://{self.host}:{self.port}"

    def create_app(self) -> web.Application:
        app = web.Application(
            client_max_size=64 * 1024,
            middlewares=[self._host_guard_middleware],
        )
        app.router.add_get("/", self._handle_index)
        app.router.add_get("/healthz", self._handle_health)
        app.router.add_get("/readyz", self._handle_ready)
        app.router.add_get("/api/state", self._handle_state)
        app.router.add_get("/ws", self._handle_websocket)
        return app

    @web.middleware
    async def _host_guard_middleware(
        self, request: web.Request, handler: Any
    ) -> web.StreamResponse:
        """P1.5: defensa contra DNS rebinding.

        Una web maliciosa que re-resuelve su DNS a 127.0.0.1 llegaba con un
        header Host foráneo y recibía rutas absolutas con nombre de usuario,
        PID y session id. El Host se valida contra el bind REAL y el Origin
        (si existe) contra el allowlist construido con self.host/self.port —
        nunca contra request.host, que controla el atacante.
        """

        allowed_hosts = {
            f"127.0.0.1:{self.port}",
            f"localhost:{self.port}",
        }
        if self.port == 80:
            allowed_hosts.update({"127.0.0.1", "localhost"})
        host = (request.headers.get("Host") or "").strip().lower()
        if host not in allowed_hosts:
            return web.json_response(
                {"error": "HOST_NOT_ALLOWED"},
                status=403,
                headers=self._security_headers(),
            )
        origin = request.headers.get("Origin")
        if origin is not None:
            allowed_origins = {f"http://{name}" for name in allowed_hosts}
            if origin.strip().lower() not in allowed_origins:
                return web.json_response(
                    {"error": "ORIGIN_NOT_ALLOWED"},
                    status=403,
                    headers=self._security_headers(),
                )
        return await handler(request)

    def set_identity(self, identity: RuntimeIdentity) -> None:
        if identity.host != self.host or identity.port != self.port:
            raise ValueError("La identidad no coincide con el bind real del dashboard")
        self.identity = identity

    def health_payload(self) -> dict[str, Any]:
        identity = self.identity
        if identity is None:
            return {
                "status": "starting",
                "live": True,
                "identity_ready": False,
                "operational_ready": False,
                "frame_sequence": self.hub.frame_sequence,
                "clients": len(self._clients),
                "error_code": "IDENTITY_NOT_CONFIGURED",
            }
        readiness = self.hub.readiness(expected_symbol=identity.symbol)
        return {
            "status": "ready" if readiness["operational_ready"] else "starting",
            "live": True,
            "identity_ready": True,
            "operational_ready": readiness["operational_ready"],
            **identity.public_payload(),
            "frame_sequence": self.hub.frame_sequence,
            "clients": len(self._clients),
            "market_states": readiness["markets"],
            "rejection_reasons": readiness["rejection_reasons"],
            "health_checked_utc_ns": time.time_ns(),
        }

    async def start(self) -> None:
        if self._runner is not None:
            raise RuntimeError("DashboardServer ya está iniciado")
        self._stopping.clear()
        await asyncio.to_thread(self._load_dashboard_html)
        self._runner = web.AppRunner(self.create_app(), access_log=None)
        await self._runner.setup()
        self._site = web.TCPSite(self._runner, self.host, self.port)
        try:
            await self._site.start()
        except BaseException:
            await self._runner.cleanup()
            self._runner = None
            self._site = None
            raise
        if (
            self.port == 0 and self._site._server is not None
        ):  # aiohttp has no public accessor
            sockets = self._site._server.sockets
            if sockets:
                self.port = int(sockets[0].getsockname()[1])
        self._broadcast_task = asyncio.create_task(
            self._broadcast_loop(), name="dashboard-broadcast"
        )

    async def close(self) -> None:
        self._stopping.set()
        if self._broadcast_task is not None:
            self._broadcast_task.cancel()
            await asyncio.gather(self._broadcast_task, return_exceptions=True)
            self._broadcast_task = None
        if self._active_websockets:
            await asyncio.gather(
                *(
                    websocket.close(
                        code=WSCloseCode.GOING_AWAY,
                        message=b"JEAN_FLOW shutdown",
                    )
                    for websocket in tuple(self._active_websockets)
                ),
                return_exceptions=True,
            )
            self._active_websockets.clear()
        self._clients.clear()
        if self._runner is not None:
            await self._runner.cleanup()
            self._runner = None
            self._site = None

    async def __aenter__(self) -> "DashboardServer":
        await self.start()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    def _load_dashboard_html(self) -> bytes:
        if self._dashboard_html is None:
            self._dashboard_html = (
                resources.files("binance_collector")
                .joinpath("dashboard.html")
                .read_bytes()
            )
        return self._dashboard_html

    @staticmethod
    def _security_headers() -> dict[str, str]:
        return {
            "Cache-Control": "no-store",
            "Content-Security-Policy": (
                "default-src 'self'; style-src 'self' 'unsafe-inline'; "
                "script-src 'self' 'unsafe-inline'; connect-src 'self' ws: wss:; "
                "img-src 'self' data:; object-src 'none'; base-uri 'none'"
            ),
            "Referrer-Policy": "no-referrer",
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
        }

    async def _handle_index(self, _: web.Request) -> web.Response:
        return web.Response(
            body=self._load_dashboard_html(),
            content_type="text/html",
            charset="utf-8",
            headers=self._security_headers(),
        )

    async def _handle_health(self, _: web.Request) -> web.Response:
        return web.Response(
            body=orjson.dumps(self.health_payload()),
            content_type="application/json",
            headers=self._security_headers(),
        )

    async def _handle_ready(self, _: web.Request) -> web.Response:
        payload = self.health_payload()
        return web.Response(
            body=orjson.dumps(payload),
            status=200 if payload.get("operational_ready") is True else 503,
            content_type="application/json",
            headers=self._security_headers(),
        )

    async def _handle_state(self, _: web.Request) -> web.Response:
        payload = self._cached_payload
        if payload is None:
            payload = await asyncio.to_thread(self._serialize_snapshot)
            self._cached_payload = payload
        # P1.5: /api/state llevaba solo Cache-Control; ahora el mismo
        # endurecimiento (nosniff incluido) que el resto de endpoints.
        return web.Response(
            body=payload,
            content_type="application/json",
            headers=self._security_headers(),
        )

    async def _handle_websocket(self, request: web.Request) -> web.WebSocketResponse:
        if len(self._clients) >= self.max_clients:
            raise web.HTTPServiceUnavailable(text="Límite de clientes alcanzado")
        origin = request.headers.get("Origin")
        # P1.5: comparar contra request.host validaba al atacante consigo
        # mismo; el allowlist se construye con el bind real del servidor.
        allowed_origins = {
            f"http://127.0.0.1:{self.port}",
            f"http://localhost:{self.port}",
        }
        if origin is not None and origin.strip().lower() not in allowed_origins:
            raise web.HTTPForbidden(text="Origin no permitido")
        mailbox = _ClientMailbox(self.hub)
        # Reserve the slot before the first await, so concurrent handshakes cannot
        # temporarily exceed max_clients.
        self._clients.add(mailbox)
        websocket = web.WebSocketResponse(
            heartbeat=20.0,
            receive_timeout=90.0,
            max_msg_size=1_024,
            compress=False,
        )
        sender: asyncio.Task[None] | None = None
        try:
            await websocket.prepare(request)
            self._active_websockets.add(websocket)
            payload = self._cached_payload
            if payload is None:
                payload = await asyncio.to_thread(self._serialize_snapshot)
                self._cached_payload = payload
            mailbox.offer(payload)
            sender = asyncio.create_task(
                self._client_sender(websocket, mailbox), name="dashboard-client-sender"
            )
            async for message in websocket:
                if message.type is WSMsgType.TEXT and message.data == "ping":
                    await websocket.send_str("pong")
                elif message.type in {WSMsgType.ERROR, WSMsgType.CLOSE}:
                    break
        finally:
            self._active_websockets.discard(websocket)
            self._clients.discard(mailbox)
            if sender is not None:
                sender.cancel()
                await asyncio.gather(sender, return_exceptions=True)
        return websocket

    async def _client_sender(
        self,
        websocket: web.WebSocketResponse,
        mailbox: _ClientMailbox,
    ) -> None:
        while not websocket.closed:
            payload = await mailbox.queue.get()
            await websocket.send_bytes(payload)

    async def _broadcast_loop(self) -> None:
        last_sequence = -1
        last_emit = 0.0
        while not self._stopping.is_set():
            await asyncio.sleep(self.publish_interval_s)
            now = time.monotonic()
            sequence = self.hub.frame_sequence
            if sequence == last_sequence and now - last_emit < self.idle_heartbeat_s:
                continue
            payload = await asyncio.to_thread(self._serialize_snapshot)
            self._cached_payload = payload
            for client in tuple(self._clients):
                client.offer(payload)
            last_sequence = sequence
            last_emit = now

    def _serialize_snapshot(self) -> bytes:
        frame = self.hub.snapshot()
        identity = self.identity
        if identity is not None:
            frame["runtime"] = identity.public_payload()
            readiness = self.hub.readiness(expected_symbol=identity.symbol)
            frame["operational_ready"] = readiness["operational_ready"]
            frame["rejection_reasons"] = readiness["rejection_reasons"]
        return orjson.dumps(frame)
