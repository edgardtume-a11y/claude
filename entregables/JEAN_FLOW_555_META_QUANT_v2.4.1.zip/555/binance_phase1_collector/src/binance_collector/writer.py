from __future__ import annotations

import csv
import os
import queue
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import IO, Final

from .metrics import Metrics
from .models import CSV_FIELDS, CsvBatch, CsvRow

_SENTINEL: Final = object()


class WriterFailed(RuntimeError):
    pass


class CsvJournalWriter:
    """Escritor con hilo propio; submit() nunca espera al disco."""

    def __init__(
        self,
        *,
        output_dir: Path,
        queue_size: int,
        max_queued_rows: int,
        batch_rows: int,
        flush_interval_s: float,
        rotation_bytes: int,
        rotation_seconds: float,
        metrics: Metrics,
        write_chunk_rows: int = 64,
        yield_sleep_s: float = 0.0005,
        fsync_interval_s: float = 5.0,
    ) -> None:
        if write_chunk_rows <= 0:
            raise ValueError("write_chunk_rows debe ser positivo")
        if not 0.0001 <= yield_sleep_s <= 0.01:
            raise ValueError("yield_sleep_s debe estar entre 0.0001 y 0.01")
        if fsync_interval_s <= 0:
            raise ValueError("fsync_interval_s debe ser positivo")
        self._output_dir = output_dir
        self._queue: queue.Queue[CsvBatch | object] = queue.Queue(maxsize=queue_size)
        self._batch_rows = batch_rows
        self._max_queued_rows = max_queued_rows
        self._queued_rows = 0
        self._queued_rows_lock = threading.Lock()
        self._flush_interval_s = flush_interval_s
        self._fsync_interval_s = fsync_interval_s
        self._last_fsync_monotonic = 0.0
        self._rows_since_fsync = 0
        self._rotation_bytes = rotation_bytes
        self._rotation_seconds = rotation_seconds
        self._metrics = metrics
        self._write_chunk_rows = write_chunk_rows
        self._yield_sleep_s = yield_sleep_s
        self._metrics.set_gauge("writer_yield_requested_ms", yield_sleep_s * 1_000)
        self._thread = threading.Thread(
            target=self._run,
            name="csv-journal-writer",
            daemon=False,
        )
        self._fatal_lock = threading.Lock()
        self._fatal: BaseException | None = None
        self._started = False
        self._finalized_files: list[Path] = []
        self._file: IO[str] | None = None
        self._csv: csv.DictWriter[str] | None = None
        self._partial_path: Path | None = None
        self._opened_monotonic = 0.0
        self._segment = 0
        self._rows_in_file = 0
        self._finalize_on_close = True

    @property
    def finalized_files(self) -> tuple[Path, ...]:
        return tuple(self._finalized_files)

    @property
    def fatal_error(self) -> BaseException | None:
        with self._fatal_lock:
            return self._fatal

    def start(self) -> None:
        if self._started:
            raise RuntimeError("El escritor ya fue iniciado")
        self._started = True
        self._thread.start()

    def submit(self, batch: CsvBatch) -> bool:
        fatal = self.fatal_error
        if fatal is not None:
            raise WriterFailed("El hilo escritor falló") from fatal
        row_count = batch.row_count
        if not self._try_reserve_rows(row_count):
            self._metrics.inc("writer_row_budget_overflows")
            return False
        try:
            self._queue.put_nowait(batch)
        except queue.Full:
            self._release_rows(row_count)
            self._metrics.inc("writer_queue_overflows")
            return False
        self._metrics.set_gauge("writer_queue_size", self._queue.qsize())
        self._metrics.set_max_gauge("writer_queue_high_water", self._queue.qsize())
        return True

    def submit_blocking(self, batch: CsvBatch, timeout_s: float = 30.0) -> None:
        deadline = time.monotonic() + timeout_s
        while True:
            fatal = self.fatal_error
            if fatal is not None:
                raise WriterFailed("El hilo escritor falló") from fatal
            row_count = batch.row_count
            if not self._try_reserve_rows(row_count):
                if time.monotonic() >= deadline:
                    raise TimeoutError("Presupuesto de filas agotado al cerrar")
                time.sleep(0.1)
                continue
            try:
                self._queue.put(batch, timeout=0.1)
                self._metrics.set_gauge("writer_queue_size", self._queue.qsize())
                self._metrics.set_max_gauge(
                    "writer_queue_high_water", self._queue.qsize()
                )
                return
            except queue.Full:
                self._release_rows(row_count)
                if time.monotonic() >= deadline:
                    raise TimeoutError(
                        "No se pudo encolar el marcador de captura incompleta"
                    )

    def close(self, timeout_s: float = 30.0, *, finalize: bool = True) -> None:
        if not self._started:
            return
        self._finalize_on_close = finalize
        deadline = time.monotonic() + timeout_s
        while self._thread.is_alive():
            fatal = self.fatal_error
            if fatal is not None:
                raise WriterFailed("El hilo escritor falló") from fatal
            try:
                self._queue.put(_SENTINEL, timeout=0.1)
                break
            except queue.Full:
                if time.monotonic() >= deadline:
                    raise TimeoutError("Timeout al cerrar el escritor CSV")
        remaining = max(0.0, deadline - time.monotonic())
        self._thread.join(remaining)
        if self._thread.is_alive():
            raise TimeoutError("El escritor CSV no terminó a tiempo")
        fatal = self.fatal_error
        if fatal is not None:
            raise WriterFailed("El hilo escritor falló") from fatal

    def _run(self) -> None:
        pending: list[CsvBatch] = []
        pending_rows = 0
        last_flush = time.monotonic()
        try:
            self._output_dir.mkdir(parents=True, exist_ok=True)
            while True:
                # P0.2: con la cola vacía y sin pendientes, el timeout quedaba
                # fijo en 0.0 (last_flush nunca avanzaba) y el hilo giraba al
                # 100 % de un core. Sin pendientes, el temporizador se rearma
                # al intervalo completo; el flush temporizado con pendientes
                # conserva su plazo exacto.
                timeout = (
                    self._flush_interval_s
                    if not pending
                    else max(
                        0.0,
                        self._flush_interval_s - (time.monotonic() - last_flush),
                    )
                )
                try:
                    item = self._queue.get(timeout=timeout)
                except queue.Empty:
                    item = None
                if item is _SENTINEL:
                    if pending:
                        self._write_pending(pending)
                    self._flush_file()
                    if self._finalize_on_close:
                        self._finalize_file()
                    else:
                        self._close_partial_file()
                    break
                if isinstance(item, CsvBatch):
                    pending.append(item)
                    pending_rows += item.row_count
                    self._queue.task_done()
                    self._metrics.set_gauge("writer_queue_size", self._queue.qsize())
                timed_flush = time.monotonic() - last_flush >= self._flush_interval_s
                if pending and (
                    pending_rows >= self._batch_rows or timed_flush or item is None
                ):
                    self._write_pending(pending)
                    pending = []
                    pending_rows = 0
                    self._flush_file()
                    last_flush = time.monotonic()
                elif not pending and item is None:
                    # Ocioso: el temporizador mide desde que quedó ocioso.
                    last_flush = time.monotonic()
        except BaseException as exc:
            self._metrics.inc("writer_failures")
            with self._fatal_lock:
                self._fatal = exc
            if self._file is not None:
                try:
                    self._file.flush()
                    self._file.close()
                except OSError:
                    pass

    def _open_file(self) -> None:
        self._segment += 1
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
        stem = f"events-{timestamp}-{self._segment:06d}"
        self._partial_path = self._output_dir / f"{stem}.csv.partial"
        self._file = self._partial_path.open(
            "x",
            encoding="utf-8",
            newline="",
            buffering=1024 * 1024,
        )
        self._csv = csv.DictWriter(
            self._file, fieldnames=CSV_FIELDS, extrasaction="raise"
        )
        self._csv.writeheader()
        self._opened_monotonic = time.monotonic()
        self._last_fsync_monotonic = self._opened_monotonic
        self._rows_since_fsync = 0
        self._rows_in_file = 0

    def _should_rotate(self) -> bool:
        if self._file is None or self._rows_in_file == 0:
            return False
        return (
            self._file.tell() >= self._rotation_bytes
            or time.monotonic() - self._opened_monotonic >= self._rotation_seconds
        )

    def _write_pending(self, batches: list[CsvBatch]) -> None:
        for batch in batches:
            if self._file is None:
                self._open_file()
            elif self._should_rotate():
                self._flush_file()
                self._finalize_file()
                self._open_file()
            assert self._csv is not None
            writer_start_utc_ns = time.time_ns()
            writer_start_monotonic_ns = time.monotonic_ns()
            row_count = batch.row_count
            chunk: list[CsvRow] = []
            rows_written = 0
            # [2.3.6] Duración local con perf_counter_ns (monotonic_ns tiene
            # tic de 15.625 ms en Windows + Python 3.12). Los campos de DATOS
            # de la fila (writer_start_time_monotonic_ns,
            # receive_to_writer_start_ns) conservan monotonic_ns: comparten
            # dominio de reloj con receive_time_monotonic_ns.
            write_started = time.perf_counter_ns()
            for row in batch.iter_rows():
                row["writer_start_time_utc_ns"] = writer_start_utc_ns
                row["writer_start_time_monotonic_ns"] = writer_start_monotonic_ns
                row["receive_to_writer_start_ns"] = writer_start_monotonic_ns - int(
                    row["receive_time_monotonic_ns"] or 0
                )
                chunk.append(row)
                if len(chunk) < self._write_chunk_rows:
                    continue
                self._csv.writerows(chunk)
                rows_written += len(chunk)
                chunk.clear()
                if rows_written < row_count:
                    # CPython 3.12 usa un waitable timer de alta resolución en
                    # Windows para sleeps positivos: este yield no necesita
                    # timeBeginPeriod y no hace busy-spin. [2.3.6] Decisión
                    # revisada para el EVENT LOOP: sus timers (Proactor/IOCP)
                    # sí redondean al tic de 15.625 ms, así que el motor pide
                    # el temporizador de 1 ms con fine_timer_resolution()
                    # (dual_main/main); es por-proceso en Windows 10 2004+ y
                    # se restaura al salir. El tiempo observado sigue medido
                    # porque el scheduler aún puede despertar tarde.
                    yield_started = time.perf_counter_ns()
                    time.sleep(self._yield_sleep_s)
                    yield_elapsed_ns = time.perf_counter_ns() - yield_started
                    self._metrics.observe(
                        "writer_cooperative_yield",
                        yield_elapsed_ns / 1_000_000,
                    )
                    if yield_elapsed_ns > max(
                        5_000_000,
                        int(self._yield_sleep_s * 4 * 1_000_000_000),
                    ):
                        self._metrics.inc("writer_yield_overshoots")
                    self._metrics.inc("writer_gil_yields")
            if chunk:
                self._csv.writerows(chunk)
                rows_written += len(chunk)
            self._metrics.observe(
                "csv_write", (time.perf_counter_ns() - write_started) / 1_000_000
            )
            if rows_written != row_count:
                raise WriterFailed(
                    f"Conteo de filas inconsistente: {rows_written} != {row_count}"
                )
            self._rows_in_file += row_count
            self._rows_since_fsync += row_count
            self._metrics.inc("csv_batches_written")
            self._metrics.inc("csv_rows_written", row_count)
            self._metrics.observe(
                "receive_to_writer_start",
                (writer_start_monotonic_ns - batch.receive_monotonic_ns) / 1_000_000,
            )
            self._release_rows(row_count)

    def _try_reserve_rows(self, count: int) -> bool:
        with self._queued_rows_lock:
            if self._queued_rows + count > self._max_queued_rows:
                return False
            self._queued_rows += count
            self._metrics.set_gauge("writer_queued_rows", self._queued_rows)
            self._metrics.set_max_gauge("writer_rows_high_water", self._queued_rows)
            return True

    def _release_rows(self, count: int) -> None:
        with self._queued_rows_lock:
            self._queued_rows = max(0, self._queued_rows - count)
            self._metrics.set_gauge("writer_queued_rows", self._queued_rows)

    def _flush_file(self) -> None:
        if self._file is None:
            return
        started = time.perf_counter_ns()
        self._file.flush()
        self._metrics.inc("csv_flushes")
        self._metrics.observe(
            "csv_flush", (time.perf_counter_ns() - started) / 1_000_000
        )
        # R8.1 [P8]: sin fsync periódico, el RPO ante corte de energía era
        # min(512 MiB/R, 3600 s) = hasta 1 hora de datos. Un fsync cada
        # fsync_interval_s acota la pérdida a ese periodo, medido como
        # csv_fsync en métricas. Solo se paga cuando hubo filas nuevas.
        now = time.monotonic()
        if (
            self._rows_since_fsync > 0
            and now - self._last_fsync_monotonic >= self._fsync_interval_s
        ):
            fsync_started = time.perf_counter_ns()
            os.fsync(self._file.fileno())
            self._metrics.observe(
                "csv_fsync", (time.perf_counter_ns() - fsync_started) / 1_000_000
            )
            self._metrics.inc("csv_periodic_fsyncs")
            self._last_fsync_monotonic = now
            self._rows_since_fsync = 0

    def _finalize_file(self) -> None:
        if self._file is None or self._partial_path is None:
            return
        self._file.flush()
        fsync_started = time.perf_counter_ns()
        os.fsync(self._file.fileno())
        self._metrics.observe(
            "csv_fsync", (time.perf_counter_ns() - fsync_started) / 1_000_000
        )
        self._file.close()
        final_path = self._partial_path.with_suffix("")
        os.replace(self._partial_path, final_path)
        self._fsync_directory()
        self._finalized_files.append(final_path)
        self._metrics.inc("csv_rotations")
        self._file = None
        self._csv = None
        self._partial_path = None

    def _fsync_directory(self) -> None:
        if not hasattr(os, "O_DIRECTORY"):
            return
        directory_fd = os.open(self._output_dir, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)

    def _close_partial_file(self) -> None:
        if self._file is None:
            return
        self._file.flush()
        fsync_started = time.perf_counter_ns()
        os.fsync(self._file.fileno())
        self._metrics.observe(
            "csv_fsync", (time.perf_counter_ns() - fsync_started) / 1_000_000
        )
        self._file.close()
        self._file = None
        self._csv = None
