# CAMBIOS v2.3.5 — El informe de la auditoría viaja SIEMPRE en UTF-8

Corrección crítica de una sola causa raíz, sin tocar ningún criterio,
umbral ni formato de datos. Los journals, sellos y gates quedan idénticos.

## Síntoma (evidencia de campo)

Dos certificaciones modo 3 vetadas en la etapa de 10 minutos con
`DATA_GATES_FAILED`, en discos distintos y con datos perfectos:

- Sesión `87fa5a61d0194771831da5ca3e908a02` (D:, TOSHIBA USB, v2.3.4).
- Sesión `d64fea5560ac489eac0b5666111cc0cf` (C:, disco interno, v2.3.4).

Firma idéntica en ambas:

- `replay_determinism` de ambos mercados:
  `RuntimeContractError: 'utf-8' codec can't decode byte 0xe9 in position
  700` (spot) y `position 767` (usdm_futures) — posiciones FIJAS y
  minúsculas, imposibles para archivos de cientos de MB.
- `audit_metrics.json` no contenía JSON sino un traceback:
  `UnicodeEncodeError: 'charmap' codec can't encode characters in position
  538-539` dentro de `cp1252.py` al hacer `print(json.dumps(...))`.
- Los `audit_*.json` escritos mostraban mojibake (`m�s`, `despu�s`,
  `contig�idad`) al leerse como UTF-8.

Mientras tanto, los DATOS estaban íntegros y lo probaron tres vías
independientes:

- `capture_commitment` PASS en ambas sesiones (tamaños y SHA-256 exactos,
  re-verificados en binario).
- Escaneo externo de los 1.58 GB de la sesión D:
  (`BYTE_MALO_EVIDENCIA.txt`): 0 bytes UTF-8 inválidos, 4/4 sellos y
  tamaños idénticos a los del cierre.
- En la sesión C:, el contenido interno de los informes muestra
  `identity` PASS con completitud 38 612/38 612 (ratio 1.0, 0 conflictos)
  y los DOS replays de cada mercado con `sha256` idénticos
  (spot `e9d8a230…`, usdm `beff8f18…`): el replay causal fue determinista.

## Causa raíz

Los exámenes de auditoría corren como hijos aislados
(`python -I -S -B -u isolated_entry.py …`) con stdout redirigido a
archivo. En Windows es-ES, un stdout redirigido usa la codificación de la
localización: **cp1252**. v2.3.4 añadió texto no-ASCII a los informes
(la nota "…después de CONNECTION CLOSED… contigüidad…", el
`fingerprint_scope` "…más niveles expandidos…" y la banda `θ̂±δ/2` del
examen de métricas), con `json.dumps(..., ensure_ascii=False)`:

- `'é'` sí existe en cp1252 (byte `0xE9`): el informe se ESCRIBÍA, pero el
  verificador lo relee como UTF-8 **estricto** (`read_json_object`) y
  `0xE9` es una continuación inválida → veto con posición fija (700/767:
  la 'é' de "después" dentro del JSON ordenado).
- `'θ̂'` NO existe en cp1252: el examen de métricas ni siquiera podía
  imprimir su informe (UnicodeEncodeError → traceback en vez de JSON).

Con `-I`, las variables `PYTHONUTF8`/`PYTHONIOENCODING` se ignoran, así
que no había forma ambiental de corregirlo: tenía que ser explícito.

## Corrección (tres capas, misma regla)

1. `launcher._isolated_command` añade **`-X utf8`** a TODOS los hijos
   aislados (única vía por línea de comandos compatible con `-I`).
2. `isolated_entry.main()` reconfigura stdout/stderr a UTF-8 al arrancar.
3. `audit.main()` hace lo mismo (defensa si se invoca sin el entry).

El contenido de los informes no cambia: solo el canal por el que viajan.

## Correcciones de veredicto previas

- El `0xE9` NUNCA fue una lectura intermitente del disco TOSHIBA ni bytes
  corruptos en los CSV: era la 'é' del propio informe. El escaneo externo
  que ya mostraba 0 bytes inválidos queda ratificado.
- El TOSHIBA sí era culpable de otra cosa: 189 `healthy_resets` y una
  etapa de 10 min estirada a 56 min en D:, frente a **0 resets y 600.0 s
  exactos** en C: (sesión `d64fea5560ac`). La regla 2 del LEEME (captura
  en disco interno) queda confirmada con campo.

## Pruebas

- Nueva `tests/test_utf8_stdio.py` (5 pruebas): fija `-X utf8` en el
  comando aislado, verifica la reconfiguración cp1252→UTF-8 en
  `audit` e `isolated_entry`, reproduce end-to-end la condición Windows
  es-ES (`PYTHONIOENCODING=cp1252`) y documenta que sin la corrección
  imprime `UnicodeEncodeError` como en el host real.
- `tests/test_runtime_contract.py` actualiza el contrato del comando
  aislado a la nueva forma (cambio explícito, nunca silencioso).
- Suite offline completa: **226 passed, 2 skipped** (smoke live opt-in).

## Sin cambios

Umbrales, gates, esquema 2.0.0, formato de journals, sellos SHA-256 y el
límite `event_loop_lag p99 <= 40 ms` (revisión 2.3.4) permanecen intactos.
