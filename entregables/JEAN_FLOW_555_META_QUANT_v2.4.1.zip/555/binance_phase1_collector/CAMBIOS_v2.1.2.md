# Cambios JEAN_FLOW 2.1.2 — compatibilidad Windows PowerShell 5.1

## Corrección crítica

- Se corrigió la interpolación inválida `"$LASTEXITCODE:"` en
  `Configure-W32Time.ps1`. Windows PowerShell 5.1 interpretaba los dos puntos
  como parte del nombre de la variable y detenía la reparación con
  `InvalidVariableReferenceWithDrive` antes de solicitar o completar UAC.
- La forma compatible es `"${LASTEXITCODE}:"`; no cambia la lógica de W32Time,
  los peers, el polling ni el gate de offset.

## Prevención de regresiones

- Se añadió una prueba Python portable que examina todos los scripts NTP y
  rechaza variables sin llaves inmediatamente antes de dos puntos.
- La prueba estática de PowerShell aplica la misma regla, además de invocar el
  parser nativo de PowerShell 5.1 cuando se ejecuta en Windows.
- `EJECUTAR_TODO_JEAN_FLOW.cmd` ejecuta esa validación antes de crear el entorno
  virtual, y el launcher vuelve a analizar todos los scripts NTP antes de UAC.
- Se corrigió la selección de `ntpq.exe` para conservar un arreglo incluso si
  existe una sola ruta candidata de Meinberg.
- Se conserva la secuencia segura: respaldo, inicio de W32Time, configuración,
  un único `resync /rediscover`, convergencia y validación final.

## Alcance

- Motor: `2.1.2`.
- Schema causal: `2.0.0` sin cambios.
- No se modificó el camino caliente de captura, `book_apply`, el watchdog del
  event loop ni el formato del journal.
