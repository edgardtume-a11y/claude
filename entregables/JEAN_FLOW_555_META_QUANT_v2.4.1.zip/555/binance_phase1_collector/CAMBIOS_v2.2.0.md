# Cambios JEAN_FLOW 2.2.0

- Base congelada: 2.1.5, sin incorporar el frontend V8 como segunda fuente de verdad.
- Gestor de sesión atómico con UUID impuesto por el launcher.
- READY fuerte con PID, proceso padre, versiones, símbolo, mercados y salud L2.
- `/healthz` separa vida, identidad y disponibilidad operacional; `/readyz`
  devuelve 503 hasta que ambos mercados estén sincronizados y frescos.
- Puerto `0` enlazado directamente por aiohttp; se elimina la carrera de probar
  un puerto y liberarlo antes del bind.
- Launcher Python supervisado, mutex por usuario y cierre por STOP del hijo propio.
- Heartbeat launcher/motor ligado a sesión para parar un hijo huérfano.
- Un único CMD público: `555\INICIAR.cmd`.
- Bootstrap bloqueado contra doble clic simultáneo y validación completa de
  `RELEASE_MANIFEST.sha256` antes de crear `.venv` y antes de certificar.
- Wheelhouse Windows Python 3.12 x64 con 22 wheels fijados (incluido `colorama`
  para pytest en Windows), manifest SHA-256 y resolución offline en el build.
- Pruebas de sesión/PID/versión/mercado incorrectos, READY parcial, libro stale,
  puerto ocupado, navegador bloqueado, timeout unilateral y ventana interrumpida.
- Gates progresivos 10/30/120 minutos y marcador final solo tras postflight y
  auditorías PASS.
- `RESULT.json` no publica PASS antes del postflight NTP; un full nuevo archiva
  el certificado anterior antes de validar el intento.
- Commitment terminal con secuencia final, lista/tamaño/hash de CSV, snapshot
  final de métricas, high-water vs capacidad y doble replay determinista.
- Ruta rápida del dashboard vuelve a validar el top-N antes de publicar SYNCED.
- Validación offline final: 132 PASS, 1 smoke live opt-in omitido; benchmark
  sintético `--enforce` PASS.
- LightGBM continúa bloqueado hasta certificar Fase 1 en el host Windows final.
