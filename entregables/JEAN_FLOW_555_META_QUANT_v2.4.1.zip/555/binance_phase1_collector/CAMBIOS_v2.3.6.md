# CAMBIOS v2.3.6 — La regla no cambió: cambió la regla de medir

Tres correcciones de una misma certificación de campo, sin tocar ningún
umbral, gate, esquema ni formato de datos. Los journals, sellos y criterios
quedan idénticos a v2.3.5.

## Evidencia de campo (sesión `5ebb3efde620`, C:, 14-ago-2026, v2.3.5)

Primera certificación donde el examen de métricas corrió COMPLETO (v2.3.5
eliminó el veto por transporte). Resultado: todos los gates de datos en
verde — commitment PASS, identidad PASS, replay determinista con sellos
idénticos por mercado, 0 resets, 600.0 s exactos — y UN solo gate en rojo:
`metrics`, con tres firmas anómalas:

1. `book_pipeline_p99` worst 16.0 ms (límite 5 ms) en ambos mercados y
   `book_apply_p99` worst 15.0 ms en futuros: valores CLAVADOS en 15/16,
   nunca intermedios, y percentiles 0.0 exactos con miles de muestras.
2. La única métrica con decimales reales era `writer_cooperative_yield`
   (3.085 ms) — la única medida con `time.perf_counter_ns()`.
3. `cobertura de ventana violada (snapshot 76: count=9304 > count_total=9303)`
   en 3 métricas del mismo shard, off-by-one exacto.

Mientras tanto, el banco de pruebas del preflight — misma laptop, minutos
antes — midió `book_pipeline_total` p99 = 0.136 ms: la máquina es 35 veces
más rápida que el límite.

## Causas raíz (tres, todas nuestras)

1. **Reloj de tic grueso.** En Windows + Python 3.12, `time.monotonic_ns()`
   usa `GetTickCount64` con resolución de **15.625 ms**. Toda duración
   sub-milisegundo medida con él sale 0, y cualquier espera que cruce un tic
   sale 15/16. Los gates de 5 ms quedaban por debajo de la resolución de la
   regla con la que se medían: imposibles de aprobar, midiera lo que midiera
   la máquina.
2. **Tic del event loop.** Los timers de asyncio (Proactor/IOCP) redondean
   al mismo tic de 15.625 ms si nadie pide el temporizador fino: despertares
   tarde reales de hasta un tic.
3. **Foto de contadores no atómica.** `snapshot()` copiaba los totales y
   recién al final leía el contenido de los deques vivos: una muestra
   anexada en medio aparecía en la ventana pero no en el total
   (`count > count_total`), y el auditor — correctamente — lo vetaba.

## Correcciones

1. **Toda duración local se mide con `time.perf_counter_ns()`**
   (resolución sub-µs): `parse`, `partial_validation`, `book_apply`,
   `journal_build`, `journal_enqueue`, `dashboard_project`,
   `book_pipeline_total`, `csv_write`, `csv_flush`, `csv_fsync`,
   `rest_snapshot_decode`. Los campos de DATOS
   (`receive_time_monotonic_ns`, `writer_start_time_monotonic_ns`,
   `receive_to_writer_start_ns`) y las métricas de dominio de datos
   (`receive_to_writer_start`, `rest_snapshot`) conservan `monotonic_ns`:
   el formato de filas no cambia ni un byte de significado.
2. **`fine_timer_resolution()`** (nuevo, en `latency.py`): pide a Windows el
   temporizador de 1 ms (`winmm.timeBeginPeriod(1)`) durante toda la
   captura y lo restaura SIEMPRE (`timeEndPeriod`). Por-proceso en Windows
   10 2004+; fuera de Windows es inocuo. Lo usan `dual_main`, `main` y el
   banco del preflight (mismas condiciones al medir que al capturar). Esto
   REVISA explícitamente la decisión contraria anotada en `writer.py`
   (v2.3.2): aquella nota era correcta para `time.sleep()` — que ya usa
   waitable timers finos — pero no cubría los timers del event loop.
3. **Invariante de la foto de métricas**: `observe()` incrementa el total
   ANTES de anexar y `snapshot()` congela el contenido de cada deque ANTES
   de copiar totales. Con ambos órdenes, `count <= count_total` se sostiene
   bajo cualquier intercalado de hilos.

## Pruebas

- Nueva `tests/test_metrics_fidelity.py` (10 pruebas): contrato de relojes
  (duraciones→perf_counter, datos→monotonic, si alguien lo revierte el
  contrato revienta), orden total-antes-de-anexar, invariante
  `count <= count_total` bajo productor concurrente, ventana/evicted/
  decimales, y `fine_timer_resolution` (pide 1 ms, restaura siempre —
  incluso con excepción — y no restaura si no pudo pedir).
- Suite offline completa: **236 passed, 2 skipped** (smoke live opt-in).

## Sin cambios

Umbrales intactos: `book_*_p99 <= 5 ms`, `event_loop_lag p99 <= 40 ms`
(revisión 2.3.4), esquema 2.0.0, formato de journals y CSV, sellos SHA-256,
comando de hijos aislados (contrato 2.3.5 con `-X utf8`). La corrección
cambia la REGLA DE MEDIR, no la regla: con la regla fina, la máquina que ya
hacía 0.136 ms ahora puede demostrarlo.
