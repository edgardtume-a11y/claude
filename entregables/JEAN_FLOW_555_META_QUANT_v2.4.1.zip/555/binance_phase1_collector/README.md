# JEAN_FLOW 2.4.1 - Fase 1 endurecida

(La narrativa de remediación de este documento se redactó en la era 2.3.0 y
se conserva como historia; la versión de esta entrega es la del título y la
de «Estado verificable».)

Recolector read-only de microestructura para Binance Spot y USD-M Futures. Esta
versión parte del motor `2.1.5` y aplica la remediación de las auditorías de
v2.2.2. La corrección causal Spot es ahora estricta: el evento que ancla el
snapshot cumple `U <= L+1 <= u` y cada evento posterior exige `U == u_anterior
+ 1` exacto (`test_order_book.py::
test_snapshot_bridge_overlap_duplicate_delete_and_gap`); un solapamiento se
rechaza y se cuenta (`l2_overlap_events`), nunca se aplica en silencio.
No contiene señales, órdenes, LightGBM ni XGBoost.

Baseline de benchmark: `BENCHMARK_REFERENCIA_20260813.json` (motor 2.3.0,
generado en Linux durante la remediación; regenérelo en el Windows objetivo
antes de certificar — los umbrales por plataforma difieren).

## Resultado de la revisión

El informe técnico describía `READY_INVALID`, pero ese código y el puerto 52111
no existen en el ZIP oficial 2.1.5. La base solo exponía un `/healthz` genérico y
creaba la sesión dentro del motor. Por eso 2.2.0 implementó el contrato desde
cero. La revisión 2.2.1 endureció la ruta numérica, el bootstrap de dependencias
y la telemetría del escritor. La 2.2.2 corrige el gate W32Time después de
reproducir en Windows un falso rechazo contra una referencia NTP distinta de la
fuente que realmente disciplinaba el reloj.

Identificadores canónicos usados por todo el sistema:

- producto: `JEAN_FLOW`;
- motor: `2.4.1` (los informes históricos citan `2.2.2`, versión de la
  auditoría que originó esta base);
- esquema de datos: `2.0.0`;
- mercados: `spot` y `usdm_futures`;
- símbolo predeterminado: `TUTUSDT`.

## Uso de un clic

1. Extrae el ZIP conservando la carpeta `555`.
2. Haz doble clic únicamente en `555\INICIAR.cmd`.
3. Elige el modo en el menú.

Use doble clic normal, nunca «Ejecutar como administrador». El bootstrap
consulta `TokenElevation` y falla cerrado si toda la consola está elevada;
únicamente el `/resync` puntual puede solicitar UAC después de autorización.

| Opción | Uso | Criterio de finalización |
|---|---|---|
| 1 | Captura normal | `Ctrl+C` una vez; después drena y audita |
| 2 | Gate inicial | 600 segundos consecutivos con ambos libros READY |
| 3 | Certificación | 10 min PASS, luego 30 min PASS y finalmente 120 min PASS |

Si no existe Python 3.12 x64 en una ruta oficial conocida, el CMD falla cerrado
y pide instalarlo manualmente desde python.org. No ejecuta aliases hallados por
`PATH` antes de verificar el release. Las dependencias de Python vienen como
wheels de Windows x64 dentro del release. Cada pin incluye SHA-256 y debe tener
una correspondencia exacta con un único wheel y con el manifest. El bootstrap
extrae esos wheels directamente a un runtime desechable, valida el `RECORD` de
cada wheel y sella el inventario completo con SHA-256 antes de importar. No usa
`pip`, no ejecuta `.pth`, no instala el proyecto en editable ni descarga nada.

## Qué significa READY

El servidor vivo, la identidad, los datos y el navegador son estados separados.
`READY.json` se escribe atómicamente solo cuando:

- el PID es el hijo supervisado por el launcher;
- `capture_session_id`, launcher PID, versión, símbolo y mercados coinciden;
- el servidor está enlazado por el propio motor en `127.0.0.1:0` y publica el
  puerto realmente reservado, sin carrera de “probar y soltar”;
- Spot y `usdm_futures` están `SYNCED`;
- ambos libros tienen bid, ask, secuencia válida y actualización fresca;
- `/readyz` devuelve exactamente la misma identidad y salud operacional.

En uso normal (modo 1) el navegador se abre una sola vez después de esa
validación. Desde 2.4.1 una etapa CERTIFICABLE no lo abre: hacerlo le quitaba
el primer plano a la consola y Windows degradaba la captura (EcoQoS). La URL
se imprime igual y el servidor sigue sirviéndola; `control/browser.json`
registra `skipped` y `skip_reason` para que el run diga qué pasó. Si la
apertura visual falla, la captura continúa; si READY o HTTP fallan, la etapa
falla cerrada.

Ejemplo abreviado:

```json
{
  "ready": true,
  "protocol_version": "1.0.0",
  "product": "JEAN_FLOW",
  "engine_version": "2.2.2",
  "data_schema_version": "2.0.0",
  "capture_session_id": "uuid",
  "pid": 12345,
  "symbol": "TUTUSDT",
  "markets": ["spot", "usdm_futures"],
  "host": "127.0.0.1",
  "port": 52111,
  "operational_ready": true
}
```

El puerto del ejemplo no está fijado: cada ejecución publica el que realmente
obtuvo del sistema operativo.

## Sesión y cierre seguro

Cada ejecución usa una carpeta nueva y una máquina de estados atómica:

`STARTING -> IDENTITY_READY -> CAPTURING -> STOPPING -> COMPLETED`

Un error termina en `FAILED`. No se reutilizan READY ni sesiones anteriores, no
se borran fallos y no se mata cualquier PID que ocupe un puerto. El launcher
supervisa un objeto `Popen` concreto y solo puede detener ese hijo: primero crea
`STOP.json`, espera el drenaje y usa terminación forzada únicamente tras timeout.
El motor valida además un heartbeat etiquetado por sesión del launcher (no
lleva firma criptográfica: identifica sesión y PID; ver SECURITY.md); si pierde
a su supervisor, se detiene en modo fail-closed en vez de seguir como huérfano.
Una lectura ilegible aislada del heartbeat se tolera mientras la última lectura
válida siga fresca (`test_launcher_codes.py::
test_heartbeat_validator_distinguishes_unreadable_from_lost`).

Un mutex Win32 nombrado protege el bootstrap durante toda la vida del proceso y
otro mutex del launcher actúa como segunda defensa. Un crash o reinicio libera
ambos objetos del kernel; no se interpreta la presencia de un archivo residual
como un lock vivo. El runtime se inicia con `-I -S` y añade de forma explícita
solo `src` y el runtime verificado, sin ejecutar archivos `.pth`. Cada arranque
vuelve a comprobar todos sus bytes; si algo cambió, preserva el directorio y lo
reconstruye desde los wheels controlados con el Python global ya validado.
Esta es integridad interna, no una firma externa: un actor que pueda sustituir
de forma coherente todo el ZIP queda fuera del modelo hasta añadir Authenticode
o una firma pública distribuida por un canal independiente. Ejecute la carpeta
con ACL de escritura restringida: un proceso que ya opere con la misma identidad
del usuario puede intentar sustituir transitoriamente un script entre controles.

## Estructura de evidencia

```text
runs/
├── preflight_<UTC>/
│   ├── clock_preflight.json
│   ├── pytest_offline.txt
│   └── benchmark_latency.json
└── <UTC>_<ETAPA>_<SESION>/
    ├── control/
    │   ├── session.json
    │   ├── READY.json
    │   └── browser.json
    ├── capture/
    │   ├── spot/*.csv
    │   ├── usdm_futures/*.csv
    │   ├── jean_flow_metrics.jsonl
    │   └── audit_*.json
    ├── clock_postflight.json
    └── RESULT.json
```

Antes de declarar `COMPLETED`, el motor compromete la secuencia causal final y
el inventario exacto de CSV (ruta, tamaño y SHA-256). La auditoría exige ese
inventario, repite dos veces el replay de cada mercado y compara el estado
canónico. `RESULT.json` permanece `pass=false` mientras falta el postflight NTP
y solo cambia a PASS tras cerrarlo. El marcador
`CAPTURA_COMPLETA_AUDITADA.json` solo se crea atómicamente después del PASS de
10, 30 y 120 minutos, cierre durable y auditorías de Spot, Futures, identidad,
métricas e integridad de release. Un nuevo intento completo archiva el marcador
anterior; su presencia nunca representa el intento que acaba de comenzar.
Tras cada postflight se recalculan integridad del release y commitment de CSV;
antes del marcador final se vuelven a reconciliar los `RESULT.json` y hashes de
las tres etapas, cerrando cambios externos durante un soak largo.

Interrumpir antes de completar una ventana saludable produce
`HEALTHY_DURATION_INCOMPLETE`; nunca se convierte en PASS por un exit code cero.

## NTP y baja latencia

El preflight exige un solo disciplinador, una fuente válida y un offset dentro
de 50 ms. En W32Time se exige
`abs_phase_offset_ms <= 50` sobre el `Phase Offset` calculado por el servicio
respecto de su fuente activa; no se compara con un servidor público ajeno. En
Meinberg se conserva el p95 de 20 lecturas consecutivas de la estimación de
`ntpd`, no 20 intercambios NTP forzados. Si el Phase Offset real de un W32Time
no administrado supera el límite, el preflight puede ofrecer un único
`System32\w32tm.exe /resync` con UAC y después revalida hasta 90 segundos. No
cambia peers, registro, servicio, firewall ni GPO. Durante la captura no se
ejecuta `resync`; el postflight es estrictamente de solo lectura.

`LocalOrderBook` y la vista viva usan enteros de punto fijo exactos con escala
`10^8`; no redondean. Un precio o cantidad con más de ocho decimales no nulos,
Unicode, exponente, signo u overflow se rechaza antes de mutar el libro. Los
eventos y el CSV conservan los strings originales, y el replay histórico sigue
usando su contrato decimal fuera de la ruta caliente.

En CPython 3.12/Windows 11, `time.sleep(x>0)` usa un waitable timer de alta
resolución; no se fuerza `timeBeginPeriod(1)` ni se hace busy-spin. El scheduler
puede despertar tarde, por lo que cada yield del writer se mide como
`writer_cooperative_yield` y su p99 se audita cuando hubo yields.

`book_apply`, pipeline, yields y lag del event loop usan reloj monotónico. NTP
disciplina UTC, pero no puede explicar ni corregir una duración local lenta.

## Límites de certificación

- `parse p99 <= 5 ms`;
- `book_apply p99 <= 5 ms`;
- `book_pipeline_total p99 <= 5 ms`;
- burst síncrono de 511 niveles p99 <= 5 ms;
- `event_loop_lag p99 <= 40 ms` (revisado en 2.3.4; antes 20 ms);
- `writer_cooperative_yield p99 <= 5 ms` cuando el writer tuvo que ceder.

Revisión 2.3.4 de `event_loop_lag`: el cuanto del temporizador de Windows de
escritorio es 15.625 ms y el colector no fuerza `timeBeginPeriod(1)` (párrafo
anterior), así que la cola de la distribución cae en múltiplos del cuanto por
construcción del sistema operativo. Evidencia de campo: sesión certificable
sana de 10 min (99a0f0a51142, BTCUSDT, 0 overflows, aggTrade en ambos
mercados) con p99 clavado en 21-22 ms — 1 cuanto + despacho — como ÚNICO gate
FAIL; el límite de 20 ms era inaprobable estructuralmente en Windows. Nuevo
corte = 2 cuantos (31.25 ms) + margen ≈ 40 ms; los atascos reales siguen
condenados (p99 sostenido >= 100 ms). La métrica se publica sin recorte; solo
cambió la línea de corte, documentada aquí, en `CERTIFICACION_FASE1.md` y en
`CAMBIOS_v2.3.4.md`. La corrección 2.3.5 (transporte UTF-8 de los informes
de auditoría en Windows es-ES) no toca ningún criterio: ver
`CAMBIOS_v2.3.5.md`. La corrección 2.3.6 tampoco: cambia la REGLA DE MEDIR
(duraciones con `perf_counter_ns` en vez del tic de 15.625 ms de
`monotonic_ns` en Windows, temporizador fino de 1 ms durante la captura y
foto de contadores con invariante `count <= count_total`), no los umbrales:
ver `CAMBIOS_v2.3.6.md`. La 2.3.7 tampoco: exime al motor de las
degradaciones de Windows 11 por ventana minimizada (EcoQoS y coalescencia
del temporizador, `SetProcessInformation`/PowerThrottling), que anulaban en
la práctica el temporizador fino: ver `CAMBIOS_v2.3.7.md`.

Los gaps explícitos pueden ocurrir y deben invalidar/resincronizar el libro. El
criterio es cero pérdida silenciosa y cero gap no reconciliado, no fingir que una
red pública jamás se reconecta.

## Estado verificable

La suite offline, el benchmark sintético, el compilado y la integridad del ZIP
se ejecutan antes de entregar el release. En esta entrega (2.4.1): 260 PASS,
2 skips opt-in (smoke live Binance, `RUN_BINANCE_LIVE=1`), y benchmark
`--enforce` PASS en Linux/Python 3.12 con el límite revisado de 40 ms. La
captura real, instalación offline limpia, Windows PowerShell,
UAC, NTP y Binance live solo pueden certificarse en el Windows final. Hasta que
el modo 3 cree su marcador, la Fase 1 operacional sigue pendiente y Machine
Learning permanece bloqueado.

## Procedencia

Base canónica auditada:

`JEAN_FLOW_555_LOW_LATENCY_NTP_v2.1.5_20260811`

SHA-256 del ZIP base:

`4c7c4e44958f3a67a191c907454da8cf8592f349c1afab7daddfd5266bf6195f`

Los archivos `CAMBIOS_v2.1.x.md` se conservan como historial. No son
instrucciones de inicio para 2.2.2.
