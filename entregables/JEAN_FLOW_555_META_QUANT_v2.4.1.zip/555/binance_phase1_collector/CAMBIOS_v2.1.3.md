# Cambios JEAN_FLOW 2.1.3 — precheck PowerShell 5.1

## Correccion critica

- Se corrigio el binding de `Assert-Condition` en `Test-TimeSyncAssets.ps1`.
  PowerShell 5.1 rechazaba el mensaje vacio producido cuando el parser no
  encontraba errores, antes de que la condicion pudiera evaluarse.
- El parametro `Message` ahora admite explicitamente cadenas vacias mediante
  `[AllowEmptyString()]`.
- La primera comprobacion tambien utiliza un mensaje no vacio (`Parser
  PowerShell 5.1: PASS.`) cuando no existen errores de sintaxis.
- El emisor comun de resultados JSON admite mensajes vacios y los reemplaza por
  un texto seguro, evitando que un error secundario oculte el diagnostico real.

## Prevencion de regresiones

- Se agrego una prueba portable que exige tanto `AllowEmptyString` como el
  mensaje de exito no vacio.
- Se conserva el precheck nativo antes de crear el entorno virtual y el analisis
  de todos los scripts NTP antes de solicitar UAC.

## Alcance

- Motor: `2.1.3`.
- Schema causal: `2.0.0` sin cambios.
- Sin cambios en captura, libro de ordenes, writer, `book_apply` o watchdog del
  event loop.
