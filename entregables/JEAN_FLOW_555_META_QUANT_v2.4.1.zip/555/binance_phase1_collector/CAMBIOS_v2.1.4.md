# Cambios JEAN_FLOW 2.1.4 - verificacion NTP sin falso acceso denegado

## Correccion critica

- `w32tm /query /source` puede devolver `0x80070005` cuando el preflight se
  ejecuta como usuario normal, aunque `w32tm /query /status /verbose` funcione
  y ya incluya la fuente efectiva en `Source` u `Origen`.
- El gate ahora acepta esa fuente de `status /verbose` exclusivamente cuando la
  consulta redundante falla por acceso denegado. Otros errores no activan el
  fallback.
- La fuente obtenida debe seguir siendo no local, corresponder a un peer NTP
  configurado y coexistir con al menos un peer activo.
- El acceso denegado queda registrado en el JSON como evidencia; no se oculta y
  la aplicacion Python sigue ejecutandose sin privilegios de administrador.

## Gate conservado

- El fallback no produce `PASS` por si solo. La certificacion todavia exige
  todas las muestras solicitadas y `p95_abs_offset_ms <= 50` mediante
  `stripchart` contra la referencia diagnostica.
- Un reloj que aun no converge devuelve `OFFSET_OUT_OF_RANGE`; no se desactiva
  ni relaja el gate.
- Se registran ademas el offset de fase, leap indicator, stratum y ultimo error
  de sincronizacion cuando Windows los publica.

## Prevencion de regresiones

- Se agregaron fixtures nativos PowerShell 5.1 para salidas en espanol e ingles,
  prioridad de la consulta directa, CMOS invalido, estado sin fuente y error no
  relacionado con permisos.
- `Test-W32Time.ps1` y `Configure-W32Time.ps1` reutilizan el mismo resolvedor de
  fuente para evitar reglas divergentes.

## Alcance

- Motor: `2.1.4`.
- Schema causal: `2.0.0` sin cambios.
- Sin cambios en captura, libro de ordenes, writer, `book_apply` o watchdog del
  event loop.
