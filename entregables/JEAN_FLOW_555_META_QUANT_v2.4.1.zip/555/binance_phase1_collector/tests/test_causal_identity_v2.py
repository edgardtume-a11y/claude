from __future__ import annotations

import argparse
import asyncio
import csv
from pathlib import Path

import pytest

from binance_collector import dual_main
from binance_collector.collector import (
    BinanceCollector,
    PipelineBackpressure,
    RawQueueBudget,
)
from binance_collector.config import Settings
from binance_collector.identity import CaptureSession, IngestSequencer
from binance_collector.metrics import Metrics
from binance_collector.models import (
    CSV_FIELDS,
    DepthSnapshot,
    DiffDepthEvent,
    RawEnvelope,
)
from binance_collector.normalize import (
    EventSequencer,
    delta_batch,
    partial_depth_batch,
    snapshot_batch,
    status_batch,
)
from binance_collector.protocol import ProtocolError, decode_combined
from binance_collector.reconstruct import ReplayError, reconstruct
from binance_collector.writer import CsvJournalWriter


TEST_SESSION = "0123456789abcdef0123456789abcdef"


class _OneMessageSocket:
    def __init__(self, payload: bytes = b"payload") -> None:
        self.payload = payload
        self.calls = 0
        self.wait_forever = asyncio.Event()

    async def recv(self, *, decode: bool) -> bytes:
        assert decode is False
        self.calls += 1
        if self.calls == 1:
            return self.payload
        await self.wait_forever.wait()
        raise AssertionError("inalcanzable")


class _ClosableSocket:
    async def close(self) -> None:
        return None


def _writer(path: Path) -> CsvJournalWriter:
    return CsvJournalWriter(
        output_dir=path,
        queue_size=32,
        max_queued_rows=20_000,
        batch_rows=100,
        flush_interval_s=0.01,
        rotation_bytes=10_000_000,
        rotation_seconds=60,
        metrics=Metrics(),
    )


def _snapshot() -> DepthSnapshot:
    return DepthSnapshot(
        last_update_id=100,
        bids=(("100", "1"),),
        asks=(("101", "1"),),
        receive_utc_ns=1_786_428_000_100_000_000,
        receive_monotonic_ns=1_000,
        payload_bytes=100,
    )


def _delta(*, ingest_seq: int = 1) -> DiffDepthEvent:
    return DiffDepthEvent(
        connection_id="c1",
        event_time_ms=1_786_428_000_100,
        symbol="TUTUSDT",
        first_update_id=100,
        final_update_id=103,
        bids=(("100", "2"),),
        asks=(),
        receive_utc_ns=1_786_428_000_200_000_000,
        receive_monotonic_ns=2_000,
        payload_bytes=80,
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=ingest_seq,
        source_socket_id="c1:spot_combined",
    )


def _write_valid_book(path: Path) -> tuple[Path, str]:
    writer = _writer(path)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    assert writer.submit(
        snapshot_batch(_snapshot(), "TUTUSDT", "c1", 1, sequencer)
    )
    assert writer.submit(delta_batch(_delta(), 1, sequencer))
    assert writer.submit(
        status_batch(
            symbol="TUTUSDT",
            connection_id="c1",
            generation=1,
            status="SYNCED",
            sequence=103,
            sequencer=sequencer,
        )
    )
    writer.close()
    state = reconstruct(writer.finalized_files)
    assert state.valid is True
    return writer.finalized_files[0], state.canonical_hash()


@pytest.mark.asyncio
async def test_receivers_share_one_global_ingest_sequence(tmp_path: Path) -> None:
    capture = CaptureSession(TEST_SESSION, IngestSequencer())
    collector = BinanceCollector(
        Settings.for_market("usdm_futures", output_dir=tmp_path),
        capture_session=capture,
    )
    output: asyncio.Queue[RawEnvelope | object] = asyncio.Queue()
    budget = RawQueueBudget()
    public = _OneMessageSocket(b"public")
    market = _OneMessageSocket(b"market")
    tasks = (
        asyncio.create_task(
            collector._receiver(
                public,  # type: ignore[arg-type]
                "connection-1",
                "connection-1:usdm_public_depth",
                output,
                budget,
            )
        ),
        asyncio.create_task(
            collector._receiver(
                market,  # type: ignore[arg-type]
                "connection-1",
                "connection-1:usdm_market_trades",
                output,
                budget,
            )
        ),
    )
    try:
        received = [
            await asyncio.wait_for(output.get(), timeout=1),
            await asyncio.wait_for(output.get(), timeout=1),
        ]
        envelopes = [item for item in received if isinstance(item, RawEnvelope)]
        assert len(envelopes) == 2
        assert {event.ingest_seq for event in envelopes} == {1, 2}
        assert {event.capture_session_id for event in envelopes} == {TEST_SESSION}
        assert {event.source_socket_id for event in envelopes} == {
            "connection-1:usdm_public_depth",
            "connection-1:usdm_market_trades",
        }
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


@pytest.mark.asyncio
async def test_full_raw_queue_does_not_consume_ingest_sequence(
    tmp_path: Path,
) -> None:
    capture = CaptureSession(TEST_SESSION, IngestSequencer())
    collector = BinanceCollector(
        Settings(output_dir=tmp_path).validated(),
        capture_session=capture,
    )
    full: asyncio.Queue[RawEnvelope | object] = asyncio.Queue(maxsize=1)
    full.put_nowait(object())
    with pytest.raises(PipelineBackpressure, match="Cola raw"):
        await collector._receiver(
            _OneMessageSocket(),  # type: ignore[arg-type]
            "c1",
            "c1:spot_combined",
            full,
            RawQueueBudget(),
        )

    output: asyncio.Queue[RawEnvelope | object] = asyncio.Queue()
    task = asyncio.create_task(
        collector._receiver(
            _OneMessageSocket(),  # type: ignore[arg-type]
            "c2",
            "c2:spot_combined",
            output,
            RawQueueBudget(),
        )
    )
    try:
        envelope = await asyncio.wait_for(output.get(), timeout=1)
        assert isinstance(envelope, RawEnvelope)
        assert envelope.ingest_seq == 1
        assert envelope.capture_session_id == TEST_SESSION
        assert envelope.source_socket_id == "c2:spot_combined"
    finally:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_receiver_failure_is_reported_only_after_accepted_raw_is_drained(
    tmp_path: Path,
    fixture_dir: Path,
) -> None:
    capture = CaptureSession(TEST_SESSION, IngestSequencer())
    collector = BinanceCollector(
        Settings(output_dir=tmp_path, shutdown_timeout_s=1.0).validated(),
        capture_session=capture,
    )
    collector.writer.start()
    payload = (fixture_dir / "agg_trade.json").read_bytes()
    raw_queue: asyncio.Queue[RawEnvelope | object] = asyncio.Queue()
    raw_queue.put_nowait(
        RawEnvelope(
            connection_id="c1",
            payload=payload,
            receive_utc_ns=1_786_428_000_200_000_000,
            receive_monotonic_ns=2_000,
            payload_bytes=len(payload),
            raw_queue_size=0,
            capture_session_id=TEST_SESSION,
            ingest_seq=1,
            source_socket_id="c1:spot_combined",
        )
    )
    budget = RawQueueBudget(bytes_inflight=len(payload))
    book_queue = asyncio.Queue()
    trade_queue = asyncio.Queue()
    partial_queue = asyncio.Queue()

    async def failed_receiver() -> None:
        raise PipelineBackpressure("receiver dirigido")

    receiver_task = asyncio.create_task(failed_receiver(), name="receiver-0")
    dispatcher_task = asyncio.create_task(
        collector._dispatcher(
            raw_queue,
            budget,
            book_queue,
            trade_queue,
            partial_queue,
        ),
        name="dispatcher",
    )
    trade_task = asyncio.create_task(
        collector._trade_worker(trade_queue),
        name="trades",
    )
    with pytest.raises(PipelineBackpressure, match="receiver dirigido"):
        await collector._drain_connection(
            websockets=(_ClosableSocket(),),  # type: ignore[arg-type]
            receiver_tasks=(receiver_task,),
            dispatcher_task=dispatcher_task,
            worker_tasks=(trade_task,),
            raw_queue=raw_queue,
            book_queue=book_queue,
            trade_queue=trade_queue,
            partial_queue=partial_queue,
        )
    trade_task.cancel()
    await asyncio.gather(trade_task, return_exceptions=True)
    await asyncio.to_thread(collector.writer.close)
    text = collector.writer.finalized_files[0].read_text(encoding="utf-8")
    assert "AGG_TRADE" in text
    assert TEST_SESSION in text


def test_protocol_and_expanded_rows_preserve_identity(fixture_dir: Path) -> None:
    settings = Settings().validated()
    payload = (fixture_dir / "depth_partial.json").read_bytes()
    event = decode_combined(
        RawEnvelope(
            connection_id="c1",
            payload=payload,
            receive_utc_ns=1_786_428_000_200_000_000,
            receive_monotonic_ns=2_000,
            payload_bytes=len(payload),
            raw_queue_size=0,
            capture_session_id=TEST_SESSION,
            ingest_seq=37,
            source_socket_id="c1:spot_combined",
        ),
        symbol=settings.symbol,
        stream_names=settings.stream_names,
    )
    batch = partial_depth_batch(
        event,
        settings.symbol,
        EventSequencer(TEST_SESSION),
        "full_top20_replacement",
    )
    assert len(batch.rows) > 1
    for row in batch.rows:
        assert row["capture_session_id"] == TEST_SESSION
        assert row["ingest_seq"] == 37
        assert row["source_socket_id"] == "c1:spot_combined"


def test_futures_rejects_stream_on_wrong_causal_socket(fixture_dir: Path) -> None:
    settings = Settings.for_market("usdm_futures")
    payload = (fixture_dir / "usdm_agg_trade.json").read_bytes()
    with pytest.raises(ProtocolError, match="socket causal incorrecto"):
        decode_combined(
            RawEnvelope(
                connection_id="f1",
                payload=payload,
                receive_utc_ns=1,
                receive_monotonic_ns=1,
                payload_bytes=len(payload),
                raw_queue_size=0,
                capture_session_id=TEST_SESSION,
                ingest_seq=1,
                source_socket_id="f1:usdm_public_depth",
            ),
            symbol=settings.symbol,
            stream_names=settings.stream_names,
            market=settings.market,
        )


def test_v2_replay_rejects_missing_websocket_identity(tmp_path: Path) -> None:
    journal, _ = _write_valid_book(tmp_path)
    with journal.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        if row["record_type"] in {"L2_DELTA", "L2_DELTA_LEVEL"}:
            row["ingest_seq"] = ""
    with journal.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    with pytest.raises(ReplayError, match="Falta ingest_seq"):
        reconstruct([journal])


def test_v2_replay_rejects_wrong_socket_identity(tmp_path: Path) -> None:
    journal, _ = _write_valid_book(tmp_path)
    with journal.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        if row["record_type"] in {"L2_DELTA", "L2_DELTA_LEVEL"}:
            row["source_socket_id"] = "c1:usdm_public_depth"
    with journal.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    with pytest.raises(ReplayError, match="no coincide"):
        reconstruct([journal])


def test_legacy_schemas_are_rejected_in_certification_path(tmp_path: Path) -> None:
    """R4.3/[P15]: un CSV con schema 1.x esquivaba TODA la validación causal.

    Los esquemas legacy quedan fuera de SUPPORTED_SCHEMA_VERSIONS: el replay
    los rechaza de forma explícita en lugar de certificarlos sin identidad.
    """

    v2_journal, _expected_hash = _write_valid_book(tmp_path / "v2")
    with v2_journal.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    legacy_fields = [
        field
        for field in CSV_FIELDS
        if field
        not in {
            "capture_session_id",
            "ingest_seq",
            "source_socket_id",
            "exchange_transaction_time_ms",
        }
    ]
    legacy_dir = tmp_path / "legacy"
    legacy_dir.mkdir()
    legacy_journal = legacy_dir / "events-legacy.csv"
    with legacy_journal.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=legacy_fields)
        writer.writeheader()
        for row in rows:
            row["schema_version"] = "1.1.0"
            writer.writerow({field: row[field] for field in legacy_fields})
    with pytest.raises(ReplayError, match="Schema no soportado"):
        reconstruct([legacy_journal])


def test_reused_directory_rejects_multiple_capture_sessions(
    tmp_path: Path,
) -> None:
    first = _writer(tmp_path)
    first.start()
    first_sequencer = EventSequencer(TEST_SESSION)
    assert first.submit(
        snapshot_batch(_snapshot(), "TUTUSDT", "c1", 1, first_sequencer)
    )
    first.close()

    other_session = "fedcba9876543210fedcba9876543210"
    second = _writer(tmp_path)
    second.start()
    second_sequencer = EventSequencer(other_session)
    assert second.submit(
        snapshot_batch(_snapshot(), "TUTUSDT", "c2", 1, second_sequencer)
    )
    second.close()
    with pytest.raises(ReplayError, match="capture_session_id diferentes"):
        reconstruct((*first.finalized_files, *second.finalized_files))


@pytest.mark.asyncio
async def test_dual_collectors_share_exact_capture_session_object(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    sessions: list[CaptureSession] = []

    class FakeDashboardServer:
        url = "http://127.0.0.1:0/"
        port = 1

        def __init__(self, *_args, **_kwargs) -> None:
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *_exc_info) -> None:
            return None

        def set_identity(self, _identity) -> None:
            return None

        def health_payload(self):
            return {
                "operational_ready": True,
                "rejection_reasons": [],
            }

    class FakeCollector:
        def __init__(self, _settings: Settings, **kwargs) -> None:
            sessions.append(kwargs["capture_session"])

        async def run(self, stop: asyncio.Event) -> None:
            await stop.wait()

    monkeypatch.setattr(dual_main, "DashboardServer", FakeDashboardServer)
    monkeypatch.setattr(dual_main, "BinanceCollector", FakeCollector)
    monkeypatch.setattr(
        dual_main,
        "_capture_commitment",
        lambda _output, _collectors, **kwargs: {
            "capture_session_id": kwargs["capture_session_id"],
            "last_ingest_seq": 1,
            "markets": {"spot": {}, "usdm_futures": {}},
        },
    )
    await dual_main._run(
        argparse.Namespace(
            run_seconds=0.01,
            output_dir=tmp_path,
            symbol="TUTUSDT",
            dom_levels=20,
            dashboard_port=0,
            no_browser=True,
        )
    )
    assert len(sessions) == 2
    assert sessions[0] is sessions[1]
    assert sessions[0].capture_session_id
