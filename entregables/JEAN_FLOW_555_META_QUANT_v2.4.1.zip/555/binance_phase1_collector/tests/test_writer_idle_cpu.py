"""P0.2: el writer ocioso quemaba el 100 % de un core.

Contra v2.2.2, el primer test medía ~2 s de CPU en 2 s de reloj (timeout
congelado en 0.0 con la cola vacía). Debe consumir una fracción mínima.
"""

from __future__ import annotations

import time
from pathlib import Path

from binance_collector.identity import new_capture_session_id
from binance_collector.metrics import Metrics
from binance_collector.normalize import EventSequencer, capture_status_batch
from binance_collector.writer import CsvJournalWriter


def _writer(tmp_path: Path, **overrides: object) -> CsvJournalWriter:
    parameters: dict[str, object] = {
        "output_dir": tmp_path,
        "queue_size": 64,
        "max_queued_rows": 10_000,
        "batch_rows": 8,
        "flush_interval_s": 0.25,
        "rotation_bytes": 10_000_000,
        "rotation_seconds": 60,
        "metrics": Metrics(),
    }
    parameters.update(overrides)
    return CsvJournalWriter(**parameters)  # type: ignore[arg-type]


def test_idle_writer_does_not_busy_spin(tmp_path: Path) -> None:
    writer = _writer(tmp_path)
    writer.start()
    cpu_before = time.process_time()
    time.sleep(2.0)
    cpu_delta = time.process_time() - cpu_before
    writer.close()
    # Contra 2.2.2 este delta era ~2.0 s (un core entero); con el rearme del
    # temporizador queda en despertares de 0.25 s prácticamente gratis.
    assert cpu_delta < 0.2, f"writer ocioso consumió {cpu_delta:.3f}s de CPU"


def test_timed_flush_still_happens_with_pending_rows(tmp_path: Path) -> None:
    metrics = Metrics()
    writer = _writer(tmp_path, metrics=metrics, batch_rows=1_000_000)
    writer.start()
    sequencer = EventSequencer(new_capture_session_id())
    assert writer.submit(
        capture_status_batch(
            symbol="TUTUSDT",
            status="TEST",
            sequencer=sequencer,
            market="spot",
        )
    )
    deadline = time.monotonic() + 5.0
    flushed = 0
    while time.monotonic() < deadline:
        flushed = int(
            metrics.snapshot()["counters"].get("csv_flushes", 0)  # type: ignore[union-attr]
        )
        if flushed >= 1:
            break
        time.sleep(0.05)
    writer.close()
    assert flushed >= 1, "el flush temporizado no ocurrió con filas pendientes"
