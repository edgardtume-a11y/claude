"""P0.4: percentil nearest-rank, count_total/evicted y gates del auditor."""

from __future__ import annotations

import json
from pathlib import Path

from binance_collector.audit import EVENT_LOOP_P99_LIMIT_MS, audit_metrics_logs
from binance_collector.metrics import Metrics, _percentile


def test_percentile_nearest_rank_never_hides_the_outlier() -> None:
    """Con n=67 y un outlier de 50 ms, el estimador round((n-1)f) reportaba
    p99 = 0.1 (P0.4b); nearest-rank reporta 50."""

    values = [0.1] * 66 + [50.0]
    assert _percentile(values, 0.99) == 50.0
    assert _percentile([10.0, 20.0, 30.0, 40.0], 0.50) == 20.0
    assert _percentile([10.0, 20.0], 0.50) == 10.0
    assert _percentile([], 0.99) == 0.0


def test_metrics_expose_count_total_and_evicted() -> None:
    metrics = Metrics(latency_window=10)
    for value in range(15):
        metrics.observe("parse", float(value))
    summary = metrics.snapshot()["latency_ms"]["parse"]  # type: ignore[index]
    assert summary["count"] == 10
    assert summary["count_total"] == 15
    assert summary["evicted"] == 5


def _snapshot_document(
    timestamp: str, latency: dict[str, object], *, terminal: int
) -> str:
    payload = {
        "counters": {
            "rest_snapshots": 1,
            "book_syncs": 1,
            "depth_diff_messages": 10,
            "agg_trade_messages": 10,
            "terminal_metric_snapshots": terminal,
            "writer_gil_yields": 1,
        },
        "gauges": {
            "raw_queue_high_water": 2,
            "raw_queue_capacity": 100,
            "raw_bytes_high_water": 1_000,
            "raw_bytes_capacity": 10_000,
            "book_queue_high_water": 2,
            "trade_queue_high_water": 2,
            "partial_queue_high_water": 2,
            "route_queue_capacity": 100,
            "writer_queue_high_water": 2,
            "writer_queue_capacity": 100,
            "writer_rows_high_water": 100,
            "writer_rows_capacity": 1_000,
        },
        "latency_ms": latency,
    }
    document = {
        "timestamp": timestamp,
        "level": "INFO",
        "logger": "binance_collector",
        "message": "metrics market=spot " + json.dumps(payload, separators=(",", ":")),
    }
    return json.dumps(document)


def _metrics_line(path: Path, latency: dict[str, object]) -> None:
    path.write_text(
        _snapshot_document("2026-08-13T00:00:00+00:00", latency, terminal=1)
        + "\n",
        encoding="utf-8",
    )


def _healthy_latency() -> dict[str, object]:
    return {
        "parse": {"count": 200, "count_total": 200, "evicted": 0, "p99": 0.3, "max": 0.5},
        "book_apply": {"count": 200, "count_total": 200, "evicted": 0, "p99": 0.4, "max": 0.6},
        "book_pipeline_total": {"count": 200, "count_total": 200, "evicted": 0, "p99": 0.5, "max": 0.9},
        "event_loop_lag": {"count": 200, "count_total": 200, "evicted": 0, "p99": 1.2, "max": 2.0},
        "writer_cooperative_yield": {"count": 200, "count_total": 200, "evicted": 0, "p99": 0.6, "max": 0.9},
    }


def test_eviction_in_a_required_metric_fails_certification(tmp_path: Path) -> None:
    path = tmp_path / "metrics.jsonl"
    _metrics_line(path, _healthy_latency())
    report = audit_metrics_logs([path], required_markets=("spot",))
    assert report["certification"] == "PASS"

    latency = _healthy_latency()
    latency["parse"] = {
        "count": 10_000,
        "count_total": 50_000,
        "evicted": 40_000,
        "p99": 0.3,
        "max": 0.5,
    }
    _metrics_line(path, latency)
    degraded = audit_metrics_logs([path], required_markets=("spot",))
    assert degraded["certification"] == "FAIL"
    checks = degraded["markets"]["spot"]["eviction_checks"]  # type: ignore[index]
    assert checks["parse_p99"]["pass"] is False
    assert checks["parse_p99"]["max_evicted"] == 40_000


def test_writer_yield_small_sample_uses_max_fallback(tmp_path: Path) -> None:
    """P0.4b: con n<100 el p99 puede ocultar el outlier; se evalúa el MAX."""

    path = tmp_path / "metrics.jsonl"
    latency = _healthy_latency()
    latency["writer_cooperative_yield"] = {
        "count": 67,
        "count_total": 67,
        "evicted": 0,
        "p99": 0.1,
        "max": 50.0,
    }
    _metrics_line(path, latency)
    report = audit_metrics_logs([path], required_markets=("spot",))
    threshold = report["markets"]["spot"]["thresholds"]["writer_yield_p99"]  # type: ignore[index]
    assert threshold["basis"] == "max_fallback_small_n"
    assert threshold["pass"] is False
    assert report["certification"] == "FAIL"

    latency["writer_cooperative_yield"]["max"] = 0.8
    _metrics_line(path, latency)
    healthy = audit_metrics_logs([path], required_markets=("spot",))
    threshold = healthy["markets"]["spot"]["thresholds"]["writer_yield_p99"]  # type: ignore[index]
    assert threshold["basis"] == "max_fallback_small_n"
    assert threshold["pass"] is True
    assert healthy["certification"] == "PASS"


def test_sliding_window_eviction_with_full_coverage_passes(
    tmp_path: Path,
) -> None:
    """[2.3.2] Evidencia de campo (sesión 45896a2c99aa, Windows real, 3.7 min
    SANOS): event_loop_lag desalojó 10 muestras de su ventana deslizante y el
    gate antiguo (evicted == 0) condenaba la sesión; un soak certificable de
    2 h desaloja SIEMPRE por construcción. La base worst-p99 sobre todas las
    ventanas cubre el soak completo sii Δcount_total <= count por snapshot."""

    path = tmp_path / "metrics.jsonl"
    first = _healthy_latency()
    second = _healthy_latency()
    second["event_loop_lag"] = {
        "count": 200,
        "count_total": 350,
        "evicted": 150,
        "p99": 1.5,
        "max": 2.4,
    }
    path.write_text(
        _snapshot_document("2026-08-13T00:00:00+00:00", first, terminal=0)
        + "\n"
        + _snapshot_document("2026-08-13T00:00:05+00:00", second, terminal=1)
        + "\n",
        encoding="utf-8",
    )
    report = audit_metrics_logs([path], required_markets=("spot",))
    assert report["certification"] == "PASS"
    checks = report["markets"]["spot"]["eviction_checks"]  # type: ignore[index]
    assert checks["event_loop_lag_p99"]["pass"] is True
    assert checks["event_loop_lag_p99"]["coverage_ok"] is True
    assert checks["event_loop_lag_p99"]["max_evicted"] == 150


def test_uncovered_arrivals_between_snapshots_fail(tmp_path: Path) -> None:
    """Si entre dos snapshots llegan más muestras de las que la ventana
    retiene, hubo muestras que NINGUNA ventana emitida vio: la truncación
    silenciosa sigue condenando la certificación."""

    path = tmp_path / "metrics.jsonl"
    first = _healthy_latency()
    second = _healthy_latency()
    second["event_loop_lag"] = {
        "count": 200,
        "count_total": 700,
        "evicted": 500,
        "p99": 1.5,
        "max": 2.4,
    }
    path.write_text(
        _snapshot_document("2026-08-13T00:00:00+00:00", first, terminal=0)
        + "\n"
        + _snapshot_document("2026-08-13T00:00:05+00:00", second, terminal=1)
        + "\n",
        encoding="utf-8",
    )
    report = audit_metrics_logs([path], required_markets=("spot",))
    assert report["certification"] == "FAIL"
    checks = report["markets"]["spot"]["eviction_checks"]  # type: ignore[index]
    assert checks["event_loop_lag_p99"]["pass"] is False
    assert checks["event_loop_lag_p99"]["coverage_ok"] is False
    errors = report["markets"]["spot"]["metric_errors"]  # type: ignore[index]
    assert any("cobertura de ventana" in error for error in errors)


def test_event_loop_limit_is_the_documented_windows_revision() -> None:
    """[2.3.4] Revisión EXPLÍCITA de criterio: 20 ms (grado servidor) →
    40 ms = 2 cuantos del temporizador de Windows de escritorio (15.625 ms)
    + margen de despacho. Quien vuelva a mover este número debe actualizar
    CERTIFICACION_FASE1.md, README.md y el CAMBIOS de su versión: este test
    obliga a que el cambio sea consciente, nunca silencioso."""

    assert EVENT_LOOP_P99_LIMIT_MS == 40.0


def test_windows_quantum_p99_certifies_with_revised_limit(
    tmp_path: Path,
) -> None:
    """[2.3.4] Evidencia de campo, sesión 99a0f0a51142 (modo 3, etapa 10 min,
    BTCUSDT, 2026-08-14): captura íntegra (0 overflows, aggTrade en ambos
    mercados, libros SYNCED) con event_loop_lag p99 clavado en 21-22 ms por
    el cuanto del temporizador de Windows, único gate FAIL con el límite
    antiguo de 20 ms. Con la revisión documentada (40 ms) esa sesión sana
    certifica; un atasco real (p99 de 100 ms) sigue condenado."""

    path = tmp_path / "metrics.jsonl"
    latency = _healthy_latency()
    latency["event_loop_lag"] = {
        "count": 10_000,
        "count_total": 10_000,
        "evicted": 0,
        "p99": 22.0,
        "max": 100.0,
    }
    _metrics_line(path, latency)
    report = audit_metrics_logs([path], required_markets=("spot",))
    assert report["certification"] == "PASS"
    threshold = report["markets"]["spot"]["thresholds"][  # type: ignore[index]
        "event_loop_lag_p99"
    ]
    assert threshold["limit_ms"] == EVENT_LOOP_P99_LIMIT_MS
    assert threshold["pass"] is True

    stalled = _healthy_latency()
    stalled["event_loop_lag"] = {
        "count": 10_000,
        "count_total": 10_000,
        "evicted": 0,
        "p99": 100.0,
        "max": 250.0,
    }
    stalled_path = tmp_path / "metrics_stalled.jsonl"
    _metrics_line(stalled_path, stalled)
    stalled_report = audit_metrics_logs([stalled_path], required_markets=("spot",))
    assert stalled_report["certification"] == "FAIL"


def test_normal_mode_publishes_thresholds_without_enforcing(
    tmp_path: Path,
) -> None:
    """[2.3.2] Uso normal: los p99 se publican honestos pero un pico del host
    no convierte una captura íntegra en FAIL; la certificación (por defecto)
    sigue exigiendo los límites."""

    path = tmp_path / "metrics.jsonl"
    latency = _healthy_latency()
    # [2.3.4] p99 por ENCIMA del límite revisado de 40 ms (antes 20 ms; ver
    # EVENT_LOOP_P99_LIMIT_MS en audit.py): el caso sigue probando que la
    # certificación condena y el uso normal solo publica.
    latency["event_loop_lag"] = {
        "count": 200,
        "count_total": 200,
        "evicted": 0,
        "p99": 55.0,
        "max": 80.0,
    }
    _metrics_line(path, latency)
    certification = audit_metrics_logs([path], required_markets=("spot",))
    assert certification["certification"] == "FAIL"

    normal = audit_metrics_logs(
        [path], required_markets=("spot",), enforce_thresholds=False
    )
    assert normal["certification"] == "PASS"
    threshold = normal["markets"]["spot"]["thresholds"][  # type: ignore[index]
        "event_loop_lag_p99"
    ]
    assert threshold["worst_value_ms"] == 55.0
    assert threshold["required"] is False
