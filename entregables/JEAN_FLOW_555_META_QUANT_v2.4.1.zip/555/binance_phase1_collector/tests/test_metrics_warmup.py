"""[2.3.9] Exclusión de calentamiento explícita del gate de p99.

Evidencia de campo (sesión b977be885902, 10 min SANOS en Windows real): el
arranque dejó ~3 muestras de writer_yield de 9.5-13.7 ms en la ventana
deslizante; el estimador p99 devolvió esos picos hasta el segundo ~70 y el
gate (worst_p99 sobre TODAS las ventanas) vetó una captura cuyo estado
estacionario fue 2.8-3.2 ms. El gate certifica salud SOSTENIDA: el basis
pasa a worst_p99 sobre las ventanas posteriores al corte de calentamiento,
con AMBOS valores publicados siempre (nunca un cambio silencioso).
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from binance_collector.audit import METRICS_WARMUP_EXCLUSION_S, audit_metrics_logs


def _stamp(offset_s: int) -> str:
    minute, second = divmod(offset_s, 60)
    return f"2026-08-14T18:{50 + minute:02d}:{second:02d}.000000+00:00"


def _latency(writer_yield_p99: float) -> dict[str, object]:
    healthy = {"count": 200, "count_total": 200, "evicted": 0}
    return {
        "parse": {**healthy, "p99": 0.3, "max": 0.5},
        "book_apply": {**healthy, "p99": 0.4, "max": 0.6},
        "book_pipeline_total": {**healthy, "p99": 0.5, "max": 0.9},
        "event_loop_lag": {**healthy, "p99": 1.2, "max": 2.0},
        "writer_cooperative_yield": {
            **healthy,
            "p99": writer_yield_p99,
            "max": max(writer_yield_p99, 13.7),
        },
    }


def _document(timestamp: str, writer_yield_p99: float, *, terminal: int) -> str:
    payload = {
        "counters": {
            "rest_snapshots": 1,
            "book_syncs": 1,
            "depth_diff_messages": 10,
            "agg_trade_messages": 10,
            "terminal_metric_snapshots": terminal,
            "writer_gil_yields": 1,
        },
        "gauges": {
            "raw_queue_high_water": 2,
            "raw_queue_capacity": 100,
            "raw_bytes_high_water": 1_000,
            "raw_bytes_capacity": 10_000,
            "book_queue_high_water": 2,
            "trade_queue_high_water": 2,
            "partial_queue_high_water": 2,
            "route_queue_capacity": 100,
            "writer_queue_high_water": 2,
            "writer_queue_capacity": 100,
            "writer_rows_high_water": 100,
            "writer_rows_capacity": 1_000,
        },
        "latency_ms": _latency(writer_yield_p99),
    }
    document = {
        "timestamp": timestamp,
        "level": "INFO",
        "logger": "binance_collector",
        "message": "metrics market=spot " + json.dumps(payload, separators=(",", ":")),
    }
    return json.dumps(document)


def _write(path: Path, lines: list[str]) -> None:
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def test_startup_spike_excluded_certifies_steady_state(tmp_path: Path) -> None:
    """El patrón real de la sesión b977be885902: pico solo en el arranque."""

    path = tmp_path / "metrics.jsonl"
    _write(
        path,
        [
            _document(_stamp(0), 9.525, terminal=0),
            _document(_stamp(60), 9.525, terminal=0),
            _document(_stamp(180), 3.16, terminal=0),
            _document(_stamp(240), 3.16, terminal=1),
        ],
    )
    report = audit_metrics_logs([path], required_markets=("spot",))
    assert report["certification"] == "PASS"
    market = report["markets"]["spot"]  # type: ignore[index]
    gate = market["thresholds"]["writer_yield_p99"]
    assert gate["basis"] == "worst_p99_post_warmup"
    assert gate["worst_value_ms"] == 3.16
    # Honestidad: el valor CON calentamiento se publica al lado, siempre.
    assert gate["worst_value_ms_incl_warmup"] == 9.525
    assert gate["pass"] is True
    warmup = market["warmup_exclusion"]
    assert warmup["applied"] is True
    assert warmup["seconds"] == METRICS_WARMUP_EXCLUSION_S == 120.0
    assert warmup["windows_total"] == 4
    assert warmup["windows_excluded"] == 2
    assert warmup["windows_evaluated"] == 2
    assert warmup["reference_timestamp"] == "2026-08-14T18:50:00+00:00"
    assert market["worst_p99_ms_post_warmup"]["writer_cooperative_yield"] == 3.16
    assert (
        market["worst_p99_ms_across_windows"]["writer_cooperative_yield"] == 9.525
    )


def test_sustained_spike_still_fails_after_warmup(tmp_path: Path) -> None:
    """Un problema SOSTENIDO aparece también tras el corte: sigue vetando."""

    path = tmp_path / "metrics.jsonl"
    _write(
        path,
        [
            _document(_stamp(0), 9.525, terminal=0),
            _document(_stamp(180), 9.525, terminal=1),
        ],
    )
    report = audit_metrics_logs([path], required_markets=("spot",))
    assert report["certification"] == "FAIL"
    gate = report["markets"]["spot"]["thresholds"]["writer_yield_p99"]  # type: ignore[index]
    assert gate["basis"] == "worst_p99_post_warmup"
    assert gate["worst_value_ms"] == 9.525
    assert gate["pass"] is False


def test_log_shorter_than_warmup_evaluates_all_windows(tmp_path: Path) -> None:
    """Sin estado estacionario no hay exclusión: comportamiento 2.3.8."""

    path = tmp_path / "metrics.jsonl"
    _write(
        path,
        [
            _document(_stamp(0), 9.525, terminal=0),
            _document(_stamp(10), 3.16, terminal=1),
        ],
    )
    report = audit_metrics_logs([path], required_markets=("spot",))
    assert report["certification"] == "FAIL"
    market = report["markets"]["spot"]  # type: ignore[index]
    gate = market["thresholds"]["writer_yield_p99"]
    assert gate["basis"] == "worst_p99"
    assert gate["worst_value_ms"] == 9.525
    assert market["warmup_exclusion"]["applied"] is False
    assert market["warmup_exclusion"]["windows_evaluated"] == 0


def test_warmup_zero_disables_the_exclusion(tmp_path: Path) -> None:
    path = tmp_path / "metrics.jsonl"
    _write(
        path,
        [
            _document(_stamp(0), 9.525, terminal=0),
            _document(_stamp(240), 3.16, terminal=1),
        ],
    )
    report = audit_metrics_logs(
        [path], required_markets=("spot",), warmup_exclusion_s=0.0
    )
    assert report["certification"] == "FAIL"
    gate = report["markets"]["spot"]["thresholds"]["writer_yield_p99"]  # type: ignore[index]
    assert gate["basis"] == "worst_p99"
    assert gate["worst_value_ms"] == 9.525


def test_unparseable_timestamp_is_evaluated_not_excluded(tmp_path: Path) -> None:
    """Camino conservador: sin timestamp interpretable la ventana SIEMPRE
    entra al gate — nadie puede esconder un pico rompiendo el timestamp."""

    path = tmp_path / "metrics.jsonl"
    spike = json.loads(_document(_stamp(0), 9.525, terminal=0))
    spike["timestamp"] = "esto-no-es-una-fecha"
    _write(
        path,
        [
            _document(_stamp(0), 3.16, terminal=0),
            json.dumps(spike),
            _document(_stamp(240), 3.16, terminal=1),
        ],
    )
    report = audit_metrics_logs([path], required_markets=("spot",))
    assert report["certification"] == "FAIL"
    gate = report["markets"]["spot"]["thresholds"]["writer_yield_p99"]  # type: ignore[index]
    assert gate["worst_value_ms"] == 9.525


def test_invalid_warmup_seconds_is_rejected(tmp_path: Path) -> None:
    path = tmp_path / "metrics.jsonl"
    _write(path, [_document(_stamp(0), 3.16, terminal=1)])
    with pytest.raises(ValueError):
        audit_metrics_logs([path], warmup_exclusion_s=-1.0)
    with pytest.raises(ValueError):
        audit_metrics_logs([path], warmup_exclusion_s=float("nan"))
