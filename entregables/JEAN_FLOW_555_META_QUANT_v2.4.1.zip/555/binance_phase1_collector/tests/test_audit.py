from __future__ import annotations

import json
from pathlib import Path

from binance_collector.audit import audit_journal, audit_metrics_logs
from binance_collector.metrics import Metrics
from binance_collector.models import DepthSnapshot, DiffDepthEvent
from binance_collector.normalize import (
    EventSequencer,
    delta_batch,
    snapshot_batch,
    status_batch,
)
from binance_collector.writer import CsvJournalWriter

TEST_SESSION = "test-capture-session-v2"


def _writer(path: Path) -> CsvJournalWriter:
    return CsvJournalWriter(
        output_dir=path,
        queue_size=16,
        max_queued_rows=1_000,
        batch_rows=100,
        flush_interval_s=0.01,
        rotation_bytes=10_000_000,
        rotation_seconds=60,
        metrics=Metrics(),
    )


def test_journal_audit_counts_events_not_expanded_level_rows(tmp_path: Path) -> None:
    snapshot = DepthSnapshot(
        last_update_id=100,
        bids=(("99", "2"), ("98", "3")),
        asks=(("101", "4"), ("102", "5")),
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=100,
    )
    delta = DiffDepthEvent(
        connection_id="c1",
        event_time_ms=1,
        symbol="TUTUSDT",
        first_update_id=100,
        final_update_id=101,
        bids=(("99", "7"),),
        asks=(),
        receive_utc_ns=2_000_000,
        receive_monotonic_ns=2,
        payload_bytes=50,
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=1,
        source_socket_id="c1:spot_combined",
    )
    writer = _writer(tmp_path)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    assert writer.submit(snapshot_batch(snapshot, "TUTUSDT", "c1", 1, sequencer))
    assert writer.submit(delta_batch(delta, 1, sequencer))
    assert writer.submit(
        status_batch(
            symbol="TUTUSDT",
            connection_id="c1",
            generation=1,
            status="SYNCED",
            sequence=101,
            sequencer=sequencer,
        )
    )
    writer.close()

    report = audit_journal(writer.finalized_files)

    assert report["certification"]["journal_integrity"] == "PASS"  # type: ignore[index]
    assert report["events"] == {  # type: ignore[comparison-overlap]
        "BOOK_STATUS": 1,
        "L2_DELTA": 1,
        "L2_SNAPSHOT": 1,
    }
    assert report["replay"]["valid_live_state"] is True  # type: ignore[index]


def test_metrics_audit_uses_latest_window_and_explicit_thresholds(
    tmp_path: Path,
) -> None:
    path = tmp_path / "metrics.jsonl"
    document = {
        "timestamp": "2026-08-11T10:00:00+00:00",
        "level": "INFO",
        "logger": "binance_collector",
        "message": "metrics market=spot "
        + json.dumps(
            {
                "counters": {
                    "depth_applied_events": 20,
                    "terminal_metric_snapshots": 1,
                },
                "gauges": {
                    "raw_queue_high_water": 2,
                    "raw_queue_capacity": 100,
                    "raw_bytes_high_water": 1_000,
                    "raw_bytes_capacity": 10_000,
                    "book_queue_high_water": 2,
                    "trade_queue_high_water": 2,
                    "partial_queue_high_water": 2,
                    "route_queue_capacity": 100,
                    "writer_queue_high_water": 2,
                    "writer_queue_capacity": 100,
                    "writer_rows_high_water": 100,
                    "writer_rows_capacity": 1_000,
                },
                "latency_ms": {
                    "parse": {"count": 100, "p99": 0.3},
                    "book_apply": {"count": 100, "p99": 0.4},
                    "book_pipeline_total": {"count": 100, "p99": 0.5},
                    "event_loop_lag": {"count": 100, "p99": 1.2},
                },
            },
            separators=(",", ":"),
        ),
    }
    path.write_text(json.dumps(document) + "\n", encoding="utf-8")

    report = audit_metrics_logs([path])

    assert report["certification"] == "PASS"
    assert report["markets"]["spot"]["windows"] == 1  # type: ignore[index]
    assert report["markets"]["spot"]["thresholds"]["parse_p99"]["pass"] is True  # type: ignore[index]

    prefix = "metrics market=spot "
    payload = json.loads(document["message"].removeprefix(prefix))
    payload["gauges"]["raw_queue_high_water"] = payload["gauges"]["raw_queue_capacity"]
    document["message"] = prefix + json.dumps(payload, separators=(",", ":"))
    path.write_text(json.dumps(document) + "\n", encoding="utf-8")
    saturated = audit_metrics_logs([path])
    # P0.4d: high_water == capacity SIN overflow es un estado legal (una
    # ráfaga que llena la cola exactamente no invalida un soak); la pérdida
    # real la cuentan los contadores de overflow.
    assert saturated["certification"] == "PASS"
    boundary_check = saturated["markets"]["spot"]["capacity_checks"]["raw_queue"]  # type: ignore[index]
    assert boundary_check["pass"] is True
    assert boundary_check["overflows"] == 0

    payload["gauges"]["raw_queue_high_water"] = (
        payload["gauges"]["raw_queue_capacity"] + 1
    )
    document["message"] = prefix + json.dumps(payload, separators=(",", ":"))
    path.write_text(json.dumps(document) + "\n", encoding="utf-8")
    exceeded = audit_metrics_logs([path])
    assert exceeded["certification"] == "FAIL"
    assert (
        exceeded["markets"]["spot"]["capacity_checks"]["raw_queue"]["pass"]  # type: ignore[index]
        is False
    )

    payload["gauges"]["raw_queue_high_water"] = payload["gauges"][
        "raw_queue_capacity"
    ]
    payload["counters"]["raw_queue_overflows"] = 3
    document["message"] = prefix + json.dumps(payload, separators=(",", ":"))
    path.write_text(json.dumps(document) + "\n", encoding="utf-8")
    overflowed = audit_metrics_logs([path])
    assert overflowed["certification"] == "FAIL"
    assert (
        overflowed["markets"]["spot"]["capacity_checks"]["raw_queue"]["overflows"]  # type: ignore[index]
        == 3
    )


def test_metrics_audit_fails_on_backpressure_counter(tmp_path: Path) -> None:
    path = tmp_path / "metrics.jsonl"
    document = {
        "timestamp": "2026-08-11T10:00:00+00:00",
        "message": "metrics market=spot "
        + json.dumps(
            {
                "counters": {"writer_queue_overflows": 1},
                "gauges": {},
                "latency_ms": {},
            },
            separators=(",", ":"),
        ),
    }
    path.write_text(json.dumps(document) + "\n", encoding="utf-8")

    report = audit_metrics_logs([path])

    assert report["certification"] == "FAIL"
    assert report["markets"]["spot"]["failure_counters"] == {  # type: ignore[index]
        "writer_queue_overflows": 1
    }


def test_metrics_audit_gates_observed_writer_yield_p99(tmp_path: Path) -> None:
    path = tmp_path / "metrics.jsonl"
    latencies = {
        "parse": {"count": 100, "p99": 0.1},
        "book_apply": {"count": 100, "p99": 0.1},
        "book_pipeline_total": {"count": 100, "p99": 0.1},
        "event_loop_lag": {"count": 100, "p99": 0.1},
        "writer_cooperative_yield": {"count": 10, "p99": 6.0},
    }
    document = {
        "timestamp": "2026-08-13T10:00:00+00:00",
        "message": "metrics market=spot "
        + json.dumps(
            {
                "counters": {"writer_gil_yields": 10},
                "gauges": {},
                "latency_ms": latencies,
            },
            separators=(",", ":"),
        ),
    }
    path.write_text(json.dumps(document) + "\n", encoding="utf-8")
    report = audit_metrics_logs([path])
    threshold = report["markets"]["spot"]["thresholds"]["writer_yield_p99"]  # type: ignore[index]
    assert threshold["required"] is True
    assert threshold["pass"] is False

    latencies["writer_cooperative_yield"]["p99"] = 1.0
    document["message"] = "metrics market=spot " + json.dumps(
        {
            "counters": {"writer_gil_yields": 10},
            "gauges": {},
            "latency_ms": latencies,
        },
        separators=(",", ":"),
    )
    path.write_text(json.dumps(document) + "\n", encoding="utf-8")
    report = audit_metrics_logs([path])
    threshold = report["markets"]["spot"]["thresholds"]["writer_yield_p99"]  # type: ignore[index]
    assert threshold["pass"] is True


def test_metrics_audit_fails_on_worst_p99_not_only_latest(tmp_path: Path) -> None:
    path = tmp_path / "metrics.jsonl"

    def document(timestamp: str, parse_p99: float) -> dict[str, object]:
        return {
            "timestamp": timestamp,
            "message": "metrics market=spot "
            + json.dumps(
                {
                    "counters": {},
                    "gauges": {},
                    "latency_ms": {
                        "parse": {"count": 100, "p99": parse_p99},
                        "book_apply": {"count": 100, "p99": 0.2},
                        "book_pipeline_total": {"count": 100, "p99": 0.2},
                        "event_loop_lag": {"count": 100, "p99": 0.3},
                    },
                },
                separators=(",", ":"),
            ),
        }

    path.write_text(
        "\n".join(
            json.dumps(item)
            for item in (
                document("2026-08-11T10:00:00+00:00", 9.0),
                document("2026-08-11T10:00:05+00:00", 0.2),
            )
        )
        + "\n",
        encoding="utf-8",
    )

    report = audit_metrics_logs([path], parse_p99_limit_ms=5.0)

    threshold = report["markets"]["spot"]["thresholds"]["parse_p99"]  # type: ignore[index]
    assert report["certification"] == "FAIL"
    assert threshold["latest_value_ms"] == 0.2
    assert threshold["worst_value_ms"] == 9.0
    assert threshold["pass"] is False


def test_metrics_audit_requires_markets_and_real_activity(tmp_path: Path) -> None:
    path = tmp_path / "metrics.jsonl"
    document = {
        "timestamp": "2026-08-11T10:00:00+00:00",
        "message": "metrics market=spot "
        + json.dumps(
            {
                "counters": {
                    "rest_snapshots": 1,
                    "book_syncs": 1,
                    "depth_diff_messages": 10,
                    "agg_trade_messages": 0,
                },
                "gauges": {},
                "latency_ms": {},
            },
            separators=(",", ":"),
        ),
    }
    path.write_text(json.dumps(document) + "\n", encoding="utf-8")

    report = audit_metrics_logs(
        [path],
        required_markets=("spot", "usdm_futures"),
        require_activity=True,
    )

    assert report["certification"] == "FAIL"
    assert report["missing_markets"] == ["usdm_futures"]
    assert report["markets"]["spot"]["activity_pass"] is False  # type: ignore[index]


def test_metrics_audit_rejects_missing_pipeline_and_too_few_samples(
    tmp_path: Path,
) -> None:
    path = tmp_path / "metrics.jsonl"
    document = {
        "timestamp": "2026-08-11T10:00:00+00:00",
        "message": "metrics market=spot "
        + json.dumps(
            {
                "counters": {},
                "gauges": {},
                "latency_ms": {
                    "parse": {"count": 99, "p99": 0.1},
                    "book_apply": {"count": 100, "p99": 0.1},
                    "event_loop_lag": {"count": 100, "p99": 0.1},
                },
            },
            separators=(",", ":"),
        ),
    }
    path.write_text(json.dumps(document) + "\n", encoding="utf-8")
    report = audit_metrics_logs([path])
    thresholds = report["markets"]["spot"]["thresholds"]  # type: ignore[index]
    assert report["certification"] == "FAIL"
    assert thresholds["parse_p99"]["pass"] is False
    assert thresholds["book_pipeline_p99"]["present"] is False
    assert thresholds["book_pipeline_p99"]["pass"] is False
