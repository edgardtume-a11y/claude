from __future__ import annotations

from pathlib import Path

import pytest

# R9.4/T4: la suite leía ~25 variables de entorno sin aislarlas; un
# SNAPSHOT_LIMIT=100 ambiental hacía fallar 12 tests. Ninguna variable del
# entorno del desarrollador puede cambiar el resultado de la suite.
_ISOLATED_ENVIRONMENT_VARIABLES = (
    "BINANCE_MARKET",
    "BINANCE_SYMBOL",
    "BINANCE_WS_BASE_URL",
    "BINANCE_REST_BASE_URL",
    "BINANCE_FUTURES_WS_BASE_URL",
    "BINANCE_FUTURES_REST_BASE_URL",
    "OUTPUT_DIR",
    "SNAPSHOT_LIMIT",
    "SNAPSHOT_TIMEOUT_S",
    "SNAPSHOT_RETRIES",
    "SNAPSHOT_MIN_INTERVAL_S",
    "RAW_QUEUE_SIZE",
    "RAW_QUEUE_MAX_BYTES",
    "ROUTE_QUEUE_SIZE",
    "WRITER_QUEUE_SIZE",
    "WRITER_QUEUE_MAX_ROWS",
    "SYNC_BUFFER_SIZE",
    "SYNC_BUFFER_MAX_BYTES",
    "MAX_LEVELS_PER_SIDE",
    "WRITER_BATCH_ROWS",
    "WRITER_CHUNK_ROWS",
    "WRITER_YIELD_SLEEP_S",
    "FLUSH_INTERVAL_S",
    "FSYNC_INTERVAL_S",
    "ROTATION_BYTES",
    "ROTATION_SECONDS",
    "METRICS_INTERVAL_S",
    "EVENT_LOOP_PROBE_INTERVAL_S",
    "COOPERATIVE_YIELD_BUDGET_MS",
    "BOOK_APPLY_OFFLOAD_LEVELS",
    "SHUTDOWN_TIMEOUT_S",
    "RECONNECT_INITIAL_S",
    "RECONNECT_MAX_S",
    "JEAN_FLOW_ALLOW_ENDPOINT_OVERRIDE",
    "JEAN_FLOW_SOURCE_ROOT",
    "JEAN_FLOW_RUNTIME_PACKAGES",
    "JEAN_FLOW_RELEASE_MANIFEST_SHA256",
    "JEAN_FLOW_RUNTIME_INVENTORY_SHA256",
    # RUN_BINANCE_LIVE se conserva a propósito: es el opt-in explícito del
    # smoke live y borrarlo lo haría inejecutable.
)


@pytest.fixture(autouse=True)
def _isolated_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    for name in _ISOLATED_ENVIRONMENT_VARIABLES:
        monkeypatch.delenv(name, raising=False)


@pytest.fixture
def fixture_dir() -> Path:
    return Path(__file__).parent / "fixtures"
