from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import pytest

from binance_collector.audit import audit_causal_identity, audit_journal, main
from binance_collector.models import CSV_FIELDS


def _header(
    *,
    market: str,
    ingest_seq: int | str,
    local_event_id: int,
    record_type: str,
    session_id: str = "session-v2",
    schema_version: str = "2.0.0",
) -> dict[str, object]:
    connection_id = f"connection-{market}"
    source_socket_id = (
        f"{connection_id}:spot_combined"
        if market == "spot"
        else (
            f"{connection_id}:usdm_market_trades"
            if record_type == "AGG_TRADE"
            else f"{connection_id}:usdm_public_depth"
        )
    )
    channel = "aggTrade" if record_type == "AGG_TRADE" else "depth@100ms"
    row: dict[str, object] = {field_name: "" for field_name in CSV_FIELDS}
    row.update(
        {
            "schema_version": schema_version,
            "capture_session_id": session_id,
            "ingest_seq": ingest_seq,
            "source_socket_id": source_socket_id,
            "local_event_id": local_event_id,
            "row_index": 0,
            "record_type": record_type,
            "exchange": "binance",
            "market": market,
            "symbol": "TUTUSDT",
            "channel": channel,
            "connection_id": connection_id,
            "exchange_event_time_ms": 1_786_428_000_000 + int(ingest_seq),
            "receive_time_utc_ns": 1_786_428_000_100_000_000 + int(ingest_seq),
            "receive_time_monotonic_ns": 10_000 + int(ingest_seq),
            "payload_bytes": 200,
            "raw_queue_size": 0,
        }
    )
    if record_type == "AGG_TRADE":
        row.update(
            {
                "exchange_trade_time_ms": 1_786_428_000_000 + int(ingest_seq),
                "price": "0.05000",
                "quantity": "100",
                "aggregate_trade_id": 1_000 + int(ingest_seq),
                "first_trade_id": 2_000 + int(ingest_seq),
                "last_trade_id": 2_000 + int(ingest_seq),
                "buyer_is_maker": False,
            }
        )
    else:
        row.update(
            {
                "book_generation": 1,
                "sequence_first": 10_000 + int(ingest_seq),
                "sequence_last": 10_000 + int(ingest_seq),
                "sequence_previous": 9_999 + int(ingest_seq),
                "level_count": 1,
                "note": "applied",
            }
        )
    return row


def _synthetic_header(
    *,
    market: str = "spot",
    session_id: str = "session-v2",
) -> dict[str, object]:
    row: dict[str, object] = {field_name: "" for field_name in CSV_FIELDS}
    row.update(
        {
            "schema_version": "2.0.0",
            "capture_session_id": session_id,
            "source_socket_id": "collector",
            "local_event_id": 1,
            "row_index": 0,
            "record_type": "CAPTURE_STATUS",
            "exchange": "binance",
            "market": market,
            "symbol": "TUTUSDT",
            "channel": "collector",
            "connection_id": "capture",
            "receive_time_utc_ns": 1,
            "receive_time_monotonic_ns": 1,
            "note": "STARTED",
        }
    )
    return row


def _write(path: Path, rows: list[dict[str, object]]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)
    return path


def test_identity_passes_contiguous_dual_and_identical_reference(tmp_path: Path) -> None:
    first = _header(
        market="spot",
        ingest_seq=1,
        local_event_id=1,
        record_type="L2_DELTA",
    )
    repeated = dict(first)
    repeated.update(
        {
            "local_event_id": 99,
            "book_generation": 2,
            "note": "buffered_after_gap",
        }
    )
    first_level = dict(first)
    first_level.update(
        {
            "row_index": 1,
            "record_type": "L2_DELTA_LEVEL",
            "side": "bid",
            "price": "0.04999",
            "quantity": "200",
        }
    )
    repeated_level = dict(first_level)
    repeated_level.update(
        {
            "local_event_id": 99,
            "book_generation": 2,
            "note": "buffered_after_gap",
        }
    )
    spot = _write(
        tmp_path / "spot" / "events-1.csv",
        [first, first_level, repeated, repeated_level],
    )
    futures = _write(
        tmp_path / "usdm_futures" / "events-1.csv",
        [
            _header(
                market="usdm_futures",
                ingest_seq=2,
                local_event_id=1,
                record_type="AGG_TRADE",
            )
        ],
    )

    report = audit_causal_identity([spot, futures])

    assert report["certification"] == "PASS"
    assert report["capture_session_id"] == "session-v2"
    assert report["markets"] == ["spot", "usdm_futures"]
    assert report["payload_references"] == 3
    assert report["unique_payloads"] == 2
    assert report["duplicate_identical_references"] == 1
    assert report["conflict_count"] == 0
    assert report["ingest_seq"] == {
        "min": 1,
        "max": 2,
        "unique_count": 2,
        "missing_count": 0,
        "missing_ranges": [],
        "missing_ranges_truncated": False,
    }


def test_identity_rejects_conflicting_reference_and_global_gap(tmp_path: Path) -> None:
    spot = _write(
        tmp_path / "spot" / "events-1.csv",
        [
            _header(
                market="spot",
                ingest_seq=1,
                local_event_id=1,
                record_type="L2_DELTA",
            )
        ],
    )
    futures = _write(
        tmp_path / "usdm_futures" / "events-1.csv",
        [
            _header(
                market="usdm_futures",
                ingest_seq=1,
                local_event_id=1,
                record_type="AGG_TRADE",
            ),
            _header(
                market="usdm_futures",
                ingest_seq=3,
                local_event_id=2,
                record_type="AGG_TRADE",
            ),
        ],
    )

    report = audit_causal_identity([spot, futures])

    assert report["certification"] == "FAIL"
    assert report["conflict_count"] == 1
    assert report["ingest_seq"]["missing_count"] == 1  # type: ignore[index]
    assert report["ingest_seq"]["missing_ranges"] == [  # type: ignore[index]
        {"first": 2, "last": 2, "count": 1}
    ]


def test_identity_rejects_same_seq_with_different_expanded_levels(
    tmp_path: Path,
) -> None:
    first = _header(
        market="spot",
        ingest_seq=1,
        local_event_id=1,
        record_type="L2_DELTA",
    )
    first_level = dict(first)
    first_level.update(
        {
            "row_index": 1,
            "record_type": "L2_DELTA_LEVEL",
            "side": "bid",
            "price": "0.04999",
            "quantity": "200",
        }
    )
    repeated = dict(first)
    repeated["local_event_id"] = 2
    conflicting_level = dict(first_level)
    conflicting_level.update(
        {
            "local_event_id": 2,
            "quantity": "201",
        }
    )
    spot = _write(
        tmp_path / "spot" / "events-1.csv",
        [first, first_level, repeated, conflicting_level],
    )
    futures = _write(
        tmp_path / "usdm_futures" / "events-1.csv",
        [
            _header(
                market="usdm_futures",
                ingest_seq=2,
                local_event_id=1,
                record_type="AGG_TRADE",
            )
        ],
    )

    report = audit_causal_identity([spot, futures])

    assert report["certification"] == "FAIL"
    assert report["conflict_count"] == 1


def test_identity_rejects_capture_whose_first_observed_seq_is_not_one(
    tmp_path: Path,
) -> None:
    spot = _write(
        tmp_path / "spot" / "events-1.csv",
        [
            _header(
                market="spot",
                ingest_seq=2,
                local_event_id=1,
                record_type="L2_DELTA",
            )
        ],
    )
    futures = _write(
        tmp_path / "usdm_futures" / "events-1.csv",
        [
            _header(
                market="usdm_futures",
                ingest_seq=3,
                local_event_id=1,
                record_type="AGG_TRADE",
            )
        ],
    )

    report = audit_causal_identity([spot, futures])

    assert report["certification"] == "FAIL"
    assert any("comenzar" in error for error in report["errors"])


def test_identity_rejects_legacy_multiple_sessions_and_nonpositive_seq(
    tmp_path: Path,
) -> None:
    spot = _write(
        tmp_path / "spot" / "events-1.csv",
        [
            _header(
                market="spot",
                ingest_seq=0,
                local_event_id=1,
                record_type="L2_DELTA",
                session_id="session-a",
                schema_version="1.1.0",
            )
        ],
    )
    futures = _write(
        tmp_path / "usdm_futures" / "events-1.csv",
        [
            _header(
                market="usdm_futures",
                ingest_seq=2,
                local_event_id=1,
                record_type="AGG_TRADE",
                session_id="session-b",
            )
        ],
    )

    report = audit_causal_identity([spot, futures])

    assert report["certification"] == "FAIL"
    assert report["schema_versions"] == ["1.1.0", "2.0.0"]
    assert report["capture_session_id"] is None
    assert report["invalid_ingest_references"] == 1


def test_identity_rejects_related_partial_and_cli_exits_two(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    spot = _write(
        tmp_path / "spot" / "events-1.csv",
        [
            _header(
                market="spot",
                ingest_seq=1,
                local_event_id=1,
                record_type="L2_DELTA",
            )
        ],
    )
    futures = _write(
        tmp_path / "usdm_futures" / "events-1.csv",
        [
            _header(
                market="usdm_futures",
                ingest_seq=2,
                local_event_id=1,
                record_type="AGG_TRADE",
            )
        ],
    )
    (spot.parent / "events-tail.csv.partial").write_text("incomplete", encoding="utf-8")
    monkeypatch.setattr(
        sys,
        "argv",
        ["binance-audit", "identity", str(spot), str(futures)],
    )

    with pytest.raises(SystemExit) as exit_info:
        main()

    assert exit_info.value.code == 2
    document = json.loads(capsys.readouterr().out)
    assert document["certification"] == "FAIL"
    assert document["partial_files"] == [str(spot.parent / "events-tail.csv.partial")]


def test_journal_report_exposes_v2_identity_fields(tmp_path: Path) -> None:
    path = _write(tmp_path / "spot" / "events-1.csv", [_synthetic_header()])

    report = audit_journal([path])

    assert report["causal_identity"] == {
        "schema_versions": ["2.0.0"],
        "capture_session_ids": ["session-v2"],
        "source_socket_ids": ["collector"],
        "ingest_seq_min": None,
        "ingest_seq_max": None,
        "unique_ingest_seq_count": 0,
        "invalid_causal_ingest_headers": 0,
    }
