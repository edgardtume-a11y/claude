"""[2.3.6] Regresión de fidelidad de métricas (evidencia: sesión 5ebb3efde620).

Tres hallazgos de campo en la certificación C: del 14-ago-2026:

1. Las duraciones medidas con ``time.monotonic_ns()`` salían clavadas en
   0.0/15.0/16.0 ms: en Windows + Python 3.12 ese reloj usa GetTickCount64
   (tic de 15.625 ms), por debajo de los gates de 5 ms. La única métrica con
   decimales reales (writer_cooperative_yield) era la única con
   ``perf_counter_ns``. Corrección: TODA duración local se mide con
   ``perf_counter_ns``; los campos de DATOS conservan ``monotonic_ns``.
2. "cobertura de ventana violada (snapshot 76: count=9304 > count_total=9303)"
   en 3 métricas del mismo shard: la foto copiaba los totales y recién al
   final leía el contenido de los deques vivos. Corrección: ``observe``
   incrementa el total ANTES de anexar y ``snapshot`` congela el contenido
   ANTES de copiar totales (invariante count <= count_total).
3. Los timers del event loop en Windows redondean al tic de 15.625 ms:
   ``fine_timer_resolution`` pide el temporizador de 1 ms (winmm) durante la
   captura y lo restaura SIEMPRE.

Estas pruebas fijan las tres correcciones sin tocar ningún umbral.
"""

from __future__ import annotations

import re
import threading
import time
from collections import deque
from pathlib import Path

from binance_collector import latency
from binance_collector.metrics import Metrics

_SRC = Path(latency.__file__).resolve().parent


def _lineas_con_monotonic(nombre: str) -> list[str]:
    texto = (_SRC / nombre).read_text(encoding="utf-8")
    return [
        linea.strip()
        for linea in texto.splitlines()
        if "time.monotonic_ns()" in linea
    ]


def test_contrato_relojes_duraciones_vs_datos() -> None:
    # Duraciones locales -> perf_counter_ns. Los ÚNICOS monotonic_ns()
    # permitidos son los del dominio de DATOS (campos de fila/evento). Si
    # alguien reintroduce el reloj de tic grueso en una duración, o cambia el
    # reloj de los datos, este contrato revienta (cambio explícito, jamás
    # silencioso).
    permitidos = {
        "collector.py": ["receive_monotonic_ns = time.monotonic_ns()"],
        "writer.py": ["writer_start_monotonic_ns = time.monotonic_ns()"],
        "rest.py": [
            "started = time.monotonic_ns()",
            "receive_monotonic_ns = time.monotonic_ns()",
        ],
    }
    for nombre, esperadas in permitidos.items():
        assert _lineas_con_monotonic(nombre) == esperadas, nombre


def test_contrato_duraciones_gateadas_usan_perf_counter() -> None:
    metricas_locales = {
        "collector.py": [
            "parse",
            "partial_validation",
            "book_apply",
            "journal_build",
            "journal_enqueue",
            "dashboard_project",
            "book_pipeline_total",
        ],
        "writer.py": ["csv_write", "csv_flush", "csv_fsync"],
        "rest.py": ["rest_snapshot_decode"],
    }
    for nombre, metricas in metricas_locales.items():
        texto = (_SRC / nombre).read_text(encoding="utf-8")
        assert "time.perf_counter_ns()" in texto, nombre
        for metrica in metricas:
            assert re.search(rf'observe\(\s*"{metrica}"', texto), (
                nombre,
                metrica,
            )


def test_observe_incrementa_total_antes_de_anexar() -> None:
    metrics = Metrics(latency_window=16)
    metrics.observe("x", 0.5)  # crea el shard del hilo actual
    shard = metrics._shard()

    ordenes: list[bool] = []

    class _DequeEspia(deque):
        def append(self, value: float) -> None:  # type: ignore[override]
            # El total debe contar YA la muestra que recién se anexa.
            ordenes.append(
                shard.observed_totals["x"] == len(self) + 1
            )
            super().append(value)

    espia = _DequeEspia(shard.observations["x"])
    shard.observations["x"] = espia
    for i in range(5):
        metrics.observe("x", float(i))
    assert ordenes == [True] * 5


def test_snapshot_count_nunca_supera_count_total() -> None:
    # Reproduce la condición del snapshot 76 de la sesión 5ebb3efde620:
    # un productor anexando sin pausa mientras otro hilo fotografía. El
    # invariante count <= count_total debe sostenerse en TODAS las fotos.
    metrics = Metrics(latency_window=64)
    alto = threading.Event()

    def productor() -> None:
        while not alto.is_set():
            metrics.observe("x", 0.25)

    hilo = threading.Thread(target=productor, daemon=True)
    hilo.start()
    try:
        limite = time.monotonic() + 1.0
        fotos = 0
        while time.monotonic() < limite:
            foto = metrics.snapshot()["latency_ms"].get("x")
            if foto is None:
                continue
            fotos += 1
            assert foto["count"] <= foto["count_total"], foto
            assert foto["evicted"] >= 0, foto
        assert fotos > 0
    finally:
        alto.set()
        hilo.join(timeout=5)


def test_snapshot_ventana_evicted_y_decimales() -> None:
    metrics = Metrics(latency_window=8)
    for i in range(20):
        metrics.observe("x", 0.123)
    foto = metrics.snapshot()["latency_ms"]["x"]
    assert foto["count"] == 8
    assert foto["count_total"] == 20
    assert foto["evicted"] == 12
    # La resolución sub-ms sobrevive el pipeline de percentiles (3 decimales).
    assert foto["p99"] == 0.123
    assert foto["max"] == 0.123


class _WinmmFalso:
    def __init__(self, begin_result: int = 0) -> None:
        self.begin_result = begin_result
        self.llamadas: list[tuple[str, int]] = []

    def timeBeginPeriod(self, valor: int) -> int:  # noqa: N802 (API winmm)
        self.llamadas.append(("begin", valor))
        return self.begin_result

    def timeEndPeriod(self, valor: int) -> int:  # noqa: N802 (API winmm)
        self.llamadas.append(("end", valor))
        return 0


class _Kernel32Falso:
    """Registra SetProcessInformation con los campos reales del struct."""

    def __init__(self, resultado: int = 1) -> None:
        self.resultado = resultado
        self.llamadas: list[tuple[int, int, int, int]] = []

    def GetCurrentProcess(self) -> int:  # noqa: N802 (API Win32)
        return -1

    def SetProcessInformation(  # noqa: N802 (API Win32)
        self, handle, clase, puntero, tamano
    ) -> int:
        estado = puntero._obj
        self.llamadas.append(
            (clase, estado.Version, estado.ControlMask, estado.StateMask)
        )
        return self.resultado


def test_fine_timer_sin_windows_es_inocuo() -> None:
    if latency._winmm() is None and latency._kernel32() is None:
        with latency.fine_timer_resolution() as report:
            assert report == {"timer_1ms": False, "foreground_qos": False}


def test_fine_timer_pide_y_restaura_1ms(monkeypatch) -> None:
    falso = _WinmmFalso()
    monkeypatch.setattr(latency, "_winmm", lambda: falso)
    monkeypatch.setattr(latency, "_kernel32", lambda: None)
    with latency.fine_timer_resolution() as report:
        assert report["timer_1ms"] is True
        assert falso.llamadas == [("begin", 1)]
    assert falso.llamadas == [("begin", 1), ("end", 1)]


def test_fine_timer_restaura_incluso_con_excepcion(monkeypatch) -> None:
    falso = _WinmmFalso()
    monkeypatch.setattr(latency, "_winmm", lambda: falso)
    monkeypatch.setattr(latency, "_kernel32", lambda: None)
    try:
        with latency.fine_timer_resolution():
            raise RuntimeError("falla simulada dentro de la captura")
    except RuntimeError:
        pass
    assert falso.llamadas == [("begin", 1), ("end", 1)]


def test_fine_timer_begin_fallido_no_llama_end(monkeypatch) -> None:
    falso = _WinmmFalso(begin_result=97)  # TIMERR_NOCANDO
    monkeypatch.setattr(latency, "_winmm", lambda: falso)
    monkeypatch.setattr(latency, "_kernel32", lambda: None)
    with latency.fine_timer_resolution() as report:
        assert report["timer_1ms"] is False
    assert falso.llamadas == [("begin", 1)]


def test_foreground_qos_exime_y_restaura(monkeypatch) -> None:
    # [2.3.7] Evidencia sesión dda44a52ff1f: con la ventana minimizada,
    # Windows 11 ignora timeBeginPeriod y degrada a E-cores salvo opt-out.
    # Al entrar: ControlMask = EXECUTION_SPEED|IGNORE_TIMER_RESOLUTION (0x5)
    # con StateMask=0 (exención). Al salir: ControlMask=0 (el sistema vuelve
    # a decidir).
    falso = _Kernel32Falso()
    monkeypatch.setattr(latency, "_winmm", lambda: None)
    monkeypatch.setattr(latency, "_kernel32", lambda: falso)
    with latency.fine_timer_resolution() as report:
        assert report["foreground_qos"] is True
        assert falso.llamadas == [
            (latency._PROCESS_POWER_THROTTLING, 1, 0x5, 0)
        ]
    assert falso.llamadas == [
        (latency._PROCESS_POWER_THROTTLING, 1, 0x5, 0),
        (latency._PROCESS_POWER_THROTTLING, 1, 0, 0),
    ]


def test_foreground_qos_fallido_no_intenta_restaurar(monkeypatch) -> None:
    falso = _Kernel32Falso(resultado=0)  # SetProcessInformation rechazado
    monkeypatch.setattr(latency, "_winmm", lambda: None)
    monkeypatch.setattr(latency, "_kernel32", lambda: falso)
    with latency.fine_timer_resolution() as report:
        assert report["foreground_qos"] is False
        # [2.3.9] En fallo se reporta el detalle (GetLastError en Windows
        # real; None/0 fuera de él o con kernel32 simulado) para poder
        # diagnosticar por qué el opt-out de EcoQoS no aplicó.
        assert "foreground_qos_error" in report
        assert report["foreground_qos_error"] in (None, 0)
    assert len(falso.llamadas) == 1


def test_contrato_motores_y_banco_usan_fine_timer() -> None:
    proyecto = _SRC.parents[1]
    fuentes = [
        _SRC / "dual_main.py",
        _SRC / "main.py",
        proyecto / "benchmarks" / "benchmark_latency.py",
    ]
    for fuente in fuentes:
        texto = fuente.read_text(encoding="utf-8")
        assert "fine_timer_resolution" in texto, fuente.name
        assert "with fine_timer_resolution()" in texto, fuente.name
