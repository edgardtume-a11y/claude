from __future__ import annotations

import asyncio

import pytest

from binance_collector.collector import BinanceCollector
from binance_collector.config import Settings
from binance_collector.identity import CaptureSession, IngestSequencer
from binance_collector.models import DepthSnapshot, DiffDepthEvent


TEST_SESSION = "test-capture-session-v2"


def _capture_session() -> CaptureSession:
    return CaptureSession(TEST_SESSION, IngestSequencer())


def _diff(first: int, final: int) -> DiffDepthEvent:
    return DiffDepthEvent(
        connection_id="c1",
        event_time_ms=1,
        symbol="TUTUSDT",
        first_update_id=first,
        final_update_id=final,
        bids=(),
        asks=(),
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=1,
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=first,
        source_socket_id="c1:spot_combined",
    )


def _snapshot(sequence: int) -> DepthSnapshot:
    return DepthSnapshot(
        last_update_id=sequence,
        bids=(("99", "1"),),
        asks=(("101", "1"),),
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=1,
    )


class FakeSnapshots:
    def __init__(self, sequences: list[int]) -> None:
        self.sequences = sequences
        self.calls = 0

    async def fetch(self) -> DepthSnapshot:
        await asyncio.sleep(0)
        sequence = self.sequences[min(self.calls, len(self.sequences) - 1)]
        self.calls += 1
        return _snapshot(sequence)


@pytest.mark.asyncio
async def test_sync_refetches_old_snapshot_then_bridges() -> None:
    collector = BinanceCollector(
        Settings(sync_buffer_size=16), capture_session=_capture_session()
    )
    queue: asyncio.Queue[DiffDepthEvent] = asyncio.Queue()
    queue.put_nowait(_diff(95, 100))
    queue.put_nowait(_diff(100, 103))
    snapshots = FakeSnapshots([90, 100])
    snapshot, retained, consumed = await collector._synchronize(  # type: ignore[arg-type]
        queue, snapshots, None
    )
    assert snapshots.calls == 2
    assert snapshot.last_update_id == 100
    assert consumed == 2
    assert [(event.first_update_id, event.final_update_id) for event in retained] == [
        (95, 100),
        (100, 103),
    ]


@pytest.mark.asyncio
async def test_bootstrap_gap_triggers_new_rest_snapshot() -> None:
    collector = BinanceCollector(
        Settings(sync_buffer_size=16), capture_session=_capture_session()
    )
    queue: asyncio.Queue[DiffDepthEvent] = asyncio.Queue()
    queue.put_nowait(_diff(102, 103))
    queue.put_nowait(_diff(103, 104))
    snapshots = FakeSnapshots([100, 103])
    snapshot, retained, consumed = await collector._synchronize(  # type: ignore[arg-type]
        queue, snapshots, None
    )
    assert snapshots.calls == 2
    assert snapshot.last_update_id == 103
    assert consumed == 2
    assert [(event.first_update_id, event.final_update_id) for event in retained] == [
        (102, 103),
        (103, 104),
    ]


@pytest.mark.asyncio
async def test_spot_bootstrap_accepts_exact_successor_without_refetch() -> None:
    collector = BinanceCollector(
        Settings(sync_buffer_size=16), capture_session=_capture_session()
    )
    queue: asyncio.Queue[DiffDepthEvent] = asyncio.Queue()
    queue.put_nowait(_diff(101, 103))
    snapshots = FakeSnapshots([100])

    snapshot, retained, consumed = await asyncio.wait_for(
        collector._synchronize(queue, snapshots, None),  # type: ignore[arg-type]
        timeout=1,
    )

    assert snapshots.calls == 1
    assert snapshot.last_update_id == 100
    assert consumed == 1
    assert [(event.first_update_id, event.final_update_id) for event in retained] == [
        (101, 103)
    ]
    assert collector.metrics.snapshot()["counters"].get("bootstrap_gaps", 0) == 0


@pytest.mark.asyncio
async def test_cancelling_sync_cancels_inflight_rest_snapshot() -> None:
    class NeverEndingSnapshot:
        def __init__(self) -> None:
            self.started = asyncio.Event()
            self.cancelled = asyncio.Event()

        async def fetch(self) -> DepthSnapshot:
            self.started.set()
            try:
                await asyncio.Future()
            finally:
                self.cancelled.set()

    collector = BinanceCollector(
        Settings(sync_buffer_size=16), capture_session=_capture_session()
    )
    queue: asyncio.Queue[DiffDepthEvent] = asyncio.Queue()
    queue.put_nowait(_diff(100, 101))
    snapshots = NeverEndingSnapshot()
    task = asyncio.create_task(
        collector._synchronize(queue, snapshots, None)  # type: ignore[arg-type]
    )
    await snapshots.started.wait()
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    assert snapshots.cancelled.is_set()
