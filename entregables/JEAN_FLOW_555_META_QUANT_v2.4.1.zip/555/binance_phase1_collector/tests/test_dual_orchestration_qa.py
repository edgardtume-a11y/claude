from __future__ import annotations

import argparse
import asyncio
import csv
import time
from contextlib import suppress
from decimal import Decimal

import pytest

from binance_collector import dual_main
from binance_collector.collector import BinanceCollector
from binance_collector.config import Settings
from binance_collector.dashboard import MarketStateHub
from binance_collector.fixed_point import parse_fixed
from binance_collector.identity import CaptureSession, IngestSequencer
from binance_collector.models import DepthSnapshot, DiffDepthEvent
from binance_collector.normalize import snapshot_batch, status_batch
from binance_collector.order_book import LocalOrderBook
from binance_collector.reconstruct import reconstruct

TEST_SESSION = "test-capture-session-v2"


def _capture_session() -> CaptureSession:
    return CaptureSession(TEST_SESSION, IngestSequencer())


class RecordingHub(MarketStateHub):
    def __init__(self) -> None:
        super().__init__(top_levels=20)
        self.book_publications = 0
        self.book_published = asyncio.Event()

    def publish_book(self, **kwargs) -> None:
        super().publish_book(**kwargs)
        self.book_publications += 1
        self.book_published.set()


def _bootstrap_snapshot(now_monotonic_ns: int) -> DepthSnapshot:
    return DepthSnapshot(
        last_update_id=100,
        bids=(("0.09863", "1"),),
        asks=(("0.09866", "1"),),
        receive_utc_ns=1_786_428_000_100_000_000,
        receive_monotonic_ns=now_monotonic_ns - 1,
        payload_bytes=100,
    )


def _futures_diff(
    *,
    first: int,
    final: int,
    previous: int,
    quantity: str,
    now_monotonic_ns: int,
) -> DiffDepthEvent:
    return DiffDepthEvent(
        connection_id="f1",
        event_time_ms=1_786_428_000_100,
        symbol="TUTUSDT",
        first_update_id=first,
        final_update_id=final,
        bids=(("0.09863", quantity),),
        asks=(),
        receive_utc_ns=1_786_428_000_200_000_000,
        receive_monotonic_ns=now_monotonic_ns,
        payload_bytes=80,
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=first,
        source_socket_id="f1:usdm_public_depth",
        previous_final_update_id=previous,
    )


def _spot_diff(
    *,
    first: int,
    final: int,
    quantity: str,
    now_monotonic_ns: int,
) -> DiffDepthEvent:
    return DiffDepthEvent(
        connection_id="s1",
        event_time_ms=1_786_428_000_100,
        symbol="TUTUSDT",
        first_update_id=first,
        final_update_id=final,
        bids=(("0.09863", quantity),),
        asks=(),
        receive_utc_ns=1_786_428_000_200_000_000,
        receive_monotonic_ns=now_monotonic_ns,
        payload_bytes=80,
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=first,
        source_socket_id="s1:spot_combined",
    )


@pytest.mark.asyncio
async def test_one_collector_failure_lets_the_sibling_drain(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path,
) -> None:
    started = {
        "spot": asyncio.Event(),
        "usdm_futures": asyncio.Event(),
    }
    sibling_drained = False
    sibling_cancelled = False

    class FakeDashboardServer:
        url = "http://127.0.0.1:0/"
        port = 1

        def __init__(self, *_args, **_kwargs) -> None:
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *_exc_info) -> None:
            return None

        def set_identity(self, _identity) -> None:
            return None

        def health_payload(self):
            return {
                "operational_ready": False,
                "rejection_reasons": ["test:not-ready"],
            }

    class FakeCollector:
        def __init__(self, settings: Settings, **_kwargs) -> None:
            self.market = settings.market

        async def run(self, stop: asyncio.Event) -> None:
            nonlocal sibling_cancelled, sibling_drained
            started[self.market].set()
            if self.market == "spot":
                await started["usdm_futures"].wait()
                raise RuntimeError("fallo dirigido Spot")
            try:
                await started["spot"].wait()
                await stop.wait()
                # Simula el último yield usado para drenar colas aceptadas.
                await asyncio.sleep(0)
                sibling_drained = True
            except asyncio.CancelledError:
                sibling_cancelled = True
                raise

    monkeypatch.setattr(dual_main, "DashboardServer", FakeDashboardServer)
    monkeypatch.setattr(dual_main, "BinanceCollector", FakeCollector)
    args = argparse.Namespace(
        run_seconds=None,
        output_dir=tmp_path,
        symbol="TUTUSDT",
        dom_levels=20,
        dashboard_port=0,
        no_browser=True,
    )

    with pytest.raises(ExceptionGroup, match="Falló la captura dual") as caught:
        await dual_main._run(args)

    assert len(caught.value.exceptions) == 1
    assert isinstance(caught.value.exceptions[0], RuntimeError)
    assert sibling_drained is True
    assert sibling_cancelled is False


@pytest.mark.asyncio
async def test_bootstrap_trailing_gap_never_publishes_a_synced_book(tmp_path) -> None:
    now = time.monotonic_ns()
    hub = RecordingHub()
    collector = BinanceCollector(
        Settings.for_market("usdm_futures", output_dir=tmp_path),
        dashboard_hub=hub,
        capture_session=_capture_session(),
    )
    collector._submit = lambda _batch: None
    snapshot = _bootstrap_snapshot(now)
    anchor = _futures_diff(
        first=99,
        final=100,
        previous=98,
        quantity="999",
        now_monotonic_ns=now,
    )
    trailing_gap = _futures_diff(
        first=101,
        final=102,
        previous=99,
        quantity="2",
        now_monotonic_ns=now + 1,
    )
    second_sync_started = asyncio.Event()
    synchronize_calls = 0

    async def fake_synchronize(_queue, _snapshots, _seed):
        nonlocal synchronize_calls
        synchronize_calls += 1
        if synchronize_calls == 1:
            return snapshot, [anchor, trailing_gap], 0
        second_sync_started.set()
        await asyncio.Event().wait()

    collector._synchronize = fake_synchronize
    task = asyncio.create_task(collector._book_worker(asyncio.Queue(), object(), "f1"))
    try:
        await asyncio.wait_for(second_sync_started.wait(), timeout=1)
        frame = hub.snapshot(now_monotonic_ns=now + 1)
        market = frame["markets"]["usdm_futures"]
        assert hub.book_publications == 0
        assert market["status"] == "SYNCING"
        assert market["book"] is None
    finally:
        task.cancel()
        with suppress(asyncio.CancelledError):
            await task


@pytest.mark.asyncio
async def test_valid_bootstrap_publishes_one_atomic_final_book(tmp_path) -> None:
    now = time.monotonic_ns()
    hub = RecordingHub()
    collector = BinanceCollector(
        Settings.for_market("usdm_futures", output_dir=tmp_path),
        dashboard_hub=hub,
        capture_session=_capture_session(),
    )
    collector._submit = lambda _batch: None
    snapshot = _bootstrap_snapshot(now)
    anchor = _futures_diff(
        first=99,
        final=100,
        previous=98,
        quantity="999",
        now_monotonic_ns=now,
    )
    live = _futures_diff(
        first=101,
        final=102,
        previous=100,
        quantity="2",
        now_monotonic_ns=now + 1,
    )

    async def fake_synchronize(_queue, _snapshots, _seed):
        return snapshot, [anchor, live], 0

    collector._synchronize = fake_synchronize
    task = asyncio.create_task(collector._book_worker(asyncio.Queue(), object(), "f1"))
    try:
        await asyncio.wait_for(hub.book_published.wait(), timeout=1)
        frame = hub.snapshot(now_monotonic_ns=now + 1)
        market = frame["markets"]["usdm_futures"]
        assert hub.book_publications == 1
        assert market["status"] == "SYNCED"
        assert market["book"]["sequence"] == 102
        assert market["book"]["bids"][0] == ("0.09863", "2")
    finally:
        task.cancel()
        with suppress(asyncio.CancelledError):
            await task


@pytest.mark.asyncio
async def test_spot_exact_successor_bootstrap_publishes_synced_book(tmp_path) -> None:
    now = time.monotonic_ns()
    hub = RecordingHub()
    collector = BinanceCollector(
        Settings.for_market("spot", output_dir=tmp_path),
        dashboard_hub=hub,
        capture_session=_capture_session(),
    )
    collector._submit = lambda _batch: None
    snapshot = _bootstrap_snapshot(now)
    successor = _spot_diff(
        first=101,
        final=102,
        quantity="2",
        now_monotonic_ns=now,
    )

    async def fake_synchronize(_queue, _snapshots, _seed):
        return snapshot, [successor], 0

    collector._synchronize = fake_synchronize
    task = asyncio.create_task(collector._book_worker(asyncio.Queue(), object(), "s1"))
    try:
        await asyncio.wait_for(hub.book_published.wait(), timeout=1)
        frame = hub.snapshot(now_monotonic_ns=now + 1)
        market = frame["markets"]["spot"]
        assert hub.book_publications == 1
        assert market["status"] == "SYNCED"
        assert market["book"]["sequence"] == 102
        assert market["book"]["bids"][0] == ("0.09863", "2")
    finally:
        task.cancel()
        with suppress(asyncio.CancelledError):
            await task


@pytest.mark.asyncio
async def test_core_futures_anchor_is_replayed_without_snapshot_rollback(
    tmp_path,
) -> None:
    settings = Settings.for_market("usdm_futures", output_dir=tmp_path)
    collector = BinanceCollector(settings, capture_session=_capture_session())
    collector.writer.start()
    snapshot = DepthSnapshot(
        last_update_id=100,
        bids=(("0.09863", "1"),),
        asks=(("0.09866", "1"),),
        receive_utc_ns=1_786_428_000_100_000_000,
        receive_monotonic_ns=1_000,
        payload_bytes=100,
    )
    anchor = DiffDepthEvent(
        connection_id="f1",
        event_time_ms=1_786_428_000_100,
        symbol="TUTUSDT",
        first_update_id=99,
        final_update_id=100,
        bids=(("0.09863", "999"),),
        asks=(),
        receive_utc_ns=1_786_428_000_200_000_000,
        receive_monotonic_ns=2_000,
        payload_bytes=80,
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=1,
        source_socket_id="f1:usdm_public_depth",
        previous_final_update_id=98,
    )
    book = LocalOrderBook(
        settings.max_levels_per_side,
        market=settings.market,
        snapshot_limit=settings.snapshot_limit,
    )
    book.load_snapshot(snapshot)

    collector._submit(
        snapshot_batch(
            snapshot,
            settings.symbol,
            anchor.connection_id,
            1,
            collector.sequencer,
            market=settings.market,
        )
    )
    await collector._apply_book_event(book, anchor, 1)
    collector._submit(
        status_batch(
            symbol=settings.symbol,
            connection_id=anchor.connection_id,
            generation=1,
            status="SYNCED",
            sequence=100,
            sequencer=collector.sequencer,
            market=settings.market,
        )
    )
    await asyncio.to_thread(collector.writer.close)

    assert book.bids[parse_fixed("0.09863")] == parse_fixed("1")
    state = reconstruct(collector.writer.finalized_files)
    assert state.valid is True
    assert state.last_update_id == 100
    assert state.bids[parse_fixed("0.09863")] == parse_fixed("1")
    with collector.writer.finalized_files[0].open(
        "r", encoding="utf-8", newline=""
    ) as handle:
        rows = list(csv.DictReader(handle))
    anchor_headers = [row for row in rows if row["record_type"] == "L2_DELTA"]
    assert len(anchor_headers) == 1
    assert anchor_headers[0]["note"] == "anchored"
