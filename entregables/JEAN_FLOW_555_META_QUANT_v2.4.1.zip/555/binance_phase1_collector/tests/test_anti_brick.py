"""FASE 1 anti-brick: [N1] overflow de dominio y R1.1 admisibilidad X2/X3.

Contra v2.2.2:
  · un snapshot con un nivel fuera de dominio mataba la tarea del libro,
    provocaba una reconexión y el siguiente snapshot repetía el error: bucle
    infinito que consumía 250 de peso REST por vuelta (ban 418 en ~72 s);
  · no existía ningún chequeo contra /exchangeInfo: el símbolo inadmisible
    se descubría a mitad de captura, nunca en el arranque.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import pytest

from binance_collector.admissibility import (
    SymbolNotAdmissible,
    evaluate_symbol_admissibility,
)
from binance_collector.collector import BinanceCollector, SymbolOutOfDomain
from binance_collector.config import Settings
from binance_collector.identity import CaptureSession, IngestSequencer
from binance_collector.models import DepthSnapshot, DiffDepthEvent

TEST_SESSION = "anti-brick-test-session"


def _exchange_info(
    *,
    symbol: str = "TUTUSDT",
    max_price: str = "1000.00000000",
    tick_size: str = "0.00000100",
    max_qty: str = "9000000.00000000",
    step_size: str = "0.00100000",
) -> dict[str, Any]:
    return {
        "symbols": [
            {
                "symbol": symbol,
                "status": "TRADING",
                "filters": [
                    {
                        "filterType": "PRICE_FILTER",
                        "maxPrice": max_price,
                        "minPrice": "0.00000100",
                        "tickSize": tick_size,
                    },
                    {
                        "filterType": "LOT_SIZE",
                        "maxQty": max_qty,
                        "minQty": "0.00100000",
                        "stepSize": step_size,
                    },
                ],
            }
        ]
    }


def test_admissible_symbol_reports_margin() -> None:
    report = evaluate_symbol_admissibility(
        _exchange_info(), symbol="TUTUSDT", market="spot"
    )
    assert report.margin > 10
    assert report.margin_warning is False


def test_symbol_with_oversized_max_qty_is_refused_at_startup() -> None:
    with pytest.raises(SymbolNotAdmissible) as caught:
        evaluate_symbol_admissibility(
            _exchange_info(max_qty="92233720369.00000000"),
            symbol="TUTUSDT",
            market="spot",
        )
    assert caught.value.code == "SYMBOL_OUT_OF_DOMAIN"
    message = str(caught.value)
    # F3/F4: el mensaje nombra símbolo, valor y límite.
    assert "TUTUSDT" in message
    assert "92233720369" in message
    assert "92233720368.54775807" in message


def test_symbol_with_sub_1e8_tick_size_is_refused() -> None:
    with pytest.raises(SymbolNotAdmissible) as caught:
        evaluate_symbol_admissibility(
            _exchange_info(tick_size="0.000000001"),
            symbol="TUTUSDT",
            market="spot",
        )
    assert caught.value.code == "SYMBOL_OUT_OF_DOMAIN"


def test_low_margin_symbol_warns_x3() -> None:
    report = evaluate_symbol_admissibility(
        _exchange_info(max_qty="10000000000.00000000"),
        symbol="TUTUSDT",
        market="spot",
    )
    assert report.margin < 10
    assert report.margin_warning is True


def test_unknown_symbol_is_refused_with_actionable_code() -> None:
    with pytest.raises(SymbolNotAdmissible) as caught:
        evaluate_symbol_admissibility(
            _exchange_info(symbol="BTCUSDT"), symbol="TUTUSDT", market="spot"
        )
    assert caught.value.code == "SYMBOL_UNKNOWN"


class _FakeSnapshotClient:
    """Doble con la API REST mínima; cuenta cada snapshot consumido."""

    def __init__(
        self,
        snapshot: DepthSnapshot,
        info: dict[str, Any],
        *,
        advance: bool = False,
    ) -> None:
        self._snapshot = snapshot
        self._info = info
        self._advance = advance
        self.fetch_calls = 0
        self.info_calls = 0

    async def fetch(self) -> DepthSnapshot:
        self.fetch_calls += 1
        if self._advance:
            from dataclasses import replace as dc_replace

            return dc_replace(
                self._snapshot,
                last_update_id=self._snapshot.last_update_id + self.fetch_calls - 1,
            )
        return self._snapshot

    async def fetch_exchange_info(self, *, exchange_info_path: str) -> dict[str, Any]:
        self.info_calls += 1
        return self._info

    async def fetch_server_time(self, *, server_time_path: str) -> dict[str, int]:
        return {
            "theta_hat_ns": 0,
            "delta_ns": 1_000_000,
            "server_time_ms": 1,
            "t1_utc_ns": 0,
            "t4_utc_ns": 1_000_000,
        }


def _collector(tmp_path: Path) -> BinanceCollector:
    return BinanceCollector(
        Settings.for_market("spot", output_dir=tmp_path / "journal"),
        capture_session=CaptureSession(TEST_SESSION, IngestSequencer()),
    )


def test_startup_gate_refuses_inadmissible_symbol_before_any_socket(
    tmp_path: Path,
) -> None:
    collector = _collector(tmp_path)
    client = _FakeSnapshotClient(
        DepthSnapshot(
            last_update_id=1,
            bids=(),
            asks=(),
            receive_utc_ns=1,
            receive_monotonic_ns=1,
            payload_bytes=1,
        ),
        _exchange_info(max_qty="92233720369.00000000"),
    )

    async def run() -> None:
        await collector._startup_gates(client, asyncio.Event())

    with pytest.raises(SymbolNotAdmissible):
        asyncio.run(run())
    # R1.1: exactamente UNA petición (exchangeInfo) y CERO snapshots.
    assert client.info_calls == 1
    assert client.fetch_calls == 0


def _diff(first: int, final: int) -> DiffDepthEvent:
    return DiffDepthEvent(
        connection_id="c1",
        event_time_ms=1,
        symbol="TUTUSDT",
        first_update_id=first,
        final_update_id=final,
        bids=(("1.0", "1"),),
        asks=(),
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=10,
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=first,
        source_socket_id="c1:spot_combined",
    )


def test_out_of_domain_snapshot_aborts_after_exactly_one_fetch(
    tmp_path: Path,
) -> None:
    """[N1]/R1.2: un snapshot inadmisible produce UNA petición REST y un
    código terminal accionable, no un bucle de reconexión."""

    collector = _collector(tmp_path)
    poisoned = DepthSnapshot(
        last_update_id=100,
        # Cantidad 1e11 > 2^63-1 a escala 1e8: FixedPointError determinista.
        bids=(("1.00000000", "100000000000"),),
        asks=(),
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=64,
    )
    client = _FakeSnapshotClient(poisoned, _exchange_info())

    async def run() -> None:
        queue: asyncio.Queue[DiffDepthEvent] = asyncio.Queue()
        await queue.put(_diff(101, 101))
        worker = asyncio.create_task(
            collector._book_worker(queue, client, "c1")  # type: ignore[arg-type]
        )
        await worker

    with pytest.raises(SymbolOutOfDomain) as caught:
        asyncio.run(run())
    assert client.fetch_calls == 1
    assert "SYMBOL_OUT_OF_DOMAIN" in str(caught.value)
    assert "TUTUSDT" in str(caught.value)
    collector.writer.close(finalize=False) if collector.writer._started else None


def test_transient_invalid_snapshot_resyncs_with_bounded_budget(
    tmp_path: Path,
) -> None:
    """Un snapshot cruzado (transitorio) reintenta acotado y aborta al agotar
    el presupuesto con SNAPSHOT_INVARIANT_PERSISTENT, nunca en bucle."""

    from binance_collector.collector import CaptureIncomplete

    collector = _collector(tmp_path)
    crossed = DepthSnapshot(
        last_update_id=100,
        bids=(("2.00000000", "1.00000000"),),
        asks=(("1.00000000", "1.00000000"),),
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=64,
    )
    client = _FakeSnapshotClient(crossed, _exchange_info())

    async def run() -> None:
        queue: asyncio.Queue[DiffDepthEvent] = asyncio.Queue()
        # Todos los diffs cubren el mismo rango que el snapshot enlaza, de
        # modo que cada iteración de resync ancla sin agotar la cola.
        for _ in range(20):
            await queue.put(_diff(101, 101))
        collector.writer.start()
        try:
            worker = asyncio.create_task(
                collector._book_worker(queue, client, "c1")  # type: ignore[arg-type]
            )
            await asyncio.wait_for(worker, timeout=30)
        finally:
            await asyncio.to_thread(collector.writer.close, finalize=False)

    with pytest.raises(CaptureIncomplete, match="SNAPSHOT_INVARIANT_PERSISTENT"):
        asyncio.run(run())
    # F2: presupuesto acotado — exactamente 3 snapshots, nunca un bucle.
    assert client.fetch_calls == 3
