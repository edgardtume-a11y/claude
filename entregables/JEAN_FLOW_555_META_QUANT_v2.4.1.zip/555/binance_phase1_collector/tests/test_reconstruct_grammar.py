"""X5/X6/R4.2: el replay ejerce EXACTAMENTE las invariantes de la captura.

Contra v2.2.2 (reconstruct sobre Decimal):
  · los seis strings divergentes eran aceptados por el replay y rechazados
    por el libro vivo (A_live ⊊ A_replay);
  · κ_live ('0.09865') ≠ κ_replay ('0.09865000'): los hashes vivo↔replay no
    podían compararse jamás;
  · un journal con ingest_seq 1→999999→999999 (payloads distintos) devolvía
    valid=True y deltas=3 ([P3]).
"""

from __future__ import annotations

import csv
from pathlib import Path

import pytest

from binance_collector.fixed_point import FixedPointError, parse_fixed
from binance_collector.identity import new_capture_session_id
from binance_collector.metrics import Metrics
from binance_collector.models import CSV_FIELDS, DepthSnapshot, DiffDepthEvent
from binance_collector.normalize import (
    EventSequencer,
    delta_batch,
    snapshot_batch,
    status_batch,
)
from binance_collector.order_book import LocalOrderBook
from binance_collector.reconstruct import ReplayError, ReplayState, reconstruct
from binance_collector.writer import CsvJournalWriter

TEST_SESSION = new_capture_session_id()

DIVERGENT_WIRE_VALUES = (
    "100000000000",
    "1.000000001",
    "0.000000005",
    "92233720369",
    "1E+2",
    "0.1e3",
)


@pytest.mark.parametrize("wire", DIVERGENT_WIRE_VALUES)
def test_live_and_replay_share_one_grammar(wire: str, tmp_path: Path) -> None:
    """X5: los seis casos hoy divergentes dan el MISMO veredicto en ambos
    caminos (rechazo)."""

    with pytest.raises(FixedPointError):
        parse_fixed(wire)

    journal = tmp_path / "events-1.csv"
    header = {field: "" for field in CSV_FIELDS}
    header.update(
        {
            "schema_version": "2.0.0",
            "capture_session_id": TEST_SESSION,
            "ingest_seq": "1",
            "source_socket_id": "c1:spot_combined",
            "local_event_id": "1",
            "row_index": "0",
            "record_type": "L2_SNAPSHOT",
            "exchange": "binance",
            "market": "spot",
            "symbol": "TUTUSDT",
            "channel": "depth@100ms",
            "connection_id": "c1",
            "book_generation": "1",
            "sequence_first": "100",
            "sequence_last": "100",
            "level_count": "1",
            "receive_time_utc_ns": "1",
            "receive_time_monotonic_ns": "1",
            "payload_bytes": "10",
        }
    )
    header["ingest_seq"] = ""
    header["source_socket_id"] = "rest:depth"
    level = dict(header)
    level.update(
        {
            "row_index": "1",
            "record_type": "L2_SNAPSHOT_LEVEL",
            "side": "bid",
            "price": wire,
            "quantity": "1.00000000",
        }
    )
    with journal.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows([header, level])
    with pytest.raises(ReplayError, match="gramática del libro vivo"):
        reconstruct([journal])


def _writer(tmp_path: Path) -> CsvJournalWriter:
    return CsvJournalWriter(
        output_dir=tmp_path,
        queue_size=64,
        max_queued_rows=10_000,
        batch_rows=8,
        flush_interval_s=0.05,
        rotation_bytes=10_000_000,
        rotation_seconds=60,
        metrics=Metrics(),
    )


def test_canonical_hash_live_equals_replay(tmp_path: Path) -> None:
    """X6: hash_live(B) == hash_replay(B) — el criterio que hace que el gate
    de reproducibilidad signifique algo por primera vez."""

    snapshot = DepthSnapshot(
        last_update_id=100,
        bids=(("0.09865000", "125.00000000"),),
        asks=(("0.09870000", "80.00000000"),),
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=64,
    )
    diff = DiffDepthEvent(
        connection_id="c1",
        event_time_ms=1,
        symbol="TUTUSDT",
        first_update_id=101,
        final_update_id=101,
        bids=(("0.09864000", "1.0"),),
        asks=(),
        receive_utc_ns=2,
        receive_monotonic_ns=2,
        payload_bytes=32,
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=1,
        source_socket_id="c1:spot_combined",
    )
    book = LocalOrderBook(1_000)
    book.load_snapshot(snapshot)
    book.apply(diff)

    writer = _writer(tmp_path)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    assert writer.submit(snapshot_batch(snapshot, "TUTUSDT", "c1", 1, sequencer))
    assert writer.submit(delta_batch(diff, 1, sequencer))
    assert writer.submit(
        status_batch(
            symbol="TUTUSDT",
            connection_id="c1",
            generation=1,
            status="SYNCED",
            sequence=101,
            sequencer=sequencer,
        )
    )
    writer.close()
    replayed = reconstruct(writer.finalized_files)
    assert replayed.valid is True

    live_state = ReplayState(
        bids=dict(book.bids),
        asks=dict(book.asks),
        generation=1,
        last_update_id=book.last_update_id,
        symbol="TUTUSDT",
        exchange="binance",
        market="spot",
    )
    assert live_state.canonical_hash() == replayed.canonical_hash()


def test_duplicate_ingest_seq_with_different_payload_fails_k1(
    tmp_path: Path,
) -> None:
    """R4.2: 1→999999→999999 con payloads distintos ya no valida."""

    from dataclasses import replace

    writer = _writer(tmp_path)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    snapshot = DepthSnapshot(
        last_update_id=100,
        bids=(("1.00000000", "1.00000000"),),
        asks=(),
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=16,
    )
    base = DiffDepthEvent(
        connection_id="c1",
        event_time_ms=1,
        symbol="TUTUSDT",
        first_update_id=101,
        final_update_id=101,
        bids=(("1.00000000", "2.00000000"),),
        asks=(),
        receive_utc_ns=2,
        receive_monotonic_ns=2,
        payload_bytes=32,
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=999_999,
        source_socket_id="c1:spot_combined",
    )
    conflicting = replace(
        base,
        first_update_id=102,
        final_update_id=102,
        receive_utc_ns=99,
        bids=(("1.00000000", "3.00000000"),),
    )
    assert writer.submit(snapshot_batch(snapshot, "TUTUSDT", "c1", 1, sequencer))
    assert writer.submit(delta_batch(base, 1, sequencer))
    assert writer.submit(delta_batch(conflicting, 1, sequencer))
    writer.close()
    with pytest.raises(ReplayError, match="K1"):
        reconstruct(writer.finalized_files)
