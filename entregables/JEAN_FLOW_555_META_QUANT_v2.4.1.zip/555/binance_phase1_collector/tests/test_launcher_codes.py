"""[W4]/P1.4/P1.1/P0.3: taxonomía de códigos del launcher y resiliencia.

Contra v2.2.2:
  · el postflight fallido emitía {"pass": false, "error_code": "PASS"};
  · toda respuesta HTTP truncada era READY_INVALID (terminal);
  · un directorio con corchetes hacía que la auditoría no encontrara CSV;
  · un os.replace en colisión mataba el heartbeat al primer intento.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from binance_collector import launcher as launcher_module
from binance_collector.audit import resolve_csv_patterns
from binance_collector.dual_main import _validate_launcher_heartbeat
from binance_collector.launcher import LauncherFailure, _strict_json_bytes
from binance_collector.runtime import RuntimeContractError, atomic_write_json


def test_postflight_never_reports_error_code_pass(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    incoherent = {"pass": True, "error_code": "PASS", "service": None}
    monkeypatch.setattr(
        launcher_module,
        "_run_clock_script",
        lambda *_args, **_kwargs: (0, incoherent),
    )
    with pytest.raises(LauncherFailure) as caught:
        launcher_module.clock_postflight(tmp_path, tmp_path)
    # [W4]/R6.3: el código nombra la CAUSA (evidencia inválida), nunca "PASS".
    assert caught.value.code == "CLOCK_GATE_EVIDENCE_INVALID"


def test_strict_json_code_belongs_to_the_caller() -> None:
    with pytest.raises(LauncherFailure) as ready:
        _strict_json_bytes(b"")
    assert ready.value.code == "READY_INVALID"
    with pytest.raises(LauncherFailure) as dashboard:
        _strict_json_bytes(b"garbage", code="DASHBOARD_RESPONSE_INVALID")
    assert dashboard.value.code == "DASHBOARD_RESPONSE_INVALID"
    with pytest.raises(LauncherFailure) as ntp:
        _strict_json_bytes(b"\xff\xfe\x00", code="NTP_OUTPUT_INVALID")
    assert ntp.value.code == "NTP_OUTPUT_INVALID"


def test_audit_finds_csv_inside_bracketed_directory(tmp_path: Path) -> None:
    """P1.1: 'D:\\proyectos[2026]\\555' rompía glob.glob tras una captura
    correcta; los directorios se aceptan directamente."""

    bracketed = tmp_path / "x[1]"
    bracketed.mkdir()
    journal = bracketed / "events-1.csv"
    journal.write_text("header\n", encoding="utf-8")
    resolved = resolve_csv_patterns([str(bracketed)])
    assert resolved == [journal]


def test_atomic_write_retries_windows_sharing_violation(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """P0.3: os.replace puede colisionar con el lector en Windows; con
    replace_retries el heartbeat sobrevive a fallos transitorios."""

    target = tmp_path / "HEARTBEAT.json"
    failures = {"remaining": 2}
    original_replace = os.replace

    def flaky_replace(source: object, destination: object) -> None:
        if failures["remaining"] > 0:
            failures["remaining"] -= 1
            raise PermissionError("sharing violation simulada")
        original_replace(source, destination)  # type: ignore[arg-type]

    monkeypatch.setattr(os, "replace", flaky_replace)
    monkeypatch.setattr(os, "name", "nt")
    atomic_write_json(
        target,
        {"ok": True},
        durable=False,
        replace_retries=5,
        replace_retry_delay_s=0.001,
    )
    assert failures["remaining"] == 0
    assert target.is_file()

    failures["remaining"] = 2
    with pytest.raises(RuntimeContractError):
        atomic_write_json(target, {"ok": True}, durable=False, replace_retries=0)


def test_heartbeat_validator_distinguishes_unreadable_from_lost(
    tmp_path: Path,
) -> None:
    """P0.3: lectura fallida (transitoria) != heartbeat de otra sesión
    (fatal). El monitor tolera la primera mientras la frescura no expire."""

    heartbeat = tmp_path / "HEARTBEAT.json"
    heartbeat.write_text("{corrupto", encoding="utf-8")
    with pytest.raises(RuntimeContractError) as unreadable:
        _validate_launcher_heartbeat(
            heartbeat,
            capture_session_id="session-a-0001",
            launcher_pid=1234,
        )
    assert unreadable.value.code == "PARENT_HEARTBEAT_UNREADABLE"

    import time as time_module

    now = time_module.time_ns()
    atomic_write_json(
        heartbeat,
        {
            "capture_session_id": "otra-sesion-9999",
            "launcher_pid": 1234,
            "started_utc_ns": now,
            "updated_utc_ns": now,
        },
    )
    with pytest.raises(RuntimeContractError) as lost:
        _validate_launcher_heartbeat(
            heartbeat,
            capture_session_id="session-a-0001",
            launcher_pid=1234,
        )
    assert lost.value.code == "PARENT_HEARTBEAT_LOST"


def test_clock_script_integrity_is_reverified_before_execution(
    tmp_path: Path,
) -> None:
    """[W3]/R6.1: un .ps1 sustituido tras el preflight ya no puede ejecutarse
    con -ExecutionPolicy Bypass: el hash se comprueba contra el manifest
    INMEDIATAMENTE antes de subprocess.run."""

    release_root = tmp_path
    project_root = release_root / "binance_phase1_collector"
    scripts = project_root / "tools" / "windows" / "time-sync"
    scripts.mkdir(parents=True)
    script = scripts / "Test-ClockSync.ps1"
    common = scripts / "TimeSync-Common.ps1"
    script.write_text("# ok\n", encoding="utf-8")
    common.write_text("# common\n", encoding="utf-8")
    from binance_collector.launcher import _sha256

    manifest = release_root / "RELEASE_MANIFEST.sha256"
    manifest.write_text(
        f"{_sha256(script)}  555/binance_phase1_collector/tools/windows/time-sync/Test-ClockSync.ps1\n"
        f"{_sha256(common)}  555/binance_phase1_collector/tools/windows/time-sync/TimeSync-Common.ps1\n",
        encoding="ascii",
    )
    launcher_module._verify_clock_script_integrity(project_root, script)

    script.write_text("# sustituido\n", encoding="utf-8")
    with pytest.raises(LauncherFailure) as caught:
        launcher_module._verify_clock_script_integrity(project_root, script)
    assert caught.value.code == "CLOCK_SCRIPT_INTEGRITY_FAILED"
