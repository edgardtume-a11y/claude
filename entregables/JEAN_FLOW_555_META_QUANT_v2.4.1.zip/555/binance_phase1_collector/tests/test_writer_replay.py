from __future__ import annotations

import asyncio
import csv
import time
from dataclasses import replace
from binance_collector.fixed_point import format_fixed, parse_fixed
from pathlib import Path

import pytest

from binance_collector.metrics import Metrics
from binance_collector.models import DepthSnapshot, DiffDepthEvent
from binance_collector.normalize import (
    EventSequencer,
    capture_status_batch,
    connection_batch,
    delta_batch,
    snapshot_batch,
    status_batch,
)
from binance_collector.reconstruct import ReplayError, reconstruct
from binance_collector.writer import CsvJournalWriter


TEST_SESSION = "test-capture-session-v2"


def _writer(path: Path, *, rotation_bytes: int = 1_000_000) -> CsvJournalWriter:
    return CsvJournalWriter(
        output_dir=path,
        queue_size=32,
        max_queued_rows=20_000,
        batch_rows=2,
        flush_interval_s=0.01,
        rotation_bytes=rotation_bytes,
        rotation_seconds=60,
        metrics=Metrics(),
    )


def _snapshot() -> DepthSnapshot:
    return DepthSnapshot(
        last_update_id=100,
        bids=(("100", "1"), ("99", "3")),
        asks=(("101", "2"), ("102", "4")),
        receive_utc_ns=time.time_ns(),
        receive_monotonic_ns=time.monotonic_ns(),
        payload_bytes=100,
    )


def _delta() -> DiffDepthEvent:
    return DiffDepthEvent(
        connection_id="c1",
        event_time_ms=int(time.time() * 1000),
        symbol="TUTUSDT",
        first_update_id=100,
        final_update_id=103,
        bids=(("100", "5"),),
        asks=(("101", "0"), ("103", "6")),
        receive_utc_ns=time.time_ns(),
        receive_monotonic_ns=time.monotonic_ns(),
        payload_bytes=100,
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=1,
        source_socket_id="c1:spot_combined",
    )


def test_csv_reconstructs_deterministic_book(tmp_path: Path) -> None:
    writer = _writer(tmp_path)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    assert writer.submit(snapshot_batch(_snapshot(), "TUTUSDT", "c1", 1, sequencer))
    assert writer.submit(delta_batch(_delta(), 1, sequencer))
    assert writer.submit(
        status_batch(
            symbol="TUTUSDT",
            connection_id="c1",
            generation=1,
            status="SYNCED",
            sequence=103,
            sequencer=sequencer,
        )
    )
    writer.close()
    state = reconstruct(writer.finalized_files)
    assert state.valid is True
    assert state.last_update_id == 103
    # X5/X6: el replay usa la MISMA aritmética de punto fijo y la MISMA forma
    # canónica (format_fixed) que el libro vivo.
    assert state.bids[parse_fixed("100")] == parse_fixed("5")
    assert format_fixed(max(state.bids)) == "100"
    assert format_fixed(min(state.asks)) == "102"
    assert (
        state.canonical_hash() == reconstruct(writer.finalized_files).canonical_hash()
    )


def test_rotation_never_splits_an_event_batch(tmp_path: Path) -> None:
    writer = _writer(tmp_path, rotation_bytes=1)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    assert writer.submit(snapshot_batch(_snapshot(), "TUTUSDT", "c1", 1, sequencer))
    assert writer.submit(delta_batch(_delta(), 1, sequencer))
    writer.close()
    assert len(writer.finalized_files) == 2
    for path in writer.finalized_files:
        with path.open("r", encoding="utf-8", newline="") as handle:
            event_ids = [row["local_event_id"] for row in csv.DictReader(handle)]
        assert len(set(event_ids)) == 1


def test_replay_rejects_synced_status_with_missing_delta(tmp_path: Path) -> None:
    writer = _writer(tmp_path)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    assert writer.submit(snapshot_batch(_snapshot(), "TUTUSDT", "c1", 1, sequencer))
    assert writer.submit(
        status_batch(
            symbol="TUTUSDT",
            connection_id="c1",
            generation=1,
            status="SYNCED",
            sequence=103,
            sequencer=sequencer,
        )
    )
    writer.close()
    with pytest.raises(ReplayError, match="no coincide"):
        reconstruct(writer.finalized_files)


def test_connection_close_and_incomplete_marker_invalidate_replay(
    tmp_path: Path,
) -> None:
    writer = _writer(tmp_path)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    assert writer.submit(snapshot_batch(_snapshot(), "TUTUSDT", "c1", 1, sequencer))
    assert writer.submit(
        status_batch(
            symbol="TUTUSDT",
            connection_id="c1",
            generation=1,
            status="SYNCED",
            sequence=100,
            sequencer=sequencer,
        )
    )
    assert writer.submit(
        connection_batch(
            symbol="TUTUSDT",
            connection_id="c1",
            state="CLOSED",
            sequencer=sequencer,
        )
    )
    assert writer.submit(
        capture_status_batch(
            symbol="TUTUSDT",
            status="INCOMPLETE:test",
            sequencer=sequencer,
        )
    )
    writer.close()
    assert reconstruct(writer.finalized_files).valid is False


def test_replay_rejects_corrupt_side(tmp_path: Path) -> None:
    writer = _writer(tmp_path)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    batch = snapshot_batch(_snapshot(), "TUTUSDT", "c1", 1, sequencer)
    batch.rows[1]["side"] = "unknown"
    assert writer.submit(batch)
    writer.close()
    with pytest.raises(ReplayError, match="Side inválido"):
        reconstruct(writer.finalized_files)


def test_replay_rejects_delta_from_connection_without_its_snapshot(
    tmp_path: Path,
) -> None:
    writer = _writer(tmp_path)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    assert writer.submit(snapshot_batch(_snapshot(), "TUTUSDT", "c1", 1, sequencer))
    assert writer.submit(
        status_batch(
            symbol="TUTUSDT",
            connection_id="c1",
            generation=1,
            status="SYNCED",
            sequence=100,
            sequencer=sequencer,
        )
    )
    assert writer.submit(
        delta_batch(
            replace(
                _delta(),
                connection_id="c2",
                source_socket_id="c2:spot_combined",
            ),
            1,
            sequencer,
        )
    )
    writer.close()
    with pytest.raises(ReplayError, match="conexión activa"):
        reconstruct(writer.finalized_files)


def test_replay_fails_closed_when_directory_contains_partial_tail(
    tmp_path: Path,
) -> None:
    writer = _writer(tmp_path)
    writer.start()
    assert writer.submit(
        snapshot_batch(_snapshot(), "TUTUSDT", "c1", 1, EventSequencer(TEST_SESSION))
    )
    writer.close()
    (tmp_path / "tail.csv.partial").write_text("incomplete", encoding="utf-8")
    with pytest.raises(ReplayError, match="segmentos parciales"):
        reconstruct(writer.finalized_files)


def test_replay_validates_stale_events_with_live_grammar(
    tmp_path: Path,
) -> None:
    """X7/[N5]: los eventos stale se persisten; ahora los valida el MISMO
    camino que la captura viva. Un stale sano pasa; uno con niveles
    duplicados tras canonicalizar ('100' vs '100.0') falla cerrado — el libro
    vivo jamás habría podido producirlo (A_live = A_replay)."""

    writer = _writer(tmp_path)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    valid_stale = replace(
        _delta(),
        first_update_id=99,
        final_update_id=100,
        bids=(("100", "2"),),
        asks=(),
    )
    assert writer.submit(snapshot_batch(_snapshot(), "TUTUSDT", "c1", 1, sequencer))
    assert writer.submit(delta_batch(valid_stale, 1, sequencer, "stale"))
    assert writer.submit(
        status_batch(
            symbol="TUTUSDT",
            connection_id="c1",
            generation=1,
            status="SYNCED",
            sequence=100,
            sequencer=sequencer,
        )
    )
    writer.close()
    state = reconstruct(writer.finalized_files)
    assert state.valid is True
    assert state.bids[parse_fixed("100")] == parse_fixed("1")

    corrupt_dir = tmp_path / "corrupt"
    corrupt_writer = _writer(corrupt_dir)
    corrupt_writer.start()
    corrupt_sequencer = EventSequencer(TEST_SESSION)
    duplicate_stale = replace(
        _delta(),
        first_update_id=99,
        final_update_id=100,
        bids=(("100", "2"), ("100.0", "3")),
        asks=(),
    )
    assert corrupt_writer.submit(
        snapshot_batch(_snapshot(), "TUTUSDT", "c1", 1, corrupt_sequencer)
    )
    assert corrupt_writer.submit(
        delta_batch(duplicate_stale, 1, corrupt_sequencer, "stale")
    )
    corrupt_writer.close()
    with pytest.raises(ReplayError, match="duplicado"):
        reconstruct(corrupt_writer.finalized_files)


def test_full_writer_can_append_incomplete_marker_before_finalize(
    tmp_path: Path,
) -> None:
    writer = CsvJournalWriter(
        output_dir=tmp_path,
        queue_size=1,
        max_queued_rows=1,
        batch_rows=2,
        flush_interval_s=0.01,
        rotation_bytes=1_000_000,
        rotation_seconds=60,
        metrics=Metrics(),
    )
    sequencer = EventSequencer(TEST_SESSION)
    first = connection_batch(
        symbol="TUTUSDT", connection_id="c1", state="OPEN", sequencer=sequencer
    )
    dropped = connection_batch(
        symbol="TUTUSDT", connection_id="c1", state="CLOSED", sequencer=sequencer
    )
    assert writer.submit(first)
    assert writer.submit(dropped) is False
    writer.start()
    writer.submit_blocking(
        capture_status_batch(
            symbol="TUTUSDT",
            status="INCOMPLETE:persistence_backpressure",
            sequencer=sequencer,
        )
    )
    writer.close()
    text = writer.finalized_files[0].read_text(encoding="utf-8")
    assert "INCOMPLETE:persistence_backpressure" in text


def test_unmarkable_incomplete_segment_stays_partial(tmp_path: Path) -> None:
    writer = _writer(tmp_path)
    writer.start()
    assert writer.submit(
        connection_batch(
            symbol="TUTUSDT",
            connection_id="c1",
            state="OPEN",
            sequencer=EventSequencer(TEST_SESSION),
        )
    )
    writer.close(finalize=False)
    assert writer.finalized_files == ()
    assert list(tmp_path.glob("*.csv.partial"))


@pytest.mark.asyncio
async def test_slow_disk_thread_does_not_block_event_loop(tmp_path: Path) -> None:
    writer = _writer(tmp_path)
    original = writer._write_pending

    def slow_write(batches):
        # P3.1b: el stall inyectado sube a 0.5 s para separar con claridad
        # "el event loop quedó bloqueado por el disco" (gap >= 0.5) del jitter
        # normal del scheduler de Windows (<0.35): el margen 0.2/0.18 anterior
        # era de 1.1x y fallaba solo.
        time.sleep(0.5)
        original(batches)

    writer._write_pending = slow_write  # type: ignore[method-assign]
    writer.start()
    assert writer.submit(
        snapshot_batch(_snapshot(), "TUTUSDT", "c1", 1, EventSequencer(TEST_SESSION))
    )
    ticks = 0
    longest_gap_s = 0.0
    previous_tick = time.monotonic()
    started = time.monotonic()
    while time.monotonic() - started < 0.75:
        await asyncio.sleep(0.01)
        current_tick = time.monotonic()
        longest_gap_s = max(longest_gap_s, current_tick - previous_tick)
        previous_tick = current_tick
        ticks += 1
    assert ticks >= 5
    assert longest_gap_s < 0.35
    await asyncio.to_thread(writer.close)
