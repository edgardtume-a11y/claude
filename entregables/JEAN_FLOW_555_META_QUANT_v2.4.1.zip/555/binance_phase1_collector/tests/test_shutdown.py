from __future__ import annotations

import asyncio
import time
from pathlib import Path

import pytest
from websockets.exceptions import ConnectionClosedOK
from websockets.frames import Close

from binance_collector.collector import (
    BinanceCollector,
    PipelineBackpressure,
    PersistenceBackpressure,
    RawQueueBudget,
)
from binance_collector.config import Settings
from binance_collector.identity import CaptureSession, IngestSequencer
from binance_collector.models import AggTradeEvent, DiffDepthEvent, PartialDepthEvent, RawEnvelope


TEST_SESSION = "test-capture-session-v2"


def _capture_session() -> CaptureSession:
    return CaptureSession(TEST_SESSION, IngestSequencer())


class FakeWebSocket:
    async def close(self) -> None:
        return None


@pytest.mark.asyncio
async def test_graceful_shutdown_drains_raw_and_trade_queues(
    tmp_path: Path,
    fixture_dir: Path,
) -> None:
    collector = BinanceCollector(
        Settings(output_dir=tmp_path, shutdown_timeout_s=1.0).validated(),
        capture_session=_capture_session(),
    )
    collector.writer.start()
    payload = (fixture_dir / "agg_trade.json").read_bytes()
    raw_queue: asyncio.Queue[RawEnvelope | object] = asyncio.Queue()
    raw_queue.put_nowait(
        RawEnvelope(
            connection_id="c1",
            payload=payload,
            receive_utc_ns=time.time_ns(),
            receive_monotonic_ns=time.monotonic_ns(),
            payload_bytes=len(payload),
            raw_queue_size=0,
            capture_session_id=TEST_SESSION,
            ingest_seq=1,
            source_socket_id="c1:spot_combined",
        )
    )
    budget = RawQueueBudget(bytes_inflight=len(payload))
    book_queue: asyncio.Queue[DiffDepthEvent] = asyncio.Queue()
    trade_queue: asyncio.Queue[AggTradeEvent] = asyncio.Queue()
    partial_queue: asyncio.Queue[PartialDepthEvent] = asyncio.Queue()
    receiver_task = asyncio.create_task(asyncio.sleep(0))
    dispatcher_task = asyncio.create_task(
        collector._dispatcher(
            raw_queue,
            budget,
            book_queue,
            trade_queue,
            partial_queue,
        )
    )
    trade_task = asyncio.create_task(collector._trade_worker(trade_queue))
    await collector._drain_connection(
        websocket=FakeWebSocket(),  # type: ignore[arg-type]
        receiver_task=receiver_task,  # type: ignore[arg-type]
        dispatcher_task=dispatcher_task,
        worker_tasks=(trade_task,),
        raw_queue=raw_queue,
        book_queue=book_queue,
        trade_queue=trade_queue,
        partial_queue=partial_queue,
    )
    trade_task.cancel()
    await asyncio.gather(trade_task, return_exceptions=True)
    await asyncio.to_thread(collector.writer.close)
    text = collector.writer.finalized_files[0].read_text(encoding="utf-8")
    assert "AGG_TRADE" in text
    assert budget.bytes_inflight == 0


@pytest.mark.asyncio
async def test_shutdown_propagates_worker_failure_even_after_queue_join(
    tmp_path: Path,
) -> None:
    collector = BinanceCollector(
        Settings(output_dir=tmp_path, shutdown_timeout_s=0.2).validated(),
        capture_session=_capture_session(),
    )
    raw_queue: asyncio.Queue[RawEnvelope | object] = asyncio.Queue()
    book_queue: asyncio.Queue[DiffDepthEvent] = asyncio.Queue()
    trade_queue: asyncio.Queue[AggTradeEvent] = asyncio.Queue()
    partial_queue: asyncio.Queue[PartialDepthEvent] = asyncio.Queue()

    async def dispatcher() -> None:
        item = await raw_queue.get()
        raw_queue.task_done()
        assert item is not None

    async def failed_worker() -> None:
        raise PersistenceBackpressure("evento L2 no persistido")

    receiver_task = asyncio.create_task(asyncio.sleep(0))
    dispatcher_task = asyncio.create_task(dispatcher())
    worker_task = asyncio.create_task(failed_worker(), name="book")
    await asyncio.sleep(0)
    with pytest.raises(PersistenceBackpressure, match="no persistido"):
        await collector._drain_connection(
            websocket=FakeWebSocket(),  # type: ignore[arg-type]
            receiver_task=receiver_task,  # type: ignore[arg-type]
            dispatcher_task=dispatcher_task,
            worker_tasks=(worker_task,),
            raw_queue=raw_queue,
            book_queue=book_queue,
            trade_queue=trade_queue,
            partial_queue=partial_queue,
        )


@pytest.mark.asyncio
async def test_shutdown_timeout_covers_sentinel_put_when_dispatcher_is_dead(
    tmp_path: Path,
) -> None:
    collector = BinanceCollector(
        Settings(output_dir=tmp_path, shutdown_timeout_s=0.05).validated(),
        capture_session=_capture_session(),
    )
    raw_queue: asyncio.Queue[RawEnvelope | object] = asyncio.Queue(maxsize=1)
    raw_queue.put_nowait(
        RawEnvelope(
            connection_id="c1",
            payload=b"{}",
            receive_utc_ns=1,
            receive_monotonic_ns=1,
            payload_bytes=2,
            raw_queue_size=0,
            capture_session_id=TEST_SESSION,
            ingest_seq=1,
            source_socket_id="c1:spot_combined",
        )
    )
    dispatcher_task = asyncio.create_task(asyncio.sleep(0), name="dispatcher")
    await dispatcher_task
    started = time.monotonic()
    with pytest.raises(Exception):
        await collector._drain_connection(
            websocket=FakeWebSocket(),  # type: ignore[arg-type]
            receiver_task=asyncio.create_task(asyncio.sleep(0)),  # type: ignore[arg-type]
            dispatcher_task=dispatcher_task,
            worker_tasks=(),
            raw_queue=raw_queue,
            book_queue=asyncio.Queue(),
            trade_queue=asyncio.Queue(),
            partial_queue=asyncio.Queue(),
        )
    # P3.1b: el modo de fallo vigilado es un CUELGUE indefinido (antes, el
    # put del sentinel podía bloquear para siempre). 0.5 s discrimina igual
    # frente al cuelgue y tolera el scheduler de un Windows cargado; 0.15 s
    # era margen de 2x sobre el timeout y fallaba por jitter.
    assert time.monotonic() - started < 0.5


@pytest.mark.asyncio
async def test_shutdown_does_not_ignore_receiver_backpressure(
    tmp_path: Path,
) -> None:
    collector = BinanceCollector(
        Settings(output_dir=tmp_path, shutdown_timeout_s=0.2).validated(),
        capture_session=_capture_session(),
    )
    raw_queue: asyncio.Queue[RawEnvelope | object] = asyncio.Queue()

    async def failed_receiver() -> None:
        raise PipelineBackpressure("raw full")

    async def dispatcher() -> None:
        item = await raw_queue.get()
        raw_queue.task_done()
        assert item is not None

    receiver_task = asyncio.create_task(failed_receiver(), name="receiver")
    dispatcher_task = asyncio.create_task(dispatcher(), name="dispatcher")
    await asyncio.sleep(0)
    with pytest.raises(PipelineBackpressure, match="raw full"):
        await collector._drain_connection(
            websocket=FakeWebSocket(),  # type: ignore[arg-type]
            receiver_task=receiver_task,
            dispatcher_task=dispatcher_task,
            worker_tasks=(),
            raw_queue=raw_queue,
            book_queue=asyncio.Queue(),
            trade_queue=asyncio.Queue(),
            partial_queue=asyncio.Queue(),
        )
    dispatcher_task.cancel()
    await asyncio.gather(dispatcher_task, return_exceptions=True)


@pytest.mark.asyncio
async def test_shutdown_accepts_expected_websocket_close(
    tmp_path: Path,
) -> None:
    collector = BinanceCollector(
        Settings(output_dir=tmp_path, shutdown_timeout_s=0.2).validated(),
        capture_session=_capture_session(),
    )
    raw_queue: asyncio.Queue[RawEnvelope | object] = asyncio.Queue()

    async def closed_receiver() -> None:
        close = Close(1000, "")
        raise ConnectionClosedOK(close, close, True)

    async def dispatcher() -> None:
        item = await raw_queue.get()
        raw_queue.task_done()
        assert item is not None

    await collector._drain_connection(
        websocket=FakeWebSocket(),  # type: ignore[arg-type]
        receiver_task=asyncio.create_task(closed_receiver(), name="receiver"),
        dispatcher_task=asyncio.create_task(dispatcher(), name="dispatcher"),
        worker_tasks=(),
        raw_queue=raw_queue,
        book_queue=asyncio.Queue(),
        trade_queue=asyncio.Queue(),
        partial_queue=asyncio.Queue(),
    )
