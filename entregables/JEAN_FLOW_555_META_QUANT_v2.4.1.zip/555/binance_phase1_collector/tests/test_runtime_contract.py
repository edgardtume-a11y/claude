from __future__ import annotations

import argparse
import asyncio
import hashlib
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

import aiohttp
import pytest

from binance_collector import __version__, dual_main, runtime
from binance_collector.config import Settings
from binance_collector.dashboard import DashboardServer, MarketStateHub
from binance_collector.launcher import (
    LauncherFailure,
    _archive_previous_certificate,
    _compare_replay_reports,
    _isolated_command,
    _open_browser_once,
    _revalidate_postflight_commitment,
    _validate_stage_receipt,
    _verify_capture_commitment,
    validate_completed_manifest,
    validate_ready_payload,
)
from binance_collector.models import SCHEMA_VERSION
from binance_collector.release_integrity import (
    ReleaseIntegrityError,
    verify_release_tree,
)
from binance_collector.runtime import (
    EXPECTED_MARKETS,
    READY_PROTOCOL_VERSION,
    RuntimeContractError,
    SessionManifest,
    atomic_write_json,
    default_runtime_identity,
    read_json_object,
)


SESSION = "runtime-contract-session-0001"


def _identity(tmp_path: Path, *, port: int = 0):
    identity = default_runtime_identity(
        engine_version=__version__,
        data_schema_version=SCHEMA_VERSION,
        capture_session_id=SESSION,
        launcher_pid=999,
        process_start_utc_ns=time.time_ns(),
        symbol="TUTUSDT",
        project_root=tmp_path,
        output_dir=tmp_path / "capture",
        package_file=Path(dual_main.__file__).resolve(),
    )
    return identity if port == 0 else identity.with_bound_port(port)


def _publish_synced(hub: MarketStateHub, market: str) -> None:
    hub.publish_book(
        market=market,
        symbol="TUTUSDT",
        generation=1,
        sequence=100 if market == "spot" else 200,
        bids=[("0.0999", "120")],
        asks=[("0.1001", "100")],
        receive_utc_ns=time.time_ns(),
        receive_monotonic_ns=time.monotonic_ns(),
        exchange_event_time_ms=int(time.time() * 1000),
    )


def _fake_capture_commitment(
    _output_dir: Path,
    _collectors: object,
    *,
    capture_session_id: str,
    last_ingest_seq: int,
) -> dict[str, object]:
    return {
        "capture_session_id": capture_session_id,
        "last_ingest_seq": max(1, last_ingest_seq),
        "markets": {"spot": {}, "usdm_futures": {}},
    }


def test_atomic_json_and_session_manifest_are_fail_closed(tmp_path: Path) -> None:
    target = tmp_path / "control" / "session.json"
    manifest = SessionManifest.create(
        target,
        capture_session_id=SESSION,
        launcher_pid=999,
        project_root=tmp_path,
        output_dir=tmp_path / "capture",
    )
    assert read_json_object(target)["state"] == "STARTING"
    identity = _identity(tmp_path)
    manifest.transition("IDENTITY_READY", identity=identity)
    manifest.transition(
        "FAILED", identity=identity, error_code="TEST", error_message="x"
    )
    assert read_json_object(target)["error"]["code"] == "TEST"
    with pytest.raises(RuntimeContractError, match="no permitida"):
        manifest.transition("CAPTURING")
    with pytest.raises(RuntimeContractError, match="reutiliza"):
        SessionManifest.create(
            target,
            capture_session_id=SESSION,
            launcher_pid=999,
            project_root=tmp_path,
            output_dir=tmp_path / "capture",
        )
    with pytest.raises(RuntimeContractError, match="not JSON compliant"):
        atomic_write_json(tmp_path / "bad.json", {"value": float("nan")})


def test_session_transition_changes_memory_only_after_durable_write(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    manifest = SessionManifest.create(
        tmp_path / "session.json",
        capture_session_id=SESSION,
        launcher_pid=999,
        project_root=tmp_path,
        output_dir=tmp_path / "capture",
    )

    def fail_write(*_args, **_kwargs) -> None:
        raise RuntimeContractError("DISK_FULL", "simulado")

    monkeypatch.setattr(runtime, "atomic_write_json", fail_write)
    with pytest.raises(RuntimeContractError) as caught:
        manifest.transition("IDENTITY_READY", identity=_identity(tmp_path))
    assert caught.value.code == "DISK_FULL"
    assert manifest.payload["state"] == "STARTING"


def test_release_manifest_detects_tampering_and_version_drift(tmp_path: Path) -> None:
    root = tmp_path / "555"
    files = {
        "jean_flow_launcher.py": 'LAUNCHER_VERSION = "2.2.0"\n',
        "binance_phase1_collector/pyproject.toml": (
            '[project]\nname = "test"\nversion = "2.2.0"\n'
        ),
        "binance_phase1_collector/src/binance_collector/__init__.py": (
            '__version__ = "2.2.0"\n'
        ),
        "binance_phase1_collector/src/binance_collector/launcher.py": (
            'LAUNCHER_VERSION = "2.2.0"\n'
        ),
        "binance_phase1_collector/tools/build_release.py": (
            'RELEASE_VERSION = "2.2.0"\n'
        ),
        "payload.txt": "datos\n",
    }
    lines: list[str] = []
    for relative, contents in files.items():
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(contents, encoding="utf-8")
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest}  555/{relative}")
    (root / "RELEASE_MANIFEST.sha256").write_text(
        "\n".join(sorted(lines)) + "\n", encoding="ascii"
    )
    report = verify_release_tree(root, expected_version="2.2.0")
    assert report["pass"] is True
    assert report["covered_files"] == len(files)
    (root / "payload.txt").write_text("alterado\n", encoding="utf-8")
    with pytest.raises(ReleaseIntegrityError) as caught:
        verify_release_tree(root, expected_version="2.2.0")
    assert caught.value.code == "RELEASE_HASH_MISMATCH"


def test_builder_calls_the_runtime_release_verifier() -> None:
    builder = Path(__file__).resolve().parents[1] / "tools" / "build_release.py"
    source = builder.read_text(encoding="utf-8")
    assert "verify_release_tree(" in source
    assert "expected_version=RELEASE_VERSION" in source
    assert '"release_integrity_validated"' in source


def test_all_child_python_commands_use_verified_isolated_entry(tmp_path: Path) -> None:
    project = tmp_path / "project"
    entry = project / "src" / "binance_collector" / "isolated_entry.py"
    command = _isolated_command(project, "module", "pytest", "-q")
    # P3.2b: -u añadido porque -I ignora PYTHONUNBUFFERED.
    # [2.3.5] -X utf8 añadido porque -I también ignora PYTHONUTF8 y
    # PYTHONIOENCODING: los informes de auditoría contienen no-ASCII
    # ('é', 'θ̂') y deben viajar SIEMPRE en UTF-8. Evidencia de campo:
    # sesiones 87fa5a61d019 (D:) y d64fea5560ac (C:) vetadas por 0xE9.
    assert command[:7] == [sys.executable, "-I", "-S", "-B", "-u", "-X", "utf8"]
    assert Path(command[7]) == entry
    assert command[8:] == ["module", "pytest", "-q"]
    with pytest.raises(ValueError, match="Modo aislado"):
        _isolated_command(project, "unknown", "pytest")


def test_starting_new_full_attempt_archives_visible_certificate(tmp_path: Path) -> None:
    marker = tmp_path / "CAPTURA_COMPLETA_AUDITADA.json"
    atomic_write_json(marker, {"pass": True, "attempt_id": "old-attempt"})
    archived = _archive_previous_certificate(tmp_path)
    assert archived is not None
    assert not marker.exists()
    assert read_json_object(Path(archived))["attempt_id"] == "old-attempt"


def test_readiness_requires_both_fresh_books_and_never_confuses_liveness() -> None:
    hub = MarketStateHub(stale_after_s=1.0)
    empty = hub.readiness(expected_symbol="TUTUSDT")
    assert empty["operational_ready"] is False
    _publish_synced(hub, "spot")
    only_spot = hub.readiness(expected_symbol="TUTUSDT")
    assert only_spot["operational_ready"] is False
    assert only_spot["markets"]["spot"]["ready"] is True
    assert only_spot["markets"]["usdm_futures"]["ready"] is False
    _publish_synced(hub, "usdm_futures")
    assert hub.readiness(expected_symbol="TUTUSDT")["operational_ready"] is True
    stale = hub.readiness(
        expected_symbol="TUTUSDT", now_monotonic_ns=time.monotonic_ns() + 2_000_000_000
    )
    assert stale["operational_ready"] is False
    assert stale["markets"]["spot"]["status"] == "STALE"


@pytest.mark.asyncio
async def test_dashboard_health_identifies_process_and_readyz_is_strict(
    tmp_path: Path,
) -> None:
    hub = MarketStateHub()
    server = DashboardServer(hub, port=0, identity=_identity(tmp_path))
    await server.start()
    try:
        identity = _identity(tmp_path, port=server.port)
        server.set_identity(identity)
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{server.url}/healthz") as response:
                health = await response.json()
                assert response.status == 200
                assert health["live"] is True
                assert health["operational_ready"] is False
                assert health["capture_session_id"] == SESSION
                assert health["pid"] == os.getpid()
                assert response.headers["Cache-Control"] == "no-store"
            async with session.get(f"{server.url}/readyz") as response:
                assert response.status == 503
            _publish_synced(hub, "spot")
            _publish_synced(hub, "usdm_futures")
            async with session.get(f"{server.url}/readyz") as response:
                ready = await response.json()
                assert response.status == 200
                assert ready["operational_ready"] is True
                assert ready["markets"] == list(EXPECTED_MARKETS)
    finally:
        await server.close()


def _valid_ready(tmp_path: Path, *, identity=None) -> dict[str, object]:
    hub = MarketStateHub()
    _publish_synced(hub, "spot")
    _publish_synced(hub, "usdm_futures")
    identity = identity or _identity(tmp_path, port=54321)
    server = DashboardServer(hub, port=54321, identity=identity)
    payload = server.health_payload()
    payload.update(
        {
            "ready": True,
            "ready_protocol_version": READY_PROTOCOL_VERSION,
            "ready_published_utc_ns": time.time_ns(),
        }
    )
    return payload


@pytest.mark.parametrize(
    ("field", "bad_value"),
    [
        ("capture_session_id", "other-session-0000"),
        ("pid", 123),
        ("launcher_pid", 123),
        ("engine_version", "9.9.9"),
        ("symbol", "BTCUSDT"),
        ("markets", ["spot", "futures"]),
        ("host", "0.0.0.0"),
        ("operational_ready", False),
    ],
)
def test_launcher_rejects_every_ready_identity_mismatch(
    tmp_path: Path, field: str, bad_value: object
) -> None:
    payload = _valid_ready(tmp_path)
    payload[field] = bad_value
    with pytest.raises(LauncherFailure, match=field):
        validate_ready_payload(
            payload,
            expected_pid=os.getpid(),
            expected_launcher_pid=999,
            expected_session_id=SESSION,
            expected_symbol="TUTUSDT",
        )


def test_launcher_rejects_stale_or_partial_market_ready(tmp_path: Path) -> None:
    stale = _valid_ready(tmp_path)
    stale["market_states"]["spot"]["age_ms"] = 99_999  # type: ignore[index]
    with pytest.raises(LauncherFailure, match="age_ms"):
        validate_ready_payload(
            stale,
            expected_pid=os.getpid(),
            expected_launcher_pid=999,
            expected_session_id=SESSION,
            expected_symbol="TUTUSDT",
        )
    partial = _valid_ready(tmp_path)
    del partial["market_states"]["usdm_futures"]  # type: ignore[index]
    with pytest.raises(LauncherFailure, match="incompletos"):
        validate_ready_payload(
            partial,
            expected_pid=os.getpid(),
            expected_launcher_pid=999,
            expected_session_id=SESSION,
            expected_symbol="TUTUSDT",
        )


def test_browser_open_timeout_is_a_bounded_visual_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # P3.1b: el discriminador es "no espera al navegador bloqueado 1 s"; el
    # margen anterior (<0.1 con navegador de 0.2) fallaba por puro jitter de
    # arranque de hilo en Windows.
    monkeypatch.setattr(
        "binance_collector.launcher.webbrowser.open",
        lambda _url: time.sleep(1.0),
    )
    started = time.monotonic()
    opened, error = _open_browser_once("http://127.0.0.1:1", timeout_s=0.01)
    assert opened is False
    assert error is not None and "BROWSER_OPEN_TIMEOUT" in error
    assert time.monotonic() - started < 0.5


def test_launcher_rejects_stale_ready_and_wrong_runtime_paths(tmp_path: Path) -> None:
    stale = _valid_ready(tmp_path)
    stale["ready_published_utc_ns"] = time.time_ns() - 60_000_000_000
    with pytest.raises(LauncherFailure, match="ready_published_utc_ns"):
        validate_ready_payload(
            stale,
            expected_pid=os.getpid(),
            expected_launcher_pid=999,
            expected_session_id=SESSION,
            expected_symbol="TUTUSDT",
            expected_project_root=tmp_path,
            expected_output_dir=tmp_path / "capture",
            expected_python_executable=Path(os.sys.executable),
            expected_package_file=Path(dual_main.__file__),
        )
    wrong_path = _valid_ready(tmp_path)
    wrong_path["output_dir"] = str((tmp_path / "other-capture").resolve())
    with pytest.raises(LauncherFailure, match="output_dir"):
        validate_ready_payload(
            wrong_path,
            expected_pid=os.getpid(),
            expected_launcher_pid=999,
            expected_session_id=SESSION,
            expected_symbol="TUTUSDT",
            expected_project_root=tmp_path,
            expected_output_dir=tmp_path / "capture",
            expected_python_executable=Path(os.sys.executable),
            expected_package_file=Path(dual_main.__file__),
        )


def test_engine_rejects_stop_file_from_another_session(tmp_path: Path) -> None:
    path = tmp_path / "STOP.json"
    atomic_write_json(
        path,
        {
            "capture_session_id": "another-session-0000",
            "requested_by_pid": 999,
            "requested_utc_ns": time.time_ns(),
            "reason": "launcher_shutdown",
        },
    )
    with pytest.raises(RuntimeContractError) as caught:
        dual_main._validate_stop_request(
            path,
            capture_session_id=SESSION,
            launcher_pid=999,
            process_start_utc_ns=time.time_ns() - 1_000_000,
        )
    assert caught.value.code == "STOP_INVALID"


def test_engine_rejects_stale_parent_heartbeat(tmp_path: Path) -> None:
    path = tmp_path / "HEARTBEAT.json"
    stale = time.time_ns() - 10_000_000_000
    atomic_write_json(
        path,
        {
            "capture_session_id": SESSION,
            "launcher_pid": 999,
            "started_utc_ns": stale,
            "updated_utc_ns": stale,
        },
    )
    with pytest.raises(RuntimeContractError) as caught:
        dual_main._validate_launcher_heartbeat(
            path,
            capture_session_id=SESSION,
            launcher_pid=999,
        )
    # [2.3.2] La frescura expirada es STALE (tolerable con launcher vivo);
    # solo la identidad ajena sigue siendo PARENT_HEARTBEAT_LOST directo.
    assert caught.value.code == "PARENT_HEARTBEAT_STALE"


def test_heartbeat_stall_is_tolerated_only_while_launcher_pid_lives() -> None:
    """[2.3.2] Evidencia de campo (sesión 45896a2c99aa, Windows 11 + HDD
    USB): una escritura del heartbeat bloqueada >5 s por E/S lenta mató un
    motor SYNCED aunque el launcher seguía vivo. La política tolera el
    estancamiento con PID vivo hasta el tope duro y mantiene el cierre
    fail-closed en <=5 s cuando el launcher murió de verdad."""

    max_age = dual_main.HEARTBEAT_MAX_AGE_NS
    hard_cap = dual_main.HEARTBEAT_STALL_HARD_CAP_NS
    action = dual_main._heartbeat_failure_action

    # Comportamiento P0.3 previo intacto: dentro de la frescura se tolera
    # aunque no haya evidencia de PID (p. ej. lectura en colisión).
    assert action(
        "PARENT_HEARTBEAT_UNREADABLE", since_valid_ns=max_age, pid_alive=False
    ) == "tolerate"
    # Estancamiento real con launcher vivo: tolerado hasta el tope duro.
    assert action(
        "PARENT_HEARTBEAT_STALE", since_valid_ns=max_age + 1, pid_alive=True
    ) == "tolerate"
    assert action(
        "PARENT_HEARTBEAT_STALE", since_valid_ns=hard_cap, pid_alive=True
    ) == "tolerate"
    # Launcher muerto: fatal en cuanto expira la frescura normal.
    assert action(
        "PARENT_HEARTBEAT_STALE", since_valid_ns=max_age + 1, pid_alive=False
    ) == "fatal"
    # Tope duro superado: fatal aunque el PID siga vivo (PID reutilizado).
    assert action(
        "PARENT_HEARTBEAT_STALE", since_valid_ns=hard_cap + 1, pid_alive=True
    ) == "fatal"
    # Identidad ajena: fatal siempre, sin pasar por la tolerancia.
    assert action(
        "PARENT_HEARTBEAT_LOST", since_valid_ns=0, pid_alive=True
    ) == "fatal"


def test_pid_alive_detects_this_process_and_a_dead_pid() -> None:
    assert dual_main._pid_alive(os.getpid()) is True
    dead = subprocess.run(
        [sys.executable, "-c", "import os; print(os.getpid())"],
        capture_output=True,
        text=True,
        check=True,
    )
    finished_pid = int(dead.stdout.strip())
    # El hijo ya terminó; su PID no debe contar como launcher vivo. (En caso
    # de reutilización inmediata del PID el tope duro de 60 s sigue acotando.)
    if not dual_main._pid_alive(finished_pid):
        assert dual_main._pid_alive(finished_pid) is False
    assert dual_main._pid_alive(-5) is False
    assert dual_main._pid_alive(None) is False
    assert dual_main._pid_alive(True) is False


def test_completed_manifest_and_double_replay_are_fail_closed(tmp_path: Path) -> None:
    identity = _identity(tmp_path, port=54321)
    ready = _valid_ready(tmp_path, identity=identity)
    session_file = tmp_path / "control" / "session.json"
    manifest = SessionManifest.create(
        session_file,
        capture_session_id=SESSION,
        launcher_pid=999,
        project_root=tmp_path,
        output_dir=tmp_path / "capture",
    )
    manifest.transition("STARTING", identity=identity)
    manifest.transition("IDENTITY_READY", identity=identity)
    manifest.transition("CAPTURING", identity=identity)
    manifest.transition("STOPPING", identity=identity)
    manifest.transition(
        "COMPLETED",
        identity=identity,
        result={
            "code": "ENGINE_COMPLETED",
            "completed_utc_ns": time.time_ns(),
            "ready_published": True,
            "required_healthy_seconds": None,
            "healthy_duration_completed": True,
            "healthy_started_monotonic_ns": None,
            "healthy_completed_monotonic_ns": None,
            "healthy_resets": 0,
            "capture_commitment": {
                "capture_session_id": SESSION,
                "last_ingest_seq": 1,
                "markets": {"spot": {}, "usdm_futures": {}},
            },
        },
    )
    validated = validate_completed_manifest(
        session_file,
        expected_session_id=SESSION,
        expected_launcher_pid=999,
        expected_engine_pid=os.getpid(),
        expected_project_root=tmp_path,
        expected_output_dir=tmp_path / "capture",
        expected_healthy_seconds=None,
        ready=ready,
    )
    assert validated["state"] == "COMPLETED"

    report = {
        "certification": {
            "journal_integrity": "PASS",
            "causal_replay": "PASS",
        },
        "replay": {"sha256": "a" * 64, "last_update_id": 123},
    }
    first = tmp_path / "first.json"
    second = tmp_path / "second.json"
    atomic_write_json(first, report)
    atomic_write_json(second, report)
    assert _compare_replay_reports(first, second)["pass"] is True
    report["replay"] = {"sha256": "b" * 64, "last_update_id": 124}
    atomic_write_json(second, report)
    assert _compare_replay_reports(first, second)["pass"] is False


def test_capture_commitment_detects_deleted_or_changed_final_segment(
    tmp_path: Path,
) -> None:
    capture = tmp_path / "capture"
    markets: dict[str, object] = {}
    for market in EXPECTED_MARKETS:
        path = capture / market / "events.csv"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"{market}\n", encoding="utf-8")
        size = path.stat().st_size
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        markets[market] = {
            "files": [
                {
                    "path": f"{market}/events.csv",
                    "size_bytes": size,
                    "sha256": digest,
                }
            ],
            "file_count": 1,
            "total_bytes": size,
        }
    commitment = {
        "capture_session_id": SESSION,
        "last_ingest_seq": 2,
        "markets": markets,
    }
    identity_report = {
        "capture_session_id": SESSION,
        "ingest_seq": {"min": 1, "max": 2},
    }
    assert (
        _verify_capture_commitment(
            capture, commitment, identity_report=identity_report
        )["pass"]
        is True
    )
    (capture / "spot" / "events.csv").unlink()
    failed = _verify_capture_commitment(
        capture, commitment, identity_report=identity_report
    )
    assert failed["pass"] is False
    assert any("falta segmento" in error for error in failed["errors"])


def test_postflight_rechecks_commitment_and_stage_receipt(tmp_path: Path) -> None:
    run_root = tmp_path / "run"
    capture = run_root / "capture"
    markets: dict[str, object] = {}
    for market in EXPECTED_MARKETS:
        path = capture / market / "events.csv"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"{market}\n", encoding="utf-8")
        markets[market] = {
            "files": [
                {
                    "path": f"{market}/events.csv",
                    "size_bytes": path.stat().st_size,
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                }
            ],
            "file_count": 1,
            "total_bytes": path.stat().st_size,
        }
    atomic_write_json(
        capture / "audit_identity.json",
        {"capture_session_id": SESSION, "ingest_seq": {"min": 1, "max": 2}},
    )
    result = {
        "pass": True,
        "status": "COMPLETED",
        "run_root": str(run_root),
        "session_manifest": {
            "result": {
                "capture_commitment": {
                    "capture_session_id": SESSION,
                    "last_ingest_seq": 2,
                    "markets": markets,
                }
            }
        },
    }
    assert _revalidate_postflight_commitment(result)["pass"] is True
    from binance_collector.launcher import _hash_evidence_files

    result["evidence_hashes"] = _hash_evidence_files(run_root)
    atomic_write_json(run_root / "RESULT.json", result)
    assert _validate_stage_receipt(result)["result_sha256"]
    (capture / "spot" / "events.csv").write_text("changed\n", encoding="utf-8")
    with pytest.raises(LauncherFailure) as caught:
        _revalidate_postflight_commitment(result)
    assert caught.value.code == "CAPTURE_COMMITMENT_CHANGED"
    with pytest.raises(LauncherFailure) as caught:
        _validate_stage_receipt(result, compare_payload=False)
    assert caught.value.code == "STAGE_EVIDENCE_CHANGED"


@pytest.mark.asyncio
async def test_engine_publishes_atomic_ready_only_after_both_markets(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    class FakeCollector:
        def __init__(self, settings: Settings, **kwargs) -> None:
            self.market = settings.market
            self.hub = kwargs["dashboard_hub"]

        async def run(self, stop: asyncio.Event) -> None:
            _publish_synced(self.hub, self.market)
            await stop.wait()

    monkeypatch.setattr(dual_main, "BinanceCollector", FakeCollector)
    monkeypatch.setattr(dual_main, "_capture_commitment", _fake_capture_commitment)
    args = argparse.Namespace(
        run_seconds=None,
        healthy_seconds=0.02,
        ready_timeout=1.0,
        output_dir=tmp_path / "capture",
        symbol="TUTUSDT",
        dom_levels=20,
        dashboard_port=0,
        no_browser=True,
        session_id=SESSION,
        parent_pid=999,
        session_file=tmp_path / "control" / "session.json",
        ready_file=tmp_path / "control" / "READY.json",
        stop_file=tmp_path / "control" / "STOP.json",
    )
    await dual_main._run(args)
    ready = read_json_object(args.ready_file)
    assert ready["ready"] is True
    assert ready["operational_ready"] is True
    assert set(ready["market_states"]) == set(EXPECTED_MARKETS)
    manifest = read_json_object(args.session_file)
    assert manifest["state"] == "COMPLETED"
    assert manifest["capture_session_id"] == SESSION


@pytest.mark.asyncio
async def test_engine_fails_without_ready_when_only_one_market_syncs(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    class FakeCollector:
        def __init__(self, settings: Settings, **kwargs) -> None:
            self.market = settings.market
            self.hub = kwargs["dashboard_hub"]

        async def run(self, stop: asyncio.Event) -> None:
            if self.market == "spot":
                _publish_synced(self.hub, self.market)
            await stop.wait()

    monkeypatch.setattr(dual_main, "BinanceCollector", FakeCollector)
    monkeypatch.setattr(dual_main, "_capture_commitment", _fake_capture_commitment)
    args = argparse.Namespace(
        run_seconds=None,
        healthy_seconds=0.02,
        ready_timeout=0.03,
        output_dir=tmp_path / "capture",
        symbol="TUTUSDT",
        dom_levels=20,
        dashboard_port=0,
        no_browser=True,
        session_id=SESSION,
        parent_pid=999,
        session_file=tmp_path / "control" / "session.json",
        ready_file=tmp_path / "control" / "READY.json",
        stop_file=tmp_path / "control" / "STOP.json",
    )
    with pytest.raises(dual_main.ReadyTimeout):
        await dual_main._run(args)
    assert not args.ready_file.exists()
    manifest = read_json_object(args.session_file)
    assert manifest["state"] == "FAILED"
    assert manifest["error"]["code"] == "READY_TIMEOUT"


@pytest.mark.asyncio
async def test_certification_window_cannot_pass_after_early_stop(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    class FakeCollector:
        def __init__(self, settings: Settings, **kwargs) -> None:
            self.market = settings.market
            self.hub = kwargs["dashboard_hub"]

        async def run(self, stop: asyncio.Event) -> None:
            _publish_synced(self.hub, self.market)
            await stop.wait()

    monkeypatch.setattr(dual_main, "BinanceCollector", FakeCollector)
    args = argparse.Namespace(
        run_seconds=None,
        healthy_seconds=10.0,
        ready_timeout=1.0,
        output_dir=tmp_path / "capture",
        symbol="TUTUSDT",
        dom_levels=20,
        dashboard_port=0,
        no_browser=True,
        session_id=SESSION,
        parent_pid=999,
        session_file=tmp_path / "control" / "session.json",
        ready_file=tmp_path / "control" / "READY.json",
        stop_file=tmp_path / "control" / "STOP.json",
    )
    task = asyncio.create_task(dual_main._run(args))
    for _ in range(100):
        if args.ready_file.exists():
            break
        await asyncio.sleep(0.01)
    assert args.ready_file.exists()
    atomic_write_json(
        args.stop_file,
        {
            "capture_session_id": SESSION,
            "requested_by_pid": 999,
            "requested_utc_ns": time.time_ns(),
            "reason": "launcher_shutdown",
        },
    )
    with pytest.raises(RuntimeContractError) as caught:
        await task
    assert caught.value.code == "HEALTHY_DURATION_INCOMPLETE"
    assert read_json_object(args.session_file)["state"] == "FAILED"


@pytest.mark.asyncio
async def test_certification_stage_never_opens_the_browser(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """[2.4.1] Una etapa con duración sana exigida NO abre el panel.

    Aunque se invoque el motor a mano (entry point `jean-flow`) sin
    --no-browser: abrir el navegador le quita el primer plano a la captura y
    Windows 11 la degrada (EcoQoS). Evidencia: sesión aa1e3beafeec.
    """

    class FakeCollector:
        def __init__(self, settings: Settings, **kwargs) -> None:
            self.market = settings.market
            self.hub = kwargs["dashboard_hub"]

        async def run(self, stop: asyncio.Event) -> None:
            _publish_synced(self.hub, self.market)
            await stop.wait()

    aperturas: list[str] = []
    monkeypatch.setattr(dual_main, "BinanceCollector", FakeCollector)
    monkeypatch.setattr(dual_main, "_capture_commitment", _fake_capture_commitment)
    monkeypatch.setattr(
        dual_main.webbrowser, "open", lambda url: aperturas.append(url) or True
    )
    args = argparse.Namespace(
        run_seconds=None,
        healthy_seconds=0.02,
        ready_timeout=1.0,
        output_dir=tmp_path / "capture",
        symbol="TUTUSDT",
        dom_levels=20,
        dashboard_port=0,
        no_browser=False,
        session_id=SESSION,
        parent_pid=999,
        session_file=tmp_path / "control" / "session.json",
        ready_file=tmp_path / "control" / "READY.json",
        stop_file=tmp_path / "control" / "STOP.json",
    )
    await dual_main._run(args)
    assert aperturas == []
    assert read_json_object(args.session_file)["state"] == "COMPLETED"


@pytest.mark.asyncio
async def test_browser_failure_is_visual_degradation_not_capture_failure(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    class FakeCollector:
        def __init__(self, settings: Settings, **kwargs) -> None:
            self.market = settings.market
            self.hub = kwargs["dashboard_hub"]

        async def run(self, stop: asyncio.Event) -> None:
            _publish_synced(self.hub, self.market)
            await stop.wait()

    monkeypatch.setattr(dual_main, "BinanceCollector", FakeCollector)
    monkeypatch.setattr(dual_main, "_capture_commitment", _fake_capture_commitment)
    monkeypatch.setattr(
        dual_main.webbrowser,
        "open",
        lambda _url: (_ for _ in ()).throw(OSError("sin navegador")),
    )
    args = argparse.Namespace(
        # [2.4.1] Uso normal acotado: una etapa con healthy_seconds ya no
        # abre el panel, y este caso existe para ejercitar el fallo REAL de
        # apertura (OSError) y comprobar que no condena la captura.
        run_seconds=0.05,
        healthy_seconds=None,
        ready_timeout=1.0,
        output_dir=tmp_path / "capture",
        symbol="TUTUSDT",
        dom_levels=20,
        dashboard_port=0,
        no_browser=False,
        session_id=SESSION,
        parent_pid=999,
        session_file=tmp_path / "control" / "session.json",
        ready_file=tmp_path / "control" / "READY.json",
        stop_file=tmp_path / "control" / "STOP.json",
    )
    await dual_main._run(args)
    assert read_json_object(args.session_file)["state"] == "COMPLETED"


@pytest.mark.asyncio
async def test_explicit_occupied_port_fails_without_reusing_old_server() -> None:
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind(("127.0.0.1", 0))
    listener.listen(1)
    port = listener.getsockname()[1]
    server = DashboardServer(MarketStateHub(), port=port)
    try:
        with pytest.raises(OSError):
            await server.start()
    finally:
        await server.close()
        listener.close()
