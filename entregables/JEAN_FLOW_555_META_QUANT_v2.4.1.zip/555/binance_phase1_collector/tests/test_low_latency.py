from __future__ import annotations

import asyncio
import gc
import sys
import threading
import time
from contextlib import suppress
from dataclasses import replace
from pathlib import Path

import pytest

from binance_collector.collector import BinanceCollector
from binance_collector.config import Settings
from binance_collector.latency import low_latency_runtime
from binance_collector.metrics import Metrics
from binance_collector.models import AggTradeEvent, DepthSnapshot
from binance_collector.normalize import EventSequencer, snapshot_batch
from binance_collector.writer import CsvJournalWriter


class _SinkWriter:
    def submit(self, _batch: object) -> bool:
        return True


def test_snapshot_rows_are_materialized_lazily_outside_hot_path() -> None:
    snapshot = DepthSnapshot(
        last_update_id=10,
        bids=(("100", "2"), ("99", "3")),
        asks=(("101", "4"),),
        receive_utc_ns=1,
        receive_monotonic_ns=2,
        payload_bytes=10,
    )
    batch = snapshot_batch(
        snapshot,
        "TUTUSDT",
        "connection-1",
        1,
        EventSequencer("test-capture-session-v2"),
    )

    assert batch._rows is None
    assert batch.row_count == 4
    rows = tuple(batch.iter_rows())
    assert batch._rows is None
    assert [row["row_index"] for row in rows] == [0, 1, 2, 3]
    assert [row["side"] for row in rows] == [None, "bid", "bid", "ask"]


def test_metric_shards_merge_while_writer_thread_is_active() -> None:
    metrics = Metrics(latency_window=2_000)
    threads: list[threading.Thread] = []

    def produce(worker: int) -> None:
        for value in range(4_000):
            metrics.inc("events")
            metrics.observe("work", float(value % 10))
            metrics.set_max_gauge("high_water", worker * 4_000 + value)

    for worker in range(4):
        thread = threading.Thread(target=produce, args=(worker,))
        thread.start()
        threads.append(thread)
    while any(thread.is_alive() for thread in threads):
        metrics.snapshot()
    for thread in threads:
        thread.join()

    result = metrics.snapshot()
    assert result["counters"]["events"] == 16_000
    assert result["gauges"]["high_water"] == 15_999
    assert result["latency_ms"]["work"]["count"] == 2_000


def test_writer_records_actual_cooperative_yield_duration(tmp_path: Path) -> None:
    metrics = Metrics()
    writer = CsvJournalWriter(
        output_dir=tmp_path,
        queue_size=4,
        max_queued_rows=100,
        batch_rows=100,
        flush_interval_s=0.01,
        rotation_bytes=1_000_000,
        rotation_seconds=60,
        metrics=metrics,
        write_chunk_rows=1,
        yield_sleep_s=0.0001,
    )
    batch = snapshot_batch(
        DepthSnapshot(
            last_update_id=1,
            bids=(("1", "1"),),
            asks=(("2", "1"),),
            receive_utc_ns=time.time_ns(),
            receive_monotonic_ns=time.monotonic_ns(),
            payload_bytes=1,
        ),
        "TUTUSDT",
        "writer-yield-test",
        1,
        EventSequencer("writer-yield-test-session"),
    )
    writer.start()
    assert writer.submit(batch)
    writer.close()
    snapshot = metrics.snapshot()
    assert snapshot["counters"]["writer_gil_yields"] == 2
    assert snapshot["latency_ms"]["writer_cooperative_yield"]["count"] == 2
    assert snapshot["gauges"]["writer_yield_requested_ms"] == pytest.approx(0.1)


def test_low_latency_runtime_restores_process_settings(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    previous_switch = sys.getswitchinterval()
    previous_thresholds = gc.get_threshold()
    monkeypatch.setenv("PYTHON_THREAD_SWITCH_INTERVAL_S", "0.001")
    monkeypatch.setenv("GC_THRESHOLD_0", "50000")
    monkeypatch.setenv("GC_THRESHOLD_1", "100")
    monkeypatch.setenv("GC_THRESHOLD_2", "100")

    with low_latency_runtime() as tuning:
        assert sys.getswitchinterval() == pytest.approx(0.001)
        assert gc.get_threshold() == (50_000, 100, 100)
        assert tuning.gc_thresholds == (50_000, 100, 100)

    assert sys.getswitchinterval() == pytest.approx(previous_switch)
    assert gc.get_threshold() == previous_thresholds


@pytest.mark.asyncio
async def test_trade_backlog_yields_to_event_loop_within_budget(tmp_path: Path) -> None:
    settings = replace(
        Settings(output_dir=tmp_path),
        route_queue_size=25_000,
        cooperative_yield_budget_ms=1.0,
    )
    collector = BinanceCollector(settings)
    collector.writer = _SinkWriter()  # type: ignore[assignment]
    session_id = collector.capture_session.capture_session_id
    queue: asyncio.Queue[AggTradeEvent] = asyncio.Queue(maxsize=25_000)
    now_ms = int(time.time() * 1_000)
    now_utc_ns = time.time_ns()
    now_monotonic_ns = time.monotonic_ns()
    for trade_id in range(20_000):
        queue.put_nowait(
            AggTradeEvent(
                connection_id="c1",
                event_time_ms=now_ms,
                trade_time_ms=now_ms,
                symbol="TUTUSDT",
                aggregate_trade_id=trade_id,
                first_trade_id=trade_id,
                last_trade_id=trade_id,
                price="0.1",
                quantity="1",
                buyer_is_maker=False,
                receive_utc_ns=now_utc_ns,
                receive_monotonic_ns=now_monotonic_ns,
                payload_bytes=100,
                raw_queue_size=0,
                capture_session_id=session_id,
                ingest_seq=trade_id + 1,
                source_socket_id="c1:spot_combined",
            )
        )

    worker = asyncio.create_task(collector._trade_worker(queue))
    try:
        for _ in range(1_000):
            if (
                collector.metrics.snapshot()["counters"].get(
                    "cooperative_yields_trade", 0
                )
                >= 1
            ):
                break
            await asyncio.sleep(0)
        snapshot = collector.metrics.snapshot()
        assert snapshot["counters"]["cooperative_yields_trade"] >= 1
        assert queue.qsize() > 0
    finally:
        worker.cancel()
        with suppress(asyncio.CancelledError):
            await worker
