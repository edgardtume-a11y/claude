"""[2.3.5] Regresión del veto por codificación en Windows es-ES.

Los informes de auditoría (JSON con ensure_ascii=False) contienen 'é',
'más', 'contigüidad' y 'θ̂'. Con stdout redirigido y locale cp1252
(Windows es-ES), 'é' se escribía como 0xE9 — el verificador (UTF-8
estricto) vetaba con "invalid continuation byte" en posición fija — y
'θ̂' hacía crashear el examen de métricas con UnicodeEncodeError.
Evidencia de campo: sesiones 87fa5a61d019 (D:) y d64fea5560ac (C:).
Estas pruebas reproducen la condición y fijan la corrección.
"""

from __future__ import annotations

import io
import os
import subprocess
import sys
from pathlib import Path

from binance_collector import audit, isolated_entry, launcher

_SRC = Path(__file__).resolve().parents[1] / "src"
_MUESTRA = "θ̂ después de más contigüidad"


def _entorno_windows_es_es() -> dict[str, str]:
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "cp1252"
    env["PYTHONPATH"] = str(_SRC)
    env.pop("PYTHONUTF8", None)
    return env


def test_isolated_command_fuerza_modo_utf8(tmp_path: Path) -> None:
    command = launcher._isolated_command(tmp_path, "module", "pytest")
    index = command.index("-X")
    assert command[index + 1] == "utf8"
    entry = str(
        tmp_path / "src" / "binance_collector" / "isolated_entry.py"
    )
    assert index < command.index(entry)


def _bytes_tras_reconfigurar(helper) -> bytes:
    stdout = io.TextIOWrapper(io.BytesIO(), encoding="cp1252")
    stderr = io.TextIOWrapper(io.BytesIO(), encoding="cp1252")
    previos = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = stdout, stderr
    try:
        helper()
        sys.stdout.write(_MUESTRA)
        sys.stdout.flush()
    finally:
        sys.stdout, sys.stderr = previos
    return stdout.buffer.getvalue()


def test_audit_reconfigura_stdout_cp1252_a_utf8() -> None:
    assert _bytes_tras_reconfigurar(audit._force_utf8_stdio).decode(
        "utf-8"
    ) == _MUESTRA


def test_isolated_entry_reconfigura_stdout_cp1252_a_utf8() -> None:
    assert _bytes_tras_reconfigurar(
        isolated_entry._force_utf8_stdio
    ).decode("utf-8") == _MUESTRA


def test_informe_de_auditoria_sobrevive_stdio_cp1252() -> None:
    codigo = (
        "from binance_collector.audit import _force_utf8_stdio\n"
        "_force_utf8_stdio()\n"
        f"print({_MUESTRA!r})\n"
    )
    completado = subprocess.run(
        [sys.executable, "-c", codigo],
        capture_output=True,
        env=_entorno_windows_es_es(),
        timeout=120,
        check=False,
    )
    assert completado.returncode == 0, completado.stderr.decode(
        "utf-8", "replace"
    )
    assert completado.stdout.decode("utf-8").strip() == _MUESTRA


def test_condicion_windows_reproducida_sin_correccion() -> None:
    # Documenta la condición original: sin la corrección, imprimir 'θ̂'
    # con stdio cp1252 revienta igual que audit_metrics en el host real.
    completado = subprocess.run(
        [sys.executable, "-c", f"print({_MUESTRA!r})"],
        capture_output=True,
        env=_entorno_windows_es_es(),
        timeout=120,
        check=False,
    )
    assert completado.returncode != 0
    assert b"UnicodeEncodeError" in completado.stderr
