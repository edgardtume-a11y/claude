from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import pytest

from binance_collector.config import Settings
from binance_collector.fixed_point import parse_fixed
from binance_collector.metrics import Metrics
from binance_collector.models import (
    AggTradeEvent,
    DepthSnapshot,
    DiffDepthEvent,
    PartialDepthEvent,
    RawEnvelope,
)
from binance_collector.normalize import (
    EventSequencer,
    delta_batch,
    snapshot_batch,
    status_batch,
)
from binance_collector.order_book import (
    ApplyResult,
    LocalOrderBook,
    PreviousSequenceGap,
    retained_after_snapshot,
)
from binance_collector.protocol import ProtocolError, decode_combined
from binance_collector.reconstruct import ReplayError, reconstruct
from binance_collector.writer import CsvJournalWriter

TEST_SESSION = "test-capture-session-v2"


def _settings(tmp_path: Path | None = None) -> Settings:
    return Settings.for_market(
        "usdm_futures",
        output_dir=tmp_path or Path("data"),
    )


def _envelope(path: Path) -> RawEnvelope:
    payload = path.read_bytes()
    source_role = (
        "usdm_market_trades" if "agg_trade" in path.name else "usdm_public_depth"
    )
    return RawEnvelope(
        connection_id="f1",
        payload=payload,
        receive_utc_ns=1_786_428_000_200_000_000,
        receive_monotonic_ns=5_000_000,
        payload_bytes=len(payload),
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=1,
        source_socket_id=f"f1:{source_role}",
    )


def _diff(first: int, final: int, previous: int) -> DiffDepthEvent:
    return DiffDepthEvent(
        connection_id="f1",
        event_time_ms=1_786_428_000_100,
        symbol="TUTUSDT",
        first_update_id=first,
        final_update_id=final,
        bids=(("0.09864", "2"),),
        asks=(),
        receive_utc_ns=1_786_428_000_200_000_000,
        receive_monotonic_ns=5_000_000,
        payload_bytes=80,
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=first,
        source_socket_id="f1:usdm_public_depth",
        previous_final_update_id=previous,
    )


def _snapshot() -> DepthSnapshot:
    return DepthSnapshot(
        last_update_id=100,
        bids=(("0.09863", "1"),),
        asks=(("0.09866", "1"),),
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=100,
    )


def _writer(path: Path) -> CsvJournalWriter:
    return CsvJournalWriter(
        output_dir=path,
        queue_size=32,
        max_queued_rows=1_000,
        batch_rows=100,
        flush_interval_s=0.01,
        rotation_bytes=10_000_000,
        rotation_seconds=60,
        metrics=Metrics(),
    )


def test_usdm_uses_tiered_combined_stream_endpoints() -> None:
    """[2.3.3] REVERSIÓN de P0.1a con oráculo O=1: desde 2026-04-23 USDⓈ-M
    segmenta el tráfico (aviso oficial «Important WebSocket Change Notice»).
    La profundidad vive en /public y aggTrade en /market; una conexión SIN
    ruta (el legado /stream de 2.3.0-2.3.2) solo recibe el nivel Public.
    Evidencia de campo 2026-08-14: btcusdt@depth* fluía (100 mensajes en
    13.5 s) y btcusdt@aggTrade quedó a 0/100 en 4 intentos sobre el endpoint
    legado. El hallazgo de la auditoría («/public/stream y /market/stream no
    existen») estaba desactualizado respecto a la documentación vigente."""

    settings = _settings()
    assert settings.snapshot_limit == 1_000
    assert settings.rest_depth_path == "/fapi/v1/depth"
    assert settings.websocket_urls == (
        "wss://fstream.binance.com/public/stream?streams="
        "tutusdt@depth20@100ms/tutusdt@depth@100ms",
        "wss://fstream.binance.com/market/stream?streams=tutusdt@aggTrade",
    )


def test_usdm_decodes_split_stream_payloads(fixture_dir: Path) -> None:
    settings = _settings()
    decoded = [
        decode_combined(
            _envelope(fixture_dir / name),
            symbol=settings.symbol,
            stream_names=settings.stream_names,
            market=settings.market,
        )
        for name in (
            "usdm_agg_trade.json",
            "usdm_depth_partial.json",
            "usdm_depth_diff.json",
        )
    ]
    assert isinstance(decoded[0], AggTradeEvent)
    assert isinstance(decoded[1], PartialDepthEvent)
    assert isinstance(decoded[2], DiffDepthEvent)
    assert decoded[1].previous_final_update_id == 100
    assert decoded[2].previous_final_update_id == 100


def test_usdm_rejects_coin_m_discriminator(fixture_dir: Path) -> None:
    """`st` presente y != 1 sigue siendo un rechazo fail-closed."""

    raw = (
        (fixture_dir / "usdm_depth_diff.json")
        .read_bytes()
        .replace(b'"pu":100', b'"pu":100,"st":2')
    )
    envelope = RawEnvelope(
        connection_id="f1",
        payload=raw,
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=len(raw),
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=1,
        source_socket_id="f1:usdm_public_depth",
    )
    settings = _settings()
    with pytest.raises(ProtocolError, match="no USD"):
        decode_combined(
            envelope,
            symbol=settings.symbol,
            stream_names=settings.stream_names,
            market=settings.market,
        )


def test_usdm_accepts_absent_discriminator_and_counts_it(
    fixture_dir: Path,
) -> None:
    """P0.1b/[P1]: los payloads documentados de fstream NO llevan `st`.

    Exigirlo rechazaba el 100 % del tráfico Futures real. Ausente se acepta y
    se contabiliza vía callback (`usdm_st_absent`).
    """

    envelope = _envelope(fixture_dir / "usdm_depth_diff.json")
    settings = Settings.for_market("usdm_futures")
    absent_calls: list[int] = []
    event = decode_combined(
        envelope,
        symbol=settings.symbol,
        stream_names=settings.stream_names,
        market=settings.market,
        on_usdm_st_absent=lambda: absent_calls.append(1),
    )
    assert isinstance(event, DiffDepthEvent)
    assert absent_calls == [1]
    # `st` explícito == 1 no dispara el contador.
    raw = (
        (fixture_dir / "usdm_depth_diff.json")
        .read_bytes()
        .replace(b'"pu":100', b'"pu":100,"st":1')
    )
    explicit = replace(envelope, payload=raw, payload_bytes=len(raw))
    absent_calls.clear()
    decode_combined(
        explicit,
        symbol=settings.symbol,
        stream_names=settings.stream_names,
        market=settings.market,
        on_usdm_st_absent=lambda: absent_calls.append(1),
    )
    assert absent_calls == []


def test_usdm_bridge_and_pu_chain_fail_closed() -> None:
    book = LocalOrderBook(100, market="usdm_futures", snapshot_limit=1_000)
    book.load_snapshot(_snapshot())
    bridge = _diff(99, 100, 98)
    assert book.apply(bridge) is ApplyResult.ANCHORED
    assert book.apply(_diff(101, 103, 100)) is ApplyResult.APPLIED
    with pytest.raises(PreviousSequenceGap, match="pu=103"):
        book.apply(_diff(104, 105, 102))


def test_usdm_anchor_at_snapshot_never_rolls_snapshot_back() -> None:
    book = LocalOrderBook(100, market="usdm_futures", snapshot_limit=1_000)
    book.load_snapshot(_snapshot())
    anchor = replace(
        _diff(99, 100, 98),
        bids=(("0.09863", "999"),),
    )
    assert book.apply(anchor) is ApplyResult.ANCHORED
    assert book.bids[parse_fixed("0.09863")] == parse_fixed("1")
    assert book.apply(_diff(101, 103, 100)) is ApplyResult.APPLIED


def test_usdm_bootstrap_prevalidates_entire_pu_chain() -> None:
    events = [_diff(99, 100, 98), _diff(101, 103, 100), _diff(104, 105, 103)]
    assert retained_after_snapshot(100, events, market="usdm_futures") == events
    broken = events[:-1] + [_diff(104, 105, 102)]
    with pytest.raises(PreviousSequenceGap, match="esperado pu=103"):
        retained_after_snapshot(100, broken, market="usdm_futures")


def test_usdm_invariant_failure_rolls_back_book_and_sequence() -> None:
    book = LocalOrderBook(100, market="usdm_futures", snapshot_limit=1_000)
    book.load_snapshot(_snapshot())
    before = dict(book.bids)
    crossed = replace(
        _diff(99, 101, 98),
        bids=(("0.09870", "1"),),
    )
    with pytest.raises(Exception, match="cruzado"):
        book.apply(crossed)
    assert dict(book.bids) == before
    assert book.last_update_id == 100


def test_usdm_bootstrap_requires_snapshot_overlap() -> None:
    assert retained_after_snapshot(
        100,
        [_diff(99, 100, 98)],
        market="usdm_futures",
    )
    with pytest.raises(Exception, match="Gap L2"):
        retained_after_snapshot(
            100,
            [_diff(101, 103, 100)],
            market="usdm_futures",
        )


def test_usdm_journal_replays_pu_and_market_identity(tmp_path: Path) -> None:
    writer = _writer(tmp_path)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    assert writer.submit(
        snapshot_batch(
            _snapshot(),
            "TUTUSDT",
            "f1",
            1,
            sequencer,
            market="usdm_futures",
        )
    )
    assert writer.submit(
        delta_batch(
            _diff(99, 100, 98),
            1,
            sequencer,
            market="usdm_futures",
        )
    )
    assert writer.submit(
        delta_batch(
            _diff(101, 103, 100),
            1,
            sequencer,
            market="usdm_futures",
        )
    )
    assert writer.submit(
        status_batch(
            symbol="TUTUSDT",
            connection_id="f1",
            generation=1,
            status="SYNCED",
            sequence=103,
            sequencer=sequencer,
            market="usdm_futures",
        )
    )
    writer.close()
    state = reconstruct(writer.finalized_files)
    assert state.valid is True
    assert state.market == "usdm_futures"
    assert state.last_update_id == 103


def test_replay_never_hybridizes_spot_and_futures(tmp_path: Path) -> None:
    writer = _writer(tmp_path)
    writer.start()
    sequencer = EventSequencer(TEST_SESSION)
    assert writer.submit(snapshot_batch(_snapshot(), "TUTUSDT", "f1", 1, sequencer))
    assert writer.submit(
        delta_batch(
            _diff(99, 100, 98),
            1,
            sequencer,
            market="usdm_futures",
        )
    )
    writer.close()
    with pytest.raises(ReplayError, match="mezcla mercados"):
        reconstruct(writer.finalized_files)
