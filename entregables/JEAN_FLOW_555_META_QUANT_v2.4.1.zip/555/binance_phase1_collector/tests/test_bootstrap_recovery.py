"""[S4]/[S5]/[S6]/[N7]/[S11]/[S14]: bootstrap y cadena de suministro.

Contra v2.2.2:
  · `.runtime_building` huérfano => BOOTSTRAP_FAILED permanente (brick);
  · colisión de mayúsculas => ENVIRONMENT_SEAL_FAILED tras extraer 793
    ficheros, con un mensaje sobre imports;
  · bomba de descompresión => MemoryError sin tipar (salida 70);
  · wheel firmado (RECORD.jws) => ininstalable;
  · 'C:evil.py' pasaba el build (supply_chain) y moría en la instalación;
  · una línea vacía o comentario en requirements.lock => release que no
    arranca.
"""

from __future__ import annotations

import base64
import csv
import hashlib
import importlib.util
import io
import sys
import zipfile
from pathlib import Path

import pytest

from binance_collector.supply_chain import (
    SupplyChainError,
    WheelPlanEntry,
    expected_runtime_inventory,
    verified_wheel_payloads,
    verified_wheel_plan,
)

BOOTSTRAP = Path(__file__).resolve().parents[2] / "jean_flow_launcher.py"


def _load_bootstrap():
    specification = importlib.util.spec_from_file_location(
        "jean_flow_bootstrap_recovery_test", BOOTSTRAP
    )
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def _record_hash(payload: bytes) -> str:
    digest = hashlib.sha256(payload).digest()
    return "sha256=" + base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


def _wheel(
    path: Path,
    files: dict[str, bytes],
    *,
    distribution: str = "demo",
    version: str = "1.0",
    record_extra_rows: list[list[str]] | None = None,
    omit_from_record: set[str] | None = None,
) -> WheelPlanEntry:
    path.parent.mkdir(parents=True, exist_ok=True)
    record_name = f"{distribution}-{version}.dist-info/RECORD"
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        record_rows: list[list[str]] = []
        for name, payload in files.items():
            archive.writestr(name, payload)
            if omit_from_record and name in omit_from_record:
                continue
            record_rows.append([name, _record_hash(payload), str(len(payload))])
        if record_extra_rows:
            record_rows.extend(record_extra_rows)
        record_rows.append([record_name, "", ""])
        text = io.StringIO()
        csv.writer(text, lineterminator="\n").writerows(record_rows)
        archive.writestr(record_name, text.getvalue())
    path.write_bytes(buffer.getvalue())
    return WheelPlanEntry(
        distribution=distribution,
        version=version,
        path=path,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    )


def test_orphan_staging_is_preserved_and_bootstrap_continues(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """[S4]/R1.3: matar el bootstrap durante la extracción no puede impedir
    el siguiente arranque."""

    bootstrap = _load_bootstrap()
    project = tmp_path / "project"
    project.mkdir()
    monkeypatch.setattr(bootstrap, "PROJECT_ROOT", project)
    staging = project / ".runtime_building"
    (staging / "packages").mkdir(parents=True)
    (staging / "packages" / "half_extracted.py").write_text("x", encoding="utf-8")

    bootstrap._recover_orphan_staging(staging)

    assert not staging.exists()
    preserved = list(project.glob(".runtime_preserved_*_staging"))
    assert len(preserved) == 1
    assert (preserved[0] / "packages" / "half_extracted.py").is_file()


def test_preserved_runtimes_are_pruned_to_two(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    bootstrap = _load_bootstrap()
    project = tmp_path / "project"
    project.mkdir()
    monkeypatch.setattr(bootstrap, "PROJECT_ROOT", project)
    for stamp in ("20260101_000000_000", "20260102_000000_000", "20260103_000000_000", "20260104_000000_000"):
        (project / f".runtime_preserved_{stamp}").mkdir()
    bootstrap._prune_preserved_runtimes()
    remaining = sorted(path.name for path in project.glob(".runtime_preserved_*"))
    assert remaining == [
        ".runtime_preserved_20260103_000000_000",
        ".runtime_preserved_20260104_000000_000",
    ]


def test_case_collision_between_wheels_is_named_at_plan_time(
    tmp_path: Path,
) -> None:
    """[S5]/R1.4: 'Shared/x.py' y 'shared/x.py' deben fallar ANTES de
    extraer, con un mensaje que nombra la colisión."""

    first = _wheel(
        tmp_path / "a" / "demo-1.0-py3-none-any.whl",
        {"Shared/x.py": b"VALUE = 1\n"},
    )
    second = _wheel(
        tmp_path / "b" / "other-1.0-py3-none-any.whl",
        {"shared/x.py": b"VALUE = 1\n"},
        distribution="other",
    )
    with pytest.raises(SupplyChainError, match="WHEEL_CASE_COLLISION") as caught:
        expected_runtime_inventory((first, second))
    message = str(caught.value)
    assert "Shared/x.py" in message
    assert "shared/x.py" in message


def test_decompression_bomb_is_rejected_before_reading(tmp_path: Path) -> None:
    """[S6]/R5.4: el tamaño DECLARADO se comprueba antes de leer un byte."""

    path = tmp_path / "bomb-1.0-py3-none-any.whl"
    record_name = "bomb-1.0.dist-info/RECORD"
    payload = b"\0" * 1024
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        info = zipfile.ZipInfo("bomb/huge.bin")
        archive.writestr(info, payload)
        # Mentimos el tamaño declarado en la cabecera para simular la bomba
        # sin generar gigabytes reales.
        text = io.StringIO()
        csv.writer(text, lineterminator="\n").writerows(
            [
                ["bomb/huge.bin", _record_hash(payload), str(len(payload))],
                [record_name, "", ""],
            ]
        )
        archive.writestr(record_name, text.getvalue())
    raw = bytearray(buffer.getvalue())
    path.write_bytes(bytes(raw))
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
    # Reconstruimos con file_size gigante vía parche del ZipInfo en memoria.
    entry = WheelPlanEntry(
        distribution="bomb",
        version="1.0",
        path=path,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    )
    import binance_collector.supply_chain as supply_chain_module

    original_zipfile = supply_chain_module.zipfile.ZipFile

    class _InflatedZip(original_zipfile):  # type: ignore[valid-type, misc]
        def infolist(self):  # type: ignore[override]
            entries = super().infolist()
            for info in entries:
                if info.filename == "bomb/huge.bin":
                    info.file_size = 5 * 1024 * 1024 * 1024
            return entries

    supply_chain_module.zipfile.ZipFile = _InflatedZip  # type: ignore[misc]
    try:
        with pytest.raises(SupplyChainError, match="límite de descompresión"):
            verified_wheel_payloads(entry)
    finally:
        supply_chain_module.zipfile.ZipFile = original_zipfile  # type: ignore[misc]
    assert infos  # el wheel real era legible


def test_signed_wheel_record_jws_is_installable(tmp_path: Path) -> None:
    """[N7]: la especificación permite RECORD.jws/RECORD.p7s sin hash."""

    with_signature = _wheel(
        tmp_path / "signed-1.0-py3-none-any.whl",
        {
            "signed/__init__.py": b"VALUE = 1\n",
            "signed-1.0.dist-info/RECORD.jws": b"{}",
        },
        distribution="signed",
        omit_from_record={"signed-1.0.dist-info/RECORD.jws"},
    )
    payloads = verified_wheel_payloads(with_signature)
    assert "signed/__init__.py" in payloads
    assert "signed-1.0.dist-info/RECORD.jws" in payloads

    with_row = _wheel(
        tmp_path / "rowsig-1.0-py3-none-any.whl",
        {
            "rowsig/__init__.py": b"VALUE = 1\n",
            "rowsig-1.0.dist-info/RECORD.p7s": b"sig",
        },
        distribution="rowsig",
        omit_from_record={"rowsig-1.0.dist-info/RECORD.p7s"},
        record_extra_rows=[["rowsig-1.0.dist-info/RECORD.p7s", "", ""]],
    )
    payloads = verified_wheel_payloads(with_row)
    assert "rowsig-1.0.dist-info/RECORD.p7s" in payloads


def test_drive_relative_entry_is_rejected_by_the_single_extractor(
    tmp_path: Path,
) -> None:
    """[S11]/I7: 'C:evil.py' aceptado por el build y rechazado solo en la
    instalación rompía fail-closed; ahora la única implementación lo rechaza
    en ambos sitios."""

    evil = _wheel(
        tmp_path / "evil-1.0-py3-none-any.whl",
        {"C:evil.py": b"boom\n"},
        distribution="evil",
    )
    with pytest.raises(SupplyChainError, match="no admitida"):
        verified_wheel_payloads(evil)


def test_requirements_lock_tolerates_comments_and_blank_lines(
    tmp_path: Path,
) -> None:
    """[S14]: el parser de 2.2.0 toleraba comentarios; 2.2.2 lo perdió."""

    project = tmp_path / "project"
    wheelhouse = project / "wheelhouse"
    entry = _wheel(wheelhouse / "demo-1.0-py3-none-any.whl", {"demo/__init__.py": b"x"})
    (project / "requirements.lock").write_text(
        "# dependencias pinneadas\n"
        "\n"
        f"demo==1.0 --hash=sha256:{entry.sha256}\n",
        encoding="ascii",
    )
    (wheelhouse / "WHEELHOUSE_MANIFEST.sha256").write_text(
        f"{entry.sha256}  demo-1.0-py3-none-any.whl\n", encoding="ascii"
    )
    plan = verified_wheel_plan(project)
    assert len(plan) == 1
    assert plan[0].distribution == "demo"
