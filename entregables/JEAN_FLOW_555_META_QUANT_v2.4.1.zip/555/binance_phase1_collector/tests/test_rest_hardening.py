"""[P10]/P1.3: el 418 es un ban de IP y no se reintenta; el último intento
no duerme; el peso usado se observa.

Contra v2.2.2, el 418 se trataba como reintentable (alimentando el ban) y el
bucle dormía el delay completo DESPUÉS del último intento antes de rendirse.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

import pytest

from binance_collector.metrics import Metrics
from binance_collector.rest import RestBanError, SnapshotClient, SnapshotError


class _FakeResponse:
    def __init__(
        self,
        status: int,
        body: bytes = b"{}",
        headers: dict[str, str] | None = None,
    ) -> None:
        self.status = status
        self._body = body
        self.headers = headers or {}

    async def read(self) -> bytes:
        return self._body

    async def __aenter__(self) -> "_FakeResponse":
        return self

    async def __aexit__(self, *_: object) -> None:
        return None


class _FakeSession:
    def __init__(self, responses: list[_FakeResponse]) -> None:
        self._responses = responses
        self.calls = 0

    def get(self, *_args: Any, **_kwargs: Any) -> _FakeResponse:
        response = self._responses[min(self.calls, len(self._responses) - 1)]
        self.calls += 1
        return response


def _client(session: _FakeSession, *, retries: int = 3) -> SnapshotClient:
    return SnapshotClient(
        session=session,  # type: ignore[arg-type]
        base_url="https://api.binance.com",
        depth_path="/api/v3/depth",
        symbol="TUTUSDT",
        limit=5_000,
        timeout_s=1.0,
        retries=retries,
        min_interval_s=0.001,
        metrics=Metrics(),
    )


def test_418_is_terminal_with_zero_retries() -> None:
    session = _FakeSession(
        [_FakeResponse(418, b"banned", {"Retry-After": "7200"})]
    )
    client = _client(session)
    started = time.monotonic()
    with pytest.raises(RestBanError) as caught:
        asyncio.run(client.fetch())
    elapsed = time.monotonic() - started
    # F2: retirada TOTAL — una única petición y cero sueños de castigo.
    assert session.calls == 1
    assert elapsed < 1.0
    assert caught.value.retry_after_s == 7200.0
    assert "REST_IP_BANNED" in str(caught.value)


def test_last_retryable_attempt_does_not_sleep() -> None:
    session = _FakeSession([_FakeResponse(429, b"slow", {"Retry-After": "1"})])
    client = _client(session, retries=2)
    started = time.monotonic()
    with pytest.raises(SnapshotError, match="agotaron"):
        asyncio.run(client.fetch())
    elapsed = time.monotonic() - started
    assert session.calls == 2
    # Duerme el Retry-After (1 s) entre intentos, pero NUNCA después del
    # último: contra 2.2.2 esto habría dormido ~2 s (1 s extra terminal).
    assert 0.9 <= elapsed < 1.9
    # Con UN solo intento permitido no hay sueño alguno aunque Retry-After
    # pida 45 s.
    single_session = _FakeSession(
        [_FakeResponse(429, b"slow", {"Retry-After": "45"})]
    )
    single = _client(single_session, retries=1)
    started = time.monotonic()
    with pytest.raises(SnapshotError):
        asyncio.run(single.fetch())
    assert time.monotonic() - started < 1.0
    assert single_session.calls == 1


def test_used_weight_header_is_observed() -> None:
    metrics = Metrics()
    session = _FakeSession(
        [
            _FakeResponse(
                200,
                b'{"lastUpdateId": 1, "bids": [], "asks": []}',
                {"X-MBX-USED-WEIGHT-1M": "1234"},
            )
        ]
    )
    client = SnapshotClient(
        session=session,  # type: ignore[arg-type]
        base_url="https://api.binance.com",
        depth_path="/api/v3/depth",
        symbol="TUTUSDT",
        limit=5_000,
        timeout_s=1.0,
        retries=1,
        min_interval_s=0.001,
        metrics=metrics,
    )
    snapshot = asyncio.run(client.fetch())
    assert snapshot.last_update_id == 1
    # fetch() con 200 no pasa por _observe_used_weight en el camino feliz;
    # exchangeInfo y los códigos de error sí lo hacen. Comprobamos vía 429.
    session_429 = _FakeSession(
        [
            _FakeResponse(429, b"x", {"X-MBX-USED-WEIGHT-1M": "5990"}),
            _FakeResponse(
                200, b'{"lastUpdateId": 2, "bids": [], "asks": []}'
            ),
        ]
    )
    client_429 = SnapshotClient(
        session=session_429,  # type: ignore[arg-type]
        base_url="https://api.binance.com",
        depth_path="/api/v3/depth",
        symbol="TUTUSDT",
        limit=5_000,
        timeout_s=1.0,
        retries=3,
        min_interval_s=0.001,
        metrics=metrics,
    )
    asyncio.run(client_429.fetch())
    gauges = metrics.snapshot()["gauges"]  # type: ignore[index]
    assert gauges["rest_used_weight_1m"] == 5990
