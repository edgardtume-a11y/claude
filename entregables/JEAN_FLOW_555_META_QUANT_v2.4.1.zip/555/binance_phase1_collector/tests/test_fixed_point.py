from __future__ import annotations

from pathlib import Path

import pytest

from binance_collector.fixed_point import (
    FIXED_SCALE,
    MAX_FIXED_VALUE,
    FixedPointError,
    format_fixed,
    parse_fixed,
)
from binance_collector.models import DepthSnapshot, DiffDepthEvent
from binance_collector.order_book import (
    ApplyResult,
    BookDomainError,
    BookInvariantError,
    LocalOrderBook,
)
from binance_collector.supply_chain import SupplyChainError, verified_wheel_plan


def _snapshot() -> DepthSnapshot:
    return DepthSnapshot(
        last_update_id=100,
        bids=(("1.00000000", "2.50000000"),),
        asks=(("1.00000002", "3"),),
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=1,
    )


def _diff(sequence: int, level: tuple[str, str]) -> DiffDepthEvent:
    return DiffDepthEvent(
        connection_id="fixed",
        event_time_ms=1,
        symbol="TUTUSDT",
        first_update_id=sequence,
        final_update_id=sequence,
        bids=(level,),
        asks=(),
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=1,
        raw_queue_size=0,
        capture_session_id="fixed-point-test-session",
        ingest_seq=sequence,
        source_socket_id="fixed:spot_combined",
    )


@pytest.mark.parametrize(
    ("text", "scaled", "canonical"),
    [
        ("0", 0, "0"),
        ("1", FIXED_SCALE, "1"),
        ("0001.230000000", 123_000_000, "1.23"),
        ("0.00000001", 1, "0.00000001"),
        ("92233720368.54775807", MAX_FIXED_VALUE, "92233720368.54775807"),
    ],
)
def test_fixed_point_is_exact_and_canonical(
    text: str,
    scaled: int,
    canonical: str,
) -> None:
    assert parse_fixed(text) == scaled
    assert format_fixed(scaled) == canonical


@pytest.mark.parametrize(
    "text",
    [
        "",
        ".1",
        "1.",
        "+1",
        "-1",
        " 1",
        "1e-8",
        "NaN",
        "Inf",
        "１.0",
        "0.000000001",
        "92233720368.54775808",
        "1" * 65,
    ],
)
def test_fixed_point_rejects_ambiguous_rounding_unicode_and_overflow(text: str) -> None:
    with pytest.raises(FixedPointError):
        parse_fixed(text)


def test_book_uses_ints_and_validates_stale_payloads() -> None:
    book = LocalOrderBook(100)
    book.load_snapshot(_snapshot())
    assert all(type(value) is int for value in (*book.bids.keys(), *book.bids.values()))
    # X6: format_fixed es la ÚNICA forma canónica y ahora la comparte el
    # replay (canonical_hash v2); el CSV conserva los strings exactos del
    # cable por separado.
    assert book.top_wire(1)[0][0] == ("1", "2.5")

    valid_stale = _diff(100, ("1", "2.5"))
    assert book.apply(valid_stale) is ApplyResult.STALE
    assert book.last_update_id == 100

    # [N5]/X7: un evento stale con payload corrupto ya no queda en el journal
    # sin que ningún camino lo valide: la clasificación stale también parsea.
    with pytest.raises(BookDomainError):
        book.apply(_diff(100, ("not-a-number", "also-invalid")))
    assert book.last_update_id == 100


def test_nonrepresentable_active_event_fails_without_mutation() -> None:
    book = LocalOrderBook(100)
    book.load_snapshot(_snapshot())
    before = dict(book.bids)
    with pytest.raises(BookInvariantError, match="requiere redondeo"):
        book.apply(_diff(101, ("0.999999999", "1")))
    assert dict(book.bids) == before
    assert book.last_update_id == 100


def _mini_supply_chain(root: Path) -> tuple[Path, Path]:
    import hashlib

    wheelhouse = root / "wheelhouse"
    wheelhouse.mkdir(parents=True)
    wheel = wheelhouse / "demo_pkg-1.2.3-py3-none-any.whl"
    wheel.write_bytes(b"trusted wheel bytes")
    digest = hashlib.sha256(wheel.read_bytes()).hexdigest()
    (root / "requirements.lock").write_text(
        f"demo-pkg==1.2.3 --hash=sha256:{digest}\n",
        encoding="ascii",
    )
    (wheelhouse / "WHEELHOUSE_MANIFEST.sha256").write_text(
        f"{digest}  {wheel.name}\n",
        encoding="ascii",
    )
    return wheel, root / "requirements.lock"


def test_supply_chain_plan_is_bijective_and_uses_direct_hash_url(
    tmp_path: Path,
) -> None:
    wheel, _ = _mini_supply_chain(tmp_path)
    plan = verified_wheel_plan(tmp_path)
    assert len(plan) == 1
    assert plan[0].path == wheel
    assert plan[0].direct_url.startswith("file:///")
    assert "#sha256=" in plan[0].direct_url


def test_supply_chain_rejects_post_manifest_wheel_change(tmp_path: Path) -> None:
    wheel, _ = _mini_supply_chain(tmp_path)
    wheel.write_bytes(b"substituted after manifest")
    with pytest.raises(SupplyChainError, match="SHA-256"):
        verified_wheel_plan(tmp_path)


def test_supply_chain_rejects_unlocked_extra_wheel(tmp_path: Path) -> None:
    _mini_supply_chain(tmp_path)
    extra = tmp_path / "wheelhouse" / "extra-1.0-py3-none-any.whl"
    extra.write_bytes(b"extra")
    with pytest.raises(SupplyChainError, match="no coinciden exactamente"):
        verified_wheel_plan(tmp_path)
