# Fixtures golden REALES — validación 2026-08-14 (host Windows objetivo)

Capturadas por `tools/capture_fixtures.py` v2.3.3 durante
`validacion_20260814T024137Z` (símbolo TUTUSDT, 50 mensajes por mercado,
SHA-256 y comando exacto en PROVENANCE.json). Verificadas después con el
decoder real (`decode_combined`): 100/100 payloads sin ProtocolError
(spot: 34 AggTrade + 8 Partial + 8 Diff; usdm: 24 Partial + 26 Diff).

ADVERTENCIA DE PROCEDENCIA: el archivo de USDⓈ-M se capturó desde el
endpoint LEGADO sin ruta (bug de capture_fixtures corregido en 2.3.4), que
desde 2026-04-23 solo entrega el nivel Public: por eso NO contiene ningún
aggTrade. El contrato del socket /market quedó demostrado por el smoke live
(BTCUSDT, >=100 mensajes decodificados, exit 0) de esa misma validación;
las fixtures golden de /market se archivarán en la próxima validación con
la herramienta corregida.
