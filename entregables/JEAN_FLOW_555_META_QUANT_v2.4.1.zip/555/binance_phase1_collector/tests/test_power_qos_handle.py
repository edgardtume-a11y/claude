"""[2.4.0] Contrato del opt-out de EcoQoS: tipos Win64 declarados.

Evidencia de campo que motiva estas pruebas (sesión aa1e3beafeec, 30 min,
BTCUSDT, Windows 11 x64, motor 2.3.9):

    low_latency_runtime ... fine_timer_1ms=True foreground_qos=False
    foreground_qos_error=6

El 6 es ERROR_INVALID_HANDLE: SetProcessInformation rechazó el HANDLE. Sin
`restype`/`argtypes`, ctypes trata el pseudo-handle `(HANDLE)-1` de
GetCurrentProcess como `int` de 32 bits y lo que llega a Win64 no es un
handle válido. Consecuencia: el opt-out de EcoQoS que 2.3.7 añadió para que
Windows 11 no degrade el proceso a E-cores ni ignore el temporizador de 1 ms
NUNCA se aplicó. Estas pruebas fijan el contrato para que no vuelva a
perderse en silencio.
"""

from __future__ import annotations

import ctypes
import sys
import types
from pathlib import Path

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from binance_collector import latency  # noqa: E402


def _kernel32_declarable(resultado: int = 1, handle: int = 0xFFFFFFFFFFFFFFFF):
    """Doble que SÍ admite atributos (como los punteros reales de ctypes)."""

    registro: dict[str, object] = {"handles": [], "llamadas": []}

    def GetCurrentProcess():  # noqa: N802 (API Win32)
        return handle

    def SetProcessInformation(h, clase, puntero, tamano):  # noqa: N802
        registro["handles"].append(h)
        estado = puntero._obj
        registro["llamadas"].append(
            (clase, estado.Version, estado.ControlMask, estado.StateMask, tamano)
        )
        return resultado

    doble = types.SimpleNamespace(
        GetCurrentProcess=GetCurrentProcess,
        SetProcessInformation=SetProcessInformation,
    )
    return doble, registro


def test_declara_tipos_win64_de_las_dos_funciones() -> None:
    doble, _ = _kernel32_declarable()

    ok, error = latency._set_power_throttling(doble, latency._POWER_MASK_CAPTURA, 0)

    assert ok is True
    assert error is None
    # El pseudo-handle debe viajar como puntero de 64 bits, no como int.
    assert doble.GetCurrentProcess.restype is ctypes.c_void_p
    assert doble.SetProcessInformation.argtypes == (
        ctypes.c_void_p,
        ctypes.c_int,
        ctypes.c_void_p,
        ctypes.c_uint32,
    )
    assert doble.SetProcessInformation.restype is ctypes.c_int


def test_el_handle_llega_entero_sin_truncar() -> None:
    # 0xFFFFFFFFFFFFFFFF es el pseudo-handle real en Win64. Si alguien
    # volviera a dejar que ctypes lo trate como int de 32 bits, aquí
    # llegaría 0xFFFFFFFF (o -1) y esta prueba lo delata.
    doble, registro = _kernel32_declarable(handle=0xFFFFFFFFFFFFFFFF)

    ok, _ = latency._set_power_throttling(doble, latency._POWER_MASK_CAPTURA, 0)

    assert ok is True
    assert registro["handles"] == [0xFFFFFFFFFFFFFFFF]


def test_struct_y_mascaras_intactos() -> None:
    # El struct PROCESS_POWER_THROTTLING_STATE no cambia en 2.4.0:
    # Version=1, ControlMask=EXECUTION_SPEED|IGNORE_TIMER_RESOLUTION, State=0.
    doble, registro = _kernel32_declarable()

    latency._set_power_throttling(doble, latency._POWER_MASK_CAPTURA, 0)

    clase, version, control, estado, tamano = registro["llamadas"][0]
    assert clase == latency._PROCESS_POWER_THROTTLING
    assert version == 1
    assert control == 0x5
    assert estado == 0
    assert tamano == 12  # tres DWORD


def test_handle_nulo_no_llama_a_la_api() -> None:
    doble, registro = _kernel32_declarable(handle=0)

    ok, error = latency._set_power_throttling(doble, latency._POWER_MASK_CAPTURA, 0)

    assert ok is False
    assert error is None
    assert registro["llamadas"] == []


def test_doble_sin_atributos_sigue_funcionando() -> None:
    # Los dobles antiguos (métodos ligados) no admiten .restype; la
    # declaración debe tolerarlo en vez de tumbar la captura.
    class _Kernel32Rigido:
        def __init__(self) -> None:
            self.llamadas: list[int] = []

        def GetCurrentProcess(self):  # noqa: N802 (API Win32)
            return -1

        def SetProcessInformation(self, h, clase, puntero, tamano):  # noqa: N802
            self.llamadas.append(clase)
            return 1

    rigido = _Kernel32Rigido()

    ok, error = latency._set_power_throttling(rigido, latency._POWER_MASK_CAPTURA, 0)

    assert ok is True
    assert error is None
    assert rigido.llamadas == [latency._PROCESS_POWER_THROTTLING]


def test_fallo_real_reporta_el_codigo() -> None:
    doble, _ = _kernel32_declarable(resultado=0)

    ok, error = latency._set_power_throttling(doble, latency._POWER_MASK_CAPTURA, 0)

    assert ok is False
    # En Windows real sería GetLastError; fuera de él, 0 o None.
    assert error in (None, 0)


def test_el_motor_declara_los_tipos_antes_de_pedir_el_opt_out(monkeypatch) -> None:
    # Contrato de extremo a extremo: fine_timer_resolution deja el informe
    # con foreground_qos=True y sin campo de error cuando el opt-out aplica.
    doble, registro = _kernel32_declarable()
    monkeypatch.setattr(latency, "_winmm", lambda: None)
    monkeypatch.setattr(latency, "_kernel32", lambda: doble)

    with latency.fine_timer_resolution() as informe:
        assert informe["foreground_qos"] is True
        assert "foreground_qos_error" not in informe

    # Al salir se devuelve el control al sistema (ControlMask=0).
    assert [llamada[2] for llamada in registro["llamadas"]] == [0x5, 0]
