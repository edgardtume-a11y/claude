from __future__ import annotations

from pathlib import Path

import pytest

from binance_collector.config import Settings
from binance_collector.models import AggTradeEvent, DiffDepthEvent, PartialDepthEvent, RawEnvelope
from binance_collector.normalize import EventSequencer, partial_depth_batch, trade_batch
from binance_collector.protocol import ServerShutdownNotice, decode_combined
from binance_collector.rest import SnapshotClient


TEST_SESSION = "test-capture-session-v2"


def _decode(path: Path):
    payload = path.read_bytes()
    settings = Settings().validated()
    return decode_combined(
        RawEnvelope(
            connection_id="c1",
            payload=payload,
            receive_utc_ns=1_720_000_000_300_000_000,
            receive_monotonic_ns=900_000,
            payload_bytes=len(payload),
            raw_queue_size=2,
            capture_session_id=TEST_SESSION,
            ingest_seq=1,
            source_socket_id="c1:spot_combined",
        ),
        symbol=settings.symbol,
        stream_names=settings.stream_names,
    )


def test_decodes_all_requested_and_canonical_streams(fixture_dir: Path) -> None:
    assert isinstance(_decode(fixture_dir / "agg_trade.json"), AggTradeEvent)
    assert isinstance(_decode(fixture_dir / "depth_partial.json"), PartialDepthEvent)
    assert isinstance(_decode(fixture_dir / "depth_diff.json"), DiffDepthEvent)


def test_partial_is_normalized_as_atomic_top20_replacement(fixture_dir: Path) -> None:
    event = _decode(fixture_dir / "depth_partial.json")
    assert isinstance(event, PartialDepthEvent)
    batch = partial_depth_batch(
        event,
        "TUTUSDT",
        EventSequencer(TEST_SESSION),
        "full_top20_replacement",
    )
    assert batch.rows[0]["record_type"] == "L2_PARTIAL"
    assert batch.rows[0]["level_count"] == 4
    assert batch.rows[0]["sequence_last"] == 103
    assert [row["side"] for row in batch.rows[1:]] == ["bid", "bid", "ask", "ask"]


def test_trade_keeps_decimal_strings_and_exchange_ids(fixture_dir: Path) -> None:
    event = _decode(fixture_dir / "agg_trade.json")
    assert isinstance(event, AggTradeEvent)
    row = trade_batch(event, EventSequencer(TEST_SESSION), None).rows[0]
    assert row["price"] == "0.03450000"
    assert row["quantity"] == "125.00000000"
    assert row["aggregate_trade_id"] == 5001
    assert row["buyer_is_maker"] is True


def test_server_shutdown_is_not_misclassified_as_bad_market_payload() -> None:
    settings = Settings().validated()
    with pytest.raises(ServerShutdownNotice):
        decode_combined(
            RawEnvelope(
                connection_id="c1",
                payload=b'{"stream":"!serverShutdown","data":{"e":"serverShutdown","E":1}}',
                receive_utc_ns=1,
                receive_monotonic_ns=1,
                payload_bytes=70,
                raw_queue_size=0,
                capture_session_id=TEST_SESSION,
                ingest_seq=1,
                source_socket_id="c1:spot_combined",
            ),
            symbol=settings.symbol,
            stream_names=settings.stream_names,
        )


def test_retry_after_is_capped_and_rejects_nonfinite() -> None:
    """P1.3: sin tope, un Retry-After de 7200/1e12/'inf' dormía para siempre
    con el lock de snapshots tomado. Cota en 60 s; NaN/inf/negativos caen al
    backoff exponencial (< 8 s)."""

    assert SnapshotClient._retry_delay(0, "7200") == 60.0
    assert SnapshotClient._retry_delay(0, "30") == 30.0
    assert SnapshotClient._retry_delay(0, "0") == 0.25
    for bogus in ("inf", "nan", "-5", "1e12"):
        delay = SnapshotClient._retry_delay(0, bogus)
        assert 0.0 < delay <= 60.0


def test_snapshot_limit_cannot_silently_degrade_book_completeness() -> None:
    with pytest.raises(ValueError, match="debe ser 5000"):
        Settings(snapshot_limit=100).validated()


def test_negative_operational_timing_is_rejected() -> None:
    with pytest.raises(ValueError, match="deben ser positivos"):
        Settings(flush_interval_s=-1).validated()
