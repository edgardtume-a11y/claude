from __future__ import annotations

import asyncio
import json
import time

import aiohttp
import pytest

from binance_collector.dashboard import (
    DashboardDataError,
    DashboardServer,
    MarketStateHub,
    _ClientMailbox,
)


def _book(
    hub: MarketStateHub,
    market: str,
    *,
    symbol: str = "TUTUSDT",
    generation: int = 1,
    sequence: int = 100,
    monotonic_ns: int = 2_000_000_000,
    bid: str = "0.0999",
    ask: str = "0.1001",
) -> None:
    hub.publish_book(
        market=market,
        symbol=symbol,
        generation=generation,
        sequence=sequence,
        bids=[(bid, "120")],
        asks=[(ask, "100")],
        receive_utc_ns=1_800_000_000_000_000_000,
        receive_monotonic_ns=monotonic_ns,
        exchange_event_time_ms=1_800_000_000_000,
    )


def test_hub_copies_book_and_computes_basis_only_for_valid_matching_books() -> None:
    hub = MarketStateHub(top_levels=2, stale_after_s=3)
    source_bids = [("0.0999", "120"), ("0.0998", "40")]
    hub.publish_book(
        market="spot",
        symbol="TUTUSDT",
        generation=1,
        sequence=100,
        bids=source_bids,
        asks=[("0.1001", "100")],
        receive_utc_ns=1,
        receive_monotonic_ns=2_000_000_000,
    )
    source_bids[0] = ("9", "9")
    _book(
        hub,
        "usdm_futures",
        bid="0.1009",
        ask="0.1011",
        monotonic_ns=2_000_000_000,
    )

    frame = hub.snapshot(now_monotonic_ns=2_100_000_000)

    spot = frame["markets"]["spot"]  # type: ignore[index]
    assert spot["book"]["bids"][0] == ("0.0999", "120")  # type: ignore[index]
    assert spot["status"] == "SYNCED"  # type: ignore[index]
    assert frame["basis_bps"] == pytest.approx(100.0)


def test_trusted_fixed_path_preserves_half_tick_midpoint() -> None:
    hub = MarketStateHub(top_levels=2)
    hub.publish_trusted_fixed_book(
        market="spot",
        symbol="TUTUSDT",
        generation=1,
        sequence=100,
        bids=((10_000_000, 12_000_000_000),),
        asks=((10_000_001, 10_000_000_000),),
        receive_utc_ns=1,
        receive_monotonic_ns=2_000_000_000,
    )

    book = hub.snapshot(now_monotonic_ns=2_000_000_001)["markets"]["spot"][  # type: ignore[index]
        "book"
    ]
    assert book["bids"][0] == ("0.1", "120")
    assert book["asks"][0] == ("0.10000001", "100")
    assert book["mid"] == "0.100000005"
    assert book["spread"] == "0.00000001"


def test_stale_or_different_symbols_suppress_basis() -> None:
    hub = MarketStateHub(stale_after_s=1)
    _book(hub, "spot", monotonic_ns=1_000_000_000)
    _book(hub, "usdm_futures", monotonic_ns=1_000_000_000)
    stale = hub.snapshot(now_monotonic_ns=2_100_000_001)
    assert stale["markets"]["spot"]["status"] == "STALE"  # type: ignore[index]
    assert stale["basis_bps"] is None

    other = MarketStateHub()
    _book(other, "spot", symbol="TUTUSDT")
    _book(other, "usdm_futures", symbol="BTCUSDT")
    assert other.snapshot(now_monotonic_ns=2_000_000_001)["basis_bps"] is None


def test_generation_sequence_and_symbol_guards() -> None:
    hub = MarketStateHub()
    _book(hub, "spot", generation=2, sequence=200)
    hub.publish_status(market="spot", status="SYNCING", clear_book=True)
    with pytest.raises(DashboardDataError, match="generación"):
        _book(hub, "spot", generation=1, sequence=999)
    with pytest.raises(DashboardDataError, match="secuencia"):
        _book(hub, "spot", generation=2, sequence=200)
    with pytest.raises(DashboardDataError, match="Símbolo"):
        _book(hub, "spot", symbol="BTCUSDT", generation=3, sequence=1)


def test_trade_history_is_bounded_and_cannot_mix_symbols() -> None:
    hub = MarketStateHub(trade_history=3, trade_frame_limit=2)
    _book(hub, "spot")
    for trade_id in range(4):
        hub.publish_trade(
            market="spot",
            symbol="TUTUSDT",
            aggregate_trade_id=trade_id,
            price="0.1",
            quantity="10",
            buyer_is_maker=bool(trade_id % 2),
            exchange_trade_time_ms=1_800_000_000_000 + trade_id,
            receive_utc_ns=1_800_000_000_000_000_000 + trade_id,
        )
    trades = hub.snapshot(now_monotonic_ns=2_000_000_001)["markets"]["spot"]["trades"]  # type: ignore[index]
    assert [trade["id"] for trade in trades] == [2, 3]
    assert trades[-1]["aggressor"] == "SELL"
    with pytest.raises(DashboardDataError, match="Trade"):
        hub.publish_trade(
            market="spot",
            symbol="BTCUSDT",
            aggregate_trade_id=5,
            price="1",
            quantity="1",
            buyer_is_maker=False,
            exchange_trade_time_ms=1,
            receive_utc_ns=1,
        )


@pytest.mark.parametrize(
    ("bids", "asks", "message"),
    [
        ([("0.09", "1"), ("0.10", "1")], [("0.11", "1")], "desordenados"),
        ([("0.10", "1")], [("0.09", "1")], "cruzado"),
        ([("nan", "1")], [("0.11", "1")], "dominio"),
    ],
)
@pytest.mark.parametrize("publisher_name", ["publish_book", "publish_trusted_book"])
def test_invalid_book_is_never_exposed(
    bids: list[tuple[str, str]],
    asks: list[tuple[str, str]],
    message: str,
    publisher_name: str,
) -> None:
    hub = MarketStateHub()
    with pytest.raises(DashboardDataError, match=message):
        getattr(hub, publisher_name)(
            market="spot",
            symbol="TUTUSDT",
            generation=1,
            sequence=1,
            bids=bids,
            asks=asks,
            receive_utc_ns=1,
            receive_monotonic_ns=1,
        )


def test_client_mailbox_is_bounded_latest_frame_wins() -> None:
    hub = MarketStateHub()
    mailbox = _ClientMailbox(hub, size=2)
    mailbox.offer(b"A")
    mailbox.offer(b"B")
    mailbox.offer(b"C")
    assert mailbox.queue.qsize() == 2
    assert mailbox.queue.get_nowait() == b"B"
    assert mailbox.queue.get_nowait() == b"C"
    assert hub.snapshot()["ui_metrics"]["client_frame_drops"] == 1  # type: ignore[index]


def test_server_rejects_non_loopback_bind() -> None:
    with pytest.raises(ValueError, match="loopback"):
        DashboardServer(MarketStateHub(), host="0.0.0.0")


@pytest.mark.asyncio
async def test_local_server_serves_dashboard_state_and_websocket() -> None:
    hub = MarketStateHub()
    _book(hub, "spot", monotonic_ns=time.monotonic_ns())
    server = DashboardServer(hub, port=0, publish_interval_s=0.01, max_clients=1)
    await server.start()
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{server.url}/") as response:
                body = await response.text()
                assert response.status == 200
                assert "JEAN_FLOW" in body
                assert "Mapa temporal de liquidez" in body
                assert response.headers["X-Frame-Options"] == "DENY"
            async with session.get(f"{server.url}/api/state") as response:
                frame = await response.json()
                assert frame["markets"]["spot"]["book"]["sequence"] == 100
            websocket = await session.ws_connect(f"{server.url}/ws")
            message = await asyncio.wait_for(websocket.receive(), timeout=1)
            assert message.type is aiohttp.WSMsgType.BINARY
            assert json.loads(message.data)["type"] == "market_frame"
            with pytest.raises(aiohttp.WSServerHandshakeError) as saturated:
                await session.ws_connect(f"{server.url}/ws")
            assert saturated.value.status == 503
            await websocket.close()
            with pytest.raises(aiohttp.WSServerHandshakeError) as forbidden:
                await session.ws_connect(
                    f"{server.url}/ws", headers={"Origin": "https://example.com"}
                )
            assert forbidden.value.status == 403
    finally:
        await server.close()


@pytest.mark.asyncio
async def test_server_close_terminates_an_active_websocket() -> None:
    server = DashboardServer(MarketStateHub(), port=0, publish_interval_s=0.01)
    await server.start()
    session = aiohttp.ClientSession()
    websocket = await session.ws_connect(f"{server.url}/ws")
    await asyncio.wait_for(websocket.receive(), timeout=1)
    try:
        await asyncio.wait_for(server.close(), timeout=1)
        # Un market_frame publicado justo antes del cierre puede seguir en
        # vuelo (verificado en Windows con el aiohttp compilado): los frames
        # de datos previos al handshake de cierre son legales; lo exigible es
        # que el cierre llegue acotado en el tiempo.
        for _ in range(50):
            closing = await asyncio.wait_for(websocket.receive(), timeout=1)
            if closing.type in {
                aiohttp.WSMsgType.CLOSE,
                aiohttp.WSMsgType.CLOSED,
                aiohttp.WSMsgType.CLOSING,
            }:
                break
            assert closing.type in {
                aiohttp.WSMsgType.BINARY,
                aiohttp.WSMsgType.TEXT,
            }
        else:
            raise AssertionError("El servidor no cerró el WebSocket activo")
    finally:
        await websocket.close()
        await session.close()
        await server.close()
