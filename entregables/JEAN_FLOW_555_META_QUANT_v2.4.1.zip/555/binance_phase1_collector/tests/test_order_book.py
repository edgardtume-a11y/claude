from __future__ import annotations

import pytest

from binance_collector.models import DepthSnapshot, DiffDepthEvent
from binance_collector.order_book import (
    ApplyResult,
    BookInvariantError,
    LocalOrderBook,
    SequenceGap,
    SequenceOverlap,
    retained_after_snapshot,
)


TEST_SESSION = "test-capture-session-v2"


def snapshot(sequence: int = 100) -> DepthSnapshot:
    return DepthSnapshot(
        last_update_id=sequence,
        bids=(("99", "2"), ("98", "3")),
        asks=(("101", "4"), ("102", "5")),
        receive_utc_ns=1,
        receive_monotonic_ns=1,
        payload_bytes=100,
    )


def diff(first: int, final: int, *, bids=(), asks=()) -> DiffDepthEvent:
    return DiffDepthEvent(
        connection_id="c1",
        event_time_ms=1,
        symbol="TUTUSDT",
        first_update_id=first,
        final_update_id=final,
        bids=tuple(bids),
        asks=tuple(asks),
        receive_utc_ns=2,
        receive_monotonic_ns=2,
        payload_bytes=50,
        raw_queue_size=0,
        capture_session_id=TEST_SESSION,
        ingest_seq=first,
        source_socket_id="c1:spot_combined",
    )


def test_snapshot_bridge_overlap_duplicate_delete_and_gap() -> None:
    book = LocalOrderBook(max_levels_per_side=100)
    book.load_snapshot(snapshot())
    bridge = diff(100, 103, bids=(("99", "7"),), asks=(("101", "0"),))
    assert book.apply(bridge) is ApplyResult.APPLIED
    assert book.last_update_id == 103
    assert book.apply(bridge) is ApplyResult.STALE
    # R2.5/[P13]: tras el primer evento aplicado, el contrato Spot exige
    # U == u_anterior + 1 EXACTO. El solapamiento se aplicaba en silencio;
    # ahora es fail-closed sin mutar el libro.
    with pytest.raises(SequenceOverlap, match="esperado U=104"):
        book.apply(diff(102, 105, bids=(("97", "1"),)))
    assert book.last_update_id == 103
    assert book.apply(diff(104, 105, bids=(("97", "1"),))) is ApplyResult.APPLIED
    assert book.apply(diff(106, 107, asks=(("103", "2"),))) is ApplyResult.APPLIED
    with pytest.raises(SequenceGap, match="esperado 108"):
        book.apply(diff(109, 110, bids=(("96", "1"),)))


def test_bridge_discards_stale_and_accepts_range_covering_next_id() -> None:
    events = [diff(95, 100), diff(100, 103), diff(102, 105)]
    retained = retained_after_snapshot(100, events)
    assert [(event.first_update_id, event.final_update_id) for event in retained] == [
        (100, 103),
        (102, 105),
    ]


def test_bridge_accepts_exact_successor_and_rejects_gap() -> None:
    retained = retained_after_snapshot(100, [diff(101, 103)])
    assert [(event.first_update_id, event.final_update_id) for event in retained] == [
        (101, 103)
    ]
    with pytest.raises(SequenceGap):
        retained_after_snapshot(100, [diff(102, 103)])


def test_conflicting_duplicate_and_crossed_book_fail_closed() -> None:
    book = LocalOrderBook(max_levels_per_side=100)
    book.load_snapshot(snapshot())
    book.apply(diff(101, 102, bids=(("99", "6"),)))
    with pytest.raises(BookInvariantError, match="conflictivo"):
        book.apply(diff(101, 102, bids=(("99", "8"),)))

    crossed = LocalOrderBook(max_levels_per_side=100)
    crossed.load_snapshot(snapshot())
    before_bids = dict(crossed.bids)
    before_sequence = crossed.last_update_id
    with pytest.raises(BookInvariantError, match="cruzado"):
        crossed.apply(diff(101, 101, bids=(("105", "1"),)))
    assert dict(crossed.bids) == before_bids
    assert crossed.last_update_id == before_sequence


def test_duplicate_price_inside_diff_is_rejected_without_mutation() -> None:
    book = LocalOrderBook(max_levels_per_side=100)
    book.load_snapshot(snapshot())
    before_bids = dict(book.bids)
    with pytest.raises(BookInvariantError, match="nivel duplicado"):
        book.apply(diff(101, 101, bids=(("99", "7"), ("99.0", "8"))))
    assert dict(book.bids) == before_bids
    assert book.last_update_id == 100


def test_invalid_snapshot_is_rejected_without_replacing_valid_state() -> None:
    book = LocalOrderBook(max_levels_per_side=100)
    book.load_snapshot(snapshot())
    before_bids = dict(book.bids)
    before_asks = dict(book.asks)

    crossed = DepthSnapshot(
        last_update_id=200,
        bids=(("105", "1"),),
        asks=(("101", "1"),),
        receive_utc_ns=2,
        receive_monotonic_ns=2,
        payload_bytes=50,
    )
    with pytest.raises(BookInvariantError, match="cruzado"):
        book.load_snapshot(crossed)

    assert dict(book.bids) == before_bids
    assert dict(book.asks) == before_asks
    assert book.last_update_id == 100

    zero_quantity = DepthSnapshot(
        last_update_id=201,
        bids=(("99", "0"),),
        asks=(("101", "1"),),
        receive_utc_ns=2,
        receive_monotonic_ns=2,
        payload_bytes=50,
    )
    with pytest.raises(BookInvariantError, match="no positiva"):
        book.load_snapshot(zero_quantity)

    assert dict(book.bids) == before_bids
    assert dict(book.asks) == before_asks
    assert book.last_update_id == 100
