"""Smoke live opt-in contra Binance real (P0.1.4, oráculo O=1).

Se habilita con RUN_BINANCE_LIVE=1 (y red). Por cada mercado conecta los
sockets REALES de `Settings.for_market(...)`, recibe mensajes crudos, pasa
CADA uno por `decode_combined` exigiendo cero ProtocolError y, en USDⓈ-M,
verifica la cadena `pu` sobre los diffs recibidos.

El símbolo por defecto es BTCUSDT (alto volumen: llena las cuotas en
segundos); puede cambiarse con RUN_BINANCE_LIVE_SYMBOL.
"""

from __future__ import annotations

import asyncio
import os
import time

import pytest
from websockets.asyncio.client import connect
from websockets.exceptions import ConnectionClosed

from binance_collector.config import Settings
from binance_collector.models import DiffDepthEvent, RawEnvelope
from binance_collector.protocol import decode_combined

_LIVE = os.getenv("RUN_BINANCE_LIVE") == "1"
_SYMBOL = os.getenv("RUN_BINANCE_LIVE_SYMBOL", "BTCUSDT")
# El socket de trades de un símbolo de bajo volumen puede tardar; con BTCUSDT
# ambos sockets llenan la cuota en segundos.
_MESSAGES_PER_SOCKET = 100
_SOCKET_TIMEOUT_S = 120.0
_ATTEMPTS_PER_SOCKET = 2


def _role_for_stream(market: str, stream_names: tuple[str, str, str], stream: str) -> str:
    if market == "spot":
        return "spot_combined"
    if stream == stream_names[0]:
        return "usdm_market_trades"
    return "usdm_public_depth"


@pytest.mark.integration
@pytest.mark.skipif(not _LIVE, reason="Define RUN_BINANCE_LIVE=1 para habilitar red real")
@pytest.mark.asyncio
@pytest.mark.parametrize("market", ["spot", "usdm_futures"])
async def test_receives_and_decodes_real_market_data(market: str) -> None:
    settings = Settings.for_market(market, symbol=_SYMBOL)
    previous_diff_u: int | None = None
    diff_chain_checked = 0
    for source_role, url in settings.websocket_sources:
        # [2.3.2] Dos intentos por socket con telemetría. Evidencia de campo:
        # un socket sano quedó a cero durante ~119 s mientras OTRA consola
        # ejecutaba la suite offline en el mismo host; un timeout aislado de
        # red/carga no debe tumbar toda la validación, y el intento fallido
        # queda impreso (sin reintentos ocultos).
        for attempt in range(1, _ATTEMPTS_PER_SOCKET + 1):
            decoded = 0
            started_monotonic = time.monotonic()
            deadline = started_monotonic + _SOCKET_TIMEOUT_S
            if market == "usdm_futures" and source_role == "usdm_public_depth":
                # Una reconexión pierde diffs intermedios: la cadena pu se
                # re-ancla por intento (los enlaces verificados se acumulan).
                previous_diff_u = None
            try:
                async with connect(
                    url,
                    compression=None,
                    max_size=2 * 1024 * 1024,
                    open_timeout=15,
                ) as websocket:
                    while decoded < _MESSAGES_PER_SOCKET:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            raise TimeoutError(
                                f"cuota incompleta en {_SOCKET_TIMEOUT_S:.0f}s"
                            )
                        payload = await asyncio.wait_for(
                            websocket.recv(decode=False), timeout=remaining
                        )
                        if isinstance(payload, str):
                            payload = payload.encode("utf-8")
                        envelope = RawEnvelope(
                            connection_id="live",
                            payload=payload,
                            receive_utc_ns=time.time_ns(),
                            receive_monotonic_ns=time.monotonic_ns(),
                            payload_bytes=len(payload),
                            raw_queue_size=0,
                            capture_session_id="live-smoke-session",
                            ingest_seq=decoded + 1,
                            source_socket_id=f"live:{source_role}",
                        )
                        # Cero ProtocolError sobre tráfico real: el contrato
                        # completo (stream names, shape, campos, símbolos)
                        # contra el exchange.
                        event = decode_combined(
                            envelope,
                            symbol=settings.symbol,
                            stream_names=settings.stream_names,
                            market=market,
                        )
                        decoded += 1
                        if (
                            market == "usdm_futures"
                            and source_role == "usdm_public_depth"
                            and isinstance(event, DiffDepthEvent)
                        ):
                            assert event.previous_final_update_id is not None
                            if previous_diff_u is not None:
                                assert (
                                    event.previous_final_update_id
                                    == previous_diff_u
                                ), (
                                    "cadena pu rota: "
                                    f"pu={event.previous_final_update_id} "
                                    f"esperado={previous_diff_u}"
                                )
                                diff_chain_checked += 1
                            previous_diff_u = event.final_update_id
            except (TimeoutError, OSError, ConnectionClosed) as exc:
                elapsed = time.monotonic() - started_monotonic
                print(
                    f"[smoke {market}/{source_role}] intento "
                    f"{attempt}/{_ATTEMPTS_PER_SOCKET}: "
                    f"{decoded}/{_MESSAGES_PER_SOCKET} mensajes en "
                    f"{elapsed:.1f}s ({type(exc).__name__}: {exc})",
                    flush=True,
                )
                if attempt >= _ATTEMPTS_PER_SOCKET:
                    pytest.fail(
                        f"{market}/{source_role}: solo "
                        f"{decoded}/{_MESSAGES_PER_SOCKET} mensajes tras "
                        f"{_ATTEMPTS_PER_SOCKET} intentos de "
                        f"{_SOCKET_TIMEOUT_S:.0f}s; no ejecute INICIAR ni "
                        "otras cargas pesadas durante la validación y "
                        "reintente"
                    )
                continue
            elapsed = time.monotonic() - started_monotonic
            print(
                f"[smoke {market}/{source_role}] intento {attempt}: "
                f"{decoded} mensajes en {elapsed:.1f}s -> OK",
                flush=True,
            )
            break
    if market == "usdm_futures":
        assert diff_chain_checked > 0, "no se verificó ningún enlace pu"
