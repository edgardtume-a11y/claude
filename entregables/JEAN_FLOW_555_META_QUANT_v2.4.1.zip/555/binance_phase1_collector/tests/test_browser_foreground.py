"""[2.4.1] El panel no se abre solo durante una etapa certificable.

Evidencia de campo (sesión `aa1e3beafeec`, 30 min, BTCUSDT, 2026-08-15):
`control/browser.json` registra `attempted_utc_ns` a los **4.0 s** de la
primera línea del log del proceso. A partir de ahí el `max` de
`writer_cooperative_yield` de USDⓈ-M subió en escalones —1.036 ms a los 5 s,
3.8 a los 10 s, 9.404 a los 30 s, 14.2 a los 105 s— y se quedó clavado en
14.2 el resto de la corrida. 14.2 ms es del orden del tic de 15.625 ms del
temporizador degradado: Windows 11 aplica EcoQoS al proceso cuya ventana NO
está en primer plano, y abrirle al usuario un navegador encima de la consola
es justamente quitarle el primer plano a la captura. El usuario, además,
tenía que volver a la consola a mano una y otra vez.

Contrato: en etapas certificables NO se abre; en uso normal sí (salvo
`--no-browser`); y la evidencia dice SIEMPRE qué pasó, con las mismas claves.
"""

from __future__ import annotations

import inspect
import sys
from pathlib import Path

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from binance_collector import launcher  # noqa: E402

_LAUNCHER_FUENTE = (_SRC / "binance_collector" / "launcher.py").read_text(
    encoding="utf-8"
)

_NORMAL = launcher.RunSpec("normal", None)
_ETAPA_10M = launcher.RunSpec("10m", 600.0)
_ETAPA_30M = launcher.RunSpec("30m", 1_800.0)
_ETAPA_120M = launcher.RunSpec("120m", 7_200.0)


def test_ninguna_etapa_certificable_abre_el_panel() -> None:
    for spec in (_ETAPA_10M, _ETAPA_30M, _ETAPA_120M):
        abrir, motivo = launcher._should_open_browser(spec, no_browser=False)
        assert abrir is False, spec.label
        assert motivo == "CERTIFICATION_FOREGROUND_PROTECTION", spec.label


def test_uso_normal_sigue_abriendo_el_panel() -> None:
    abrir, motivo = launcher._should_open_browser(_NORMAL, no_browser=False)
    assert abrir is True
    assert motivo is None


def test_la_bandera_del_usuario_manda_en_uso_normal() -> None:
    abrir, motivo = launcher._should_open_browser(_NORMAL, no_browser=True)
    assert abrir is False
    assert motivo == "USER_REQUESTED_NO_BROWSER"


def test_la_bandera_no_cambia_el_veredicto_de_una_etapa_certificable() -> None:
    # Con o sin bandera, una etapa certificable jamás abre el panel.
    abrir, _ = launcher._should_open_browser(_ETAPA_30M, no_browser=True)
    assert abrir is False


def test_la_evidencia_tiene_las_mismas_claves_se_abra_o_no() -> None:
    abierto = launcher._browser_evidence(
        "http://127.0.0.1:51890",
        opened=True,
        error=None,
        attempted_utc_ns=1786762600088352800,
        skip_reason=None,
    )
    omitido = launcher._browser_evidence(
        "http://127.0.0.1:51890",
        opened=False,
        error=None,
        attempted_utc_ns=None,
        skip_reason="CERTIFICATION_FOREGROUND_PROTECTION",
    )
    assert set(abierto) == set(omitido) == {
        "attempted_utc_ns",
        "opened",
        "error",
        "url",
        "skipped",
        "skip_reason",
    }
    assert abierto["skipped"] is False and abierto["skip_reason"] is None
    assert omitido["skipped"] is True
    assert omitido["skip_reason"] == "CERTIFICATION_FOREGROUND_PROTECTION"
    # Un run omitido no puede fingir que lo intentó.
    assert omitido["attempted_utc_ns"] is None
    assert omitido["opened"] is False


def test_run_capture_acepta_la_politica_del_panel() -> None:
    parametros = inspect.signature(launcher.run_capture).parameters
    assert parametros["open_browser"].kind is inspect.Parameter.KEYWORD_ONLY
    assert parametros["browser_skip_reason"].kind is inspect.Parameter.KEYWORD_ONLY


def test_main_decide_con_la_funcion_y_se_lo_pasa_a_run_capture() -> None:
    # Contrato de origen: nadie puede volver a llamar a run_capture sin
    # declarar la política del panel.
    principal = _LAUNCHER_FUENTE.index("def main(")
    decision = _LAUNCHER_FUENTE.index("_should_open_browser(", principal)
    captura = _LAUNCHER_FUENTE.index("run_capture(", decision)
    assert decision < captura
    assert "open_browser=abrir_panel" in _LAUNCHER_FUENTE
    assert "browser_skip_reason=motivo_panel" in _LAUNCHER_FUENTE


def test_la_bandera_existe_en_la_linea_de_comandos() -> None:
    args = launcher._parser().parse_args(["--mode", "full", "--symbol", "BTCUSDT"])
    assert args.no_browser is False
    args = launcher._parser().parse_args(["--no-browser"])
    assert args.no_browser is True


def test_solo_hay_una_puerta_para_abrir_el_navegador() -> None:
    # webbrowser.open sólo puede invocarse desde _open_browser_once, y
    # _open_browser_once sólo desde la rama guardada por `if open_browser:`.
    assert _LAUNCHER_FUENTE.count("webbrowser.open(") == 1
    assert _LAUNCHER_FUENTE.count("_open_browser_once(") == 2  # def + 1 llamada
    llamada = _LAUNCHER_FUENTE.index("browser_opened, browser_error = _open_browser_once(")
    guarda = _LAUNCHER_FUENTE.rindex("if open_browser:", 0, llamada)
    assert guarda < llamada


# --- Segunda puerta: el MOTOR (entry point público `jean-flow`) -------------


def test_el_launcher_siempre_le_pasa_no_browser_al_motor() -> None:
    # Si alguien quitara este literal, el motor volvería a abrir el panel en
    # etapas certificables y ningún otro test lo notaría.
    comando = _LAUNCHER_FUENTE.index("def run_capture(")
    aislado = _LAUNCHER_FUENTE.index("_isolated_command(", comando)
    fin = _LAUNCHER_FUENTE.index("if spec.healthy_seconds is not None:", aislado)
    assert '"--no-browser"' in _LAUNCHER_FUENTE[aislado:fin]


def test_el_motor_no_abre_el_panel_en_una_etapa_certificable() -> None:
    from binance_collector import dual_main

    fuente = (
        _SRC / "binance_collector" / "dual_main.py"
    ).read_text(encoding="utf-8")
    apertura = fuente.index("webbrowser.open, dashboard.url")
    guarda = fuente.rindex("if healthy_seconds is not None:", 0, apertura)
    bandera = fuente.rindex("if not args.no_browser", 0, guarda)
    # La guarda de certificación está DENTRO del bloque de la bandera y
    # ANTES de la apertura: ninguna etapa con duración sana exigida abre.
    assert bandera < guarda < apertura
    assert "CERTIFICATION_FOREGROUND_PROTECTION" in fuente
    # Y sigue existiendo una sola apertura en el motor.
    assert fuente.count("webbrowser.open") == 1
    assert dual_main is not None
