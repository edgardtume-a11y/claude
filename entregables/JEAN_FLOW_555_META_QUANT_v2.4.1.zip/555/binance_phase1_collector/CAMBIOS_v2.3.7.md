# CAMBIOS v2.3.7 — El motor se declara trabajo de primer plano

Una sola corrección, sin tocar ningún umbral, gate, esquema ni formato.
Continúa la cadena de 2.3.6 con la evidencia de su primer run de campo.

## Evidencia de campo (sesión `dda44a52ff1f`, C:\JF\555, v2.3.6, 14-ago-2026)

La regla de medir de 2.3.6 funcionó: decimales reales en todas las
duraciones (book_apply 1.4/4.29 ms, book_pipeline 2.061 ms en spot, parse
0.21/0.35 ms), `metric_errors` vacío en ambos mercados (el off-by-one
murió) y todos los gates de datos en verde otra vez (commitment, identidad,
replays con sellos idénticos, 0 resets, 600.0 s). Quedaron DOS números al
filo, ambos del mismo tipo:

- `writer_yield_p99` 6.907/9.586 ms (límite 5): el MISMO sleep que en la
  sesión anterior (5ebb3efde620, sin ninguna de estas correcciones) había
  medido 3.085/3.898 ms. El writer se volvió 2-3x más lento, no más rápido.
- `book_pipeline_p99` futuros 5.272 ms (límite 5): la parte offloaded
  (`asyncio.to_thread`) espera despertares de hilo, misma sensibilidad.

Y la pista decisiva: el log registró `fine_timer_1ms=True` — Windows
ACEPTÓ la petición del temporizador de 1 ms — pero `event_loop_lag` p99
quedó en 24 ms, idéntico a cuando nadie pedía nada. Petición aceptada y
efecto nulo.

## Causa raíz

Windows 11 aplica a los procesos cuya ventana está minimizada u ocluida
(la consola negra durante una captura de horas, minimizada a las 6 a. m.)
dos degradaciones de energía: IGNORA las peticiones de resolución de
temporizador aunque las haya aceptado, y programa el proceso bajo EcoQoS —
en esta laptop (Intel híbrido P+E), sobre los E-cores. Resultado: sleeps y
despertares de hilo 2-3x más tardíos exactamente cuando el motor cree que
tiene el temporizador fino.

## Corrección

`fine_timer_resolution()` (latency.py) añade el opt-out oficial:
`SetProcessInformation(ProcessPowerThrottling)` con
`EXECUTION_SPEED | IGNORE_TIMER_RESOLUTION` y `StateMask=0` — "no me
degrades a E-cores, respeta mi temporizador aunque mi ventana esté
minimizada". Al salir devuelve el control al sistema (`ControlMask=0`).
Mejor esfuerzo: si kernel32 no coopera, la captura continúa y el log lo
dice (`foreground_qos=False`). Los tres puntos de entrada (dual_main,
main, banco del preflight) ya usaban este contexto: cero cambios de
cableado.

## Regla operativa que la evidencia confirma

Las certificaciones se corren con la laptop enchufada, sin suspender, sin
programas pesados — y AHORA el proceso queda exento de la degradación por
ventana minimizada. Aun así, dejar la ventana negra visible (no minimizada)
sigue siendo lo recomendado durante una certificación: menos heurísticas de
energía en juego, más margen.

## Pruebas

`tests/test_metrics_fidelity.py` crece a 12: el opt-out envía exactamente
`(Version=1, ControlMask=0x5, StateMask=0)` al entrar y `ControlMask=0` al
salir (leído del struct real vía un kernel32 simulado), un
SetProcessInformation rechazado no intenta restaurar, y los casos previos
del temporizador quedan intactos con el nuevo informe
`{timer_1ms, foreground_qos}`. Suite offline completa: **238 passed,
2 skipped**.

## Sin cambios

Umbrales EXACTAMENTE iguales (`book_*_p99 <= 5 ms`,
`writer_yield_p99 <= 5 ms`, `event_loop_lag p99 <= 40 ms` revisión 2.3.4),
esquema 2.0.0, journals, sellos, comando aislado (`-X utf8`, contrato
2.3.5), regla de medir (perf_counter_ns, contrato 2.3.6).
