# CAMBIOS v2.3.2 — Correcciones con evidencia de campo (primer despliegue real)

Versión previa: 2.3.0/2.3.1. Todos los cambios de esta iteración nacen de la
**primera ejecución real** del release en el equipo Windows 11 objetivo
(es-ES, Python 3.12.10) contra Binance real: sesión
`45896a2c99aa4a279d27224c69270eba` (TUTUSDT, Spot + USDⓈ-M simultáneos,
SYNCED en ambos mercados, dashboard en vivo), más una ejecución de
`VALIDAR_EN_WINDOWS.cmd` y un intento de modo 3. La evidencia cruda quedó en
el `runs.zip` del host y en `validacion_20260814T013512Z/`.

## Resultado central de la evidencia (antes de los cambios)

La captura real fue **íntegra**: `audit journal` = PASS en ambos mercados
(replay determinista, hash canónico v2 calculado), `audit identity` = PASS
con **C_ing = 1.0** (9 558/9 558 ingest únicos, cero conflictos K1, cero
huecos). Es la primera validación O=1 del pipeline completo con tráfico real
en el host real. Los fallos observados fueron TODOS de gates de proceso, no
de datos — y dos de ellos eran falsos positivos de esta suite:

## 1. `PARENT_HEARTBEAT_LOST` falso con launcher vivo (motor, P0)

**Hecho:** a los 3.7 min, el motor se suicidó con exit 20
(`PARENT_HEARTBEAT_LOST: Heartbeat obsoleto o con timestamps inválidos`)
aunque el launcher seguía vivo: `HEARTBEAT.json` se actualizó **52 ms
después** de la condena (`updated_utc_ns=...161.967` vs. condena a
`...161.915`) y el propio launcher escribió después `RESULT.json` y
`LAUNCHER_FAILED.json`. Causa: la escritura del heartbeat (cada 1 s) quedó
bloqueada >5 s (`HEARTBEAT_MAX_AGE_NS`) por E/S lenta del disco USB externo
donde se instaló el release — el mismo journal registra estancamientos
reales de 10-11 s (`receive_to_writer_start max=11 297 ms`).

**Cambio (`dual_main.py`):**

- La frescura expirada / timestamps incoherentes ahora lanzan
  `PARENT_HEARTBEAT_STALE` (nuevo código). `PARENT_HEARTBEAT_LOST` directo
  queda reservado a identidad ajena (otra sesión u otro launcher): fatal
  inmediato, sin tolerancia, como antes.
- Nueva política pura `_heartbeat_failure_action(code, since_valid_ns,
  pid_alive)`: ilegible/estancado se tolera dentro de los 5 s previos
  (comportamiento P0.3 intacto) y, más allá, SOLO si el PID del launcher
  sigue vivo (`_pid_alive`: `OpenProcess`/`GetExitCodeProcess` en Windows,
  `kill(pid,0)` en POSIX) y no se superó el tope duro
  `HEARTBEAT_STALL_HARD_CAP_NS = 60 s`.
- Cierre fail-closed intacto: launcher muerto → caída en ≤5 s; PID
  reutilizado → el tope duro acota a 60 s; cada tolerancia queda en el log
  (`HEARTBEAT_READ_TRANSIENT code=... age_s=...`).

## 2. Gate de evicción de métricas: de `evicted == 0` a cobertura (auditor, P0)

**Hecho:** `audit metrics` marcó FAIL la sesión sana porque
`event_loop_lag` desalojó **10 muestras** de su ventana deslizante
(10 000 muestras, snapshots cada 5 s). Con la regla 2.3.0 (`evicted == 0`),
**cualquier** soak certificable de 2 h fallaría por construcción: la ventana
desaloja siempre en sesiones largas.

**Cambio (`audit.py`):** el gate certifica ahora el invariante correcto —
que **ninguna muestra quedara fuera de toda ventana emitida**. La base
certificada es worst-p99 sobre TODAS las ventanas; cubre el soak completo
sii entre snapshots consecutivos no llegaron más muestras de las que la
ventana retiene (`Δcount_total ≤ count`, serie coherente y no decreciente:
`_eviction_series_covers_all_samples`). Con snapshots de 5 s y ventana de
10 000 eso exige tasas sostenidas <~2 000 muestras/s — un orden de magnitud
sobre lo observado. La truncación **silenciosa o incoherente** sigue
condenando: evicción sin serie verificable, `count > count_total`, serie
decreciente o llegadas sin ventana (`cobertura de ventana violada` en
`metric_errors`). El informe publica `window_snapshots` y `coverage_ok` por
gate.

## 3. Actividad y límites p99 = gates de CERTIFICACIÓN, no de uso normal

**Hecho:** con el gate 2.3.0, el modo 1 (uso normal) de la sesión real
habría terminado «Auditoría FAIL» pese a la captura íntegra, por dos causas
ajenas a la integridad: TUTUSDT no tuvo **ningún** aggTrade de futuros en
3.7 min (ilíquido legítimo) y los p99 del host picaron durante los
estancamientos de E/S (pipeline 16 ms > 5 ms; event_loop 23 ms > 20 ms).

**Cambio (`audit.py`, `launcher.py`):** nuevo `--no-threshold-check` en
`audit metrics` (además del existente `--no-activity-check`): publica los
p99, su cobertura y los contadores **igual de honestos**, pero no los exige.
`audit_capture(...)` los aplica solo en uso normal
(`certification_gates=False`); los modos 2/3 siguen exigiendo actividad por
stream y límites p99 sin cambios. La integridad estructural (líneas
malformadas, contadores de pérdida, snapshot terminal único, coherencia de
capacidad, cobertura de ventana) se exige SIEMPRE, en todos los modos.

## 4. `benchmark --enforce`: re-medición única registrada (launcher, P1)

**Hecho:** el intento de modo 3 falló en `OFFLINE_VALIDATION_FAILED`
(benchmark `--enforce`) porque se ejecutó **mientras** la validación de red
corría en otra consola: en máquina ociosa el mismo host había pasado con
`event_loop_lag p99 = 16 ms` (umbral 20 ms) minutos antes.

**Cambio (`benchmark_latency.py`):** con `--enforce`, un fallo dispara UNA
re-medición tras 10 s de cooldown (aviso por stderr). Sin reintentos
ocultos: el JSON final registra `attempts` y `first_attempt`
(checks + measurements del intento fallido). Umbrales sin cambios.

## 5. Smoke live: 2 intentos por socket con telemetría (tests, P1)

**Hecho:** en la validación real, el smoke de USDⓈ-M expiró con **cero
mensajes en ~119 s** en un socket que minutos antes entregaba ~9 msg/s al
motor — con la suite offline del otro INICIAR saturando el host durante la
ventana. El test no decía qué socket ni cuántos mensajes llevaba.

**Cambio (`test_live_smoke.py`, `validar_red.py`):** cada socket tiene ahora
2 intentos de conexión con telemetría impresa
(`[smoke market/rol] intento i/2: n/100 mensajes en X s`); la cadena `pu` se
re-ancla por intento (una reconexión pierde diffs legítimamente) y los
enlaces verificados se acumulan. `validar_red` fija
`RUN_BINANCE_LIVE_SYMBOL` por asignación directa y, ante FALLO, imprime la
causa operativa más probable (ejecutar la validación sola, sin INICIAR
concurrente).

## 2.3.1 (recordatorio, ya entregado en este árbol)

- `runtime.py`: nombre temporal corto en `atomic_write_json`
  (`.{nombre}.{uuid12}.tmp`): el heartbeat moría exactamente en
  MAX_PATH=260 con rutas profundas.
- `launcher.py`: rechazo temprano `PATH_TOO_LONG` con mensaje accionable
  (mover a ruta corta o activar LongPathsEnabled).

## Pruebas

Suite completa: **219 passed, 2 skipped** (los 2 son el smoke live opt-in).
Nuevos tests: política de tolerancia del heartbeat y `_pid_alive`
(`test_runtime_contract.py`), cobertura de ventana PASS/FAIL y modo normal
sin límites (`test_metrics_eviction.py`). Los audits de la evidencia real
del host se re-ejecutaron con esta versión: journal PASS ×2, identidad PASS
(C_ing=1.0), métricas PASS en modo normal / FAIL honesto en modo
certificación (picos reales del host registrados).
