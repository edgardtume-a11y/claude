# Cambios JEAN_FLOW 2.1.0 — baja latencia y reloj Windows

El schema CSV permanece en `2.0.0`; la version `2.1.0` identifica el motor. No
se inicia Fase 2, LightGBM ni ejecucion de ordenes.

## Diagnostico causal

- `book_apply` p99 de 16 ms no representaba solo el mapa L2: el cronometro
  incluia normalizacion CSV, enqueue, top-N/dashboard y metricas. El nucleo
  medido aisladamente ya estaba por debajo de 0,1 ms en el escenario auditado.
- el lag de 438 ms era reproducible llenando las `asyncio.Queue`: un `get()`
  sobre cola no vacia no suspende, por lo que los workers drenaban miles de
  eventos sin devolver control al scheduler.
- mover disco a un thread no elimina por si solo competencia de GIL: expandir y
  escribir un snapshot de 10.001 filas seguia creando colas largas.
- NTP no participa en ninguna de esas dos duraciones porque ambas usan reloj
  monotonico. Solo corrige la comparacion UTC exchange→recepcion.

## Refactor aplicado

- presupuesto cooperativo temporal de 1 ms en todos los loops con backlog;
- watchdog de event loop independiente de logging/serializacion;
- `book_apply` limitado a `LocalOrderBook.apply` y metricas separadas por etapa;
- `CsvBatch` lazy: header + niveles compactos en el loop, expansion en writer;
- escritura CSV en chunks de 64 filas y cesion real de 0,5 ms: evita que
  `Sleep(0)` vuelva a seleccionar inmediatamente el writer;
- metricas por shard de thread sin lock global por evento;
- carga `SortedDict` en bloque, cache decimal acotada y undo atomico;
- snapshot REST/decode, snapshots de metricas y JSON del dashboard derivados con
  `asyncio.to_thread` cuando corresponde;
- dashboard con serializacion cacheada y cierre explicito de WebSockets;
- tuning reversible de quantum GIL y umbrales GC;
- correccion del bootstrap Spot vigente: primer retenido `U <= L <= u`; la
  continuidad live conserva `U <= local_u+1 <= u`;
- 5 pruebas nuevas para CSV lazy, concurrencia de metricas, backlog, tuning y
  cierre WebSocket, mas regresion explicita `U=L+1`.

## Evidencia offline

- pytest: 84 PASS, 1 smoke live opt-in SKIP;
- seis ejecuciones consecutivas posteriores al ajuste final: PASS;
- peor p99 observado: `book_apply=0,023 ms`, pipeline total `0,1951 ms`, lag
  durante snapshot CSV de 10.001 filas `12,0793 ms`;
- `compileall`: PASS.

Consulte `BENCHMARK_REFERENCIA_20260811.json`. Estos datos pertenecen al host de
construccion; Windows debe volver a ejecutar `benchmark_latency.py --enforce`,
smoke dual de 30 minutos y soak dual de 2 horas.

## NTP Windows

- W32Time `PublicInternet`: cuatro peers del Pool, polling especial de 1.800 s,
  respaldo/restauracion y verificacion read-only;
- W32Time `ControlledHighAccuracy`: 64 s solo con tres o mas fuentes aprobadas;
- Meinberg opcional: sin binarios empaquetados, verificacion SHA-256 +
  Authenticode y diagnostico con `ntpq`;
- bloqueo de Active Directory y de dos disciplinadores simultaneos;
- ninguna llamada NTP, `w32tm`, `ntpq` o `resync` entra en el hot path.

No se garantiza offset de 1 ms mediante Internet publico. Para ese objetivo se
necesita fuente y red controladas, habitualmente GNSS/PTP o appliance local.
