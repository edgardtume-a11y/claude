# Informe de corrección real — JEAN_FLOW 2.2.2

Fecha: 2026-08-13  
Estado: corrección offline verificada; reintento Windows/live pendiente.

## Diagnóstico forense

Se analizaron los ocho JSON de dos intentos reales incluidos en `runs.zip`.
Ambos llegaron correctamente al preflight y fallaron solo en el reloj:

| Evidencia | Intento 1 | Intento 2 |
|---|---:|---:|
| Integridad release/runtime | PASS | PASS |
| W32Time | Running / Auto | Running / Auto |
| Fuente activa | `1.pool.ntp.org,0x8` | `1.pool.ntp.org,0x8` |
| Leap / stratum / último error | 0 / 2 / 0 | 0 / 2 / 0 |
| Phase Offset W32Time | 2.426 ms | 2.426 ms |
| Referencia externa 2.2.1 | `time.windows.com` | `time.windows.com` |
| p95 externo | 95.972 ms | 103.318 ms |
| Resultado 2.2.1 | `OFFSET_OUT_OF_RANGE` | `OFFSET_OUT_OF_RANGE` |

No hay evidencia de fallo en Python 3.12, el runtime, los 20 wheels, el manifest
ni el parser regional. Binance no llegó a evaluarse porque el colector nunca
llegó a iniciarse. El acceso denegado de
la primera consulta `/query /source` tampoco fue la causa: el fallback desde
`/status /verbose` resolvió la fuente y el segundo intento consultó directamente
sin error.

## Causa raíz

`w32tm /stripchart /computer:servidor` calcula el offset contra ese servidor
concreto. JEAN_FLOW 2.2.1 fijaba `time.windows.com`, aunque el cliente estaba
sincronizado con otra fuente. La diferencia entre dos relojes públicos y dos
rutas de red —incluida su asimetría— se trataba incorrectamente como si fuera
el error del reloj respecto de su propio disciplinador.

Microsoft define `CurrentTimeOffset`, también mostrado como `Phase Offset`,
como el offset entre el reloj del equipo y la fuente elegida por W32Time. Ese es
el observable coherente con el estado del servicio. No demuestra verdad UTC
absoluta de una fuente pública; sí evita mezclar fuentes diferentes dentro del
mismo gate.

## Corrección

1. `TimeSync-Common.ps1` hace obligatorio el Phase Offset, conserva el valor
   crudo y rechaza ausencia, NaN o infinito.
2. `Test-W32Time.ps1` usa la ruta absoluta de System32, valida fuente, peers,
   frescura y estado; liga Phase Offset y Source al mismo `status /verbose`,
   exige ese peer activo y aplica `abs(Phase Offset) <= 50 ms` sin redondear.
3. `Test-ClockSync.ps1` conserva 20 observaciones únicamente para Meinberg. Una
   lectura W32Time se etiqueta honestamente como `abs_phase_offset_ms`, no p95.
4. Si un offset real es alto, el launcher solo considera recuperable un
   W32Time único, Running/Auto y fuera de dominio/GPO. Requiere consola y
   confirmación explícita.
5. La única acción elevada automática del launcher es el binario resuelto por ruta absoluta de System32 con
   parámetros inmutables: `System32\w32tm.exe /resync`. El proceso Python y el
   motor siguen sin elevación. Un inicio completo con «Ejecutar como
   administrador» se rechaza antes de cargar el runtime.
6. Después se repite el gate read-only hasta PASS o un plazo de 90 segundos.
   Nunca hay un segundo resync. El postflight no contiene ruta de recuperación.
   El launcher no invoca los scripts heredados de configuración W32Time, porque
   elevar un archivo modificable dejaría una ventana TOCTOU; estados de servicio
   incorrectos fallan cerrados para intervención administrativa manual.

## Evidencia offline

| Control | Resultado |
|---|---:|
| Regresión del caso real 2.426 vs 103.318 ms | PASS |
| Límites exactos ±50 ms | PASS |
| Casos GPO/Meinberg/doble servicio/decline/postflight | PASS |
| Suite completa | 176 PASS, 1 SKIP live opt-in |
| Compilación | PASS |
| Ruff crítico `E9,F63,F7,F82` | PASS |
| Benchmark `--enforce` | PASS, cinco gates |
| ZIP reproducible, CRC y manifest | PASS; dos builds finales byte-idénticos y extracción verificada |

## Límite pendiente

Linux no puede certificar PowerShell 5.1, UAC, W32Time ni Binance. La entrega
debe extraerse en una carpeta nueva de Windows y repetirse allí. El PASS del
caso reportado se espera porque su Phase Offset real era 2.426 ms, pero solo la
evidencia del nuevo arranque puede confirmarlo en ese equipo.
