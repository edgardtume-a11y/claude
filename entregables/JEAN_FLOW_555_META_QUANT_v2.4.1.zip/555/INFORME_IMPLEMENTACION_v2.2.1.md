# Informe técnico real — JEAN_FLOW 2.2.1

Fecha: 2026-08-13  
Estado: refactor offline verificado; certificación Windows/live pendiente.

## Resultado ejecutivo

Se auditó el código real 2.2.0 antes de aceptar las cuatro hipótesis. Dos
premisas requerían corrección:

- CPython 3.12 no depende necesariamente del tick Windows de 15,6 ms para un
  `time.sleep()` positivo; desde 3.11 usa un waitable timer de alta resolución.
- `Decimal` implica más memoria/asignación, pero no es por sí mismo un objeto
  rastreado por el GC cíclico de CPython 3.12. Elevar `GC_THRESHOLD_0` a 50.000
  afecta contenedores rastreados y backlog, no “50.000 Decimals”.

Sí se reprodujo un fallo P0 de cadena de suministro: `PIP_FIND_LINKS` ambiental
podía aportar otro wheel con la versión fijada y pip podía escogerlo después de
validar el wheelhouse. La revisión 2.2.1 cierra ese bypass y el TOCTOU de los
bytes del wheel.

## Cambios implementados

### Punto fijo exacto

- `LocalOrderBook` usa `SortedDict[int, int]` con escala `10^8`.
- El codec solo acepta dígitos ASCII, punto decimal único y valores sin signo,
  exponente, espacios ni separadores locales.
- Un valor con más de ocho decimales solo se acepta si los restantes son cero.
  No existe redondeo silencioso.
- Se limita el valor escalado a `2^63-1` y el texto a 64 caracteres.
- El parser se ejecuta después de clasificar stale, preservando el contrato que
  ignora el payload numérico de un evento que no se aplicará.
- Snapshot y diff se construyen/validan antes de mutar; el undo log continúa
  revirtiendo una actualización que cruce el libro o viole límites.
- `_price_cache` se eliminó. El estado ya no retiene cientos de miles de strings
  de precios borrados. Una LRU global de 8192 tokens amortiza las ráfagas con
  valores repetidos y queda acotada a aproximadamente 1,4 MB en el perfil local.
- La ruta productiva pasa top-N fijo directamente al hub. El formateo para UI
  ocurre en el worker de serialización, fuera del event loop.
- Eventos y CSV conservan los strings originales; `SCHEMA_VERSION` permanece en
  2.0.0 y el replay histórico conserva `Decimal` fuera de la ruta viva.

La escala fija solicitada no se declara universal para todos los símbolos de
Binance. `tickSize` y `stepSize` son propiedades por símbolo. Si un valor
observado no cabe exactamente en `10^8`, el motor falla cerrado y no lo redondea.

### Writer y timer

- Se mantiene `time.sleep(0.0005)` entre chunks. En el runtime obligatorio
  Python 3.12/Windows 11 ya usa un waitable timer de alta resolución.
- No se añadió busy-spin: consumiría CPU y competiría con el event loop.
- No se añadió `timeBeginPeriod(1)`: tiene efecto de sistema/proceso, coste de
  energía/scheduler y no garantiza un despertar en 0,5 ms.
- Cada pausa registra `writer_cooperative_yield`; se cuenta un oversleep mayor
  de 5 ms o 4× el solicitado y la auditoría exige p99 <= 5 ms cuando hubo yields.

### Bootstrap y TOCTOU

- Cada línea de `requirements.lock` contiene un pin exacto y SHA-256.
- `verified_wheel_plan()` exige una biyección exacta entre 20 requisitos, 20
  wheels y 20 entradas del manifest; rechaza symlinks, extras y duplicados.
- El bootstrap extrae directamente los wheels ya hash-verificados. Antes de
  escribir comprueba cada entrada contra `dist-info/RECORD`, rechaza `.data`,
  `.pth`, bytecode, symlinks, rutas traversal y colisiones no idénticas.
- El inventario instalado se sella en `RUNTIME_MANIFEST.sha256`; todos sus bytes
  se vuelven a calcular antes de cualquier import en cada arranque.
- Se eliminaron la instalación editable, el Python interno no autenticado y el
  sentinel público `--inside-venv`. El Python 3.12 global validado mantiene el
  mutex durante toda la captura y usa `-I -S`/rutas explícitas.

### Exclusión mutua

- En Windows, `BootstrapLock` usa `CreateMutexW` con nombre derivado de la raíz
  y permanece adquirido durante toda la captura.
- El mutex de `SingleInstance` del supervisor continúa como segunda defensa.
- Ambos objetos del kernel desaparecen al cerrar el último handle, incluso tras
  un crash. En sistemas no Windows, el lock asesor del archivo conserva el
  descriptor; un nombre residual no equivale a un lock adquirido.

## Evidencia offline

| Control | Resultado |
|---|---:|
| Suite | 162 PASS, 1 SKIP live opt-in |
| Compilación | PASS |
| Ruff crítico `E9,F63,F7,F82` | PASS |
| Wheel plan | 20/20 pins/hashes PASS |
| Extracción wheel/RECORD + seal runtime | PASS |
| Benchmark `--enforce` | PASS |
| Gates book/apply/pipeline | PASS, límites 5 ms |
| Burst 511 niveles | PASS, límite 5 ms |
| Event-loop lag | PASS, límite 20 ms |
| Writer yield | PASS, límite 5 ms |

Son mediciones sintéticas de una ejecución Linux x86-64/Python 3.12.13; sirven
como regresión offline, no como certificación del planificador Windows.

## Pendiente obligatorio

1. Extraer el ZIP en Windows 11 con Python 3.12 x64 limpio.
2. Bloquear red durante la creación del runtime y verificar que solo se usan
   los 20 wheels incluidos.
3. Ejecutar CMD, PowerShell, UAC y el disciplinador NTP real.
4. Medir la distribución de al menos 50.000 yields de 0,5 ms bajo carga,
   foreground/minimizado y AC/batería.
5. Completar Binance live 10/30/120 minutos y obtener
   `CAPTURA_COMPLETA_AUDITADA.json` del propio modo 3.
6. Probar antivirus, dos dobles clic simultáneos, cierre abrupto, disco lleno y
   recuperación después de reinicio.

Hasta completar esos gates no se declara certificación operacional ni se
habilita LightGBM, señales u órdenes.

El manifest y su verificador aportan integridad interna y detección de
corrupción; no son una firma externa contra un actor capaz de reemplazar
simultáneamente todo el release. Ese modelo exige Authenticode o una firma
pública distribuida por un canal independiente.

## Referencias primarias

- Python 3.12 `time.sleep`: <https://docs.python.org/3.12/library/time.html#time.sleep>
- Microsoft `timeBeginPeriod`: <https://learn.microsoft.com/en-us/windows/win32/api/timeapi/nf-timeapi-timebeginperiod>
- Binance Spot filters: <https://developers.binance.com/en/docs/products/spot/filters>
- Python 3.12 GC: <https://docs.python.org/3.12/library/gc.html>
