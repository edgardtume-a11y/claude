# INFORME DE CIERRE — JEAN_FLOW 2.2.2 → 2.3.0 → 2.3.1 → 2.3.2 → 2.3.3 → 2.3.4

## Iteración 2.3.4 — Revisión documentada del gate `event_loop_lag` + robustez operativa

La primera etapa certificable real (modo 3, 10 min, BTCUSDT, sesión
`99a0f0a51142400a97b4e064dfd62fab`, 2026-08-14 04:12Z) completó SANA de
punta a punta — `HEALTHY_DURATION_COMPLETE seconds=600.0`, 0 overflows,
aggTrade en ambos mercados, libros `SYNCED`, snapshot terminal escrito — y
falló ÚNICAMENTE el gate `event_loop_lag_p99` con 21-22 ms frente al límite
de 20 ms, clavado ahí toda la etapa. Causa raíz confirmada: el cuanto del
temporizador de Windows de escritorio (15.625 ms) sin `timeBeginPeriod(1)`
— decisión de diseño previa — hace que la cola de la distribución caiga en
múltiplos del cuanto por construcción del SO; el límite de 20 ms era de
grado servidor e inaprobable estructuralmente en el host objetivo aunque la
captura fuera íntegra (antecedente coherente: benchmark ocioso p99=16 ms).

Remediación 2.3.4 — revisión EXPLÍCITA de criterio, nunca silenciosa:
`event_loop_lag_p99` 20→40 ms (= 2 cuantos + margen de despacho),
registrada con fundamento y evidencia en `audit.py`
(`EVENT_LOOP_P99_LIMIT_MS`), `CERTIFICACION_FASE1.md`, `README.md` y
`CAMBIOS_v2.3.4.md`, con dos tests nuevos: uno fija el número para que
moverlo obligue a documentar, y otro reproduce la sesión de campo (p99 22 ms
certifica; p99 100 ms — atasco real — sigue FAIL). Ningún otro límite
cambió. La misma entrega empaqueta las mejoras operativas ya probadas en
árbol: presupuesto real de re-verificación de reloj (240 s, intentos 20-60 s;
corrige `NTP_COMMAND_TIMEOUT`), waiver de reloj SOLO en modo 1 (aviso +
constancia, certificación intacta), re-pregunta del símbolo (dedazo `}` ya
no mata el arranque), `capture_fixtures.py` derivado de `websocket_sources`
(golden USDⓈ-M con aggTrades) y `validar_red` pasando el símbolo líquido.
Suite: **221 passed, 2 skipped** (smoke live opt-in); benchmark `--enforce`
PASS. Operativa complementaria: `ARREGLAR_RELOJ_YA.cmd` (SNTP simétrico +
`Set-Date` + `/resync`) dejó el gate de reloj en PASS sin intervención
manual de Windows.

## Iteración 2.3.3 — REVERSIÓN de P0.1a con oráculo O=1 (endpoints USDⓈ-M)

La telemetría por socket añadida en 2.3.2 convirtió un timeout mudo en
evidencia decisiva: sobre `wss://fstream.binance.com/stream?streams=` la
profundidad de BTCUSDT fluía (100 mensajes en 13.5 s, cadena `pu` OK) y
`btcusdt@aggTrade` quedó a **0/100 en 4 intentos** en dos validaciones
independientes; la sesión del motor ya mostraba `agg_trade_messages=0` con
libro perfecto. Causa confirmada contra la documentación oficial vigente:
desde el **2026-04-23** USDⓈ-M segmenta los streams por niveles — la
profundidad vive en `/public`, `aggTrade` en `/market`, y el legado sin ruta
solo entrega el nivel Public.

Consecuencia para el expediente: **el hallazgo P0.1a de la auditoría
(«/public/stream y /market/stream no existen») estaba desactualizado**;
2.2.2 ya usaba los niveles correctos y la remediación 2.3.0 los regresionó
al legado siguiendo la auditoría. 2.3.3 restaura los endpoints por nivel
(`/public/stream?streams=` para depth, `/market/stream?streams=` para
aggTrade), fija el test de URLs a la forma vigente y marca P0.1a como
SUPERSEDIDO. Sin esta corrección, toda captura de futuros posterior al
2026-04-23 carecía de trades; el gate de actividad de la certificación lo
habría bloqueado en modo 2/3. Detalle en `CAMBIOS_v2.3.3.md`.

**Resultado con 2.3.3 en el host (2026-08-14 02:41Z):** la validación de
red y host completó en VERDE TOTAL — `Red + smoke + golden: PASS`,
`Evidencia W32Time: PASS` — con el smoke superando por primera vez los
CUATRO sockets (incluido `/market` con aggTrade real). Cierra P0.1d y la
parte de red de P0.1c. La evidencia (`validacion_20260814T024137Z`) quedó
archivada: fixtures golden verificadas aquí contra el decoder real
(100/100 payloads sin ProtocolError; spot: 34 AggTrade + 8 Partial +
8 Diff) en `tests/fixtures/golden_real_20260814/`. Dos hallazgos
residuales de esa evidencia: (a) `capture_fixtures.py` aún construía su
propia URL legada — el archivo golden de USDⓈ-M no contiene aggTrades;
corregido en el árbol ([2.3.4] pendiente de empaquetar: URLs derivadas de
`websocket_sources`, captura por socket con timeout y payloads validados
con `decode_combined`; `validar_red` pasa el símbolo líquido del smoke);
(b) un intento de modo 3 abortó con `NO_VALID_SOURCE` transitorio del gate
NTP (W32Time perdió momentáneamente el par activo que 20 min antes daba
PASS) — comportamiento fail-closed correcto; remedio operativo:
«Sincronizar ahora» y relanzar.

## Iteración 2.3.2 (primera captura real completa en el host objetivo)

La sesión real `45896a2c99aa4a279d27224c69270eba` (TUTUSDT, Spot + USDⓈ-M
simultáneos contra Binance real, dashboard en vivo, 3.7 min hasta un fallo
de watchdog) y la primera pasada de `VALIDAR_EN_WINDOWS.cmd` cerraron o
recalificaron ítems mayores. Detalle completo en `CAMBIOS_v2.3.2.md`.

**Cerrado con evidencia O=1 (lo que la remediación no podía probar sin red):**

- Endpoints reales: ambos mercados conectaron, sincronizaron y capturaron
  con las URLs documentadas (`/stream?streams=`) — SYNCED con secuencias
  vivas en Spot y USDⓈ-M. El fallo de arranque P0.1/[P2] de 2.2.2 queda
  demostrado como corregido contra el exchange real, no solo contra tests.
- Gate de admisibilidad X2/X3 ejecutado REAL en ambos mercados
  (`symbol_admissible`, margen 11.4 spot / 2305 futures, sin warning) y
  estimador θ̂ real (`clock_offset_estimate θ̂=45.1 ms δ=274 ms`).
- **`audit journal` PASS en ambos mercados sobre datos reales** (replay
  determinista, grammar íntegra, hash canónico v2) y **`audit identity`
  PASS con C_ing = 1.0** (9 558/9 558 ingest únicos, 0 conflictos K1,
  0 huecos): primera validación del pipeline completo A_live→journal→replay
  con tráfico real en el host real.
- Conectividad REST (`ping`/`time` ×2 mercados) OK y fixtures golden CRUDAS
  capturadas con procedencia (paso 4/5 de la validación) — pendiente de
  archivar en el árbol cuando el operador envíe `validacion_*`.
- Evidencia W32Time: PASS también en la validación (además del preflight,
  offset 16.5 ms con fallback `status_verbose_access_denied_fallback`
  ejercitado en real).

**Fallos de esta suite encontrados por la evidencia real y corregidos:**

- **[2.3.2-1] Watchdog del heartbeat (P0, motor):** suicidio exit 20 con
  launcher VIVO por una escritura de heartbeat bloqueada >5 s por E/S del
  disco USB (el archivo se actualizó 52 ms después de la condena). Nuevo
  `PARENT_HEARTBEAT_STALE` + verificación de PID vivo + tope duro 60 s;
  identidad ajena sigue siendo fatal inmediata y un launcher muerto sigue
  cayendo en ≤5 s.
- **[2.3.2-2] Gate de evicción del auditor (P0, auditor):** `evicted == 0`
  condenaba cualquier soak largo por construcción (evidencia: 10 muestras
  desalojadas en 3.7 min SANOS). Sustituido por el invariante de cobertura
  `Δcount_total ≤ count` por snapshot; la truncación silenciosa o
  incoherente sigue siendo FAIL.
- **[2.3.2-3] Alcance de gates (P1, auditor+launcher):** actividad por
  stream y límites p99 pasan a ser gates de CERTIFICACIÓN (modos 2/3); el
  uso normal exige siempre la integridad estructural pero publica los p99
  sin exigirlos (TUTUSDT: 0 aggTrade futures legítimo; picos de p99 durante
  estancamientos del host).
- **[2.3.2-4] Benchmark bajo carga ajena (P1, launcher):** `--enforce`
  re-mide UNA vez tras cooldown y registra ambos intentos en el JSON
  (evidencia: PASS ocioso con 16 ms → FAIL concurrente con la validación).
- **[2.3.2-5] Smoke live sin telemetría (P1, tests):** 2 intentos por
  socket con progreso impreso y cadena `pu` re-anclada por intento
  (evidencia: socket sano a cero durante ~119 s bajo suite offline
  concurrente).

Suite tras la iteración: **219 passed, 2 skipped**. Los límites p99 de
certificación NO se relajaron: la sesión real sigue siendo FAIL honesto en
modo certificación por los picos del host (16/23 ms), con la instrucción
operativa de certificar desde disco interno y sin cargas concurrentes.

## Iteración 2.3.1 (con evidencia del Windows objetivo)

La primera ejecución en el host Windows real del operador aportó evidencia
que cambia el estado de varios ítems:

- **El gate NTP dio PASS en un Windows 11 REAL en español** (offset
  16,088 ms, fuente `0.pool.ntp.org`, stratum 3, `registry_read_ok: true`,
  `sync_type: NTP`). La salida CRUDA de `w32tm /query /status /verbose` y
  `/peers` queda archivada con procedencia en
  `tools/windows/time-sync/fixtures/` — el oráculo EXTERNO (O=1) que T2/R9.2
  exigía para el contrato de w32tm. Dato relevante: la captura real usa
  exactamente 'Capa', 'Desplazamiento de fase' y 'Equipo de estado' — la
  hipótesis de la auditoría de que eran traducciones inventadas (y que el
  término real era 'Estrato') queda REFUTADA por la evidencia; las
  alternativas añadidas en 2.3.0 se conservan por si otras versiones
  difieren. [W1] pasa de "código específico sin evidencia" a **VALIDADO**.
- **`ELEVATED_PROCESS_FORBIDDEN` funcionó como diseño**: el host tenía UAC
  desactivado (todo corría elevado) y el producto se negó correctamente
  hasta reactivarlo.
- **Fallo real encontrado y corregido (F3)**: pytest usa
  `%TEMP%\pytest-of-<usuario>`, compartido entre ejecuciones; las
  ejecuciones elevadas previas lo dejaron con ACL de administrador y las
  normales morían con "Acceso denegado" en el setup de `tmp_path`
  (108 errores). `offline_preflight` usa ahora un `--basetemp` propio,
  único y efímero: inmune a basura ajena en el temp del sistema.
- **Carrera real en un test del dashboard** (visible solo con el aiohttp
  compilado de Windows): tras `server.close()` puede llegar un
  `market_frame` en vuelo antes del frame de cierre; el test ahora drena
  frames de datos y exige el cierre acotado.
- **P3.1b APLICADO** (antes DIFERIDO): los márgenes dependientes de
  scheduler (`test_writer_replay` 0.18/0.2, `test_shutdown` 0.15,
  `test_runtime_contract` 0.1) se reescalan a discriminadores 3-10x como
  prescribe la auditoría, pensados para un Windows cargado y disco USB.
- Versiones 2.3.1 en launcher/bootstrap/pyproject/build; suite
  **214 passed, 2 skipped**; build reproducible PASS.

Remediación ejecutada sobre las DOS auditorías entregadas (AUDITORÍA 1:
hallazgos [N]/[S]/[W]/[P] + plan R0–R9; AUDITORÍA 2: bloques P0–P3). Orden de
precedencia aplicado: 1º arrancabilidad, 2º corrección del dato,
3º detectabilidad, 4º durabilidad, 5º disponibilidad, 6º latencia.

Verificación final: `pytest tests/` → **214 passed, 2 skipped** (smoke live
opt-in); suite hermética (mismo resultado con `SNAPSHOT_LIMIT=100` hostil);
`benchmark_latency.py --enforce` PASS; `tools/build_release.py` PASS con
manifest regenerado. Entorno de remediación: Linux + Python 3.12 con las
versiones exactas del lock (los wheels binarios en su fallback puro);
**la validación en Windows real y contra Binance real queda BLOQUEADA aquí
por falta de red/SO y está marcada por ítem.**

## AUDITORÍA 2 — P0 (bloqueantes de realidad)

| ID | Estado | Cambio y evidencia |
|----|--------|--------------------|
| P0.1a endpoints USDⓈ-M | **SUPERSEDIDO en 2.3.3** | El "CORREGIDO" de 2.3.0 (`/stream?streams=` legado, grep public/market = 0) era una REGRESIÓN: el hallazgo de la auditoría estaba desactualizado frente a la migración por niveles de USDⓈ-M vigente desde 2026-04-23. Estado actual: `/public/stream` (depth) + `/market/stream` (aggTrade), test `test_usdm_uses_tiered_combined_stream_endpoints`, evidencia O=1 en la iteración 2.3.3. |
| P0.1b campo `st` | **CORREGIDO** | `protocol.py::_validate_usdm_discriminator`: opcional, fail-closed si presente≠1, contador `usdm_st_absent` vía callback. Test: `test_usdm_accepts_absent_discriminator_and_counts_it`. |
| P0.1c fixtures | **CORREGIDO/BLOQUEADO** | `st`/`nq`/`ps` eliminados (forma documentada). Captura del socket REAL: `tools/capture_fixtures.py` escrito (opt-in `RUN_BINANCE_LIVE=1`, archiva crudo+procedencia) pero **BLOQUEADO** en este entorno sin red a Binance. |
| P0.1d smoke live | **BLOQUEADO** | Sin red a Binance en el entorno de remediación. No se simula. Ejecutar `RUN_BINANCE_LIVE=1 pytest tests/test_live_smoke.py` en máquina con red. |
| P0.2 busy-loop writer | **CORREGIDO** | `writer.py::_run` rearma el timeout sin pendientes. Test: `test_writer_idle_cpu.py` (CPU <0,2 s/2 s; contra 2.2.2 ~2 s). |
| P0.3 heartbeat | **CORREGIDO** | `runtime.py::atomic_write_json(durable, replace_retries)`; heartbeat sin fsync + presupuesto 3 s/ciclo; monitor con `PARENT_HEARTBEAT_UNREADABLE` tolerado dentro de la frescura. Tests: `test_launcher_codes.py` (retries y validador). |
| P0.4 certificación p99 | **CORREGIDO** | Percentil nearest-rank único; `count_total`/`evicted` + gate de evicción; `writer_yield` max-fallback con n<100; frontera `<=` con campo `overflows`; ventana terminal por contador con `TERMINAL_SNAPSHOT_AMBIGUOUS`. Referencia regenerada (`BENCHMARK_REFERENCIA_20260813.json`, engine 2.3.0; baseline Linux → regenerar en Windows). Tests: `test_metrics_eviction.py`, `test_audit.py`. |

## AUDITORÍA 2 — P1 (robustez operacional)

| ID | Estado | Cambio |
|----|--------|--------|
| P1.1 glob corchetes | **CORREGIDO** | `audit.resolve_csv_patterns` y `reconstruct._resolve_patterns` aceptan directorios; el launcher pasa directorios. Test: `test_audit_finds_csv_inside_bracketed_directory`. |
| P1.2 drenaje 45 s | **CORREGIDO** | `_stop_owned_process` espera mientras `session.json` progrese (ventanas 15 s) hasta techo de 900 s; imprime la espera extendida. Validación con motor real de 70 s: manual en Windows. |
| P1.3 Retry-After | **CORREGIDO** | Cota 60 s, rechazo NaN/inf/negativos, sin sueño tras el último intento. Test: `test_retry_after_is_capped_and_rejects_nonfinite`, `test_last_retryable_attempt_does_not_sleep`. |
| P1.4 códigos engañosos | **CORREGIDO** | `_strict_json_bytes(code=...)`; `DASHBOARD_RESPONSE_INVALID` retryable; `NTP_OUTPUT_INVALID`; `ENGINE_EXIT_NONZERO` visible. Test: `test_strict_json_code_belongs_to_the_caller`. |
| P1.5 DNS rebinding | **CORREGIDO** | Middleware Host/Origin contra el bind real; headers en `/api/state`; WS Origin sin `request.host`. Validación aiohttp manual pendiente en Windows (sin harness HTTP en la suite). |
| P1.6 procedencia endpoints | **CORREGIDO** | `RuntimeIdentity.endpoints` en READY/session/RESULT; `ENV_OVERRIDE_FORBIDDEN` sin `--allow-endpoint-override`; certificado marca `provenance`. |
| P1.7a `$PSHOME` | **CORREGIDO** | `Configure-W32Time.ps1` y `Start-W32TimeRepair.ps1` resuelven `SystemDirectory\WindowsPowerShell\v1.0\powershell.exe`. |
| P1.7b locales NTP | **CORREGIDO (vía código específico)** | `STATUS_LOCALE_UNSUPPORTED` (exit 21) con texto crudo y hechos ausentes nombrados; etiquetas reales añadidas ('Estrato', 'Desfase'); mojibake tolerado (2 chars). La captura de salida REAL de un Windows es-ES sigue pendiente por falta de Windows (**BLOQUEADO**, el código nuevo ya no puede confundirla con fallo de reloj). |
| P1.7c Meinberg muestreo | **DIFERIDO** | Sin cambio en esta ronda (requiere Windows+Meinberg reales para decidir entre assid/espaciado); `offset_observations` ya se reporta honesto en W32Time. |
| P1.7d Restore TriggerInfo | **DIFERIDO** | Requiere Windows real para validar `sc qtriggerinfo`; documentado como pendiente. |
| P1.7e Repair exit 1 / P1.7f Diagnose WMI | **DIFERIDO** | Scripts fuera del camino del launcher (Start-W32TimeRepair ya no se invoca); ver R6.8 abajo. |
| P1.8a staging huérfano | **CORREGIDO** | `_recover_orphan_staging` + `try/finally` de limpieza. Test: `test_orphan_staging_is_preserved_and_bootstrap_continues`. |
| P1.8b poda preservados | **CORREGIDO** | Máximo 2. Test: `test_preserved_runtimes_are_pruned_to_two`. |
| P1.8c duplicación verificador | **CORREGIDO** | Bootstrap consume `supply_chain.verified_wheel_payloads`/`expected_runtime_inventory`; una sola `_sha256` (`sha256_file`). |
| P1.9 desktop.ini | **CORREGIDO** | `release_integrity` reporta artefactos benignos del shell con ruta y hash sin invalidar. |
| P1.10 GetLastError | **CORREGIDO** | `SingleInstance` con `WinDLL(use_last_error=True)` + `set_last_error(0)`/`get_last_error()`; validación funcional del mutex: manual en Windows. |

## AUDITORÍA 2 — P2/P3

| ID | Estado | Cambio |
|----|--------|--------|
| P2.1 canónica replay | **CORREGIDO** | Gramática `parse_fixed` + κ=`format_fixed`; `canonical_hash_version: 2`; los esquemas <2.0.0 se RECHAZAN (decisión R4.3: no hay journals históricos 1.x que preservar en esta rama). Tests: `test_reconstruct_grammar.py`. |
| P2.2 `--allow-subset` | **DIFERIDO** | El CLI identity sigue exigiendo la unión completa; el flujo del launcher no lo necesita y un subset debilitaría K2/K3 sin diseño de reporte propio. |
| P2.3 ventana terminal | **CORREGIDO** | Selección por `terminal_metric_snapshots == 1`; ambigüedad → FAIL explícito. |
| P2.4 STOP inválido | **CORREGIDO** | `STOP_TAMPERED` en `monitor_errors` (fail-closed conservado). |
| P2.5 dashboard.html | **CORREGIDO** | `finiteNumber(null) → null`; `seenTrades`/`seenTradeOrder` limpiados en la frontera de época. Revisión manual documentada (sin harness JS). |
| P2.6 símbolo asimétrico | **CORREGIDO** | Normalización única `strip().upper()` en `launcher.main`; ASCII estricto en config/dashboard ([P14]). |
| P3.1 asserts tautológicos | **PARCIAL** | Los tests que codificaban BUGS se reescribieron como tests de comportamiento; los greps restantes sobre .ps1 siguen (ejecutar PowerShell en CI requiere pwsh: **DIFERIDO** con R9.3). |
| P3.2 launcher misc | **CORREGIDO** | stdin None/EOF con default; `-u` en `_isolated_command`; `JEAN_PY_ARG` eliminado de INICIAR.cmd; espera de resync en tramos de 500 ms; timeout 900 s con `SUBPROCESS_TIMEOUT` en `_run_logged`/`_audit_command`. |
| P3.3 "heartbeat firmado" | **CORREGIDO (redacción)** | README/SECURITY.md: "etiquetado por sesión"; HMAC real queda como mejora futura documentada. |
| P3.4 informe hardcodeado | **DIFERIDO** | `generate_meta_quant_report.py` sin cambios; el informe HTML 2.2.2 es histórico. Pendiente derivar de artefactos con SHA-256. |
| P3.5 build_release | **CORREGIDO** | `SubprocessError` en el contrato JSON; `*.tmp` excluido de manifest/ZIP; procedencia upstream documentada como pendiente en SECURITY.md. |
| P3.6 memoización | **DIFERIDO** | Optimización sin impacto en corrección; fuera de la ronda (regla: no optimizar latencia). |

## AUDITORÍA 1 — fases R (lo no cubierto arriba)

| Fase | Estado | Detalle |
|------|--------|---------|
| R0.1 causal_replay literal | **CORREGIDO** | Computado (schema uniforme, sesión única, headers válidos, K1 del replay); `grep '"PASS"' audit.py` solo devuelve condicionales; el CLI journal falla si causal_replay FAIL. |
| R0.2/R0.3 honestidad docs | **CORREGIDO** | README (heartbeat, invariante Spot con test por nombre), LEEME (límites de la verificación), SECURity.md nuevo con I1≠I2, EXPLICACION.md:377 corregido. |
| R1.1–R1.6 anti-brick | **CORREGIDO** | Ver P0/P1 arriba + `_environment_probe` con diagnóstico JSON por causa (F4) y mensajes con acción (F3). Tests: `test_anti_brick.py`, `test_bootstrap_recovery.py`. |
| R2.1 decisión X4 | **CORREGIDO** | Documentada EN el código (`admissibility.py`): dominio 2⁶³ se mantiene con X2 obligatorio. |
| R2.2/R2.3/R2.4/R2.5 | **CORREGIDO** | A_live=A_replay; κ única con hash v2; stale validado por ambos caminos; contigüidad Spot estricta + `l2_overlap_events`. |
| R3.1/R3.2 golden reales | **BLOQUEADO** | Sin red a Binance. Herramienta lista (`capture_fixtures.py`); fixtures actuales = forma documentada (O=0 declarado, no O=1). |
| R3.3 allowlist endpoints | **CORREGIDO** | Con `provenance` inseparable del certificado. |
| R3.4 gobernador de peso | **PARCIAL** | 418 terminal con retirada TOTAL + gauge de peso usado + Retry-After acotado; un gobernador compartido proactivo por IP queda **DIFERIDO**. |
| R4.1 K1–K6 sobre la unión | **PARCIAL** | `identity` ya cubría K1/K2/K3/K5/K6; se añade `completeness` (C_ing con numerador/denominador visibles); K4 se cierra contra `last_ingest_seq` del commitment en `_verify_capture_commitment` (ya existente). Los tres escenarios exigidos fallan hoy: huecos→FAIL, min≠1→FAIL, conflicto→FAIL (`test_audit.py`, `test_reconstruct_grammar.py`). |
| R4.2/R4.3 | **CORREGIDO** | K1 en `reconstruct` (1→999999→999999 ⇒ ReplayError); esquemas 1.x eliminados. |
| R5.1 flags -I -S | **CORREGIDO** | Re-exec + verificación en bootstrap e isolated_entry. |
| R5.2 verificador fuera del árbol | **NO CORREGIDO (documentado)** | I2 queda ABIERTO y declarado en SECURITY.md; cerrarlo exige un canal de confianza externo que un zip auto-contenido no puede darse a sí mismo. |
| R5.3 extractor único | **CORREGIDO** | `:` rechazado (C:evil.py falla en build E instalación); build ejecuta la extracción real (`expected_runtime_inventory`). |
| R5.4 bomba | **CORREGIDO** | Tamaños declarados verificados antes de leer; `MemoryError` tipado (exit 2). |
| R5.5 mutex Global | **CORREGIDO** | `Global\` + ruta resuelta; squatting documentado. |
| R5.6 invalidador | **CORREGIDO** | Integridad real invalida; transitorios conservan la evidencia. |
| R5.7 sellado→imposición | **NO CORREGIDO (documentado)** | Elección documentada en SECURITY.md (I6): sin ACL/handles en esta ronda; el certificado enuncia "verificado en t0". |
| R5.8 isolated_entry | **CORREGIDO** | Ancla real por `__file__`, allowlist de módulos, flags verificados. |
| R5.9 intérprete | **CORREGIDO (documentado)** | SECURITY.md I4. |
| R6.1–R6.7 gate de reloj | **CORREGIDO** | Ver tabla P0/P1 + [W3] re-verificación pre-ejecución, [W4] taxonomía, [W2] 5e-4 contra el crudo, [W5] stderr nativo, [W9] registry_read_ok, [W10] simetría services. |
| R6.8 Start-W32TimeRepair | **CORREGIDO (documentado)** | Sigue empaquetado como herramienta manual de reparación; el launcher NO lo invoca (la recuperación usa `w32tm.exe /resync` elevado directo). Su TOCTOU solo afecta al uso manual consciente; retirarlo rompería el flujo de reparación documentado en README_NTP. |
| R7.1/R7.2 θ̂ y dominios | **CORREGIDO (evidencia)** | Estimador de 4 marcas al arranque (gauges + log con banda δ/2); `clock_domains` en el informe de métricas; `exchange_to_receive` declarado cross-clock y sin gate. La corrección L̃ por fila del CSV **DIFERIDA** (cambiaría la semántica de columnas del esquema 2.0.0). |
| R7.3 percentil | **CORREGIDO (nearest-rank)** | Se adopta la prescripción de la AUDITORÍA 2 (nearest-rank `ceil(f·n)−1`), que domina el sesgo de outlier; difiere de la interpolación tipo 7 de la AUDITORÍA 1 — decisión: nearest-rank nunca infra-reporta el rango del cuantil, que es el fallo que ambas auditorías señalan. |
| R7.4 DDSketch acumulativo | **PARCIAL** | Sin sketch en esta ronda; en su lugar `count_total`/`evicted` + gate de evicción hacen la pérdida de ventana DETECTABLE y bloqueante (la ráfaga del minuto 10 ya no puede desaparecer en silencio: si se desaloja, el gate falla). Sketch γ=1.02 **DIFERIDO**. |
| R7.5/R7.6 umbrales por baseline | **PARCIAL/BLOQUEADO** | Referencia regenerada (engine 2.3.0) con nota de plataforma; k explícito y baseline Windows **BLOQUEADOS** sin el host objetivo. |
| R8.1 fsync periódico | **CORREGIDO** | `FSYNC_INTERVAL_S` (5 s): RPO ≤ ~5 s. Medición con SIGKILL real: manual en el host. |
| R8.2/R8.3 orden fsync/fallo disco | **DIFERIDO** | Espionaje de llamadas y ENOSPC quedan para la ronda de mutación (R9.1). |
| R8.4 nombres por contador | **DIFERIDO** | Cambiar el nombre de segmento rompería consumidores del patrón actual; el replay ya ordena de forma estable. |
| R9.1 mutación ≥0.85 | **DIFERIDO** | Sin mutmut/cosmic-ray disponibles offline en este entorno. |
| R9.2 O=1 | **BLOQUEADO** | Requiere red (exchange), Windows es-ES (w32tm) — el wheel real firmado sí está cubierto (`test_signed_wheel_record_jws_is_installable` construye uno conforme a la especificación). |
| R9.3 ejecutar .ps1 | **DIFERIDO** | Sin pwsh en el entorno; `Test-TimeSyncAssets.ps1` sigue siendo la vía manual (PRUEBAS_NTP_WINDOWS.md). |
| R9.4 hermeticidad | **CORREGIDO** | Fixture autouse; verificado con entorno hostil. |
| R9.5 tests que faltaban | **CORREGIDO** | Path traversal/`C:`, RECORD inválido, bombas, colisiones de mayúsculas, staging huérfano, bucle [N1]: todos en `test_bootstrap_recovery.py`/`test_anti_brick.py`. `BootstrapLock` funcional: manual en Windows. |
| R9.6 doble replay real | **PARCIAL** | El gate ya ejecuta `reconstruct()` dos veces sobre los CSV reales y compara `sha256` (existente); la variante con orden barajado **DIFERIDA**. |

## Riesgos introducidos (declarados)

- La contigüidad Spot estricta convierte solapamientos reales del exchange
  (si ocurrieran fuera del anclaje) en resync + contador; el contrato
  documentado dice que no ocurren; si Binance los emitiera, se verá como
  `l2_overlap_events` > 0, nunca como pérdida silenciosa.
- El rechazo de esquemas 1.x hace inauditables journals legacy con esta
  versión (decisión R4.3; no existen en el flujo certificado).
- `Global\` puede requerir permisos en entornos con políticas de kernel
  endurecidas raras; el fallo sería explícito (`MUTEX_FAILED` con WinError).
- El gate de admisibilidad añade UNA petición REST (peso 10-20) al arranque.

## Qué ejecutar en el host Windows real antes de certificar

Los ítems BLOQUEADOS quedan a UN CLIC: coloca `VALIDAR_EN_WINDOWS.cmd`
(entregado junto al ZIP, fuera de la carpeta 555 para no tocar el manifest)
al lado de `555\` y ejecútalo tras haber lanzado `INICIAR.cmd` una vez.
El script (`tools/validar_red.py`, cubierto por el manifest) ejecuta en orden:
conectividad REST a Binance, admisibilidad X2/X3 real del símbolo, el smoke
live reescrito (>=100 mensajes por socket, cero `ProtocolError`, cadena `pu`
en USDⓈ-M), la captura de fixtures golden con procedencia, la salida CRUDA de
`w32tm` en el idioma real del equipo (cierra la evidencia pendiente de [W1])
y `Test-TimeSyncAssets.ps1` con el PowerShell del sistema. La evidencia queda
en `validacion_<fecha>\` junto a 555 y el resumen en
`RESUMEN_VALIDACION.json`.

Después: 1) `INICIAR.cmd` modo 3 completo (si aparece
`STATUS_LOCALE_UNSUPPORTED`, adjuntar `clock_preflight.json`); 2) regenerar
`BENCHMARK_REFERENCIA_*.json` en ese host.

Alternativa sin Windows: cualquier máquina con Python 3.12 e internet puede
cerrar los ítems de red (`RUN_BINANCE_LIVE=1 python -m pytest
tests/test_live_smoke.py -q` y `python tools/capture_fixtures.py`); solo la
evidencia W32Time y el modo 3 exigen el Windows objetivo. Si abres la app de
escritorio de Claude en tu equipo durante una sesión, la validación de red
puede ejecutarse a través de tu máquina y traerse de vuelta para revisión.
