# Informe de implementación JEAN_FLOW 2.2.0

Fecha de construcción: 2026-08-13  
Estado: endurecimiento offline completado; certificación operacional Windows/live pendiente.

## 1. Decisión de base

Se reconstruyó sobre `JEAN_FLOW_555_LOW_LATENCY_NTP_v2.1.5_20260811`, SHA-256:

`4c7c4e44958f3a67a191c907454da8cf8592f349c1afab7daddfd5266bf6195f`

La inspección completa de esa base no encontró `READY`, `READY_INVALID`,
`session.json`, identidad de launcher ni el puerto fijo descrito en el informe
técnico. Tampoco contiene 223 pruebas: su árbol tiene 100 pruebas offline PASS y
un smoke live opt-in omitido. Por tanto, el error observado pertenecía a otra
envoltura no entregada y no podía reproducirse honestamente sobre 2.1.5.

La solución implementa el contrato recomendado desde cero y conserva la
reconstrucción causal Spot `U <= L+1 <= u` de 2.1.5. No se mezcló el frontend V8
ni se inició la fase LightGBM.

## 2. Mejoras aplicadas

### Identidad y READY

- El launcher crea un UUID único e impone una sola `CaptureSession` al motor y a
  ambos mercados.
- `session.json` usa creación exclusiva, JSON estricto, reemplazo atómico y una
  máquina de estados fail-closed.
- READY vincula producto, versiones, PID del motor, PID del launcher, instante de
  creación, sesión, símbolo, mercados canónicos, rutas, intérprete, paquete y
  puerto.
- `/healthz` separa vida e identidad; `/readyz` solo devuelve HTTP 200 si Spot y
  `usdm_futures` tienen libros `SYNCED`, frescos, no cruzados, con bid/ask y
  secuencia válida.
- El servidor enlaza directamente `127.0.0.1:0`; no existe la carrera de buscar
  un puerto y liberarlo antes del bind.

### Supervisión y cierre

- Dos inicios simultáneos quedan bloqueados tanto durante el bootstrap de
  `.venv` como durante la captura.
- Un heartbeat atómico ligado a la sesión hace que el motor falle cerrado si
  pierde al launcher.
- `STOP.json` valida sesión, PID solicitante, timestamp y motivo.
- Solo se drena/termina el `Popen` propio; no se mata un proceso por ocupar un
  puerto.
- El navegador tiene timeout y es un estado visual independiente: su fallo no
  invalida datos ya autenticados ni bloquea la supervisión.

### Evidencia terminal y auditoría

- Antes de `COMPLETED`, el motor compromete `last_ingest_seq` y el inventario
  exacto de CSV con ruta, tamaño y SHA-256.
- La auditoría exige igualdad exacta entre archivos presentes y comprometidos,
  y que la identidad causal alcance la secuencia final.
- Cada journal se reconstruye dos veces de forma independiente; ambos estados y
  hashes canónicos deben coincidir.
- Se exige una instantánea terminal de métricas por mercado, cuatro p99 con al
  menos 100 muestras, actividad Spot/Futures, cero contadores críticos y todo
  high-water estrictamente por debajo de su capacidad.
- `RESULT.json` queda `pass=false/PENDING_CLOCK_POSTFLIGHT` hasta terminar el NTP
  postflight. Un intento completo nuevo archiva el certificado previo.
- Tras cada postflight se repiten la verificación del árbol y la reconciliación
  del commitment; antes del marcador completo se verifican otra vez cada
  `RESULT.json` y todos sus hashes, evitando un PASS ante mutación TOCTOU.

### Bootstrap, dependencias e integridad

- Un único `555\INICIAR.cmd` detecta exclusivamente Python 3.12 x64 y puede
  ofrecer la instalación oficial vía winget con confirmación.
- El wheelhouse contiene 22 wheels fijados para CPython 3.12/Windows x64,
  incluido `colorama` requerido condicionalmente por pytest en Windows.
- Los wheels se verifican contra `WHEELHOUSE_MANIFEST.sha256`; pip trabaja con
  `--no-index`.
- `RELEASE_MANIFEST.sha256` cubre todo archivo controlado. El bootstrap y el
  launcher vuelven a verificar hashes, archivos inesperados y cinco fuentes de
  versión antes de ejecutar o certificar.
- El builder valida wheelhouse, resolución offline, manifest, colisiones de ruta
  y versiones, excluye artefactos runtime y genera un ZIP determinista con raíz
  `555/`.

### Reloj

- W32Time y Meinberg exigen un único disciplinador, fuente válida, 20
  observaciones y `p95_abs_offset_ms <= 50`.
- W32Time usa `stripchart`; Meinberg toma lecturas consecutivas de la estimación
  mantenida por `ntpd`. No se presenta ese segundo caso como 20 paquetes NTP
  independientes.
- No se ejecuta `resync` en la ruta caliente. El postflight es read-only.

## 3. Evidencia offline obtenida

| Control | Resultado |
|---|---|
| Compilación Python | PASS |
| Ruff crítico (`E4,E7,E9,F`) | PASS |
| Suite | 132 PASS, 1 SKIP live opt-in |
| Benchmark `--enforce` | PASS |
| `book_apply` p99 | 0,010 ms (límite 5 ms) |
| pipeline p99 | 0,3665 ms (límite 5 ms) |
| event-loop lag p99 | 2,5225 ms (límite 20 ms) |
| Wheelhouse | 22/22 pins y SHA-256 PASS |

El benchmark es sintético y fue ejecutado en Linux x86-64 con Python 3.12.13;
no sustituye el resultado del host Windows final.

## 4. Pendiente antes de declarar Fase 1 certificada

No se declara aún “doble clic → Binance → 10/30/120 minutos” como probado,
porque esta sesión no dispone de Windows 11, PowerShell 5.1, UAC ni los servicios
NTP reales del equipo destino. Deben completarse allí:

1. extracción limpia con la red bloqueada durante la instalación del entorno;
2. doble clic y verificación de CMD/Unicode/rutas;
3. preflight W32Time o Meinberg real;
4. captura Binance Spot + USD-M y progresión saludable 10, 30 y 120 minutos;
5. creación de `runs\CAPTURA_COMPLETA_AUDITADA.json` por el propio modo 3;
6. pruebas de antivirus, UAC cancelado, Ctrl+C, disco lleno y reinicio.

No hay monitoreo continuo de RSS/crecimiento de memoria ni una serie NTP durante
el soak; sí existen límites de cola, high-water, contadores de overflow y NTP
pre/post. Esos dos controles continuos quedan recomendados como P1 posterior,
sin alterar la ruta caliente de esta entrega.

Hasta superar la validación Windows/live, LightGBM, XGBoost, features, señales y
órdenes permanecen fuera de alcance.
