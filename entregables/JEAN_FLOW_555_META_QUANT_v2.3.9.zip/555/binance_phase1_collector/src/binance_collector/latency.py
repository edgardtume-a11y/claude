from __future__ import annotations

import gc
import os
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Iterator


class CooperativeBudget:
    """Deadline barato para ceder CPU cuando una cola nunca queda vacia."""

    __slots__ = ("budget_ns", "deadline_ns")

    def __init__(self, budget_ms: float) -> None:
        if budget_ms <= 0:
            raise ValueError("budget_ms debe ser positivo")
        self.budget_ns = max(1, int(budget_ms * 1_000_000))
        self.deadline_ns = time.monotonic_ns() + self.budget_ns

    def expired(self, now_ns: int | None = None) -> bool:
        now = time.monotonic_ns() if now_ns is None else now_ns
        return now >= self.deadline_ns

    def reset(self) -> None:
        self.deadline_ns = time.monotonic_ns() + self.budget_ns


@dataclass(frozen=True, slots=True)
class RuntimeTuning:
    thread_switch_interval_s: float
    gc_thresholds: tuple[int, int, int]


def _env_float(name: str, default: float) -> float:
    return float(os.getenv(name, str(default)))


def _env_int(name: str, default: int) -> int:
    return int(os.getenv(name, str(default)))


def _winmm():
    # [2.3.6] Separado para poder simularlo en pruebas sin Windows real.
    if sys.platform != "win32":
        return None
    try:  # pragma: no cover - solo ejecutable en Windows
        import ctypes

        return ctypes.WinDLL("winmm")
    except OSError:  # pragma: no cover - winmm ausente: mejor esfuerzo
        return None


def _kernel32():
    # [2.3.7] Separado para poder simularlo en pruebas sin Windows real.
    if sys.platform != "win32":
        return None
    try:  # pragma: no cover - solo ejecutable en Windows
        import ctypes

        return ctypes.WinDLL("kernel32", use_last_error=True)
    except OSError:  # pragma: no cover - mejor esfuerzo
        return None


_PROCESS_POWER_THROTTLING = 4
_POWER_THROTTLING_VERSION = 1
_POWER_THROTTLING_EXECUTION_SPEED = 0x1
_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION = 0x4
_POWER_MASK_CAPTURA = (
    _POWER_THROTTLING_EXECUTION_SPEED
    | _POWER_THROTTLING_IGNORE_TIMER_RESOLUTION
)


def _set_power_throttling(
    kernel32, control_mask: int, state_mask: int
) -> tuple[bool, int | None]:
    """Aplica PROCESS_POWER_THROTTLING_STATE al proceso actual.

    ControlMask con bit encendido + StateMask=0 = opt-out explícito de esa
    degradación ("siempre velocidad normal", "siempre respetar el
    temporizador"). ControlMask=0 = el sistema vuelve a decidir (defecto).

    [2.3.9] Devuelve (ok, error): en fallo, error es GetLastError (Win32)
    para poder DIAGNOSTICAR por qué el opt-out no aplicó (evidencia de campo:
    sesión b977be885902 registró foreground_qos=False sin ningún detalle).
    None cuando no hay código disponible (excepción antes de la llamada).
    """

    import ctypes

    class _PowerState(ctypes.Structure):
        _fields_ = [
            ("Version", ctypes.c_ulong),
            ("ControlMask", ctypes.c_ulong),
            ("StateMask", ctypes.c_ulong),
        ]

    estado = _PowerState(_POWER_THROTTLING_VERSION, control_mask, state_mask)
    try:
        handle = kernel32.GetCurrentProcess()
        ok = bool(
            kernel32.SetProcessInformation(
                handle,
                _PROCESS_POWER_THROTTLING,
                ctypes.byref(estado),
                ctypes.sizeof(estado),
            )
        )
    except (OSError, AttributeError):
        return False, None
    if ok:
        return True, None
    try:
        # Solo existe en Windows; fuera de él (o con kernel32 simulado en
        # pruebas) no hay código de error que reportar.
        return False, int(ctypes.get_last_error())
    except (OSError, ValueError, TypeError, AttributeError):
        return False, None


@contextmanager
def fine_timer_resolution() -> Iterator[dict[str, object]]:
    """[2.3.6/2.3.7] Temporizador de 1 ms + QoS de primer plano en Windows.

    Dos capas, misma causa raíz (el tic de ~15.625 ms del temporizador):

    1. [2.3.6] winmm.timeBeginPeriod(1) pide la resolución de 1 ms;
       timeEndPeriod(1) la restaura SIEMPRE. Evidencia: sesión 5ebb3efde620,
       p99 clavados en 15/16 ms.
    2. [2.3.7] Opt-out de PROCESS_POWER_THROTTLING: Windows 11 IGNORA la
       petición de temporizador y degrada a E-cores (EcoQoS) los procesos
       cuya ventana está minimizada/tapada. Evidencia: sesión dda44a52ff1f —
       fine_timer_1ms=True y aun así event_loop_lag p99 24 ms (idéntico a
       sin petición) y sleeps del writer 2-3x más lentos que en la sesión
       anterior. EXECUTION_SPEED + IGNORE_TIMER_RESOLUTION con StateMask=0
       exime al motor de ambas degradaciones; al salir se devuelve el
       control al sistema (ControlMask=0).

    Fuera de Windows no hace nada. Mejor esfuerzo: sin winmm/kernel32 la
    captura continúa sin los ajustes y el informe lo dice.
    """

    winmm = _winmm()
    kernel32 = _kernel32()
    report: dict[str, object] = {"timer_1ms": False, "foreground_qos": False}
    if winmm is not None:
        try:
            # 0 == TIMERR_NOERROR
            report["timer_1ms"] = winmm.timeBeginPeriod(1) == 0
        except (OSError, AttributeError):
            report["timer_1ms"] = False
    if kernel32 is not None:
        qos_ok, qos_error = _set_power_throttling(
            kernel32, _POWER_MASK_CAPTURA, 0
        )
        report["foreground_qos"] = qos_ok
        if not qos_ok:
            # [2.3.9] GetLastError del opt-out fallido, para diagnóstico en
            # el log de sesión (antes solo se sabía "False", sin causa).
            report["foreground_qos_error"] = qos_error
    try:
        yield report
    finally:
        if report["foreground_qos"]:
            _set_power_throttling(kernel32, 0, 0)
        if report["timer_1ms"]:
            try:
                winmm.timeEndPeriod(1)
            except (OSError, AttributeError):  # pragma: no cover
                pass


@contextmanager
def low_latency_runtime() -> Iterator[RuntimeTuning]:
    """Reduce colas largas del GIL/GC y restaura el proceso al finalizar.

    No desactiva el GC: eleva sus umbrales para evitar colecciones ciclicas en
    cada rafaga, conservando limpieza automatica en capturas prolongadas.
    """

    switch_interval = _env_float("PYTHON_THREAD_SWITCH_INTERVAL_S", 0.001)
    thresholds = (
        _env_int("GC_THRESHOLD_0", 50_000),
        _env_int("GC_THRESHOLD_1", 100),
        _env_int("GC_THRESHOLD_2", 100),
    )
    if not 0.0005 <= switch_interval <= 0.01:
        raise ValueError(
            "PYTHON_THREAD_SWITCH_INTERVAL_S debe estar entre 0.0005 y 0.01"
        )
    if any(value <= 0 for value in thresholds):
        raise ValueError("Los umbrales GC deben ser positivos")

    previous_switch = sys.getswitchinterval()
    previous_thresholds = gc.get_threshold()
    sys.setswitchinterval(switch_interval)
    gc.set_threshold(*thresholds)
    try:
        yield RuntimeTuning(switch_interval, thresholds)
    finally:
        gc.set_threshold(*previous_thresholds)
        sys.setswitchinterval(previous_switch)
