"""JEAN_FLOW: recolector causal Binance Spot y USDⓈ-M de Fase 1."""

__version__ = "2.3.9"
