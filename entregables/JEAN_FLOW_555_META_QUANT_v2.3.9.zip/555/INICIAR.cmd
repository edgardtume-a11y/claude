@echo off
setlocal EnableExtensions
chcp 65001 >nul
title JEAN_FLOW 2.3.9 - Inicio supervisado
cd /d "%~dp0"

set "JEAN_PY_EXE="
for %%P in (
  "%LocalAppData%\Programs\Python\Python312\python.exe"
  "%ProgramFiles%\Python312\python.exe"
  "%ProgramW6432%\Python312\python.exe"
) do (
  if not defined JEAN_PY_EXE if exist "%%~fP" (
    "%%~fP" -I -S -B -c "import struct,sys;raise SystemExit(0 if sys.version_info[:2]==(3,12) and struct.calcsize('P')==8 else 1)" >nul 2>&1
    if not errorlevel 1 set "JEAN_PY_EXE=%%~fP"
  )
)

if not defined JEAN_PY_EXE (
  echo ============================================================
  echo BOOTSTRAP_FAILED: no se encontro Python 3.12 x64.
  echo Instala Python 3.12 x64 desde python.org y vuelve a ejecutar.
  echo No se inicio ningun proceso ni se modifico el reloj.
  echo ============================================================
  if exist "%SystemRoot%\System32\choice.exe" "%SystemRoot%\System32\choice.exe" /C S /N /M "Pulsa S para salir: " >nul
  exit /b 2
)

echo Iniciando JEAN_FLOW desde: %~dp0
"%JEAN_PY_EXE%" -I -S -B -u "%~dp0jean_flow_launcher.py" %*
set "JEAN_EXIT=%ERRORLEVEL%"

echo.
if "%JEAN_EXIT%"=="0" (
  echo JEAN_FLOW termino correctamente.
) else (
  echo JEAN_FLOW termino con codigo %JEAN_EXIT%.
  echo La evidencia de la sesion se conserva en binance_phase1_collector\runs.
)
if exist "%SystemRoot%\System32\choice.exe" "%SystemRoot%\System32\choice.exe" /C S /N /M "Pulsa S para cerrar: " >nul
exit /b %JEAN_EXIT%
