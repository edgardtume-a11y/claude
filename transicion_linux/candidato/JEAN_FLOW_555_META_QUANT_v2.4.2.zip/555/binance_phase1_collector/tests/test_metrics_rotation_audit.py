from __future__ import annotations

from pathlib import Path

import pytest

from binance_collector import launcher


def _touch(path: Path) -> Path:
    path.write_text("{}\n", encoding="utf-8")
    return path


def test_serie_sin_rotacion_es_solo_el_base(tmp_path: Path) -> None:
    base = _touch(tmp_path / "jean_flow_metrics.jsonl")
    assert launcher._metrics_series_paths(base) == [base]


def test_serie_rotada_va_de_antigua_a_reciente(tmp_path: Path) -> None:
    base = _touch(tmp_path / "jean_flow_metrics.jsonl")
    rot1 = _touch(tmp_path / "jean_flow_metrics.jsonl.1")
    rot2 = _touch(tmp_path / "jean_flow_metrics.jsonl.2")
    rot5 = _touch(tmp_path / "jean_flow_metrics.jsonl.5")
    # RotatingFileHandler: .5 es el fragmento más antiguo, el base el último.
    assert launcher._metrics_series_paths(base) == [rot5, rot2, rot1, base]


def test_serie_ignora_sufijos_no_numericos_y_symlinks(tmp_path: Path) -> None:
    base = _touch(tmp_path / "jean_flow_metrics.jsonl")
    _touch(tmp_path / "jean_flow_metrics.jsonl.bak")
    real = _touch(tmp_path / "jean_flow_metrics.jsonl.1")
    enlace = tmp_path / "jean_flow_metrics.jsonl.2"
    try:
        enlace.symlink_to(real)
    except OSError:
        # En Windows crear symlinks exige privilegio; el resto del caso vale.
        pytest.skip("symlinks no disponibles en este host")
    assert launcher._metrics_series_paths(base) == [real, base]


def test_la_serie_siempre_termina_en_el_base_aunque_no_exista(tmp_path: Path) -> None:
    # Fallo cerrado: si el base falta, el auditor de métricas fallará al
    # abrirlo — la serie jamás lo omite en silencio.
    base = tmp_path / "jean_flow_metrics.jsonl"
    assert launcher._metrics_series_paths(base) == [base]
