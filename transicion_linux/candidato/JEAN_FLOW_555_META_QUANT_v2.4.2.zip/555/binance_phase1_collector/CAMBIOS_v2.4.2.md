# CAMBIOS v2.4.2 — el auditor ve el log de métricas COMPLETO

**Un solo cambio funcional, quirúrgico.**

## El defecto (real, presente desde que el log rota)

El log `jean_flow_metrics.jsonl` rota con `RotatingFileHandler`
(64 MiB × 5 respaldos, `main.py:50-55`), pero `audit_capture` pasaba al
auditor de métricas **únicamente el fichero base**
(`launcher.py`, invocación de `binance_collector.audit metrics`). En una
corrida lo bastante larga como para rotar, la serie auditada quedaba
incompleta: la ventana temprana (calentamiento incluido) vivía en los
fragmentos `.N` que nadie leía.

El defecto fue detectado durante la preparación de la transición a Linux
(análisis del RC externo, 20 de agosto de 2026) y afecta por igual a la rama
de Windows: por eso esta versión.

## La corrección

Nueva función `_metrics_series_paths(...)`: reconstruye la serie completa en
orden causal — `.N` más alto primero (el más antiguo) y el fichero base al
final (el más reciente) — ignorando sufijos no numéricos y symlinks, y
`audit_capture` pasa TODA la serie al auditor (`binance_collector.audit
metrics` ya aceptaba varias rutas; ningún cambio en el auditor).

Fallo cerrado conservado: si el fichero base no existe, el auditor de
métricas falla al abrirlo — la serie jamás lo omite en silencio.

## Qué NO cambia

- Ningún umbral, ningún gate, ningún formato de evidencia.
- `RESULT.pass` y `CAPTURA_COMPLETA_AUDITADA.json` conservan exactamente su
  significado y su criterio.
- El resto del árbol es byte a byte el de la 2.4.1 sellada.

## Pruebas

`tests/test_metrics_rotation_audit.py` (4 casos): serie sin rotación, orden
causal con rotación, exclusión de sufijos no numéricos y symlinks, y fallo
cerrado con base ausente. Batería completa en verde.
