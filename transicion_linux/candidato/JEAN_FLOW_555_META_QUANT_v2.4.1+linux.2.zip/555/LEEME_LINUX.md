# JEAN_FLOW 2.4.1+linux.2 — guía operativa del candidato Linux

## Estado honesto

Este paquete es el **candidato a release de Linux construido sobre la versión
vigente 2.4.1**, no sobre un árbol histórico. Los 11 módulos del núcleo causal
(collector, writer, audit, reconstruct, order_book, normalize, protocol, rest,
metrics, dashboard, config) son **byte a byte idénticos a los del paquete
sellado `JEAN_FLOW_555_META_QUANT_v2.4.1.zip`**, y así lo prueba
`CORE_SOURCE_MANIFEST.sha256`, validado por el pipeline de release.

Validado en frío sobre Linux x86-64 (Python 3.12):

- batería offline: **292 superadas, 2 omitidas (red opt-in), 0 fallos** —
  las 263 de la 2.4.1 más las pruebas nuevas de Linux (reloj, superficie del
  release, gate de disco, serie de métricas rotadas, lock estable);
- replay causal sobre la corrida real `d64fea5560ac` (~1,2 M filas): sellos
  canónicos **idénticos byte a byte a los generados en Windows** en spot y
  futuros, con doble ejecución determinista;
- wheelhouse Linux: 20 ruedas en las versiones exactas del lock, verificadas
  contra el lock sellado de Windows (13 puras, byte a byte) y contra PyPI
  (7 binarias manylinux cp312 compiladas);
- integridad del release por el pipeline oficial (`tools/build_release.py`).

**Lo que este paquete todavía NO es:** una certificación. Faltan las pruebas
que solo pueden hacerse en el equipo Linux objetivo (el VPS decidido): chrony
real, systemd como supervisor, red Binance, y la escalera 10/30/120 de la
Fase 2 del plan rector. La certificación operacional solo existirá cuando ese
equipo genere `CAPTURA_COMPLETA_AUDITADA.json` con los umbrales vigentes.

## Qué cambia respecto del RC de ChatGPT (2.3.4+linux.2)

Este candidato conserva sus aciertos (SIGTERM drenado, modos offline/preflight,
gate de disco, evidencia de chrony por CSV, sidecar, instalador con rollback
atómico, lock POSIX estable, auditoría de métricas rotadas, `-X utf8`) y
corrige sus dos defectos de fondo:

1. **Base de código**: aquel RC portaba el motor 2.3.4, cuatro versiones
   atrás; perdía, entre otras, la exclusión de calentamiento de 120 s del
   gate p99 (2.3.9) y la política de panel/navegador (2.4.1). Este candidato
   parte del 2.4.1 sellado.
2. **Criterio del reloj**: aquel RC convirtió en gate bloqueante la banda
   |offset| + dispersión_raíz + retardo_raíz/2 ≤ 50 ms. [DECISIÓN DEL
   PROYECTO, plan rector §6.3] ese criterio calificado está diseñado pero NO
   se implementa como gate hasta que exista un consumidor. Aquí el gate
   bloqueante vuelve a ser el vigente (|offset| ≤ 50 ms, mismo número y mismo
   sentido que en Windows) y la banda se **publica** como evidencia con
   `utc_calificada`: DEMOSTRADA / INSUFICIENTE / UNKNOWN.

## Plataforma

| Elemento | Decisión |
|---|---|
| Sistema | Ubuntu 24.04 LTS nativo, x86-64 (el VPS decidido el 20-ago) |
| Python | CPython 3.12 x64 (`/usr/bin/python3.12`) |
| Reloj | chronyd; gate de solo lectura de 50 ms + banda publicada |
| Supervisor | systemd sobre el launcher (`tools/linux/jean-flow.service`) |
| Usuario | `jean-flow`, sin privilegios; root rechazado con fallo cerrado |
| Código | `/opt/jean-flow/releases/<versión>`, root:root solo lectura |
| Estado | `/var/lib/jean-flow` (`JEAN_FLOW_STATE_ROOT`) |
| Locks | `/run/jean-flow` (`JEAN_FLOW_RUNTIME_DIR`) |
| Disco | SSD/NVMe interno; gate previo de espacio libre por modo |

No se usa WSL2, Docker ni reescritura en Rust (decisiones del plan rector).

## Preparar Ubuntu (una vez, con red)

```bash
sudo apt update
sudo apt install python3.12 chrony
sudo install -m 644 binance_phase1_collector/tools/linux/chrony-jean-flow.conf \
  /etc/chrony/conf.d/jean-flow.conf
sudo systemctl restart chrony && sudo systemctl enable chrony
chronyc waitsync 60 0.05 0.0 1 && chronyc -c tracking
```

## Instalar y validar sin capturar

```bash
sudo binance_phase1_collector/tools/linux/install.sh      # instala y valida offline
./INICIAR.sh --mode offline                               # integridad + tests + benchmark
./INICIAR.sh --mode preflight                             # añade el gate de reloj
```

## Capturar

```bash
./INICIAR.sh --mode 10m  --symbol BTCUSDT   # prueba certificable de 10 min
./INICIAR.sh --mode full --symbol BTCUSDT   # certificación completa 10+30+120
sudo systemctl start jean-flow              # captura continua supervisada
```

La escalera de la Fase 2 del plan rector (10/30/120 intercaladas con Windows,
umbrales vigentes sin relajar ninguno) decide la migración; este paquete solo
la hace posible.

## Recoger evidencia

```bash
binance_phase1_collector/tools/linux/recoger_evidencia.sh
```

Solo lee; empaqueta únicamente informes (`.json .jsonl .txt .log .md`,
≤100 MB), jamás CSV de datos, e incluye la evidencia del sidecar de chrony.

## Vuelta atrás

```bash
sudo binance_phase1_collector/tools/linux/rollback.sh
```

Vuelve al release anterior con swap atómico de symlinks, validándolo offline
antes del cambio. Los datos de `/var/lib/jean-flow` no se tocan jamás.
