from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


MAX_REPORT_BYTES = 16 * 1024 * 1024


def _load(path: Path) -> dict[str, Any]:
    raw = path.read_bytes()
    if not raw or len(raw) > MAX_REPORT_BYTES:
        raise ValueError(f"{path}: reporte vacío o demasiado grande")

    def reject(value: str) -> None:
        raise ValueError(f"constante no finita: {value}")

    payload = json.loads(raw.decode("utf-8-sig"), parse_constant=reject)
    if not isinstance(payload, dict):
        raise ValueError(f"{path}: se esperaba un objeto JSON")
    replay = payload.get("replay")
    certification = payload.get("certification")
    if not isinstance(replay, dict) or not isinstance(certification, dict):
        raise ValueError(f"{path}: replay/certification ausente")
    if certification.get("journal_integrity") != "PASS":
        raise ValueError(f"{path}: journal_integrity no es PASS")
    if certification.get("causal_replay") != "PASS":
        raise ValueError(f"{path}: causal_replay no es PASS")
    digest = replay.get("sha256")
    if (
        not isinstance(digest, str)
        or len(digest) != 64
        or any(character not in "0123456789abcdef" for character in digest)
    ):
        raise ValueError(f"{path}: replay.sha256 inválido")
    return payload


def compare(first_path: Path, second_path: Path) -> dict[str, Any]:
    first = _load(first_path)
    second = _load(second_path)
    first_replay = first["replay"]
    second_replay = second["replay"]
    identical = first_replay == second_replay
    return {
        "pass": identical,
        "comparison": "canonical_replay_object",
        "first": str(first_path.resolve()),
        "second": str(second_path.resolve()),
        "first_sha256": first_replay["sha256"],
        "second_sha256": second_replay["sha256"],
        "canonical_hash_version": first_replay.get("canonical_hash_version"),
        "same_sha256": first_replay["sha256"] == second_replay["sha256"],
        "same_replay_object": identical,
        "note": (
            "Las rutas y el formato del reporte completo son metadatos de "
            "plataforma; no forman parte del gate determinista."
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Compara el estado causal canónico entre dos plataformas"
    )
    parser.add_argument("first", type=Path)
    parser.add_argument("second", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        result = compare(args.first, args.second)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
        result = {"pass": False, "error_code": "REPLAY_COMPARISON_INVALID", "message": str(exc)}
    rendered = json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    if args.output is not None:
        args.output.write_text(rendered, encoding="utf-8", newline="\n")
    print(rendered, end="")
    return 0 if result.get("pass") is True else 1


if __name__ == "__main__":
    raise SystemExit(main())
