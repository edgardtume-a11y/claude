from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

RELEASE_VERSION = "2.4.1+linux.2"
ARCHIVE_ROOT = "555"
MANIFEST_NAME = "RELEASE_MANIFEST.sha256"
SOURCE_ROOT = Path(__file__).resolve().parents[2]
PROJECT_ROOT = SOURCE_ROOT / "binance_phase1_collector"
EXCLUDED_PARTS = frozenset(
    {
        ".git",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        ".venv",
        ".runtime",
        ".runtime_building",
        "__pycache__",
        "build",
        "data",
        "data_dual",
        "dist",
        "runs",
    }
)
# P3.5b/[S14c]: un RELEASE_MANIFEST.tmp huérfano de un build interrumpido se
# empaquetaba como fichero legítimo en el build siguiente.
EXCLUDED_SUFFIXES = (".pyc", ".pyo", ".tmp")
FIXED_ZIP_TIME = (2026, 8, 13, 0, 0, 0)
WHEELHOUSE = PROJECT_ROOT / "wheelhouse"
WHEELHOUSE_MANIFEST = WHEELHOUSE / "WHEELHOUSE_MANIFEST.sha256"
CORE_SOURCE_MANIFEST = PROJECT_ROOT / "CORE_SOURCE_MANIFEST.sha256"
CORE_SOURCE_FILES = frozenset(
    {
        "src/binance_collector/audit.py",
        "src/binance_collector/collector.py",
        "src/binance_collector/config.py",
        "src/binance_collector/dashboard.py",
        "src/binance_collector/metrics.py",
        "src/binance_collector/normalize.py",
        "src/binance_collector/order_book.py",
        "src/binance_collector/protocol.py",
        "src/binance_collector/reconstruct.py",
        "src/binance_collector/rest.py",
        "src/binance_collector/writer.py",
    }
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _is_excluded(path: Path) -> bool:
    relative = path.relative_to(SOURCE_ROOT)
    if any(
        part in EXCLUDED_PARTS
        or part.endswith(".egg-info")
        or part.startswith(".venv_preserved_")
        or part.startswith(".runtime_preserved_")
        for part in relative.parts
    ):
        return True
    if path.name in {".jean_flow_launcher.lock", ".jean_flow_bootstrap.lock"}:
        return True
    return path.name.endswith(EXCLUDED_SUFFIXES)


def _files(*, include_manifest: bool) -> list[Path]:
    result = []
    for path in SOURCE_ROOT.rglob("*"):
        if not path.is_file() or _is_excluded(path):
            continue
        if not include_manifest and path.name == MANIFEST_NAME:
            continue
        result.append(path)
    return sorted(
        result, key=lambda item: item.relative_to(SOURCE_ROOT).as_posix().casefold()
    )


def _validate_tree(files: list[Path]) -> None:
    commands = [path for path in files if path.suffix.casefold() == ".cmd"]
    expected = SOURCE_ROOT / "INICIAR.cmd"
    if commands != [expected]:
        raise RuntimeError(
            f"Se requiere únicamente {expected}; encontrados {commands!r}"
        )
    linux_entry = SOURCE_ROOT / "INICIAR.sh"
    root_shell_scripts = [
        path
        for path in files
        if path.parent == SOURCE_ROOT and path.suffix.casefold() == ".sh"
    ]
    if root_shell_scripts != [linux_entry]:
        raise RuntimeError(
            f"Se requiere un único punto de entrada Linux {linux_entry}; "
            f"encontrados {root_shell_scripts!r}"
        )
    for path in files:
        relative = path.relative_to(SOURCE_ROOT).as_posix()
        parts = PurePosixPath(relative).parts
        if not parts or any(part in {"", ".", ".."} for part in parts):
            raise RuntimeError(f"Ruta insegura: {relative!r}")


def _validate_wheelhouse() -> None:
    """Fail the build if the offline Linux dependency set is inconsistent."""

    source_dir = PROJECT_ROOT / "src"
    sys.path.insert(0, str(source_dir))
    try:
        from binance_collector.supply_chain import (
            SupplyChainError,
            expected_runtime_inventory,
            verified_wheel_plan,
        )

        try:
            plan = verified_wheel_plan(PROJECT_ROOT)
            expected_runtime_inventory(plan)
        except SupplyChainError as exc:
            raise RuntimeError(f"WHEELHOUSE_INVALID: {exc}") from exc
    finally:
        try:
            sys.path.remove(str(source_dir))
        except ValueError:
            pass

    command = [
        sys.executable,
        "-I",
        "-m",
        "pip",
        "--isolated",
        "install",
        "--disable-pip-version-check",
        "--no-input",
        "--dry-run",
        "--ignore-installed",
        "--no-index",
        "--no-cache-dir",
        "--find-links",
        str(WHEELHOUSE),
        "--only-binary=:all:",
        "--require-hashes",
        # pip --platform no expande automáticamente todos los alias PEP 600.
        # El conjunto exacto de wheels sellado usa tags 2_17/2014, 2_28 y
        # 2_5/manylinux1; Ubuntu 24.04 (glibc 2.39) admite los cinco.
        "--platform",
        "manylinux_2_17_x86_64",
        "--platform",
        "manylinux2014_x86_64",
        "--platform",
        "manylinux_2_28_x86_64",
        "--platform",
        "manylinux_2_5_x86_64",
        "--platform",
        "manylinux1_x86_64",
        "--python-version",
        "3.12",
        "--implementation",
        "cp",
        "--abi",
        "cp312",
        "-r",
        str(PROJECT_ROOT / "requirements.lock"),
    ]
    completed = subprocess.run(
        command,
        cwd=PROJECT_ROOT,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
        timeout=120,
    )
    if completed.returncode != 0:
        detail = completed.stdout.decode("utf-8", errors="replace")[-4_000:]
        raise RuntimeError(
            "El wheelhouse no resuelve offline para CPython 3.12/Linux x86-64:\n"
            + detail
        )


def _validate_core_source_manifest() -> None:
    entries: dict[str, str] = {}
    try:
        lines = CORE_SOURCE_MANIFEST.read_text(encoding="ascii").splitlines()
    except (OSError, UnicodeError) as exc:
        raise RuntimeError(f"CORE_SOURCE_MANIFEST_INVALID: {exc}") from exc
    for line in lines:
        digest, separator, relative = line.partition("  ")
        candidate = PROJECT_ROOT / relative
        if (
            separator != "  "
            or len(digest) != 64
            or any(character not in "0123456789abcdef" for character in digest)
            or relative not in CORE_SOURCE_FILES
            or relative in entries
            or not candidate.is_file()
            or candidate.is_symlink()
            or _sha256(candidate) != digest
        ):
            raise RuntimeError(
                f"CORE_SOURCE_MANIFEST_INVALID: entrada no canónica {line!r}"
            )
        entries[relative] = digest
    if set(entries) != CORE_SOURCE_FILES:
        raise RuntimeError("CORE_SOURCE_MANIFEST_INVALID: inventario incompleto")


def _write_manifest(files: list[Path]) -> Path:
    manifest = SOURCE_ROOT / MANIFEST_NAME
    lines = [
        f"{_sha256(path)}  {ARCHIVE_ROOT}/{path.relative_to(SOURCE_ROOT).as_posix()}"
        for path in files
    ]
    temporary = manifest.with_suffix(".tmp")
    temporary.write_text("\n".join(lines) + "\n", encoding="ascii", newline="\n")
    os.replace(temporary, manifest)
    return manifest


def build(output: Path) -> dict[str, object]:
    output = output.resolve()
    if output == SOURCE_ROOT or output.is_relative_to(SOURCE_ROOT):
        raise RuntimeError("El ZIP de salida debe estar fuera de la raíz 555")
    _validate_core_source_manifest()
    _validate_wheelhouse()
    files_without_manifest = _files(include_manifest=False)
    _validate_tree(files_without_manifest)
    _write_manifest(files_without_manifest)
    # Use the exact same fail-closed verifier as the bootstrap before a ZIP can
    # be published.  This catches version drift, Unicode/case collisions and
    # any mismatch between build-time and runtime exclusions.
    source_dir = PROJECT_ROOT / "src"
    sys.path.insert(0, str(source_dir))
    try:
        from binance_collector.release_integrity import (
            ReleaseIntegrityError,
            verify_release_tree,
        )

        try:
            integrity = verify_release_tree(
                SOURCE_ROOT,
                expected_version=RELEASE_VERSION,
            )
        except ReleaseIntegrityError as exc:
            raise RuntimeError(f"{exc.code}: {exc}") from exc
    finally:
        try:
            sys.path.remove(str(source_dir))
        except ValueError:
            pass
    files = _files(include_manifest=True)
    _validate_tree(files)
    output.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{output.name}.", suffix=".tmp", dir=output.parent
    )
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        with zipfile.ZipFile(
            temporary,
            "w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=9,
            allowZip64=True,
        ) as archive:
            for path in files:
                relative = path.relative_to(SOURCE_ROOT).as_posix()
                info = zipfile.ZipInfo(f"{ARCHIVE_ROOT}/{relative}", FIXED_ZIP_TIME)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                mode = 0o755 if path.suffix.casefold() == ".sh" else 0o644
                info.external_attr = (mode & 0xFFFF) << 16
                info.flag_bits |= 0x800
                archive.writestr(
                    info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED
                )
        os.replace(temporary, output)
    finally:
        temporary.unlink(missing_ok=True)
    return {
        "pass": True,
        "release_version": RELEASE_VERSION,
        "archive": str(output),
        "archive_sha256": _sha256(output),
        "wheelhouse_validated": True,
        "release_integrity_validated": integrity["pass"] is True,
        "release_manifest_sha256": integrity["manifest_sha256"],
        "files": len(files),
        "size_bytes": output.stat().st_size,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Construye el ZIP reproducible JEAN_FLOW"
    )
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    try:
        result = build(args.output)
    # P3.5a: un TimeoutExpired del dry-run de pip rompía el contrato JSON.
    except (OSError, RuntimeError, zipfile.BadZipFile, subprocess.SubprocessError) as exc:
        result = {
            "pass": False,
            "error_code": "RELEASE_BUILD_FAILED",
            "message": f"{type(exc).__name__}: {exc}",
        }
        print(json.dumps(result, sort_keys=True, separators=(",", ":")))
        return 1
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
