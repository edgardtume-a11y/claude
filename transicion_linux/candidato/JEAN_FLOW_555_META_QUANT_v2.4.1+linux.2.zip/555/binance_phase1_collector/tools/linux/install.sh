#!/usr/bin/env bash
set -euo pipefail

release_version='2.4.1+linux.2'
service_name='jean-flow.service'
sidecar_name='jean-flow-chrony-sidecar.service'
start_service=0
if [[ "${1:-}" == '--start' ]]; then
  start_service=1
elif [[ $# -ne 0 ]]; then
  printf 'Uso: %s [--start]\n' "$0" >&2
  exit 2
fi

if [[ "${EUID}" -ne 0 ]]; then
  printf '%s\n' 'INSTALL_REQUIRES_ROOT: use sudo solo para instalar.' >&2
  exit 2
fi
if [[ "$(uname -s)" != 'Linux' || "$(uname -m)" != 'x86_64' ]]; then
  printf '%s\n' 'PLATFORM_UNSUPPORTED: se requiere Linux x86-64.' >&2
  exit 2
fi
if [[ ! -r /etc/os-release ]]; then
  printf '%s\n' 'OS_RELEASE_MISSING: no se pudo identificar Ubuntu.' >&2
  exit 2
fi
. /etc/os-release
if [[ "${ID:-}" != 'ubuntu' || "${VERSION_ID:-}" != '24.04' ]]; then
  printf 'OS_UNSUPPORTED: detectado %s %s; se requiere Ubuntu 24.04.\n' \
    "${ID:-desconocido}" "${VERSION_ID:-desconocido}" >&2
  exit 2
fi
for required in /usr/bin/python3.12 /usr/bin/chronyc /usr/bin/systemctl /usr/sbin/runuser; do
  if [[ ! -x "${required}" ]]; then
    printf 'DEPENDENCY_MISSING: %s\n' "${required}" >&2
    exit 2
  fi
done

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
source_root="$(cd -- "${script_dir}/../../.." && pwd -P)"
target_root="/opt/jean-flow/releases/${release_version}"
target_tree="${target_root}/555"

if [[ -e "${target_root}" ]]; then
  printf 'RELEASE_EXISTS: %s; no se sobrescribe.\n' "${target_root}" >&2
  exit 2
fi

if ! /usr/bin/getent group jean-flow >/dev/null; then
  /usr/sbin/groupadd --system jean-flow
fi
if ! id -u jean-flow >/dev/null 2>&1; then
  /usr/sbin/useradd --system --home-dir /var/lib/jean-flow \
    --shell /usr/sbin/nologin --gid jean-flow jean-flow
fi

/usr/bin/install -d -o root -g root -m 0755 /opt/jean-flow/releases
/usr/bin/install -d -o jean-flow -g jean-flow -m 0700 /var/lib/jean-flow
/usr/bin/install -d -o jean-flow -g jean-flow -m 0700 /var/lib/jean-flow/.run
/usr/bin/install -d -o root -g jean-flow -m 0750 /etc/jean-flow
/usr/bin/install -d -o root -g root -m 0755 "${target_root}"
/bin/cp -a -- "${source_root}" "${target_tree}"
/bin/chown -R root:root "${target_root}"
/usr/bin/find "${target_root}" -type d -exec /bin/chmod 0755 {} +
/usr/bin/find "${target_root}" -type f -exec /bin/chmod 0644 {} +
/bin/chmod 0755 "${target_tree}/INICIAR.sh"
/bin/chmod 0755 "${target_tree}/binance_phase1_collector/tools/linux/"*.sh

if [[ ! -f /etc/jean-flow/jean-flow.env ]]; then
  /usr/bin/install -o root -g jean-flow -m 0640 \
    "${target_tree}/binance_phase1_collector/tools/linux/jean-flow.env.example" \
    /etc/jean-flow/jean-flow.env
fi

# Validación fría antes de hacer visible el release. Construye el runtime
# desde el wheelhouse local, sin red y con el usuario de servicio.
/usr/sbin/runuser -u jean-flow -- /usr/bin/env \
  JEAN_FLOW_STATE_ROOT=/var/lib/jean-flow \
  JEAN_FLOW_RUNTIME_DIR=/var/lib/jean-flow/.run \
  "${target_tree}/INICIAR.sh" --mode offline --no-browser

current_target=''
if [[ -L /opt/jean-flow/current ]]; then
  current_target="$(readlink -f /opt/jean-flow/current)"
fi
if [[ -n "${current_target}" ]]; then
  /bin/ln -sfn "${current_target}" /opt/jean-flow/previous.next
  /bin/mv -Tf /opt/jean-flow/previous.next /opt/jean-flow/previous
fi
/bin/ln -s "${target_root}" /opt/jean-flow/current.next
/bin/mv -Tf /opt/jean-flow/current.next /opt/jean-flow/current

/usr/bin/install -o root -g root -m 0644 \
  "${target_tree}/binance_phase1_collector/tools/linux/${service_name}" \
  "/etc/systemd/system/${service_name}"
/usr/bin/install -o root -g root -m 0644 \
  "${target_tree}/binance_phase1_collector/tools/linux/${sidecar_name}" \
  "/etc/systemd/system/${sidecar_name}"
/usr/bin/systemd-analyze verify "/etc/systemd/system/${service_name}"
/usr/bin/systemd-analyze verify "/etc/systemd/system/${sidecar_name}"
/usr/bin/systemctl daemon-reload
/usr/bin/systemctl enable "${service_name}"
if [[ "${start_service}" -eq 1 ]]; then
  /usr/bin/systemctl restart "${service_name}"
fi

printf 'INSTALLED: %s\n' "${target_root}"
printf '%s\n' 'Siguiente paso: revise /etc/jean-flow/jean-flow.env y ejecute:'
printf '%s\n' '  sudo systemctl start jean-flow.service'
