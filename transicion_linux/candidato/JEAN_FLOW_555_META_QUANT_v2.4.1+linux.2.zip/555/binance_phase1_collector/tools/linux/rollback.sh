#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  printf '%s\n' 'ROLLBACK_REQUIRES_ROOT: use sudo.' >&2
  exit 2
fi
if [[ ! -L /opt/jean-flow/current || ! -L /opt/jean-flow/previous ]]; then
  printf '%s\n' 'ROLLBACK_TARGET_MISSING: faltan current/previous.' >&2
  exit 2
fi

current_target="$(readlink -f /opt/jean-flow/current)"
previous_target="$(readlink -f /opt/jean-flow/previous)"
previous_entry="${previous_target}/555/INICIAR.sh"
if [[ ! -x "${previous_entry}" ]]; then
  printf 'ROLLBACK_TARGET_INVALID: %s\n' "${previous_entry}" >&2
  exit 2
fi

/usr/bin/systemctl stop jean-flow.service
/usr/sbin/runuser -u jean-flow -- /usr/bin/env \
  JEAN_FLOW_STATE_ROOT=/var/lib/jean-flow \
  JEAN_FLOW_RUNTIME_DIR=/var/lib/jean-flow/.run \
  "${previous_entry}" --mode offline --no-browser

/bin/ln -s "${previous_target}" /opt/jean-flow/current.next
/bin/mv -Tf /opt/jean-flow/current.next /opt/jean-flow/current
/bin/ln -s "${current_target}" /opt/jean-flow/previous.next
/bin/mv -Tf /opt/jean-flow/previous.next /opt/jean-flow/previous
/usr/bin/systemctl start jean-flow.service

printf 'ROLLBACK_OK: current=%s previous=%s\n' \
  "$(readlink -f /opt/jean-flow/current)" \
  "$(readlink -f /opt/jean-flow/previous)"
