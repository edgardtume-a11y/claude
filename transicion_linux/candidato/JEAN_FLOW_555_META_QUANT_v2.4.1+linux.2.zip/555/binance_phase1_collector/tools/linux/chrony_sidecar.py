from __future__ import annotations

import argparse
import json
import os
import signal
import stat
import subprocess
import threading
import time
from pathlib import Path
from typing import Any


CHRONYC = Path("/usr/bin/chronyc")
STOP = threading.Event()


def _stop(_signum: int, _frame: object) -> None:
    STOP.set()


def _trusted_binary() -> Path:
    if CHRONYC.is_symlink():
        raise RuntimeError("chronyc no puede ser un symlink")
    resolved = CHRONYC.resolve(strict=True)
    metadata = resolved.stat()
    if (
        not stat.S_ISREG(metadata.st_mode)
        or metadata.st_uid != 0
        or metadata.st_mode & 0o022
        or not os.access(resolved, os.X_OK)
    ):
        raise RuntimeError("chronyc no es un binario de sistema confiable")
    return resolved


def _chronyc(binary: Path, command: str) -> dict[str, Any]:
    try:
        completed = subprocess.run(
            [str(binary), "-n", "-c", command],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=8.0,
        )
        output = completed.stdout.decode("utf-8", errors="replace").strip()
        return {
            "returncode": completed.returncode,
            "output_csv": output,
            "pass": completed.returncode == 0 and bool(output),
        }
    except subprocess.TimeoutExpired:
        return {"returncode": None, "output_csv": "", "pass": False, "error": "TIMEOUT"}


def _active_session(runs_root: Path) -> dict[str, Any] | None:
    candidates = sorted(
        runs_root.glob("*/control/session.json"),
        key=lambda path: path.stat().st_mtime_ns if path.exists() else 0,
        reverse=True,
    )
    for path in candidates[:10]:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            continue
        if isinstance(payload, dict) and payload.get("state") in {
            "STARTING",
            "IDENTITY_READY",
            "CAPTURING",
            "STOPPING",
        }:
            return {
                "capture_session_id": payload.get("capture_session_id"),
                "state": payload.get("state"),
                "launcher_pid": payload.get("launcher_pid"),
                "engine_pid": payload.get("engine_pid"),
                "manifest": str(path),
            }
    return None


def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        + "\n"
    ).encode("utf-8")
    descriptor = os.open(
        path,
        os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_CLOEXEC", 0),
        0o600,
    )
    try:
        os.write(descriptor, encoded)
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def main() -> int:
    parser = argparse.ArgumentParser(description="Sidecar read-only de chrony")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--runs-root", required=True, type=Path)
    parser.add_argument("--interval", type=float, default=60.0)
    args = parser.parse_args()
    if not 10.0 <= args.interval <= 3600.0:
        raise SystemExit("interval debe estar entre 10 y 3600 segundos")
    binary = _trusted_binary()
    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)
    boot_id_path = Path("/proc/sys/kernel/random/boot_id")
    boot_id = boot_id_path.read_text(encoding="ascii").strip()
    while not STOP.is_set():
        payload = {
            "schema_version": 1,
            "sidecar_pid": os.getpid(),
            "boot_id": boot_id,
            "observed_utc_ns": time.time_ns(),
            "observed_monotonic_ns": time.monotonic_ns(),
            "session": _active_session(args.runs_root),
            "tracking": _chronyc(binary, "tracking"),
            "sources": _chronyc(binary, "sources"),
            "informational_only": True,
        }
        _append_jsonl(args.output, payload)
        STOP.wait(args.interval)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
