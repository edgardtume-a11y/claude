#!/usr/bin/env bash
# Recogedor de evidencia para Linux — equivalente de RECOGER_EVIDENCIA_TODO.cmd
# con su MISMA política, heredada literal del protocolo:
#   - SOLO lee y copia: jamás modifica, renombra ni borra nada.
#   - Solo informes: .json .jsonl .txt .log .md — NUNCA CSV de datos.
#   - Nada mayor de 100 MB por archivo.
#   - Recorre TODAS las carpetas runs/ cuyo padre sea binance_phase1_collector
#     bajo la raíz de estado, incluidas instalaciones apartadas.
#
# Uso:  ./recoger_evidencia.sh [RAIZ]     (por defecto JEAN_FLOW_STATE_ROOT,
#                                          o /var/lib/jean-flow si existe,
#                                          o el árbol junto a este script)

set -euo pipefail
umask 077

if [[ "${EUID}" -eq 0 ]]; then
  printf '%s\n' 'ROOT_PROCESS_FORBIDDEN: ejecute sin sudo.' >&2
  exit 2
fi

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
raiz="${1:-${JEAN_FLOW_STATE_ROOT:-}}"
if [[ -z "${raiz}" ]]; then
  if [[ -d /var/lib/jean-flow/runs ]]; then
    raiz=/var/lib/jean-flow
  else
    raiz="$(cd -- "${script_dir}/../../.." && pwd -P)"
  fi
fi

marca="$(date -u +%Y%m%dT%H%M%SZ)"
destino="${HOME}/EVIDENCIA_PARA_CLAUDE_TODO_${marca}.tar.gz"
lista="$(mktemp)"
trap 'rm -f "${lista}"' EXIT

find "${raiz}" -maxdepth 8 -type d -name runs 2>/dev/null | while read -r rdir; do
  case "${rdir}" in
    */binance_phase1_collector/runs|"${raiz}/runs") ;;
    *) continue ;;
  esac
  find "${rdir}" -type f \( -name '*.json' -o -name '*.jsonl' -o -name '*.txt' \
    -o -name '*.log' -o -name '*.md' \) -size -100M -print
done > "${lista}"

# El sidecar de chrony guarda su evidencia fuera de runs/: se incluye.
if [[ -d "${raiz}/clock" ]]; then
  find "${raiz}/clock" -type f -name '*.jsonl' -size -100M -print >> "${lista}"
fi

if [[ ! -s "${lista}" ]]; then
  printf '%s\n' 'No se encontró ninguna carpeta runs/ con informes: nada que recoger.' >&2
  exit 1
fi

tar -czf "${destino}" --files-from="${lista}" -P
sha256sum "${destino}" | tee "${destino}.sha256"
printf 'Evidencia empaquetada en: %s\n' "${destino}"
printf 'Sube ese archivo (y su .sha256) al chat.\n'
