from __future__ import annotations

import os
import runpy
import sys
from pathlib import Path

sys.dont_write_bytecode = True


def _force_utf8_stdio() -> None:
    # [2.3.5] Todo hijo aislado imprime informes JSON (ensure_ascii=False)
    # que el launcher relee como UTF-8 estricto. En Windows es-ES un stdout
    # redirigido usa cp1252 ('é'→0xE9 → "invalid continuation byte"; 'θ̂' no
    # representable → UnicodeEncodeError). Con -I se ignoran PYTHONUTF8 y
    # PYTHONIOENCODING, así que se reconfigura aquí, además del flag
    # -X utf8 que añade el launcher (defensa en profundidad).
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8")
            except (OSError, ValueError):  # pragma: no cover - mejor esfuerzo
                pass

# [S12]: allowlist de módulos ejecutables; `mode == "module"` no tenía
# ninguna mientras `mode == "path"` sí validaba.
_ALLOWED_MODULES = frozenset(
    {
        "pytest",
        "binance_collector.dual_main",
        "binance_collector.audit",
        "binance_collector.main",
        "binance_collector.reconstruct",
    }
)


def _verified_paths() -> tuple[Path, Path, Path]:
    # I5: la propiedad del PROCESO se comprueba en tiempo de ejecución, no se
    # presupone del comando que nos lanzó.
    if not (sys.flags.isolated and sys.flags.no_site and sys.flags.utf8_mode):
        raise RuntimeError("ISOLATED_FLAGS_MISSING: ejecute con -X utf8 -I -S")
    source_value = os.environ.get("JEAN_FLOW_SOURCE_ROOT")
    site_value = os.environ.get("JEAN_FLOW_RUNTIME_PACKAGES")
    runtime_root_value = os.environ.get("JEAN_FLOW_RUNTIME_ROOT")
    manifest_digest = os.environ.get("JEAN_FLOW_RELEASE_MANIFEST_SHA256")
    if not source_value or not site_value or not runtime_root_value or not manifest_digest:
        raise RuntimeError("ISOLATED_RUNTIME_ENV_MISSING")
    source = Path(source_value).resolve()
    site_packages = Path(site_value).resolve()
    runtime_root = Path(runtime_root_value).resolve()
    # [S12]: la validación anterior (`source != (source.parent/"src")`)
    # equivalía a `source.name == "src"`: parecía un anclaje y no anclaba
    # nada — con control del entorno del hijo, sys.path[0] apuntaba a un
    # árbol del atacante. El ancla real es la ubicación de ESTE archivo, que
    # el launcher invoca por ruta absoluta dentro del proyecto verificado.
    anchor_project = Path(__file__).resolve().parents[2]
    project = source.parent
    if (
        project != anchor_project
        or source != (anchor_project / "src").resolve()
        or site_packages != (runtime_root / "packages").resolve()
        or not source.is_dir()
        or not site_packages.is_dir()
    ):
        raise RuntimeError("ISOLATED_RUNTIME_PATH_INVALID")
    sys.path.insert(0, str(source))

    from binance_collector.supply_chain import (
        SupplyChainError,
        verify_runtime_tree,
    )

    try:
        runtime_report = verify_runtime_tree(project, site_packages)
    except SupplyChainError as exc:
        raise RuntimeError(f"ISOLATED_RUNTIME_INTEGRITY_FAILED: {exc}") from exc
    inherited_runtime = os.environ.get("JEAN_FLOW_RUNTIME_INVENTORY_SHA256")
    if runtime_report["inventory_sha256"] != inherited_runtime:
        raise RuntimeError("ISOLATED_RUNTIME_INVENTORY_MISMATCH")
    sys.path.append(str(site_packages))

    from binance_collector import __version__
    from binance_collector.release_integrity import verify_release_tree

    integrity = verify_release_tree(project.parent, expected_version=__version__)
    if integrity["manifest_sha256"] != manifest_digest:
        raise RuntimeError("ISOLATED_RUNTIME_MANIFEST_MISMATCH")
    return source, site_packages, project


def main() -> None:
    _force_utf8_stdio()
    _source, _site_packages, project = _verified_paths()
    if len(sys.argv) < 3 or sys.argv[1] not in {"module", "path"}:
        raise RuntimeError("Uso: isolated_entry.py {module|path} TARGET [args]")
    mode, target, *arguments = sys.argv[1:]
    sys.argv = [target, *arguments]
    if mode == "module":
        if target not in _ALLOWED_MODULES:
            raise RuntimeError(
                f"ISOLATED_RUNTIME_TARGET_INVALID: módulo no permitido {target!r}"
            )
        runpy.run_module(target, run_name="__main__", alter_sys=True)
        return
    target_path = Path(target).resolve()
    if (
        not target_path.is_file()
        or target_path.is_symlink()
        or not target_path.is_relative_to(project)
        or target_path.suffix != ".py"
    ):
        raise RuntimeError("ISOLATED_RUNTIME_TARGET_INVALID")
    runpy.run_path(str(target_path), run_name="__main__")


if __name__ == "__main__":
    main()
