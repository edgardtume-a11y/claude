"""Evidencia y gate de reloj para Linux, leyendo chronyd en CSV estable.

Sustituye en Linux a la cadena PowerShell de tiempo de Windows (salida
localizada con decenas de regex multilingües, STATUS_LOCALE_UNSUPPORTED):
``chronyc -n -c tracking`` emite CSV idéntico en cualquier locale y este
módulo lo valida campo a campo, fallando cerrado ante cualquier anomalía.

Dos números, dos papeles — y no se mezclan:

* **Gate vigente (bloqueante):** ``abs(offset del sistema) <= CLOCK_WARN_MS``.
  Es el MISMO criterio y el MISMO umbral de 50 ms que aplica el gate de
  Windows sobre el desplazamiento de fase; solo cambia la fuente de la
  medición. No se endurece ni se relaja aquí.
* **Calidad UTC calificada (informativa):** la banda demostrable
  ``abs(offset) + dispersion_raiz + retardo_raiz/2`` se publica junto al
  veredicto ``utc_calificada`` (DEMOSTRADA / INSUFICIENTE / UNKNOWN).
  [DECISIÓN DEL PROYECTO, plan rector §6.3] ese criterio está diseñado pero
  NO implementado como gate hasta que exista un consumidor que lo necesite:
  aquí es evidencia y nunca puede negar nada.

Este módulo es de SOLO LECTURA: jamás disciplina, escalona ni configura el
reloj. Eso es de chronyd y de nadie más.
"""

from __future__ import annotations

import math
import os
import stat
import subprocess
import time
from pathlib import Path
from typing import Any, Callable


CHRONYC_PATH = Path("/usr/bin/chronyc")
TRACKING_FIELD_COUNT = 14
DEFAULT_WARN_MS = 50.0


class ChronyEvidenceError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def _finite_float(value: str, *, field: str) -> float:
    try:
        parsed = float(value)
    except ValueError as exc:
        raise ChronyEvidenceError(
            "CHRONY_TRACKING_INVALID", f"{field} no es numérico"
        ) from exc
    if not math.isfinite(parsed):
        raise ChronyEvidenceError("CHRONY_TRACKING_INVALID", f"{field} no es finito")
    return parsed


def _finite_int(value: str, *, field: str) -> int:
    parsed = _finite_float(value, field=field)
    integer = int(parsed)
    if parsed != integer:
        raise ChronyEvidenceError("CHRONY_TRACKING_INVALID", f"{field} no es entero")
    return integer


def parse_tracking_csv(
    raw: str,
    *,
    now_utc_s: float | None = None,
    warn_ms: float = DEFAULT_WARN_MS,
) -> dict[str, Any]:
    """Valida ``chronyc -n -c tracking`` y aplica el gate vigente de 50 ms."""

    lines = [line.strip() for line in raw.splitlines() if line.strip()]
    if len(lines) != 1:
        raise ChronyEvidenceError(
            "CHRONY_TRACKING_INVALID", "se esperaba exactamente una línea CSV"
        )
    fields = [field.strip() for field in lines[0].split(",")]
    if len(fields) != TRACKING_FIELD_COUNT:
        raise ChronyEvidenceError(
            "CHRONY_TRACKING_INVALID",
            f"se esperaban {TRACKING_FIELD_COUNT} campos; llegaron {len(fields)}",
        )

    reference_id, reference_source = fields[0], fields[1]
    if not reference_id or not reference_source:
        raise ChronyEvidenceError(
            "CHRONY_UNSYNCHRONIZED", "chrony no informa una fuente activa"
        )
    stratum = _finite_int(fields[2], field="stratum")
    reference_time = _finite_float(fields[3], field="reference_time_utc_s")
    system_time = _finite_float(fields[4], field="system_time_s")
    last_offset = _finite_float(fields[5], field="last_offset_s")
    rms_offset = _finite_float(fields[6], field="rms_offset_s")
    frequency = _finite_float(fields[7], field="frequency_ppm")
    residual_frequency = _finite_float(fields[8], field="residual_frequency_ppm")
    skew = _finite_float(fields[9], field="skew_ppm")
    root_delay = _finite_float(fields[10], field="root_delay_s")
    root_dispersion = _finite_float(fields[11], field="root_dispersion_s")
    update_interval = _finite_float(fields[12], field="update_interval_s")
    leap_status = fields[13]

    if not 1 <= stratum <= 15:
        raise ChronyEvidenceError(
            "CHRONY_UNSYNCHRONIZED", f"stratum fuera de rango: {stratum}"
        )
    if leap_status.casefold() != "normal":
        raise ChronyEvidenceError(
            "CHRONY_UNSYNCHRONIZED", f"leap status no normal: {leap_status!r}"
        )
    if reference_time <= 0.0 or update_interval <= 0.0:
        raise ChronyEvidenceError(
            "CHRONY_TRACKING_INVALID", "tiempo de referencia/intervalo inválido"
        )
    if root_delay < 0.0 or root_dispersion < 0.0 or skew < 0.0:
        raise ChronyEvidenceError(
            "CHRONY_TRACKING_INVALID", "delay/dispersion/skew negativos"
        )

    observed_utc_s = time.time() if now_utc_s is None else float(now_utc_s)
    reference_age_s = observed_utc_s - reference_time
    # Frescura: mismo invariante que el contrato del gate de Windows
    # (2·poll + 60 s) y la misma tolerancia de futuro que
    # READY_CLOCK_FUTURE_TOLERANCE_S.
    maximum_age_s = (2.0 * update_interval) + 60.0
    if reference_age_s < -5.0 or reference_age_s > maximum_age_s:
        raise ChronyEvidenceError(
            "CHRONY_REFERENCE_STALE",
            f"fuente sin actualización reciente: age={reference_age_s:.3f}s",
        )

    abs_phase_offset_ms = abs(system_time) * 1_000.0
    banda_ms = (root_dispersion + 0.5 * root_delay) * 1_000.0
    incertidumbre_total_ms = abs_phase_offset_ms + banda_ms

    # Gate VIGENTE: |offset| <= 50 ms, el mismo número y el mismo sentido que
    # el gate de W32Time. La banda NO participa del veredicto.
    passed = abs_phase_offset_ms <= warn_ms
    # Calidad UTC calificada: |offset| + banda <= L. INFORMATIVA; nunca niega.
    utc_calificada = "DEMOSTRADA" if incertidumbre_total_ms <= warn_ms else "INSUFICIENTE"

    return {
        "pass": passed,
        "error_code": "PASS" if passed else "CLOCK_OFFSET_EXCEEDED",
        "clock_provider": "chrony",
        "offset_method": "chronyd_tracking_csv",
        "warn_ms": warn_ms,
        "phase_offset_ms": round(system_time * 1_000.0, 6),
        "abs_phase_offset_ms": round(abs_phase_offset_ms, 6),
        "banda_ms": round(banda_ms, 6),
        "incertidumbre_total_ms": round(incertidumbre_total_ms, 6),
        "utc_calificada": utc_calificada,
        "reference_id": reference_id,
        "reference_source": reference_source,
        "stratum": stratum,
        "reference_time_utc_s": reference_time,
        "reference_age_s": round(reference_age_s, 6),
        "last_offset_s": last_offset,
        "rms_offset_s": rms_offset,
        "frequency_ppm": frequency,
        "residual_frequency_ppm": residual_frequency,
        "skew_ppm": skew,
        "root_delay_s": root_delay,
        "root_dispersion_s": root_dispersion,
        "update_interval_s": update_interval,
        "leap_status": leap_status,
        "observed_utc_ns": int(observed_utc_s * 1_000_000_000),
        "raw_tracking_csv": lines[0],
    }


def verify_chronyc_binary(path: Path = CHRONYC_PATH) -> Path:
    """Solo acepta un ejecutable fijo del sistema, de root y no escribible."""

    try:
        if path.is_symlink():
            raise ChronyEvidenceError(
                "CHRONYC_BINARY_UNTRUSTED", f"{path} no puede ser un symlink"
            )
        resolved = path.resolve(strict=True)
        metadata = resolved.stat()
    except OSError as exc:
        raise ChronyEvidenceError(
            "CHRONYC_NOT_FOUND", f"chronyc no disponible en {path}: {exc}"
        ) from exc
    if not stat.S_ISREG(metadata.st_mode) or not os.access(resolved, os.X_OK):
        raise ChronyEvidenceError(
            "CHRONYC_BINARY_UNTRUSTED", f"{resolved} no es ejecutable regular"
        )
    if metadata.st_uid != 0 or metadata.st_mode & 0o022:
        raise ChronyEvidenceError(
            "CHRONYC_BINARY_UNTRUSTED",
            f"{resolved} debe pertenecer a root y no ser escribible por grupo/otros",
        )
    return resolved


Runner = Callable[..., "subprocess.CompletedProcess[bytes]"]


def read_clock_evidence(
    *,
    binary: Path = CHRONYC_PATH,
    timeout_s: float = 8.0,
    warn_ms: float = DEFAULT_WARN_MS,
    now_utc_s: float | None = None,
    runner: Runner = subprocess.run,
) -> dict[str, Any]:
    started_monotonic_ns = time.monotonic_ns()
    try:
        trusted_binary = verify_chronyc_binary(binary)
        completed = runner(
            [str(trusted_binary), "-n", "-c", "tracking"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=timeout_s,
        )
        if completed.returncode != 0:
            detail = completed.stdout.decode("utf-8", errors="replace")[-1_000:]
            raise ChronyEvidenceError(
                "CHRONYC_COMMAND_FAILED",
                f"chronyc terminó con {completed.returncode}: {detail}",
            )
        try:
            decoded = completed.stdout.decode("utf-8", errors="strict")
        except UnicodeError as exc:
            raise ChronyEvidenceError(
                "CHRONY_TRACKING_INVALID", "chronyc no devolvió UTF-8"
            ) from exc
        payload = parse_tracking_csv(decoded, now_utc_s=now_utc_s, warn_ms=warn_ms)
    except subprocess.TimeoutExpired:
        payload = {
            "pass": False,
            "error_code": "CHRONYC_TIMEOUT",
            "message": f"chronyc superó {timeout_s:.1f} s",
            "utc_calificada": "UNKNOWN",
        }
    except ChronyEvidenceError as exc:
        payload = {
            "pass": False,
            "error_code": exc.code,
            "message": str(exc),
            "utc_calificada": "UNKNOWN",
        }
    payload["clock_provider"] = "chrony"
    payload["warn_ms"] = warn_ms
    payload["duration_monotonic_ns"] = time.monotonic_ns() - started_monotonic_ns
    return payload


def preflight_clock(
    *,
    binary: Path = CHRONYC_PATH,
    max_wait_s: float = 60.0,
    poll_interval_s: float = 5.0,
    warn_ms: float = DEFAULT_WARN_MS,
    runner: Runner = subprocess.run,
) -> dict[str, Any]:
    """Reintenta en solo-lectura hasta que chrony esté listo; jamás lo ajusta."""

    deadline = time.monotonic() + max_wait_s
    attempts: list[dict[str, Any]] = []
    while True:
        payload = read_clock_evidence(binary=binary, warn_ms=warn_ms, runner=runner)
        attempts.append(payload)
        if payload.get("pass") is True:
            break
        if payload.get("error_code") in {
            "CHRONYC_NOT_FOUND",
            "CHRONYC_BINARY_UNTRUSTED",
            "CHRONY_TRACKING_INVALID",
        }:
            break
        remaining = deadline - time.monotonic()
        if remaining <= 0.0:
            break
        time.sleep(min(poll_interval_s, remaining))
    result = dict(attempts[-1])
    result["attempt_count"] = len(attempts)
    result["attempts"] = attempts
    return result
