from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import locale
import math
import os
import platform
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import webbrowser
from contextlib import AbstractContextManager, suppress
from ctypes import wintypes
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PureWindowsPath
from typing import Any, BinaryIO

from . import __version__
from .models import SCHEMA_VERSION
from .release_integrity import ReleaseIntegrityError, verify_release_tree
from .runtime import (
    EXPECTED_MARKETS,
    PRODUCT_NAME,
    READY_PROTOCOL_VERSION,
    SESSION_MANIFEST_VERSION,
    RuntimeContractError,
    SessionManifest,
    atomic_write_json,
    finite_number,
    read_json_object,
)
from .supply_chain import SupplyChainError, verify_runtime_tree

LAUNCHER_VERSION = "2.4.1+linux.2"
CLOCK_WARN_MS = 50.0


def _raise_keyboard_interrupt(_signum: int, _frame: object) -> None:
    # systemd detiene con SIGTERM: se convierte en el mismo camino drenado
    # que Ctrl+C para producir commitment, auditoría y RESULT.json.
    raise KeyboardInterrupt
READY_MAX_BYTES = 256 * 1024
READY_MAX_AGE_MS = 3_000.0
READY_FILE_MAX_AGE_S = 15.0
READY_CLOCK_FUTURE_TOLERANCE_S = 5.0
ENGINE_SHUTDOWN_TIMEOUT_S = 45.0
ENGINE_DRAIN_HARD_CAP_S = 900.0
_LOOPBACK_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


class LauncherFailure(RuntimeError):
    def __init__(self, code: str, message: str, *, exit_code: int = 1) -> None:
        super().__init__(message)
        self.code = code
        self.exit_code = exit_code


@dataclass(frozen=True, slots=True)
class RunSpec:
    label: str
    healthy_seconds: float | None


class LauncherHeartbeat(AbstractContextManager["LauncherHeartbeat"]):
    """Durable parent heartbeat; an orphaned engine fails closed within seconds."""

    def __init__(self, path: Path, session_id: str, *, interval_s: float = 1.0) -> None:
        self.path = path.resolve()
        self.session_id = session_id
        self.interval_s = interval_s
        self.started_utc_ns = time.time_ns()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.error: BaseException | None = None

    def _write(self) -> None:
        # P0.3: sin fsync (su valor es frescura, no durabilidad; el fsync
        # competía con los CSV en el mismo volumen) y con reintentos del
        # os.replace ante la sharing violation transitoria de Windows cuando
        # el motor tiene el archivo abierto para leerlo.
        atomic_write_json(
            self.path,
            {
                "capture_session_id": self.session_id,
                "launcher_pid": os.getpid(),
                "started_utc_ns": self.started_utc_ns,
                "updated_utc_ns": time.time_ns(),
            },
            durable=False,
            replace_retries=5,
        )

    def _run(self) -> None:
        while not self._stop.wait(self.interval_s):
            # Presupuesto de ~3 s por ciclo: un fallo transitorio (antivirus,
            # replace en colisión) ya no mata el hilo al primer intento; solo
            # un fallo persistente agota el presupuesto y detiene la captura.
            deadline = time.monotonic() + 3.0
            while True:
                try:
                    self._write()
                    break
                except BaseException as exc:
                    if time.monotonic() >= deadline:
                        self.error = exc
                        self._stop.set()
                        return
                    time.sleep(0.1)

    def __enter__(self) -> "LauncherHeartbeat":
        self._write()
        self._thread = threading.Thread(
            target=self._run,
            name="jean-flow-launcher-heartbeat",
            daemon=True,
        )
        self._thread.start()
        return self

    def __exit__(self, *_exc_info: object) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2)
            self._thread = None

    def raise_if_failed(self) -> None:
        if self.error is not None:
            raise LauncherFailure(
                "LAUNCHER_HEARTBEAT_FAILED",
                f"{type(self.error).__name__}: {self.error}",
            )


def _strict_json_bytes(raw: bytes, *, code: str = "READY_INVALID") -> dict[str, Any]:
    # P1.4: el código es del LLAMADOR. Antes toda respuesta HTTP truncada de
    # /readyz y toda salida PowerShell no-JSON aterrizaban como READY_INVALID,
    # un código terminal que no nombraba la causa.
    if not raw or len(raw) > READY_MAX_BYTES:
        raise LauncherFailure(code, "JSON de runtime vacío o demasiado grande")

    def reject(value: str) -> None:
        raise ValueError(f"Constante no finita: {value}")

    try:
        value = json.loads(raw.decode("utf-8-sig"), parse_constant=reject)
    except (UnicodeError, json.JSONDecodeError, ValueError) as exc:
        raise LauncherFailure(code, f"JSON inválido: {exc}") from exc
    if not isinstance(value, dict):
        raise LauncherFailure(code, "Se esperaba un objeto JSON")
    return value


def _require(payload: dict[str, Any], key: str, expected: Any) -> None:
    if payload.get(key) != expected:
        raise LauncherFailure(
            "READY_INVALID",
            f"{key} esperado={expected!r} recibido={payload.get(key)!r}",
        )


def _normalized_absolute_path(value: Any, *, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise LauncherFailure("READY_INVALID", f"{field} ausente")
    path = Path(value)
    if not path.is_absolute():
        raise LauncherFailure("READY_INVALID", f"{field} no es una ruta absoluta")
    return os.path.normcase(str(path.resolve()))


def _require_runtime_path(
    payload: dict[str, Any], field: str, expected: Path | None
) -> None:
    received = _normalized_absolute_path(payload.get(field), field=field)
    if expected is None:
        return
    normalized_expected = os.path.normcase(str(expected.resolve()))
    if received != normalized_expected:
        raise LauncherFailure(
            "READY_INVALID",
            f"{field} esperado={normalized_expected!r} recibido={received!r}",
        )


def validate_ready_payload(
    payload: dict[str, Any],
    *,
    expected_pid: int,
    expected_launcher_pid: int,
    expected_session_id: str,
    expected_symbol: str,
    expected_project_root: Path | None = None,
    expected_output_dir: Path | None = None,
    expected_python_executable: Path | None = None,
    expected_package_file: Path | None = None,
) -> str:
    """Fail closed unless READY identifies this exact process and both books."""

    _require(payload, "ready", True)
    _require(payload, "protocol_version", READY_PROTOCOL_VERSION)
    _require(payload, "ready_protocol_version", READY_PROTOCOL_VERSION)
    _require(payload, "product", PRODUCT_NAME)
    _require(payload, "engine_version", __version__)
    _require(payload, "data_schema_version", SCHEMA_VERSION)
    _require(payload, "capture_session_id", expected_session_id)
    _require(payload, "pid", expected_pid)
    _require(payload, "launcher_pid", expected_launcher_pid)
    _require(payload, "symbol", expected_symbol.upper())
    _require(payload, "markets", list(EXPECTED_MARKETS))
    _require(payload, "host", "127.0.0.1")
    _require(payload, "operational_ready", True)
    process_start_utc_ns = payload.get("process_start_utc_ns")
    if (
        not isinstance(process_start_utc_ns, int)
        or isinstance(process_start_utc_ns, bool)
        or process_start_utc_ns <= 0
    ):
        raise LauncherFailure("READY_INVALID", "process_start_utc_ns inválido")
    published_utc_ns = payload.get("ready_published_utc_ns")
    now_utc_ns = time.time_ns()
    if (
        not isinstance(published_utc_ns, int)
        or isinstance(published_utc_ns, bool)
        or published_utc_ns < process_start_utc_ns
        or published_utc_ns
        > now_utc_ns + int(READY_CLOCK_FUTURE_TOLERANCE_S * 1_000_000_000)
    ):
        raise LauncherFailure(
            "READY_INVALID", "ready_published_utc_ns inválido"
        )
    if now_utc_ns - published_utc_ns > int(READY_FILE_MAX_AGE_S * 1_000_000_000):
        # [P11]: la antigüedad es retryable (el motor refresca READY cada 5 s
        # mientras siga operativo); no debe ser terminal a la primera lectura.
        raise LauncherFailure(
            "READY_STALE", "ready_published_utc_ns obsoleto; reintentando"
        )
    _require_runtime_path(payload, "project_root", expected_project_root)
    _require_runtime_path(payload, "output_dir", expected_output_dir)
    _require_runtime_path(payload, "python_executable", expected_python_executable)
    _require_runtime_path(payload, "package_file", expected_package_file)
    port = payload.get("port")
    if not isinstance(port, int) or isinstance(port, bool) or not 1 <= port <= 65_535:
        raise LauncherFailure("READY_INVALID", "Puerto READY inválido")
    url = payload.get("url")
    if not isinstance(url, str):
        raise LauncherFailure("READY_INVALID", "URL READY ausente")
    parsed = urllib.parse.urlsplit(url)
    if (
        parsed.scheme != "http"
        or parsed.hostname != "127.0.0.1"
        or parsed.port != port
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or parsed.path not in {"", "/"}
    ):
        raise LauncherFailure("READY_INVALID", f"URL local inválida: {url!r}")

    market_states = payload.get("market_states")
    if not isinstance(market_states, dict) or set(market_states) != set(
        EXPECTED_MARKETS
    ):
        raise LauncherFailure("READY_INVALID", "Estados Spot/Futures incompletos")
    for market in EXPECTED_MARKETS:
        state = market_states[market]
        if not isinstance(state, dict):
            raise LauncherFailure("READY_INVALID", f"Estado {market} inválido")
        for key, expected in (
            ("ready", True),
            ("status", "SYNCED"),
            ("symbol", expected_symbol.upper()),
            ("has_bids", True),
            ("has_asks", True),
        ):
            if state.get(key) != expected:
                raise LauncherFailure(
                    "READY_INVALID", f"{market}.{key} no cumple READY"
                )
        sequence = state.get("sequence")
        if not isinstance(sequence, int) or isinstance(sequence, bool) or sequence < 0:
            raise LauncherFailure("READY_INVALID", f"{market}.sequence inválida")
        age_ms = state.get("age_ms")
        if not finite_number(age_ms) or not 0 <= float(age_ms) <= READY_MAX_AGE_MS:
            raise LauncherFailure("READY_INVALID", f"{market}.age_ms obsoleta")
    return url


def validate_health_payload(
    health: dict[str, Any],
    *,
    ready: dict[str, Any],
    expected_pid: int,
    expected_launcher_pid: int,
    expected_session_id: str,
    expected_symbol: str,
    expected_project_root: Path,
    expected_output_dir: Path,
    expected_python_executable: Path,
    expected_package_file: Path,
) -> None:
    _require(health, "live", True)
    _require(health, "identity_ready", True)
    _require(health, "operational_ready", True)
    for key in (
        "protocol_version",
        "product",
        "engine_version",
        "data_schema_version",
        "capture_session_id",
        "pid",
        "launcher_pid",
        "process_start_utc_ns",
        "symbol",
        "markets",
        "host",
        "port",
        "url",
    ):
        _require(health, key, ready.get(key))
    # Reuse every market and URL check on the live endpoint.
    candidate = dict(health)
    candidate["ready"] = True
    candidate["ready_protocol_version"] = READY_PROTOCOL_VERSION
    candidate["ready_published_utc_ns"] = ready.get("ready_published_utc_ns")
    validate_ready_payload(
        candidate,
        expected_pid=expected_pid,
        expected_launcher_pid=expected_launcher_pid,
        expected_session_id=expected_session_id,
        expected_symbol=expected_symbol,
        expected_project_root=expected_project_root,
        expected_output_dir=expected_output_dir,
        expected_python_executable=expected_python_executable,
        expected_package_file=expected_package_file,
    )


def _http_json(url: str, *, timeout_s: float = 2.0) -> dict[str, Any]:
    request = urllib.request.Request(
        url,
        method="GET",
        headers={"Accept": "application/json", "Cache-Control": "no-cache"},
    )
    try:
        with _LOOPBACK_OPENER.open(request, timeout=timeout_s) as response:
            if response.status != 200:
                raise LauncherFailure(
                    "DASHBOARD_HTTP_FAILED", f"HTTP {response.status} en {url}"
                )
            content_length = response.headers.get("Content-Length")
            if content_length and int(content_length) > READY_MAX_BYTES:
                raise LauncherFailure(
                    "DASHBOARD_HTTP_FAILED", "Respuesta demasiado grande"
                )
            raw = response.read(READY_MAX_BYTES + 1)
    except (OSError, ValueError, urllib.error.URLError) as exc:
        raise LauncherFailure("DASHBOARD_HTTP_FAILED", str(exc)) from exc
    return _strict_json_bytes(raw, code="DASHBOARD_RESPONSE_INVALID")


def _wait_for_ready(
    process: subprocess.Popen[bytes],
    ready_file: Path,
    heartbeat: LauncherHeartbeat,
    *,
    session_id: str,
    symbol: str,
    timeout_s: float,
    project_root: Path,
    output_dir: Path,
) -> tuple[dict[str, Any], str]:
    deadline = time.monotonic() + timeout_s
    last_http_error: LauncherFailure | None = None
    while time.monotonic() < deadline:
        heartbeat.raise_if_failed()
        exit_code = process.poll()
        if exit_code is not None:
            raise LauncherFailure(
                "ENGINE_EXITED_BEFORE_READY", f"El motor terminó con código {exit_code}"
            )
        if ready_file.exists():
            try:
                ready = read_json_object(ready_file, max_bytes=READY_MAX_BYTES)
            except RuntimeContractError as exc:
                raise LauncherFailure("READY_INVALID", str(exc)) from exc
            try:
                url = validate_ready_payload(
                    ready,
                    expected_pid=process.pid,
                    expected_launcher_pid=os.getpid(),
                    expected_session_id=session_id,
                    expected_symbol=symbol,
                    expected_project_root=project_root,
                    expected_output_dir=output_dir,
                    expected_python_executable=Path(sys.executable),
                    expected_package_file=(
                        project_root / "src" / "binance_collector" / "dual_main.py"
                    ),
                )
                health = _http_json(url + "/readyz")
                validate_health_payload(
                    health,
                    ready=ready,
                    expected_pid=process.pid,
                    expected_launcher_pid=os.getpid(),
                    expected_session_id=session_id,
                    expected_symbol=symbol,
                    expected_project_root=project_root,
                    expected_output_dir=output_dir,
                    expected_python_executable=Path(sys.executable),
                    expected_package_file=(
                        project_root / "src" / "binance_collector" / "dual_main.py"
                    ),
                )
                return ready, url
            except LauncherFailure as exc:
                if exc.code == "READY_INVALID":
                    raise
                # DASHBOARD_HTTP_FAILED, DASHBOARD_RESPONSE_INVALID y
                # READY_STALE son transitorios: se reintenta hasta el plazo.
                last_http_error = exc
        time.sleep(0.1)
    if last_http_error is not None:
        raise last_http_error
    raise LauncherFailure("READY_TIMEOUT", f"READY no apareció en {timeout_s:.0f} s")


def _wait_for_engine(
    process: subprocess.Popen[bytes], heartbeat: LauncherHeartbeat
) -> int:
    while True:
        heartbeat.raise_if_failed()
        try:
            return process.wait(timeout=0.5)
        except subprocess.TimeoutExpired:
            continue


def _write_stop(stop_file: Path, session_id: str) -> None:
    if stop_file.exists():
        return
    atomic_write_json(
        stop_file,
        {
            "capture_session_id": session_id,
            "requested_by_pid": os.getpid(),
            "requested_utc_ns": time.time_ns(),
            "reason": "launcher_shutdown",
        },
    )


def _session_progress_marker(session_file: Path | None) -> tuple[int, int] | None:
    if session_file is None:
        return None
    try:
        payload = read_json_object(session_file)
    except RuntimeContractError:
        return None
    update_index = payload.get("update_index")
    updated = payload.get("updated_utc_ns")
    if isinstance(update_index, int) and isinstance(updated, int):
        return (update_index, updated)
    return None


def _stop_owned_process(
    process: subprocess.Popen[bytes],
    stop_file: Path,
    session_id: str,
    session_file: Path | None = None,
) -> int:
    try:
        _write_stop(stop_file, session_id)
    except (OSError, RuntimeContractError) as exc:
        print(f"STOP_FILE_FAILED: {exc}; terminando únicamente el hijo propio.")
        process.terminate()
        try:
            return process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            return process.wait(timeout=10)
    # P1.2: el plazo fijo de 45 s incluía el SHA-256 de TODA la captura; en
    # discos lentos o con antivirus mataba al motor en STOPPING con datos
    # sanos. Mientras el manifest de sesión muestre progreso (ventanas de
    # 15 s) se sigue esperando, hasta un techo duro absoluto.
    started = time.monotonic()
    hard_deadline = started + ENGINE_DRAIN_HARD_CAP_S
    no_progress_deadline = started + ENGINE_SHUTDOWN_TIMEOUT_S
    last_marker = _session_progress_marker(session_file)
    while True:
        try:
            exit_code = process.wait(timeout=5)
            waited = time.monotonic() - started
            if waited > ENGINE_SHUTDOWN_TIMEOUT_S:
                print(
                    f"Cierre drenado completado tras {waited:.0f} s "
                    "(espera extendida por progreso del manifest)."
                )
            return exit_code
        except subprocess.TimeoutExpired:
            pass
        now = time.monotonic()
        marker = _session_progress_marker(session_file)
        if marker is not None and marker != last_marker:
            last_marker = marker
            no_progress_deadline = now + 15.0
        if now >= hard_deadline or now >= no_progress_deadline:
            break
    print("Cierre drenado agotó el plazo; terminando únicamente el hijo propio.")
    process.terminate()
    try:
        return process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        return process.wait(timeout=10)


def _decode_powershell(raw: bytes) -> str:
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16", errors="strict")
    if raw and raw.count(b"\x00") > len(raw) // 4:
        return raw.decode("utf-16-le", errors="strict")
    encodings = ("utf-8-sig", locale.getpreferredencoding(False), "cp1252")
    for encoding in dict.fromkeys(encodings):
        try:
            return raw.decode(encoding, errors="strict")
        except UnicodeError:
            continue
    raise LauncherFailure("NTP_OUTPUT_INVALID", "Codificación PowerShell desconocida")


def _trusted_system_directory() -> Path:
    if os.name != "nt":
        raise LauncherFailure("WINDOWS_SYSTEM_PATH_INVALID", "Windows requerido")
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.GetSystemDirectoryW.argtypes = (wintypes.LPWSTR, wintypes.UINT)
    kernel32.GetSystemDirectoryW.restype = wintypes.UINT
    buffer = ctypes.create_unicode_buffer(32_768)
    length = kernel32.GetSystemDirectoryW(buffer, len(buffer))
    if length == 0 or length >= len(buffer):
        raise LauncherFailure(
            "WINDOWS_SYSTEM_PATH_INVALID", "No se pudo resolver System32"
        )
    return Path(buffer.value)


def _windows_process_is_elevated() -> bool:
    """Second defense if the supervisor is invoked outside the public bootstrap."""

    if os.name != "nt":
        return False
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel32.CloseHandle.restype = wintypes.BOOL
    advapi32.OpenProcessToken.argtypes = (
        wintypes.HANDLE,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.HANDLE),
    )
    advapi32.OpenProcessToken.restype = wintypes.BOOL
    advapi32.GetTokenInformation.argtypes = (
        wintypes.HANDLE,
        ctypes.c_int,
        wintypes.LPVOID,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
    )
    advapi32.GetTokenInformation.restype = wintypes.BOOL
    token = wintypes.HANDLE()
    if not advapi32.OpenProcessToken(
        kernel32.GetCurrentProcess(), 0x0008, ctypes.byref(token)
    ):
        raise LauncherFailure(
            "ELEVATION_STATE_UNKNOWN",
            f"OpenProcessToken WinError {ctypes.get_last_error()}",
        )
    try:
        elevated = wintypes.DWORD()
        returned = wintypes.DWORD()
        if not advapi32.GetTokenInformation(
            token,
            20,
            ctypes.byref(elevated),
            ctypes.sizeof(elevated),
            ctypes.byref(returned),
        ):
            raise LauncherFailure(
                "ELEVATION_STATE_UNKNOWN",
                f"GetTokenInformation WinError {ctypes.get_last_error()}",
            )
        if returned.value != ctypes.sizeof(elevated):
            raise LauncherFailure(
                "ELEVATION_STATE_UNKNOWN", "Tamaño TokenElevation inesperado"
            )
        return bool(elevated.value)
    finally:
        kernel32.CloseHandle(token)


def _trusted_powershell_path() -> Path:
    powershell = (
        _trusted_system_directory() / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    )
    if not powershell.is_file():
        raise LauncherFailure(
            "POWERSHELL_NOT_TRUSTED",
            f"No existe el PowerShell del sistema esperado: {powershell}",
        )
    return powershell


def _trusted_w32tm_path() -> Path:
    w32tm = _trusted_system_directory() / "w32tm.exe"
    if not w32tm.is_file():
        raise LauncherFailure(
            "W32TIME_BINARY_NOT_TRUSTED",
            f"No existe el w32tm del sistema esperado: {w32tm}",
        )
    return w32tm


class _ShellExecuteInfoW(ctypes.Structure):
    _fields_ = (
        ("cbSize", wintypes.DWORD),
        ("fMask", wintypes.ULONG),
        ("hwnd", wintypes.HWND),
        ("lpVerb", wintypes.LPCWSTR),
        ("lpFile", wintypes.LPCWSTR),
        ("lpParameters", wintypes.LPCWSTR),
        ("lpDirectory", wintypes.LPCWSTR),
        ("nShow", ctypes.c_int),
        ("hInstApp", wintypes.HINSTANCE),
        ("lpIDList", wintypes.LPVOID),
        ("lpClass", wintypes.LPCWSTR),
        ("hkeyClass", wintypes.HKEY),
        ("dwHotKey", wintypes.DWORD),
        ("hIcon", wintypes.HANDLE),
        ("hProcess", wintypes.HANDLE),
    )


def _run_elevated_w32time_resync() -> dict[str, Any]:
    """Run exactly ``System32\\w32tm.exe /resync`` behind one UAC prompt."""

    binary = _trusted_w32tm_path()
    shell32 = ctypes.WinDLL("shell32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    shell32.ShellExecuteExW.argtypes = (ctypes.POINTER(_ShellExecuteInfoW),)
    shell32.ShellExecuteExW.restype = wintypes.BOOL
    kernel32.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
    kernel32.WaitForSingleObject.restype = wintypes.DWORD
    kernel32.GetExitCodeProcess.argtypes = (wintypes.HANDLE, wintypes.LPDWORD)
    kernel32.GetExitCodeProcess.restype = wintypes.BOOL
    kernel32.TerminateProcess.argtypes = (wintypes.HANDLE, wintypes.UINT)
    kernel32.TerminateProcess.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel32.CloseHandle.restype = wintypes.BOOL

    # SEE_MASK_NOCLOSEPROCESS keeps the process handle for an authenticated
    # exit code. SEE_MASK_NOASYNC makes ShellExecuteEx complete synchronously.
    request = _ShellExecuteInfoW()
    request.cbSize = ctypes.sizeof(request)
    request.fMask = 0x00000040 | 0x00000100
    request.lpVerb = "runas"
    request.lpFile = str(binary)
    request.lpParameters = "/resync"
    request.lpDirectory = str(binary.parent)
    request.nShow = 0
    requested_utc_ns = time.time_ns()
    started_ns = time.monotonic_ns()
    if not shell32.ShellExecuteExW(ctypes.byref(request)):
        error = ctypes.get_last_error()
        code = "UAC_CANCELLED" if error == 1223 else "UAC_FAILED"
        raise LauncherFailure(code, f"No se pudo elevar w32tm (WinError {error})")
    if not request.hProcess:
        raise LauncherFailure("W32TIME_RESYNC_FAILED", "w32tm no devolvió proceso")
    try:
        # P3.2d: una espera única de 120 s bloqueaba Ctrl+C todo ese tiempo.
        # Esperas de <=500 ms con reevaluación conservan la interrumpibilidad.
        deadline_ns = time.monotonic_ns() + 120_000_000_000
        while True:
            wait_result = kernel32.WaitForSingleObject(request.hProcess, 500)
            if wait_result != 0x00000102:
                break
            if time.monotonic_ns() >= deadline_ns:
                break
        if wait_result == 0x00000102:
            terminated = bool(kernel32.TerminateProcess(request.hProcess, 124))
            termination_error = 0 if terminated else ctypes.get_last_error()
            terminated_wait = (
                kernel32.WaitForSingleObject(request.hProcess, 10_000)
                if terminated
                else 0x00000102
            )
            if not terminated or terminated_wait != 0:
                raise LauncherFailure(
                    "W32TIME_RESYNC_TIMEOUT_UNTERMINATED",
                    "w32tm /resync superó 120 segundos y no se pudo "
                    f"confirmar su terminación (WinError {termination_error}; "
                    f"wait={terminated_wait})",
                )
            raise LauncherFailure(
                "W32TIME_RESYNC_TIMEOUT",
                "w32tm /resync superó 120 segundos y fue terminado",
            )
        if wait_result != 0:
            raise LauncherFailure(
                "W32TIME_RESYNC_FAILED", f"WaitForSingleObject={wait_result}"
            )
        exit_code = wintypes.DWORD()
        if not kernel32.GetExitCodeProcess(request.hProcess, ctypes.byref(exit_code)):
            error = ctypes.get_last_error()
            raise LauncherFailure(
                "W32TIME_RESYNC_FAILED",
                f"No se pudo leer el exit code de w32tm (WinError {error})",
            )
    finally:
        kernel32.CloseHandle(request.hProcess)
    passed = exit_code.value == 0
    return {
        "pass": passed,
        "error_code": "PASS" if passed else "W32TIME_RESYNC_FAILED",
        "action": "w32tm_resync",
        "binary": str(binary),
        "arguments": ["/resync"],
        "process_exit_code": exit_code.value,
        "requested_utc_ns": requested_utc_ns,
        "completed_utc_ns": time.time_ns(),
        "duration_ms": (time.monotonic_ns() - started_ns) / 1_000_000,
    }


def _release_manifest_expected_hashes(project_root: Path) -> dict[str, str]:
    """Parse RELEASE_MANIFEST.sha256 into {relative_posix_path: sha256}."""

    manifest = project_root.parent / "RELEASE_MANIFEST.sha256"
    expected: dict[str, str] = {}
    try:
        for line in manifest.read_text(encoding="ascii").splitlines():
            digest, separator, archived = line.partition("  ")
            if separator != "  " or len(digest) != 64:
                continue
            expected[archived.removeprefix("555/")] = digest
    except (OSError, UnicodeError) as exc:
        raise LauncherFailure(
            "CLOCK_SCRIPT_INTEGRITY_FAILED",
            f"No se pudo leer RELEASE_MANIFEST.sha256: {exc}",
        ) from exc
    return expected


def _verify_clock_script_integrity(project_root: Path, script: Path) -> None:
    """[W3]/R6.1: re-verifica el hash del .ps1 y su librería INMEDIATAMENTE
    antes de ejecutarlos con -ExecutionPolicy Bypass.

    El patrón anterior (verificar en el preflight, ejecutar minutos después)
    era exactamente la ventana validar→esperar→ejecutar que el changelog
    afirmaba haber cerrado: era el único camino capaz de fabricar un PASS.
    """

    expected = _release_manifest_expected_hashes(project_root)
    dependencies = (
        script,
        script.parent / "TimeSync-Common.ps1",
    )
    for dependency in dependencies:
        try:
            relative = dependency.resolve().relative_to(
                project_root.parent.resolve()
            ).as_posix()
        except ValueError as exc:
            raise LauncherFailure(
                "CLOCK_SCRIPT_INTEGRITY_FAILED",
                f"Script fuera del release: {dependency}",
            ) from exc
        expected_digest = expected.get(relative)
        if expected_digest is None:
            raise LauncherFailure(
                "CLOCK_SCRIPT_INTEGRITY_FAILED",
                f"{relative} no está cubierto por RELEASE_MANIFEST.sha256",
            )
        if _sha256(dependency) != expected_digest:
            raise LauncherFailure(
                "CLOCK_SCRIPT_INTEGRITY_FAILED",
                f"El hash de {relative} cambió respecto del manifest; "
                "no se ejecuta",
            )


def _run_clock_script(
    project_root: Path,
    name: str,
    *arguments: str,
    timeout_s: float = 180.0,
) -> tuple[int, dict[str, Any]]:
    if not math.isfinite(timeout_s) or timeout_s <= 0.0:
        raise LauncherFailure("NTP_COMMAND_TIMEOUT", "Plazo NTP inválido")
    script = project_root / "tools" / "windows" / "time-sync" / name
    _verify_clock_script_integrity(project_root, script)
    powershell = _trusted_powershell_path()
    command = [
        str(powershell),
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(script),
        *arguments,
    ]
    try:
        completed = subprocess.run(
            command,
            cwd=project_root,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
            timeout=timeout_s,
        )
    except subprocess.TimeoutExpired as exc:
        raise LauncherFailure(
            "NTP_COMMAND_TIMEOUT", f"{name} superó {timeout_s:.3f} segundos"
        ) from exc
    except OSError as exc:
        raise LauncherFailure("NTP_COMMAND_FAILED", f"{name}: {exc}") from exc
    payload = _strict_json_bytes(
        _decode_powershell(completed.stdout).encode("utf-8"),
        code="NTP_OUTPUT_INVALID",
    )
    return completed.returncode, payload


def _valid_w32_status_evidence(payload: dict[str, Any]) -> bool:
    service = payload.get("service")
    offset = payload.get("abs_phase_offset_ms")
    phase = payload.get("phase_offset_ms")
    phase_raw = payload.get("phase_offset_ms_raw")
    poll = payload.get("poll_seconds")
    age = payload.get("last_good_sync_age_seconds")
    last_sync_error = payload.get("last_sync_error")
    leap_indicator = payload.get("leap_indicator")
    state_machine = payload.get("state_machine")
    source = payload.get("source")
    source_from_status = payload.get("source_from_status")
    source_from_query = payload.get("source_from_query")
    query_access_denied = payload.get("source_query_access_denied")
    if not all(finite_number(value) for value in (offset, phase, phase_raw, poll, age)):
        return False
    # [W2]/M8: `phase` lo redondea .NET ([Math]::Round, escala ×10³ + ToEven)
    # y aquí se RE-DERIVABA con round() de CPython exigiendo 1e-9. Ambos
    # algoritmos difieren en el 3,74 % de los valores representables de w32tm
    # (18 681 de 500 001 en [0,50] ms; en el punto medio exacto la diferencia
    # es un dígito completo, 0.001): 1 de cada 27 arranques con reloj
    # perfecto quedaba bloqueado y cada divergencia en postflight descartaba
    # una captura completa. Regla M8: nunca re-derivar entre runtimes. La
    # coherencia se comprueba contra el valor CRUDO con media unidad del
    # último dígito representable (5e-4): cualquier redondeo correcto —
    # ToEven o half-up — la satisface; un payload fabricado incoherente no.
    if not math.isclose(
        abs(float(phase_raw)), float(offset), rel_tol=0.0, abs_tol=1e-9
    ) or not math.isclose(
        float(phase), float(phase_raw), rel_tol=0.0, abs_tol=5e-4 + 1e-9
    ):
        return False
    # [W9]/R6.4: un campo derivado de una lectura que pudo fallar lleva el
    # éxito de esa lectura como campo propio, y aquí se exige. Sin esto, un
    # registro ilegible dejaba sync_type='' y
    # source_matches_configured_peer=True de forma VACUA (fail-open).
    if payload.get("registry_read_ok") is not True:
        return False
    sync_type = payload.get("sync_type")
    if not isinstance(sync_type, str) or not sync_type.strip():
        return False
    if (
        not isinstance(source, str)
        or not source.strip()
        or not isinstance(source_from_status, str)
        or source.strip().casefold() != source_from_status.strip().casefold()
        or not isinstance(query_access_denied, bool)
    ):
        return False
    if not query_access_denied and (
        not isinstance(source_from_query, str)
        or source.split(",", 1)[0].strip().casefold()
        != source_from_query.split(",", 1)[0].strip().casefold()
    ):
        return False
    return (
        isinstance(service, dict)
        and service.get("kind") == "W32Time"
        and service.get("running") is True
        and service.get("state") == "Running"
        and service.get("start_mode") == "Auto"
        and payload.get("active_peer_confirmed") is True
        and payload.get("source_peer_active") is True
        and payload.get("source_matches_configured_peer") is True
        and isinstance(last_sync_error, int)
        and not isinstance(last_sync_error, bool)
        and last_sync_error == 0
        and isinstance(leap_indicator, int)
        and not isinstance(leap_indicator, bool)
        and leap_indicator in (0, 1, 2)
        and isinstance(payload.get("stratum"), int)
        and not isinstance(payload.get("stratum"), bool)
        and 1 <= int(payload["stratum"]) <= 15
        and isinstance(state_machine, int)
        and not isinstance(state_machine, bool)
        and state_machine in (1, 2)
        and float(poll) > 0.0
        and 0.0 <= float(age) <= (float(poll) * 2.0) + 60.0
        and float(offset) >= 0.0
    )


def _w32_offset_recovery_eligible(payload: dict[str, Any]) -> bool:
    """Allow one resync only for a complete, unmanaged W32Time diagnosis."""

    service = payload.get("service")
    services = payload.get("services")
    offset = payload.get("abs_phase_offset_ms")
    warn_ms = payload.get("warn_ms")
    return (
        payload.get("error_code") == "OFFSET_OUT_OF_RANGE"
        and payload.get("offset_method") == "w32time_phase_offset"
        and _valid_w32_status_evidence(payload)
        and float(offset) > CLOCK_WARN_MS
        and finite_number(warn_ms)
        and float(warn_ms) == CLOCK_WARN_MS
        and payload.get("domain_joined") is False
        and payload.get("policy_managed") is False
        and isinstance(service, dict)
        and isinstance(service.get("name"), str)
        and bool(service.get("name"))
        and isinstance(service.get("path"), str)
        and bool(service.get("path"))
        and service.get("running") is True
        and service.get("state") == "Running"
        and service.get("start_mode") == "Auto"
        and isinstance(services, list)
        and len(services) == 1
        and isinstance(services[0], dict)
        and services[0].get("kind") == "W32Time"
        and services[0].get("running") is True
    )


def _w32_configuration_unchanged(before: dict[str, Any], after: dict[str, Any]) -> bool:
    for key in (
        "domain_joined",
        "policy_managed",
        "sync_type",
        "configured_peer_list",
    ):
        if key not in before or key not in after or before[key] != after[key]:
            return False
    before_service = before.get("service")
    after_service = after.get("service")
    if not isinstance(before_service, dict) or not isinstance(after_service, dict):
        return False
    for key in ("kind", "name", "path", "start_mode"):
        if (
            key not in before_service
            or key not in after_service
            or before_service[key] != after_service[key]
        ):
            return False
    return True


def _clock_gate_passed(code: int, payload: dict[str, Any]) -> bool:
    if (
        code != 0
        or payload.get("pass") is not True
        or payload.get("error_code") != "PASS"
    ):
        return False
    service = payload.get("service")
    warn_ms = payload.get("warn_ms")
    if not isinstance(service, dict) or not finite_number(warn_ms):
        return False
    if float(warn_ms) != CLOCK_WARN_MS:
        return False
    if service.get("kind") == "W32Time":
        offset = payload.get("abs_phase_offset_ms")
        services = payload.get("services")
        running_services = (
            [
                item
                for item in services
                if isinstance(item, dict) and item.get("running") is True
            ]
            if isinstance(services, list)
            else []
        )
        # [W10]/R6.6: la vía de PASS ahora exige lo mismo que la rama Meinberg
        # y que la vía de recuperación: exactamente UN disciplinador activo de
        # tipo W32Time y presencia de la evidencia de dominio/política. La
        # invariante "doble disciplinador falla cerrado" ya no depende solo
        # del .ps1.
        return (
            payload.get("offset_method") == "w32time_phase_offset"
            and _valid_w32_status_evidence(payload)
            and isinstance(services, list)
            and len(running_services) == 1
            and running_services[0].get("kind") == "W32Time"
            and isinstance(payload.get("domain_joined"), bool)
            and isinstance(payload.get("policy_managed"), bool)
            and finite_number(offset)
            and 0.0 <= float(offset) <= CLOCK_WARN_MS
        )
    if service.get("kind") == "MeinbergNtp":
        services = payload.get("services")
        runtime = payload.get("runtime")
        peers = payload.get("peers")
        selected_peer = payload.get("selected_peer")
        ntpq_path = payload.get("ntpq_path")
        p95 = payload.get("p95_abs_offset_ms")
        maximum = payload.get("max_abs_offset_ms")
        service_path = service.get("path")
        service_match = (
            re.match(r'^\s*"([^"]+\.exe)"(?:\s|$)', str(service_path), re.I)
            or re.match(r"^\s*(.+?\.exe)(?:\s|$)", str(service_path), re.I)
        )
        running_services = (
            [
                item
                for item in services
                if isinstance(item, dict) and item.get("running") is True
            ]
            if isinstance(services, list)
            else []
        )
        if (
            service.get("running") is not True
            or service.get("state") != "Running"
            or not isinstance(service.get("name"), str)
            or not service.get("name")
            or not isinstance(service.get("path"), str)
            or not service.get("path")
            or not isinstance(selected_peer, str)
            or not selected_peer.lstrip().startswith("*")
            or not isinstance(ntpq_path, str)
            or PureWindowsPath(ntpq_path).name.casefold() != "ntpq.exe"
            or not PureWindowsPath(ntpq_path).is_absolute()
            or service_match is None
            or not PureWindowsPath(service_match.group(1)).is_absolute()
            or PureWindowsPath(ntpq_path).parent.as_posix().casefold()
            != PureWindowsPath(service_match.group(1)).parent.as_posix().casefold()
            or len(running_services) != 1
            or running_services[0] != service
            or not isinstance(peers, list)
            or not peers
            or not all(isinstance(line, str) for line in peers)
            or selected_peer not in peers
            or not isinstance(runtime, list)
            or len(runtime) != 20
            or not finite_number(p95)
            or not finite_number(maximum)
        ):
            return False
        offsets: list[float] = []
        for index, sample in enumerate(runtime, start=1):
            if (
                not isinstance(sample, dict)
                or sample.get("sample") != index
                or isinstance(sample.get("sample"), bool)
                or sample.get("exit_code") != 0
                or isinstance(sample.get("exit_code"), bool)
                or not isinstance(sample.get("output"), list)
                or not sample.get("output")
                or not all(isinstance(line, str) for line in sample["output"])
                or not finite_number(sample.get("offset_abs_ms"))
                or float(sample["offset_abs_ms"]) < 0.0
            ):
                return False
            raw_match = re.search(
                r"(?i)(?:^|[,\s])offset=([+-]?\d+(?:\.\d+)?)",
                " ".join(sample["output"]),
            )
            if raw_match is None:
                return False
            raw_offset = float(raw_match.group(1))
            if not math.isfinite(raw_offset) or not math.isclose(
                abs(raw_offset),
                float(sample["offset_abs_ms"]),
                rel_tol=0.0,
                abs_tol=1e-12,
            ):
                return False
            offsets.append(abs(raw_offset))
        offsets.sort()
        expected_p95 = offsets[math.ceil(0.95 * len(offsets)) - 1]
        expected_maximum = offsets[-1]
        return (
            isinstance(payload.get("samples"), int)
            and not isinstance(payload.get("samples"), bool)
            and payload.get("samples") == 20
            and 0.0 <= expected_p95 <= CLOCK_WARN_MS
            and float(maximum) >= float(p95)
            and math.isclose(
                float(p95), round(expected_p95, 6), rel_tol=0.0, abs_tol=1e-12
            )
            and math.isclose(
                float(maximum),
                round(expected_maximum, 6),
                rel_tol=0.0,
                abs_tol=1e-12,
            )
        )
    return False


def _confirm_clock_action(prompt: str) -> bool:
    if sys.stdin is None or not sys.stdin.isatty():
        raise LauncherFailure(
            "CLOCK_RESYNC_AUTH_REQUIRED",
            "La reparación del reloj exige una consola interactiva",
        )
    try:
        return input(prompt).strip().upper() == "S"
    except EOFError as exc:
        raise LauncherFailure(
            "CLOCK_RESYNC_AUTH_REQUIRED", "No se pudo obtener autorización"
        ) from exc


def clock_preflight(project_root: Path, evidence_dir: Path) -> dict[str, Any]:
    code, payload = _run_clock_script(
        project_root, "Test-ClockSync.ps1", "-Samples", "20", "-WarnMs", "50"
    )
    initial_payload = payload
    atomic_write_json(evidence_dir / "clock_preflight.json", payload)
    if _clock_gate_passed(code, payload):
        return payload
    if code == 0 or payload.get("pass") is True:
        error_code = "CLOCK_GATE_EVIDENCE_INVALID"
    else:
        error_code = str(payload.get("error_code", "CLOCK_SYNC_FAILED"))
    offset_recovery = _w32_offset_recovery_eligible(payload)
    if not offset_recovery:
        # F3/F4: el mensaje nombra la CAUSA y una acción, no solo el síntoma.
        cause_messages = {
            "STATUS_LOCALE_UNSUPPORTED": (
                "w32tm respondió en un idioma cuyas etiquetas este parser no "
                "reconoce; NO es un fallo de su reloj. El texto crudo quedó "
                "en clock_preflight.json (campo status); repórtelo para "
                "añadir el idioma."
            ),
            "QUERY_ACCESS_DENIED": (
                "Windows denegó una consulta w32tm obligatoria; ejecute la "
                "consola con su usuario normal (sin restricciones AppLocker) "
                "o revise permisos del servicio W32Time."
            ),
            "SERVICE_STOPPED": (
                "W32Time está detenido: inicie el servicio 'Hora de Windows' "
                "(services.msc) y vuelva a ejecutar."
            ),
        }
        raise LauncherFailure(
            error_code,
            cause_messages.get(
                error_code, "El gate NTP falló y no admite reparación segura"
            ),
        )
    offset_ms = float(payload["abs_phase_offset_ms"])
    prompt = (
        f"W32Time informa {offset_ms:.3f} ms respecto de su fuente activa, "
        "por encima del límite de 50 ms. Windows podría adelantar o "
        "atrasar el reloj. ¿Autorizar un único /resync con UAC, sin "
        "cambiar su configuración? [S/N]: "
    )
    if not _confirm_clock_action(prompt):
        raise LauncherFailure("CLOCK_REPAIR_DECLINED", "Reparación NTP cancelada")
    repair_path = evidence_dir / "clock_offset_recovery.json"
    try:
        repair = _run_elevated_w32time_resync()
    except LauncherFailure as exc:
        failure_evidence = {
            "pass": False,
            "error_code": exc.code,
            "action": "w32tm_resync",
            "arguments": ["/resync"],
            "message": str(exc),
            "failed_utc_ns": time.time_ns(),
        }
        with suppress(Exception):
            atomic_write_json(repair_path, failure_evidence)
        raise
    repair_code = 0 if repair.get("pass") is True else 1
    repair_failure = "CLOCK_OFFSET_RECOVERY_FAILED"
    atomic_write_json(repair_path, repair)
    if repair_code != 0:
        failure_code = str(repair.get("error_code", repair_failure))
        raise LauncherFailure(failure_code, "La recuperación W32Time falló")
    rechecks: list[dict[str, Any]] = []
    # [2.3.4] Evidencia de campo (host objetivo, reinicio con desvío de
    # 344 ms): el /resync con UAC COMPLETÓ pero cada recheck moría en
    # NTP_COMMAND_TIMEOUT porque el tope de 15 s por intento es menor que lo
    # que tarda Test-ClockSync (arranque de PowerShell + 20 muestras) en un
    # portátil cargado — el bucle entero agotaba sus 90 s solo con timeouts
    # y condenaba una reparación que había funcionado. Presupuesto realista:
    # 240 s totales, hasta 60 s por intento, y sin lanzar intentos condenados
    # con <20 s restantes.
    deadline = time.monotonic() + 240.0
    while time.monotonic() < deadline:
        remaining_s = deadline - time.monotonic()
        if remaining_s < 20.0 and rechecks:
            break
        try:
            code, payload = _run_clock_script(
                project_root,
                "Test-ClockSync.ps1",
                "-Samples",
                "20",
                "-WarnMs",
                "50",
                timeout_s=min(60.0, max(20.0, remaining_s)),
            )
        except LauncherFailure as exc:
            code = 1
            payload = {
                "pass": False,
                "error_code": exc.code,
                "message": str(exc),
                "failed_utc_ns": time.time_ns(),
            }
        rechecks.append(payload)
        if _clock_gate_passed(code, payload):
            break
        remaining_s = deadline - time.monotonic()
        if remaining_s <= 0.0:
            break
        time.sleep(min(5.0, remaining_s))
    atomic_write_json(
        evidence_dir / "clock_recovery_rechecks.json", {"attempts": rechecks}
    )
    atomic_write_json(evidence_dir / "clock_preflight_after_repair.json", payload)
    if not _clock_gate_passed(code, payload):
        if _valid_w32_status_evidence(payload) and not _w32_configuration_unchanged(
            initial_payload, payload
        ):
            raise LauncherFailure(
                "CLOCK_CONFIGURATION_CHANGED",
                "La configuración W32Time cambió durante la recuperación",
            )
        cause = payload.get("error_code", "CLOCK_GATE_EVIDENCE_INVALID")
        raise LauncherFailure(
            "CLOCK_REVALIDATION_FAILED", f"NTP sigue fuera de umbral: {cause}"
        )
    if not _w32_configuration_unchanged(initial_payload, payload):
        raise LauncherFailure(
            "CLOCK_CONFIGURATION_CHANGED",
            "La configuración W32Time cambió durante la recuperación",
        )
    return payload


def clock_postflight(project_root: Path, evidence_dir: Path) -> dict[str, Any]:
    """Read-only NTP check after capture; never repairs or disciplines the clock."""

    code, payload = _run_clock_script(
        project_root, "Test-ClockSync.ps1", "-Samples", "20", "-WarnMs", "50"
    )
    atomic_write_json(evidence_dir / "clock_postflight.json", payload)
    if not _clock_gate_passed(code, payload):
        # [W4]/R6.3: cuando el .ps1 dijo PASS pero el launcher rechazó la
        # evidencia, `payload["error_code"]` es "PASS": el RESULT terminaba
        # con {"pass": false, "error_code": "PASS"} y la consola imprimía
        # "PASS: El reloj no superó el postflight". El código de fallo es
        # función de la CAUSA, no del payload juzgado (mismo criterio que el
        # preflight).
        if code == 0 or payload.get("pass") is True:
            error_code = "CLOCK_GATE_EVIDENCE_INVALID"
        else:
            error_code = str(payload.get("error_code", "CLOCK_POSTFLIGHT_FAILED"))
            if error_code == "PASS":
                error_code = "CLOCK_GATE_EVIDENCE_INVALID"
        raise LauncherFailure(
            error_code,
            "El reloj no superó el postflight; la captura no se certifica",
        )
    return payload


def linux_clock_preflight(evidence_dir: Path) -> dict[str, Any]:
    """Gate de reloj de SOLO LECTURA contra chronyd; jamás lo disciplina."""

    from .clock_linux import preflight_clock

    payload = preflight_clock(warn_ms=CLOCK_WARN_MS)
    atomic_write_json(evidence_dir / "clock_preflight.json", payload)
    if payload.get("pass") is not True:
        raise LauncherFailure(
            str(payload.get("error_code", "CLOCK_SYNC_FAILED")),
            str(payload.get("message", "chronyd no superó el gate de 50 ms")),
        )
    return payload


def linux_clock_postflight(evidence_dir: Path) -> dict[str, Any]:
    """Una única lectura de chronyd tras la captura, misma vara que el preflight."""

    from .clock_linux import read_clock_evidence

    payload = read_clock_evidence(warn_ms=CLOCK_WARN_MS)
    atomic_write_json(evidence_dir / "clock_postflight.json", payload)
    if payload.get("pass") is not True:
        raise LauncherFailure(
            str(payload.get("error_code", "CLOCK_POSTFLIGHT_FAILED")),
            str(payload.get("message", "chronyd no superó el postflight")),
        )
    return payload


def disk_preflight(runs_root: Path, evidence_dir: Path, *, mode: str) -> dict[str, Any]:
    """Bloquea sesiones en vivo sin margen útil de disco (evidencia primero)."""

    minimum_gib = {
        "preflight": 30.0,
        "normal": 128.0,
        "10m": 10.0,
        "full": 30.0,
    }[mode]
    try:
        runs_root.mkdir(parents=True, exist_ok=True)
        usage = shutil.disk_usage(runs_root)
    except OSError as exc:
        raise LauncherFailure(
            "DISK_SPACE_INSUFFICIENT",
            f"No se pudo examinar {runs_root}: {exc}",
        ) from exc
    free_gib = usage.free / (1024**3)
    free_ratio = usage.free / usage.total if usage.total else 0.0
    passed = free_gib >= minimum_gib and free_ratio >= 0.15
    payload = {
        "pass": passed,
        "error_code": "PASS" if passed else "DISK_SPACE_INSUFFICIENT",
        "mode": mode,
        "path": str(runs_root.resolve()),
        "total_bytes": usage.total,
        "used_bytes": usage.used,
        "free_bytes": usage.free,
        "free_gib": round(free_gib, 3),
        "free_ratio": round(free_ratio, 6),
        "minimum_free_gib": minimum_gib,
        "minimum_free_ratio": 0.15,
        "checked_utc_ns": time.time_ns(),
    }
    atomic_write_json(evidence_dir / "disk_preflight.json", payload)
    if not passed:
        raise LauncherFailure(
            "DISK_SPACE_INSUFFICIENT",
            f"libres={free_gib:.1f} GiB ({free_ratio:.1%}); se requieren "
            f"al menos {minimum_gib:.0f} GiB y 15%",
        )
    return payload


def _metrics_series_paths(metrics_base: Path) -> list[Path]:
    """Serie completa del log de métricas, en orden causal.

    El log rota (``RotatingFileHandler``, 64 MiB × 5 respaldos) y el auditor
    debe ver TODOS los fragmentos, no solo el fichero base: ``.N`` más alto =
    fragmento más antiguo, y el base es el más reciente. Los sufijos no
    numéricos y los symlinks se ignoran (fallo cerrado: si el base falta, el
    auditor de métricas fallará al abrirlo, nunca aprobará en silencio).
    """

    rotated: list[tuple[int, Path]] = []
    for candidate in metrics_base.parent.glob(metrics_base.name + ".*"):
        suffix = candidate.name.removeprefix(metrics_base.name + ".")
        if suffix.isdigit() and candidate.is_file() and not candidate.is_symlink():
            rotated.append((int(suffix), candidate))
    return [path for _index, path in sorted(rotated, reverse=True)] + [metrics_base]


def _run_logged(
    command: list[str],
    *,
    cwd: Path,
    output: Path,
    timeout_s: float = 900.0,
) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as stream:
        try:
            completed = subprocess.run(
                command,
                cwd=cwd,
                stdin=subprocess.DEVNULL,
                stdout=stream,
                stderr=subprocess.STDOUT,
                check=False,
                timeout=timeout_s,
            )
        except subprocess.TimeoutExpired as exc:
            raise LauncherFailure(
                "SUBPROCESS_TIMEOUT",
                f"{' '.join(command[1:])} superó {timeout_s:.0f} s; "
                f"revise {output}",
            ) from exc
    if completed.returncode != 0:
        raise LauncherFailure(
            "OFFLINE_VALIDATION_FAILED",
            f"Falló {' '.join(command[1:])}; revise {output}",
        )


def _isolated_command(
    project_root: Path,
    mode: str,
    target: str | Path,
    *arguments: str,
) -> list[str]:
    if mode not in {"module", "path"}:
        raise ValueError(f"Modo aislado inválido: {mode}")
    entry = project_root / "src" / "binance_collector" / "isolated_entry.py"
    # P3.2b: con -I las variables PYTHON* se ignoran, así que
    # PYTHONUNBUFFERED=1 era inerte; -u impone unbuffered de verdad.
    return [
        sys.executable,
        "-I",
        "-S",
        "-B",
        "-u",
        # [2.3.5] UTF-8 SIEMPRE en los hijos aislados: sus informes JSON
        # (ensure_ascii=False) se releen como UTF-8 estricto. Con -I las
        # variables PYTHONUTF8/PYTHONIOENCODING se ignoran; -X utf8 es la
        # única vía por línea de comandos. Evidencia de campo: sesiones
        # 87fa5a61d019 (D:) y d64fea5560ac (C:) vetadas por 0xE9 — la 'é'
        # de "después" del propio informe, en cp1252 — y el examen de
        # métricas crasheando al imprimir 'θ̂' (no existe en cp1252).
        "-X",
        "utf8",
        str(entry),
        mode,
        str(target),
        *arguments,
    ]


def offline_preflight(project_root: Path, evidence_dir: Path) -> None:
    # F3/F5: pytest usa por defecto %TEMP%\pytest-of-<usuario>, un directorio
    # COMPARTIDO entre ejecuciones. Verificado en el host real: una ejecución
    # anterior elevada deja esa carpeta con ACL de administrador y todas las
    # ejecuciones normales posteriores mueren con "Acceso denegado" en el
    # setup de tmp_path (108 errores). Un basetemp propio, único y efímero
    # inmuniza el preflight contra basura ajena en el temp del sistema.
    pytest_basetemp = Path(
        tempfile.mkdtemp(prefix="jean_flow_pytest_")
    )
    try:
        _run_logged(
            _isolated_command(
                project_root,
                "module",
                "pytest",
                f"--basetemp={pytest_basetemp}",
            ),
            cwd=project_root,
            output=evidence_dir / "pytest_offline.txt",
        )
    finally:
        shutil.rmtree(pytest_basetemp, ignore_errors=True)
    _run_logged(
        _isolated_command(
            project_root,
            "path",
            project_root / "benchmarks" / "benchmark_latency.py",
            "--enforce",
        ),
        cwd=project_root,
        output=evidence_dir / "benchmark_latency.json",
    )


def _audit_command(
    command: list[str], cwd: Path, output: Path, *, timeout_s: float = 900.0
) -> bool:
    with output.open("wb") as stream:
        try:
            completed = subprocess.run(
                command,
                cwd=cwd,
                stdin=subprocess.DEVNULL,
                stdout=stream,
                stderr=subprocess.STDOUT,
                check=False,
                timeout=timeout_s,
            )
        except subprocess.TimeoutExpired:
            stream.write(b"\nSUBPROCESS_TIMEOUT\n")
            return False
    return completed.returncode == 0


def _compare_replay_reports(first_path: Path, second_path: Path) -> dict[str, Any]:
    """Require two independent replays to reach the identical canonical state."""

    try:
        first = read_json_object(first_path, max_bytes=8 * 1024 * 1024)
        second = read_json_object(second_path, max_bytes=8 * 1024 * 1024)
        first_certification = first.get("certification")
        second_certification = second.get("certification")
        first_replay = first.get("replay")
        second_replay = second.get("replay")
        if not isinstance(first_certification, dict) or not isinstance(
            second_certification, dict
        ):
            raise ValueError("certification ausente")
        if first_certification.get("journal_integrity") != "PASS" or (
            second_certification.get("journal_integrity") != "PASS"
        ):
            raise ValueError("journal_integrity no es PASS en ambos replays")
        if first_certification.get("causal_replay") != "PASS" or (
            second_certification.get("causal_replay") != "PASS"
        ):
            raise ValueError("causal_replay no es PASS en ambos replays")
        if not isinstance(first_replay, dict) or not isinstance(second_replay, dict):
            raise ValueError("replay ausente")
        first_hash = first_replay.get("sha256")
        second_hash = second_replay.get("sha256")
        if not isinstance(first_hash, str) or len(first_hash) != 64:
            raise ValueError("sha256 del primer replay inválido")
        if not isinstance(second_hash, str) or len(second_hash) != 64:
            raise ValueError("sha256 del segundo replay inválido")
        if any(character not in "0123456789abcdef" for character in first_hash.lower()):
            raise ValueError("sha256 del primer replay no es hexadecimal")
        if any(
            character not in "0123456789abcdef" for character in second_hash.lower()
        ):
            raise ValueError("sha256 del segundo replay no es hexadecimal")
        identical = first_replay == second_replay and first_hash == second_hash
        return {
            "pass": identical,
            "first_sha256": first_hash,
            "second_sha256": second_hash,
            "final_state_identical": first_replay == second_replay,
            "error": None if identical else "Los replays produjeron estados distintos",
        }
    except (OSError, ValueError, RuntimeContractError) as exc:
        return {
            "pass": False,
            "first_sha256": None,
            "second_sha256": None,
            "final_state_identical": False,
            "error": f"{type(exc).__name__}: {exc}",
        }


def _verify_capture_commitment(
    capture_dir: Path,
    commitment: dict[str, Any],
    *,
    identity_report: dict[str, Any] | None = None,
) -> dict[str, Any]:
    errors: list[str] = []
    markets = commitment.get("markets")
    committed_paths: set[str] = set()
    checked_files = 0
    if not isinstance(markets, dict) or set(markets) != set(EXPECTED_MARKETS):
        errors.append("Mercados del commitment incompletos")
        markets = {}
    for market in EXPECTED_MARKETS:
        market_commitment = markets.get(market)
        entries = (
            market_commitment.get("files")
            if isinstance(market_commitment, dict)
            else None
        )
        if not isinstance(entries, list) or not entries:
            errors.append(f"{market}: inventario vacío")
            continue
        total_bytes = 0
        for entry in entries:
            if not isinstance(entry, dict):
                errors.append(f"{market}: entrada inválida")
                continue
            relative = entry.get("path")
            digest = entry.get("sha256")
            size = entry.get("size_bytes")
            if (
                not isinstance(relative, str)
                or not relative.startswith(f"{market}/")
                or Path(relative).is_absolute()
                or "\\" in relative
                or any(part in {"", ".", ".."} for part in Path(relative).parts)
                or relative in committed_paths
                or not isinstance(digest, str)
                or len(digest) != 64
                or any(character not in "0123456789abcdef" for character in digest)
                or not isinstance(size, int)
                or isinstance(size, bool)
                or size <= 0
            ):
                errors.append(f"{market}: metadatos inválidos {entry!r}")
                continue
            path = (capture_dir / relative).resolve()
            if (
                not path.is_relative_to(capture_dir.resolve())
                or not path.is_file()
                or path.is_symlink()
            ):
                errors.append(f"{market}: falta segmento {relative}")
                continue
            actual_size = path.stat().st_size
            actual_digest = _sha256(path)
            if actual_size != size or actual_digest != digest:
                errors.append(f"{market}: hash/tamaño cambió en {relative}")
                continue
            committed_paths.add(relative)
            checked_files += 1
            total_bytes += size
        if isinstance(market_commitment, dict):
            if market_commitment.get("file_count") != len(entries):
                errors.append(f"{market}: file_count no coincide")
            if market_commitment.get("total_bytes") != total_bytes:
                errors.append(f"{market}: total_bytes no coincide")
    actual_paths = {
        path.relative_to(capture_dir).as_posix()
        for path in capture_dir.rglob("*.csv")
        if path.is_file()
    }
    if actual_paths != committed_paths:
        errors.append("El conjunto de CSV no coincide exactamente con el commitment")
    last_ingest_seq = commitment.get("last_ingest_seq")
    if (
        not isinstance(last_ingest_seq, int)
        or isinstance(last_ingest_seq, bool)
        or last_ingest_seq <= 0
    ):
        errors.append("last_ingest_seq inválido")
    if identity_report is not None:
        ingest = identity_report.get("ingest_seq")
        if not isinstance(ingest, dict) or ingest.get("max") != last_ingest_seq:
            errors.append("El auditor no alcanzó last_ingest_seq comprometido")
        if identity_report.get("capture_session_id") != commitment.get(
            "capture_session_id"
        ):
            errors.append("La sesión del auditor no coincide con el commitment")
    return {
        "pass": not errors,
        "errors": errors,
        "checked_files": checked_files,
        "last_ingest_seq": last_ingest_seq,
    }


def audit_capture(
    project_root: Path,
    capture_dir: Path,
    commitment: dict[str, Any],
    *,
    certification_gates: bool = True,
) -> dict[str, Any]:
    # P1.1: se pasa el DIRECTORIO (audit lo expande internamente) en lugar de
    # un glob textual: una instalación en 'D:\proyectos[2026]\555' hacía que
    # glob.glob no encontrara ningún CSV tras una captura correcta.
    journal_commands = {
        market: _isolated_command(
            project_root,
            "module",
            "binance_collector.audit",
            "journal",
            str(capture_dir / market),
        )
        for market in EXPECTED_MARKETS
    }
    journal_checks: dict[str, bool] = {}
    replay_determinism: dict[str, dict[str, Any]] = {}
    for market, command in journal_commands.items():
        first_path = capture_dir / f"audit_{market}.json"
        second_path = capture_dir / f"audit_{market}_replay_2.json"
        first_pass = _audit_command(command, project_root, first_path)
        second_pass = _audit_command(command, project_root, second_path)
        comparison = _compare_replay_reports(first_path, second_path)
        replay_determinism[market] = comparison
        journal_checks[market] = (
            first_pass and second_pass and comparison.get("pass") is True
        )

    metrics_paths = _metrics_series_paths(capture_dir / "jean_flow_metrics.jsonl")

    checks = {
        **journal_checks,
        "identity": _audit_command(
            _isolated_command(
                project_root,
                "module",
                "binance_collector.audit",
                "identity",
                str(capture_dir / "spot"),
                str(capture_dir / "usdm_futures"),
            ),
            project_root,
            capture_dir / "audit_identity.json",
        ),
        "metrics": _audit_command(
            _isolated_command(
                project_root,
                "module",
                "binance_collector.audit",
                "metrics",
                *(str(path) for path in metrics_paths),
                # [2.3.2] Actividad por stream (aggTrade>0…) y límites p99
                # son gates de CERTIFICACIÓN: un símbolo ilíquido pasa horas
                # sin trades legítimamente y un pico transitorio del host no
                # convierte una captura íntegra de uso normal en FAIL
                # (evidencia de campo: TUTUSDT, 0 aggTrade y p99 con picos
                # durante estancamientos de E/S, con journal e identidad
                # PASS). La integridad estructural se exige SIEMPRE; los
                # modos certificables exigen además actividad y límites.
                *(
                    ()
                    if certification_gates
                    else ("--no-activity-check", "--no-threshold-check")
                ),
            ),
            project_root,
            capture_dir / "audit_metrics.json",
        ),
    }
    identity_report: dict[str, Any] | None = None
    if checks["identity"]:
        try:
            identity_report = read_json_object(
                capture_dir / "audit_identity.json", max_bytes=8 * 1024 * 1024
            )
        except RuntimeContractError:
            checks["identity"] = False
    commitment_check = _verify_capture_commitment(
        capture_dir,
        commitment,
        identity_report=identity_report,
    )
    checks["capture_commitment"] = commitment_check["pass"] is True
    partials = sorted(str(path) for path in capture_dir.rglob("*.partial"))
    result = {
        "pass": all(checks.values()) and not partials,
        "checks": checks,
        "replay_determinism": replay_determinism,
        "capture_commitment": commitment_check,
        "partial_files": partials,
        "completed_utc_ns": time.time_ns(),
    }
    atomic_write_json(capture_dir / "postflight.json", result)
    return result


def validate_completed_manifest(
    path: Path,
    *,
    expected_session_id: str,
    expected_launcher_pid: int,
    expected_engine_pid: int,
    expected_project_root: Path,
    expected_output_dir: Path,
    expected_healthy_seconds: float | None,
    ready: dict[str, Any],
) -> dict[str, Any]:
    """Validate the engine's durable terminal state instead of trusting exit code 0."""

    try:
        payload = read_json_object(path, max_bytes=READY_MAX_BYTES)
    except RuntimeContractError as exc:
        raise LauncherFailure("SESSION_FINAL_INVALID", str(exc)) from exc

    def fail(message: str) -> None:
        raise LauncherFailure("SESSION_FINAL_INVALID", message)

    if payload.get("manifest_version") != SESSION_MANIFEST_VERSION:
        fail("manifest_version no coincide")
    if payload.get("capture_session_id") != expected_session_id:
        fail("capture_session_id final no coincide")
    if payload.get("state") != "COMPLETED":
        fail(f"state final esperado='COMPLETED' recibido={payload.get('state')!r}")
    if payload.get("launcher_pid") != expected_launcher_pid:
        fail("launcher_pid final no coincide")
    if payload.get("engine_pid") != expected_engine_pid:
        fail("engine_pid final no coincide")
    for field, expected in (
        ("project_root", expected_project_root),
        ("output_dir", expected_output_dir),
    ):
        try:
            received = _normalized_absolute_path(payload.get(field), field=field)
        except LauncherFailure as exc:
            raise LauncherFailure("SESSION_FINAL_INVALID", str(exc)) from exc
        if received != os.path.normcase(str(expected.resolve())):
            fail(f"{field} final no coincide")
    created = payload.get("created_utc_ns")
    updated = payload.get("updated_utc_ns")
    update_index = payload.get("update_index")
    if (
        not isinstance(created, int)
        or isinstance(created, bool)
        or not isinstance(updated, int)
        or isinstance(updated, bool)
        or updated < created
        or not isinstance(update_index, int)
        or isinstance(update_index, bool)
        or update_index < 5
    ):
        fail("timestamps/update_index finales inválidos")
    identity = payload.get("identity")
    if not isinstance(identity, dict):
        fail("identity final ausente")
    for field in (
        "protocol_version",
        "product",
        "engine_version",
        "data_schema_version",
        "capture_session_id",
        "pid",
        "launcher_pid",
        "process_start_utc_ns",
        "symbol",
        "markets",
        "host",
        "port",
        "url",
        "project_root",
        "output_dir",
        "python_executable",
        "package_file",
    ):
        if identity.get(field) != ready.get(field):
            fail(f"identity.{field} cambió después de READY")
    result = payload.get("result")
    if (
        not isinstance(result, dict)
        or result.get("code") != "ENGINE_COMPLETED"
        or result.get("ready_published") is not True
        or result.get("healthy_duration_completed") is not True
        or not isinstance(result.get("completed_utc_ns"), int)
    ):
        fail("result final no demuestra cierre completo")
    if result.get("required_healthy_seconds") != expected_healthy_seconds:
        fail("La duración saludable requerida no coincide")
    healthy_resets = result.get("healthy_resets")
    if (
        not isinstance(healthy_resets, int)
        or isinstance(healthy_resets, bool)
        or healthy_resets < 0
    ):
        fail("healthy_resets inválido")
    if expected_healthy_seconds is not None:
        healthy_started = result.get("healthy_started_monotonic_ns")
        healthy_completed = result.get("healthy_completed_monotonic_ns")
        if (
            not isinstance(healthy_started, int)
            or isinstance(healthy_started, bool)
            or not isinstance(healthy_completed, int)
            or isinstance(healthy_completed, bool)
            or healthy_completed < healthy_started
            or healthy_completed - healthy_started
            < int(expected_healthy_seconds * 1_000_000_000)
        ):
            fail("La evidencia monotónica no completa la ventana saludable")
    commitment = result.get("capture_commitment")
    if (
        not isinstance(commitment, dict)
        or commitment.get("capture_session_id") != expected_session_id
        or not isinstance(commitment.get("last_ingest_seq"), int)
        or isinstance(commitment.get("last_ingest_seq"), bool)
        or int(commitment["last_ingest_seq"]) <= 0
        or not isinstance(commitment.get("markets"), dict)
        or set(commitment["markets"]) != set(EXPECTED_MARKETS)
    ):
        fail("capture_commitment final inválido")
    if payload.get("error") is not None:
        fail("un manifest COMPLETED no puede contener error")
    return payload


def _creation_options() -> dict[str, Any]:
    if os.name == "nt":
        return {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
    return {"start_new_session": True}


def _open_browser_once(url: str, *, timeout_s: float = 10.0) -> tuple[bool, str | None]:
    completed = threading.Event()
    outcome: dict[str, Any] = {}

    def open_target() -> None:
        try:
            outcome["opened"] = bool(webbrowser.open(url))
        except Exception as exc:
            outcome["error"] = f"{type(exc).__name__}: {exc}"
        finally:
            completed.set()

    threading.Thread(
        target=open_target,
        name="jean-flow-browser-open",
        daemon=True,
    ).start()
    if not completed.wait(timeout_s):
        return False, f"BROWSER_OPEN_TIMEOUT: superó {timeout_s:.0f} s"
    return bool(outcome.get("opened", False)), outcome.get("error")


def _should_open_browser(
    spec: "RunSpec", *, no_browser: bool
) -> tuple[bool, str | None]:
    """[2.4.1] ¿Se abre el panel solo? Devuelve (abrir, motivo_de_no_abrir).

    Evidencia de campo (sesión aa1e3beafeec, 30 min, BTCUSDT): el panel se
    abrió solo a los 4.0 s de vida del proceso y se llevó el PRIMER PLANO.
    A partir de ahí el `max` de `writer_cooperative_yield` de USDⓈ-M subió
    en escalones —1.036 ms a los 5 s, 3.8 a los 10 s, 9.404 a los 30 s,
    14.2 a los 105 s— y se quedó ahí el resto de la corrida: 14.2 ms es del
    orden del tic de 15.625 ms del temporizador degradado. Windows 11
    degrada (EcoQoS) al proceso cuya ventana NO está en primer plano, que es
    exactamente lo que provoca abrirle al usuario un navegador encima de la
    consola. El usuario además tenía que volver a la consola a mano.

    En una ETAPA CERTIFICABLE el panel no aporta nada al veredicto y sí
    perturba la medición: no se abre. En uso normal (`healthy_seconds is
    None`) mirar el panel ES el objetivo y se sigue abriendo, salvo
    `--no-browser`. El panel sigue servido en la misma URL: quien quiera
    verlo lo abre cuando quiera.
    """

    if no_browser:
        return False, "USER_REQUESTED_NO_BROWSER"
    if spec.healthy_seconds is not None:
        return False, "CERTIFICATION_FOREGROUND_PROTECTION"
    return True, None


def _browser_evidence(
    url: str,
    *,
    opened: bool,
    error: str | None,
    attempted_utc_ns: int | None,
    skip_reason: str | None,
) -> dict[str, Any]:
    """[2.4.1] Evidencia del panel con las MISMAS claves se abra o no.

    Un run que no abrió el navegador debe decir por qué, no callarse.
    """

    return {
        "attempted_utc_ns": attempted_utc_ns,
        "opened": opened,
        "error": error,
        "url": url,
        "skipped": skip_reason is not None,
        "skip_reason": skip_reason,
    }


def run_capture(
    project_root: Path,
    runs_root: Path,
    spec: RunSpec,
    *,
    symbol: str,
    ready_timeout_s: float,
    open_browser: bool = True,
    browser_skip_reason: str | None = None,
) -> dict[str, Any]:
    session_id = uuid.uuid4().hex
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    run_root = (runs_root / f"{stamp}_{spec.label}_{session_id[:12]}").resolve()
    capture_dir = run_root / "capture"
    control_dir = run_root / "control"
    control_dir.mkdir(parents=True, exist_ok=False)
    session_file = control_dir / "session.json"
    ready_file = control_dir / "READY.json"
    stop_file = control_dir / "STOP.json"
    heartbeat_file = control_dir / "HEARTBEAT.json"
    launcher_manifest = SessionManifest.create(
        session_file,
        capture_session_id=session_id,
        launcher_pid=os.getpid(),
        project_root=project_root,
        output_dir=capture_dir,
    )
    command = _isolated_command(
        project_root,
        "module",
        "binance_collector.dual_main",
        "--symbol",
        symbol,
        "--output-dir",
        str(capture_dir),
        "--dashboard-port",
        "0",
        "--session-id",
        session_id,
        "--parent-pid",
        str(os.getpid()),
        "--session-file",
        str(session_file),
        "--ready-file",
        str(ready_file),
        "--stop-file",
        str(stop_file),
        "--heartbeat-file",
        str(heartbeat_file),
        "--ready-timeout",
        str(ready_timeout_s),
        "--no-browser",
    )
    if spec.healthy_seconds is not None:
        command.extend(("--healthy-seconds", str(spec.healthy_seconds)))
    environment = os.environ.copy()
    environment["PYTHONUNBUFFERED"] = "1"
    heartbeat = LauncherHeartbeat(heartbeat_file, session_id)
    heartbeat.__enter__()
    try:
        process = subprocess.Popen(
            command,
            cwd=project_root,
            env=environment,
            stdin=None,
            stdout=None,
            stderr=None,
            shell=False,
            **_creation_options(),
        )
    except BaseException as exc:
        heartbeat.__exit__(type(exc), exc, exc.__traceback__)
        with suppress(RuntimeContractError):
            launcher_manifest.transition(
                "FAILED",
                error_code="ENGINE_SPAWN_FAILED",
                error_message=str(exc),
            )
        raise
    interrupted = False
    try:
        ready, url = _wait_for_ready(
            process,
            ready_file,
            heartbeat,
            session_id=session_id,
            symbol=symbol,
            timeout_s=ready_timeout_s + 10,
            project_root=project_root,
            output_dir=capture_dir,
        )
        print(f"READY_VALID - GRABANDO - sesión {session_id}")
        print(f"Dashboard disponible en {url}")
        if open_browser:
            browser_attempted_utc_ns = time.time_ns()
            browser_opened, browser_error = _open_browser_once(url)
            atomic_write_json(
                control_dir / "browser.json",
                _browser_evidence(
                    url,
                    opened=browser_opened,
                    error=browser_error,
                    attempted_utc_ns=browser_attempted_utc_ns,
                    skip_reason=None,
                ),
            )
            if not browser_opened:
                print(
                    "BROWSER_OPEN_FAILED: la captura continúa; abra "
                    "manualmente la URL."
                )
        else:
            # [2.4.1] No se abre: hacerlo roba el primer plano y Windows
            # degrada el proceso (ver _should_open_browser).
            atomic_write_json(
                control_dir / "browser.json",
                _browser_evidence(
                    url,
                    opened=False,
                    error=None,
                    attempted_utc_ns=None,
                    skip_reason=browser_skip_reason
                    or "CERTIFICATION_FOREGROUND_PROTECTION",
                ),
            )
            print(
                "PANEL NO ABIERTO A PROPOSITO: abrirlo pondria el navegador "
                "delante de esta ventana y Windows degradaria la captura. "
                f"El panel sigue en {url} si quiere mirarlo; durante la "
                "certificacion es mejor no tocar el equipo."
            )
        try:
            engine_exit = _wait_for_engine(process, heartbeat)
        except KeyboardInterrupt:
            interrupted = True
            print("Solicitando cierre drenado; no cierre esta ventana...")
            engine_exit = _stop_owned_process(
                process, stop_file, session_id, session_file
            )
    except BaseException:
        if process.poll() is None:
            with suppress(Exception):
                _stop_owned_process(process, stop_file, session_id, session_file)
        heartbeat.__exit__(None, None, None)
        raise

    heartbeat.__exit__(None, None, None)
    manifest_validation: dict[str, Any]
    final_manifest: dict[str, Any] | None = None
    manifest_failure: LauncherFailure | None = None
    if engine_exit == 0:
        try:
            final_manifest = validate_completed_manifest(
                session_file,
                expected_session_id=session_id,
                expected_launcher_pid=os.getpid(),
                expected_engine_pid=process.pid,
                expected_project_root=project_root,
                expected_output_dir=capture_dir,
                expected_healthy_seconds=spec.healthy_seconds,
                ready=ready,
            )
            manifest_validation = {"pass": True, "error_code": None, "message": None}
        except LauncherFailure as exc:
            manifest_failure = exc
            manifest_validation = {
                "pass": False,
                "error_code": exc.code,
                "message": str(exc),
            }
        if final_manifest is not None:
            commitment = final_manifest["result"]["capture_commitment"]
            audit = audit_capture(
                project_root,
                capture_dir,
                commitment,
                certification_gates=spec.healthy_seconds is not None,
            )
        else:
            audit = {
                "pass": False,
                "checks": {},
                "partial_files": [],
                "error_code": "SESSION_FINAL_INVALID",
            }
    else:
        manifest_validation = {
            "pass": False,
            "error_code": "ENGINE_EXIT_NONZERO",
            "message": f"El motor terminó con código {engine_exit}",
        }
        audit = {"pass": False, "checks": {}, "partial_files": []}
    data_gates_pass = (
        engine_exit == 0
        and manifest_validation["pass"] is True
        and audit.get("pass") is True
    )
    result = {
        # A data PASS is not a stage PASS until the launcher completes the
        # mandatory read-only clock postflight in ``main``.
        "pass": False,
        "status": (
            "PENDING_CLOCK_POSTFLIGHT" if data_gates_pass else "DATA_GATES_FAILED"
        ),
        "data_gates_pass": data_gates_pass,
        "label": spec.label,
        "capture_session_id": session_id,
        "engine_exit_code": engine_exit,
        "interrupted": interrupted,
        "ready": ready,
        "session_manifest_validation": manifest_validation,
        "session_manifest": final_manifest,
        "audit": audit,
        "run_root": str(run_root),
        "completed_utc_ns": time.time_ns(),
    }
    atomic_write_json(run_root / "RESULT.json", result)
    if not data_gates_pass:
        if manifest_failure is not None:
            raise manifest_failure
        if engine_exit != 0:
            # P1.4b: antes el error visible era POSTFLIGHT_FAILED aunque el
            # RESULT registrara ENGINE_EXIT_NONZERO: código ≠ causa.
            raise LauncherFailure(
                "ENGINE_EXIT_NONZERO",
                f"El motor terminó con código {engine_exit}; revise {run_root}",
            )
        raise LauncherFailure("POSTFLIGHT_FAILED", f"Auditoría FAIL en {run_root}")
    return result


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _hash_evidence_files(root: Path) -> list[dict[str, Any]]:
    allowed = {".csv", ".json", ".jsonl", ".partial", ".txt"}
    entries: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.name == "RESULT.json":
            continue
        if path.suffix.lower() not in allowed:
            continue
        entries.append(
            {
                "path": path.relative_to(root).as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": _sha256(path),
            }
        )
    return entries


def _reverify_release(
    project_root: Path,
    initial_integrity: dict[str, Any],
) -> dict[str, Any]:
    """Require the release tree to remain identical throughout a long run."""

    try:
        current = verify_release_tree(
            project_root.parent,
            expected_version=LAUNCHER_VERSION,
        )
    except ReleaseIntegrityError as exc:
        raise LauncherFailure(exc.code, str(exc)) from exc
    if current.get("manifest_sha256") != initial_integrity.get("manifest_sha256"):
        raise LauncherFailure(
            "RELEASE_CHANGED_DURING_CAPTURE",
            "El manifest de release cambió después del preflight",
        )
    current["runtime_integrity"] = _verify_runtime_integrity(project_root)
    return current


def _revalidate_postflight_commitment(result: dict[str, Any]) -> dict[str, Any]:
    """Detect any journal mutation between data audit and clock postflight."""

    run_root = Path(str(result.get("run_root", ""))).resolve()
    capture_dir = run_root / "capture"
    session_manifest = result.get("session_manifest")
    if not isinstance(session_manifest, dict):
        raise LauncherFailure("CAPTURE_COMMITMENT_CHANGED", "Manifest terminal ausente")
    terminal = session_manifest.get("result")
    commitment = (
        terminal.get("capture_commitment") if isinstance(terminal, dict) else None
    )
    if not isinstance(commitment, dict):
        raise LauncherFailure(
            "CAPTURE_COMMITMENT_CHANGED", "Commitment terminal ausente"
        )
    try:
        identity_report = read_json_object(
            capture_dir / "audit_identity.json",
            max_bytes=8 * 1024 * 1024,
        )
    except RuntimeContractError as exc:
        raise LauncherFailure("CAPTURE_COMMITMENT_CHANGED", str(exc)) from exc
    check = _verify_capture_commitment(
        capture_dir,
        commitment,
        identity_report=identity_report,
    )
    if check.get("pass") is not True:
        raise LauncherFailure(
            "CAPTURE_COMMITMENT_CHANGED",
            "; ".join(map(str, check.get("errors", ["commitment inválido"]))),
        )
    return check


def _validate_stage_receipt(
    result: dict[str, Any],
    *,
    compare_payload: bool = True,
) -> dict[str, Any]:
    """Reconcile a completed RESULT with every non-RESULT evidence file."""

    run_root = Path(str(result.get("run_root", ""))).resolve()
    result_file = run_root / "RESULT.json"
    try:
        on_disk = read_json_object(result_file, max_bytes=32 * 1024 * 1024)
    except RuntimeContractError as exc:
        raise LauncherFailure("STAGE_EVIDENCE_CHANGED", str(exc)) from exc
    if (
        (compare_payload and on_disk != result)
        or on_disk.get("pass") is not True
        or (on_disk.get("status") != "COMPLETED")
    ):
        raise LauncherFailure(
            "STAGE_EVIDENCE_CHANGED", "RESULT.json no coincide con la etapa cerrada"
        )
    expected = on_disk.get("evidence_hashes")
    current = _hash_evidence_files(run_root)
    if not isinstance(expected, list) or current != expected:
        raise LauncherFailure(
            "STAGE_EVIDENCE_CHANGED",
            "Los archivos de evidencia cambiaron después del PASS de etapa",
        )
    return {
        "label": on_disk.get("label"),
        "capture_session_id": on_disk.get("capture_session_id"),
        "result_path": str(result_file),
        "result_size_bytes": result_file.stat().st_size,
        "result_sha256": _sha256(result_file),
        "evidence_file_count": len(current),
        "verified_utc_ns": time.time_ns(),
    }


def _archive_previous_certificate(runs_root: Path) -> str | None:
    marker = runs_root / "CAPTURA_COMPLETA_AUDITADA.json"
    if not marker.exists():
        return None
    if not marker.is_file() or marker.is_symlink():
        raise LauncherFailure(
            "CERTIFICATE_PATH_INVALID", f"Marcador anterior inseguro: {marker}"
        )
    history = runs_root / "certificate_history"
    history.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    destination = history / f"CAPTURA_COMPLETA_AUDITADA_{stamp}.json"
    try:
        os.replace(marker, destination)
    except OSError as exc:
        raise LauncherFailure("CERTIFICATE_ARCHIVE_FAILED", str(exc)) from exc
    return str(destination)


def _invalidate_previous_certificate(runs_root: Path) -> str | None:
    """Remove a stale success marker before any new full attempt can fail."""

    try:
        return _archive_previous_certificate(runs_root)
    except LauncherFailure:
        raise
    except OSError as exc:
        raise LauncherFailure("CERTIFICATE_ARCHIVE_FAILED", str(exc)) from exc


class SingleInstance(AbstractContextManager["SingleInstance"]):
    def __init__(self, project_root: Path) -> None:
        # [S7b]/[S8]: identidad por ruta RESUELTA y normalizada (subst/8.3 ya
        # no generan tokens distintos) y espacio de nombres Global\ para que
        # dos sesiones de usuario (RDP + consola) se excluyan de verdad.
        canonical = os.path.normcase(str(project_root.resolve()))
        token = hashlib.sha256(canonical.casefold().encode("utf-8")).hexdigest()[:24]
        self.name = f"Global\\JEAN_FLOW_{token}"
        self.handle: int | None = None
        self._kernel32: Any | None = None
        self.lock_stream: BinaryIO | None = None
        # Bajo systemd los locks viven en /run/jean-flow (JEAN_FLOW_RUNTIME_DIR);
        # sin esa variable se conserva el comportamiento histórico junto al árbol.
        lock_root = Path(
            os.environ.get("JEAN_FLOW_RUNTIME_DIR", str(project_root))
        ).resolve()
        self.lock_path = lock_root / ".jean_flow_launcher.lock"

    def __enter__(self) -> "SingleInstance":
        if os.name == "nt":
            # [S8]: patrón correcto de GetLastError — use_last_error=True y
            # lectura inmediata; ctypes.windll.kernel32.GetLastError() tras
            # bytecode intermedio podía perder ERROR_ALREADY_EXISTS y dejar
            # dos supervisores escribiendo evidencia entrelazada.
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.CreateMutexW.argtypes = (
                wintypes.LPVOID,
                wintypes.BOOL,
                wintypes.LPCWSTR,
            )
            kernel32.CreateMutexW.restype = wintypes.HANDLE
            kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
            kernel32.CloseHandle.restype = wintypes.BOOL
            self._kernel32 = kernel32
            ctypes.set_last_error(0)
            handle = kernel32.CreateMutexW(None, False, self.name)
            creation_error = ctypes.get_last_error()
            if not handle:
                raise LauncherFailure(
                    "MUTEX_FAILED",
                    f"No se pudo crear el mutex (WinError {creation_error})",
                )
            self.handle = int(handle)
            if creation_error == 183:
                kernel32.CloseHandle(handle)
                self.handle = None
                raise LauncherFailure("ALREADY_RUNNING", "JEAN_FLOW ya está iniciado")
        else:
            import fcntl

            self.lock_path.parent.mkdir(parents=True, exist_ok=True)
            self.lock_stream = self.lock_path.open("a+b")
            try:
                fcntl.flock(self.lock_stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as exc:
                self.lock_stream.close()
                self.lock_stream = None
                raise LauncherFailure(
                    "ALREADY_RUNNING", "JEAN_FLOW ya está iniciado"
                ) from exc
        return self

    def __exit__(self, *_exc_info: object) -> None:
        if self.handle is not None and self._kernel32 is not None:
            self._kernel32.CloseHandle(wintypes.HANDLE(self.handle))
            self.handle = None
            self._kernel32 = None
        if self.lock_stream is not None:
            with suppress(OSError):
                self.lock_stream.close()
            self.lock_stream = None
        # POSIX: el inode del lock NO se elimina. Un unlink entre close/open
        # permite que dos procesos bloqueen inodos distintos durante la
        # carrera; el archivo estable (p. ej. en /run/jean-flow) es lo correcto.


def _verify_runtime_integrity(project_root: Path) -> dict[str, object]:
    runtime_value = os.environ.get("JEAN_FLOW_RUNTIME_PACKAGES")
    if not runtime_value:
        raise LauncherFailure(
            "RUNTIME_INTEGRITY_FAILED", "Bootstrap no publicó el runtime verificado"
        )
    runtime = Path(runtime_value).resolve()
    expected_root = Path(
        os.environ.get("JEAN_FLOW_RUNTIME_ROOT", str(project_root / ".runtime"))
    ).resolve()
    if runtime != (expected_root / "packages").resolve():
        raise LauncherFailure(
            "RUNTIME_INTEGRITY_FAILED", "Ruta del runtime no coincide con el proyecto"
        )
    try:
        return verify_runtime_tree(project_root, runtime)
    except SupplyChainError as exc:
        raise LauncherFailure("RUNTIME_INTEGRITY_FAILED", str(exc)) from exc


def verify_runtime(project_root: Path) -> dict[str, Any]:
    if LAUNCHER_VERSION != __version__:
        raise LauncherFailure(
            "VERSION_MISMATCH",
            f"launcher={LAUNCHER_VERSION} package={__version__}",
        )
    import binance_collector

    package_file = Path(binance_collector.__file__).resolve()
    expected_source = (project_root / "src" / "binance_collector").resolve()
    if not package_file.is_relative_to(expected_source):
        raise LauncherFailure(
            "VERSION_MISMATCH",
            f"Se importó otra instalación: {package_file}",
        )
    if sys.version_info[:2] != (3, 12):
        raise LauncherFailure("PYTHON_UNSUPPORTED", platform.python_version())
    if sys.maxsize <= 2**32:
        raise LauncherFailure("PYTHON_ARCH_UNSUPPORTED", "Se requiere Python x64")
    try:
        integrity = verify_release_tree(
            project_root.parent,
            expected_version=LAUNCHER_VERSION,
        )
    except ReleaseIntegrityError as exc:
        raise LauncherFailure(exc.code, str(exc)) from exc
    inherited_manifest = os.environ.get("JEAN_FLOW_RELEASE_MANIFEST_SHA256")
    if inherited_manifest != integrity["manifest_sha256"]:
        raise LauncherFailure(
            "RELEASE_MANIFEST_MISMATCH",
            "Bootstrap y motor no verificaron el mismo manifest",
        )
    runtime_integrity = _verify_runtime_integrity(project_root)
    inherited_runtime = os.environ.get("JEAN_FLOW_RUNTIME_INVENTORY_SHA256")
    if runtime_integrity["inventory_sha256"] != inherited_runtime:
        raise LauncherFailure(
            "RUNTIME_INTEGRITY_FAILED",
            "Bootstrap y motor no verificaron el mismo inventario runtime",
        )
    integrity["runtime_integrity"] = runtime_integrity
    return integrity


_ENDPOINT_OVERRIDE_VARIABLES = (
    "BINANCE_WS_BASE_URL",
    "BINANCE_REST_BASE_URL",
    "BINANCE_FUTURES_WS_BASE_URL",
    "BINANCE_FUTURES_REST_BASE_URL",
)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Launcher supervisado JEAN_FLOW")
    parser.add_argument(
        "--mode",
        choices=("offline", "preflight", "normal", "10m", "full"),
        help=(
            "offline valida integridad/tests/benchmark sin red; preflight añade "
            "el gate de reloj; normal/10m/full inician captura"
        ),
    )
    parser.add_argument("--symbol", default="TUTUSDT")
    parser.add_argument("--ready-timeout", type=float, default=180.0)
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help=(
            "[2.4.1] No abrir el panel automáticamente tampoco en uso "
            "normal. Las etapas certificables NUNCA lo abren: el navegador "
            "roba el primer plano y Windows degrada el proceso"
        ),
    )
    parser.add_argument(
        "--allow-endpoint-override",
        action="store_true",
        help=(
            "Permite variables BINANCE_*_URL en modo supervisado; el override "
            "queda registrado en la evidencia y el certificado se marca como "
            "provenance SYNTHETIC/OVERRIDDEN"
        ),
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    try:
        if _windows_process_is_elevated():
            raise LauncherFailure(
                "ELEVATED_PROCESS_FORBIDDEN",
                "Ejecuta INICIAR con doble clic normal; no uses "
                "'Ejecutar como administrador'",
            )
        # Misma regla en POSIX: el motor jamás corre con privilegios.
        if os.name == "posix" and hasattr(os, "geteuid") and os.geteuid() == 0:
            raise LauncherFailure(
                "ELEVATED_PROCESS_FORBIDDEN",
                "No ejecutes JEAN_FLOW como root ni con sudo; usa tu usuario normal",
            )
    except LauncherFailure as exc:
        print(f"{exc.code}: {exc}")
        return exc.exit_code
    args = _parser().parse_args(argv)
    if os.name == "posix" and threading.current_thread() is threading.main_thread():
        # systemd detiene con SIGTERM: mismo camino drenado que Ctrl+C
        # (commitment, auditoría y RESULT), nunca una muerte súbita.
        signal.signal(signal.SIGTERM, _raise_keyboard_interrupt)
    # P2.6: el motor normaliza strip().upper() y el launcher comparaba solo
    # upper(): '--symbol " btcusdt "' producía READY válido para el motor y
    # READY_INVALID fatal aquí. Se normaliza UNA vez al entrar.
    args.symbol = args.symbol.strip().upper()
    if args.mode is None:
        # P3.2a: stdin puede ser None (pythonw/servicio); isatty() sobre None
        # y un EOF de input() no deben tumbar el launcher.
        if sys.stdin is not None and sys.stdin.isatty():
            print("Seleccione el modo:")
            print("  1 - Uso normal (hasta Ctrl+C)")
            print("  2 - Prueba certificable de 10 minutos")
            print("  3 - Certificación completa 10 + 30 + 120 minutos")
            try:
                choice = input("Opción [1]: ").strip() or "1"
            except EOFError:
                choice = "1"
            args.mode = {"1": "normal", "2": "10m", "3": "full"}.get(choice)
            if args.mode is None:
                print("Opción inválida; se usará el modo normal.")
                args.mode = "normal"
            # [2.3.2] El símbolo era un default silencioso (TUTUSDT) y la
            # certificación exige actividad en TODOS los streams: un símbolo
            # ilíquido puede pasar una ventana de 10 min sin UN solo aggTrade
            # de futuros (evidencia de campo: 0 en 3.7 min) y condena el modo
            # 2/3 al final de la etapa. Se pregunta UNA vez, con default al
            # símbolo del proyecto en uso normal y a BTCUSDT en modos
            # certificables; la elección queda registrada en identidad,
            # commitment y certificado como siempre.
            suggested = "BTCUSDT" if args.mode in ("10m", "full") else args.symbol
            if args.mode in ("10m", "full") and args.symbol != "BTCUSDT":
                print(
                    "La certificación necesita un símbolo con volumen real "
                    "en Spot y Futuros (recomendado: BTCUSDT)."
                )
            # [2.3.4] Evidencia de campo: un dedazo ("}") en el símbolo
            # moría en el MOTOR (BINANCE_SYMBOL debe ser ASCII alfanumérico)
            # después de minutos de preflight silencioso. Se valida AQUÍ con
            # la misma regla y se repregunta en vez de abortar la sesión.
            for _attempt in range(3):
                try:
                    typed = input(f"Símbolo [{suggested}]: ").strip().upper()
                except EOFError:
                    typed = ""
                candidate = typed or suggested
                if candidate.isascii() and candidate.isalnum():
                    args.symbol = candidate
                    break
                print(
                    "Símbolo inválido: solo letras y números (ej. BTCUSDT). "
                    f"Enter = {suggested}."
                )
            else:
                args.symbol = suggested
        else:
            args.mode = "normal"
    # P1.6: los overrides BINANCE_* llegaban al motor sin quedar registrados
    # en READY/commitment/certificado. En modo supervisado se rechazan salvo
    # bandera explícita, y en ese caso quedan en la evidencia.
    endpoint_overrides = {
        name: os.environ[name]
        for name in _ENDPOINT_OVERRIDE_VARIABLES
        if os.environ.get(name)
    }
    if endpoint_overrides and not args.allow_endpoint_override:
        print(
            "ENV_OVERRIDE_FORBIDDEN: variables de endpoint presentes en el "
            f"entorno: {sorted(endpoint_overrides)}. Elimínelas o ejecute con "
            "--allow-endpoint-override (la captura quedará marcada como no "
            "certificable contra Binance real)."
        )
        return 2
    if args.allow_endpoint_override:
        os.environ["JEAN_FLOW_ALLOW_ENDPOINT_OVERRIDE"] = "1"
    project_root = Path(__file__).resolve().parents[2]
    # Bajo systemd el estado vive en /var/lib/jean-flow (código de solo
    # lectura en /opt); sin la variable se conserva el diseño histórico.
    state_root = Path(
        os.environ.get("JEAN_FLOW_STATE_ROOT", str(project_root))
    ).resolve()
    runs_root = state_root / "runs"
    # F3 (anti-brick de ruta): el peor descendiente bajo runs\ (directorio de
    # etapa + capture\usdm_futures\events-*.csv.partial) añade ~115
    # caracteres. Verificado en el host real: con la carpeta a 116 caracteres
    # de profundidad, el heartbeat murió exactamente en MAX_PATH=260 a mitad
    # de captura. Se rechaza EN EL ARRANQUE con la acción nombrada.
    if os.name == "nt" and len(str(runs_root)) + 120 > 259:
        print(
            "PATH_TOO_LONG: la carpeta del proyecto está demasiado profunda "
            f"({len(str(runs_root))} caracteres hasta runs\\; Windows corta "
            "en 260). Mueva la carpeta 555 a una ruta corta, por ejemplo "
            "D:\\JF\\555, o active LongPathsEnabled en el registro, y vuelva "
            "a ejecutar."
        )
        return 2
    preflight = runs_root / (
        "preflight_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    )
    attempt_id = uuid.uuid4().hex
    try:
        runs_root.mkdir(parents=True, exist_ok=True)
        preflight.mkdir()
        with SingleInstance(project_root):
            # Once this exclusive full attempt starts, an older PASS is history,
            # including when the new tree fails its integrity gate.
            previous_certificate = (
                _invalidate_previous_certificate(runs_root)
                if args.mode == "full"
                else None
            )
            release_integrity = verify_runtime(project_root)
            atomic_write_json(preflight / "release_integrity.json", release_integrity)
            atomic_write_json(
                preflight / "certification_attempt.json",
                {
                    "attempt_id": attempt_id,
                    "mode": args.mode,
                    "previous_certificate_archived_to": previous_certificate,
                    "endpoint_overrides": endpoint_overrides,
                    "provenance": (
                        "ENDPOINT_OVERRIDDEN" if endpoint_overrides else "BINANCE"
                    ),
                    "started_utc_ns": time.time_ns(),
                },
            )
            print(f"JEAN_FLOW {__version__}")
            print(f"Proyecto: {project_root}")
            print(f"Python: {sys.executable} ({platform.python_version()})")
            is_linux = sys.platform.startswith("linux")
            if os.name != "nt" and not is_linux:
                raise LauncherFailure(
                    "PLATFORM_UNSUPPORTED",
                    "Este release admite Linux x86-64 y conserva la "
                    "implementación histórica de Windows",
                )
            if args.mode == "offline":
                offline_preflight(project_root, preflight)
                atomic_write_json(
                    preflight / "OFFLINE_READY.json",
                    {
                        "pass": True,
                        "mode": "offline",
                        "release_integrity": release_integrity,
                        "completed_utc_ns": time.time_ns(),
                    },
                )
                print(f"OFFLINE_READY: {preflight}")
                return 0
            disk_preflight(runs_root, preflight, mode=args.mode)
            if args.mode == "preflight":
                clock_start = (
                    linux_clock_preflight(preflight)
                    if is_linux
                    else clock_preflight(project_root, preflight)
                )
                offline_preflight(project_root, preflight)
                atomic_write_json(
                    preflight / "PREFLIGHT_READY.json",
                    {
                        "pass": True,
                        "mode": "preflight",
                        "release_integrity": release_integrity,
                        "clock_preflight": clock_start,
                        "completed_utc_ns": time.time_ns(),
                    },
                )
                print(f"PREFLIGHT_READY: {preflight}")
                return 0
            if args.mode == "normal":
                # [2.3.4] El reloj estricto es un gate de CERTIFICACIÓN
                # (coherente con [2.3.2-3]): el uso normal graba SIEMPRE y
                # deja el estado del reloj ANOTADO en la evidencia (además
                # del estimador θ̂ cross-clock que el motor publica en el
                # arranque). Evidencia de campo: un reinicio de Windows dejó
                # 344 ms de desvío transitorio y bloqueaba también la
                # grabación diaria, no solo la certificación.
                try:
                    clock_start = (
                        linux_clock_preflight(preflight)
                        if is_linux
                        else clock_preflight(project_root, preflight)
                    )
                except LauncherFailure as exc:
                    clock_start = {
                        "pass": False,
                        "waived_mode": "normal",
                        "error_code": exc.code,
                        "message": str(exc),
                        "waived_utc_ns": time.time_ns(),
                    }
                    atomic_write_json(
                        preflight / "clock_preflight_waived.json", clock_start
                    )
                    print(
                        f"AVISO RELOJ (uso normal): {exc.code}: {exc}. La "
                        "captura continúa; el desvío queda anotado en la "
                        "evidencia y esta sesión NO es certificable."
                    )
            else:
                clock_start = (
                    linux_clock_preflight(preflight)
                    if is_linux
                    else clock_preflight(project_root, preflight)
                )
            offline_preflight(project_root, preflight)

            specs = {
                "normal": (RunSpec("normal", None),),
                "10m": (RunSpec("10m", 600.0),),
                "full": (
                    RunSpec("10m", 600.0),
                    RunSpec("30m", 1_800.0),
                    RunSpec("120m", 7_200.0),
                ),
            }[args.mode]
            results: list[dict[str, Any]] = []
            for spec in specs:
                abrir_panel, motivo_panel = _should_open_browser(
                    spec, no_browser=args.no_browser
                )
                result = run_capture(
                    project_root,
                    runs_root,
                    spec,
                    symbol=args.symbol,
                    ready_timeout_s=args.ready_timeout,
                    open_browser=abrir_panel,
                    browser_skip_reason=motivo_panel,
                )
                run_root = Path(result["run_root"])
                result["release_integrity"] = release_integrity
                try:
                    result["clock_postflight"] = (
                        linux_clock_postflight(run_root)
                        if is_linux
                        else clock_postflight(project_root, run_root)
                    )
                except LauncherFailure as exc:
                    if spec.healthy_seconds is None:
                        # [2.3.4] Mismo alcance que el preflight: en uso
                        # normal el reloj no condena una captura íntegra,
                        # queda anotado con su causa.
                        result["clock_postflight"] = {
                            "pass": False,
                            "waived_mode": "normal",
                            "error_code": exc.code,
                            "message": str(exc),
                        }
                        print(
                            "AVISO RELOJ al cierre (uso normal): "
                            f"{exc.code}: {exc}. La sesión queda grabada; "
                            "no es certificable."
                        )
                    else:
                        result["pass"] = False
                        result["status"] = "CLOCK_POSTFLIGHT_FAILED"
                        result["clock_postflight"] = {
                            "pass": False,
                            "error_code": exc.code,
                            "message": str(exc),
                        }
                        result["evidence_hashes"] = _hash_evidence_files(
                            run_root
                        )
                        atomic_write_json(run_root / "RESULT.json", result)
                        raise
                # NTP sampling can take long enough for external mutation. No
                # stage PASS is published until code and committed journals are
                # revalidated after that sampling window.
                result["release_integrity_postflight"] = _reverify_release(
                    project_root,
                    release_integrity,
                )
                result["capture_commitment_postflight"] = (
                    _revalidate_postflight_commitment(result)
                )
                result["status"] = "COMPLETED"
                result["pass"] = True
                result["stage_completed_utc_ns"] = time.time_ns()
                result["evidence_hashes"] = _hash_evidence_files(run_root)
                atomic_write_json(run_root / "RESULT.json", result)
                result["stage_receipt"] = _validate_stage_receipt(result)
                # The receipt is metadata derived from RESULT and is stored in
                # the certificate list, not rewritten into RESULT recursively.
                results.append(result)
            if args.mode == "full":
                final_release_integrity = _reverify_release(
                    project_root,
                    release_integrity,
                )
                stage_receipts = [
                    _validate_stage_receipt(result, compare_payload=False)
                    for result in results
                ]
                certificate = {
                    "pass": True,
                    "marker": "CAPTURA_COMPLETA_AUDITADA",
                    "provenance": (
                        "ENDPOINT_OVERRIDDEN" if endpoint_overrides else "BINANCE"
                    ),
                    "endpoint_overrides": endpoint_overrides,
                    "attempt_id": attempt_id,
                    "engine_version": __version__,
                    "data_schema_version": SCHEMA_VERSION,
                    "symbol": args.symbol.upper(),
                    "markets": list(EXPECTED_MARKETS),
                    "launcher_pid": os.getpid(),
                    "host": {
                        "platform": platform.platform(),
                        "python": platform.python_version(),
                        "machine": platform.machine(),
                    },
                    "release_integrity": final_release_integrity,
                    "release_manifest_sha256": final_release_integrity[
                        "manifest_sha256"
                    ],
                    "clock_preflight": clock_start,
                    "preflight_evidence_hashes": _hash_evidence_files(preflight),
                    "stages": results,
                    "stage_receipts": stage_receipts,
                    "completed_utc_ns": time.time_ns(),
                }
                marker = runs_root / "CAPTURA_COMPLETA_AUDITADA.json"
                atomic_write_json(marker, certificate)
                print(f"CAPTURA_COMPLETA_AUDITADA: {marker}")
            return 0
    except (LauncherFailure, RuntimeContractError) as exc:
        code = exc.code
        with suppress(Exception):
            atomic_write_json(
                preflight / "LAUNCHER_FAILED.json",
                {
                    "pass": False,
                    "attempt_id": attempt_id,
                    "mode": args.mode,
                    "error_code": code,
                    "message": str(exc),
                    "failed_utc_ns": time.time_ns(),
                },
            )
        print(f"{code}: {exc}")
        return exc.exit_code if isinstance(exc, LauncherFailure) else 1
    except KeyboardInterrupt:
        with suppress(Exception):
            atomic_write_json(
                preflight / "LAUNCHER_FAILED.json",
                {
                    "pass": False,
                    "attempt_id": attempt_id,
                    "mode": args.mode,
                    "error_code": "INTERRUPTED",
                    "message": "Operación cancelada por el usuario",
                    "failed_utc_ns": time.time_ns(),
                },
            )
        print("INTERRUPTED: operación cancelada por el usuario")
        return 130
    except Exception as exc:
        with suppress(Exception):
            atomic_write_json(
                preflight / "LAUNCHER_FAILED.json",
                {
                    "pass": False,
                    "attempt_id": attempt_id,
                    "mode": args.mode,
                    "error_code": "LAUNCHER_INTERNAL_ERROR",
                    "exception_type": type(exc).__name__,
                    "message": str(exc),
                    "failed_utc_ns": time.time_ns(),
                },
            )
        print(f"LAUNCHER_INTERNAL_ERROR: {type(exc).__name__}: {exc}")
        return 70


if __name__ == "__main__":
    raise SystemExit(main())
