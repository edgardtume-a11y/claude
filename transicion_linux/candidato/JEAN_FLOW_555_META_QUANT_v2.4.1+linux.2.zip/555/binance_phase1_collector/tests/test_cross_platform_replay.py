from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import pytest


TOOL = (
    Path(__file__).resolve().parents[1]
    / "tools"
    / "compare_cross_platform_replay.py"
)


def _module():
    spec = importlib.util.spec_from_file_location("compare_cross_platform_replay", TOOL)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _report(
    path: Path,
    *,
    source_file: str,
    digest: str = "a" * 64,
    causal_replay: str = "PASS",
) -> None:
    path.write_text(
        json.dumps(
            {
                "files": [source_file],
                "certification": {
                    "journal_integrity": "PASS",
                    "causal_replay": causal_replay,
                },
                "replay": {
                    "canonical_hash_version": 2,
                    "market": "spot",
                    "sha256": digest,
                },
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )


def test_full_report_paths_may_differ_but_replay_must_match(tmp_path: Path) -> None:
    windows = tmp_path / "windows.json"
    linux = tmp_path / "linux.json"
    _report(windows, source_file=r"C:\\JF\\capture\\events.csv")
    _report(linux, source_file="/var/lib/jean-flow/capture/events.csv")
    result = _module().compare(windows, linux)
    assert result["pass"] is True
    assert result["same_replay_object"] is True


def test_replay_hash_change_is_no_go(tmp_path: Path) -> None:
    first = tmp_path / "first.json"
    second = tmp_path / "second.json"
    _report(first, source_file="first", digest="a" * 64)
    _report(second, source_file="second", digest="b" * 64)
    result = _module().compare(first, second)
    assert result["pass"] is False


def test_causal_replay_must_be_pass(tmp_path: Path) -> None:
    first = tmp_path / "first.json"
    second = tmp_path / "second.json"
    _report(first, source_file="first", causal_replay="FAIL")
    _report(second, source_file="second")
    with pytest.raises(ValueError, match="causal_replay no es PASS"):
        _module().compare(first, second)
