from __future__ import annotations

from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
ROOT = PROJECT.parent


def test_systemd_supervises_launcher_as_unprivileged_user() -> None:
    unit = (PROJECT / "tools" / "linux" / "jean-flow.service").read_text(
        encoding="utf-8"
    )
    assert "User=jean-flow" in unit
    assert "/555/INICIAR.sh --mode normal" in unit
    assert "dual_main" not in unit
    assert "ProtectClock=yes" in unit
    assert "ProtectSystem=strict" in unit
    assert "KillSignal=SIGTERM" in unit
    assert "JEAN_FLOW_STATE_ROOT=/var/lib/jean-flow" in unit
    assert "JEAN_FLOW_RUNTIME_DIR=/run/jean-flow" in unit


def test_linux_launcher_closes_fail_closed_and_keeps_stable_lock_inode() -> None:
    launcher = (PROJECT / "src" / "binance_collector" / "launcher.py").read_text(
        encoding="utf-8"
    )
    single_instance = launcher[
        launcher.index("class SingleInstance") : launcher.index(
            "def _verify_runtime_integrity"
        )
    ]
    assert "self.lock_path.unlink" not in single_instance
    assert "signal.SIGTERM" in launcher
    # [2.4.1] run_capture ya falla cerrado: escribe RESULT (DATA_GATES_FAILED)
    # y lanza ANTES de que main pueda declarar la etapa COMPLETED.
    data_gate = launcher.index("if not data_gates_pass:")
    stage_pass = launcher.index('result["status"] = "COMPLETED"')
    assert data_gate < stage_pass


def test_large_commitment_publishes_progress_before_hashing() -> None:
    dual_main = (PROJECT / "src" / "binance_collector" / "dual_main.py").read_text(
        encoding="utf-8"
    )
    stopping = dual_main.index('"COMMITMENT_IN_PROGRESS"')
    commitment = dual_main.index("_capture_commitment,", stopping)
    assert stopping < commitment
    assert "bytes_hashed >= next_progress" in dual_main
    assert "32 * 1024 * 1024" in dual_main


def test_public_entrypoint_rejects_root_and_forces_utf8() -> None:
    entry = (ROOT / "INICIAR.sh").read_text(encoding="utf-8")
    assert "ROOT_PROCESS_FORBIDDEN" in entry
    assert "/usr/bin/python3.12" in entry
    assert "-X utf8 -I -S -B -u" in entry


def test_el_launcher_rechaza_root_en_posix() -> None:
    launcher = (PROJECT / "src" / "binance_collector" / "launcher.py").read_text(
        encoding="utf-8"
    )
    assert "os.geteuid() == 0" in launcher
    assert "ELEVATED_PROCESS_FORBIDDEN" in launcher


def test_el_auditor_ve_todos_los_fragmentos_rotados_de_metricas() -> None:
    launcher = (PROJECT / "src" / "binance_collector" / "launcher.py").read_text(
        encoding="utf-8"
    )
    assert "_metrics_series_paths(capture_dir / \"jean_flow_metrics.jsonl\")" in launcher
