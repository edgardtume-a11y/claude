from __future__ import annotations

import os
from collections import namedtuple
from pathlib import Path

import pytest

from binance_collector import launcher


# ---------------------------------------------------------------------------
# Serie de métricas rotadas: el auditor debe ver TODO el log, en orden causal.
# ---------------------------------------------------------------------------


def _touch(path: Path) -> Path:
    path.write_text("{}\n", encoding="utf-8")
    return path


def test_serie_de_metricas_sin_rotacion_es_solo_el_base(tmp_path: Path) -> None:
    base = _touch(tmp_path / "jean_flow_metrics.jsonl")
    assert launcher._metrics_series_paths(base) == [base]


def test_serie_de_metricas_rotadas_va_de_antigua_a_reciente(tmp_path: Path) -> None:
    base = _touch(tmp_path / "jean_flow_metrics.jsonl")
    rot1 = _touch(tmp_path / "jean_flow_metrics.jsonl.1")
    rot2 = _touch(tmp_path / "jean_flow_metrics.jsonl.2")
    rot5 = _touch(tmp_path / "jean_flow_metrics.jsonl.5")
    # RotatingFileHandler: .5 es el más antiguo, el base el más reciente.
    assert launcher._metrics_series_paths(base) == [rot5, rot2, rot1, base]


def test_serie_de_metricas_ignora_sufijos_no_numericos_y_symlinks(
    tmp_path: Path,
) -> None:
    base = _touch(tmp_path / "jean_flow_metrics.jsonl")
    _touch(tmp_path / "jean_flow_metrics.jsonl.bak")
    _touch(tmp_path / "jean_flow_metrics.jsonl.viejo")
    real = _touch(tmp_path / "jean_flow_metrics.jsonl.1")
    enlace = tmp_path / "jean_flow_metrics.jsonl.2"
    enlace.symlink_to(real)
    assert launcher._metrics_series_paths(base) == [real, base]


def test_la_serie_siempre_termina_en_el_base_aunque_no_exista(tmp_path: Path) -> None:
    # Fallo cerrado: si el base falta, el auditor de métricas fallará al
    # abrirlo — la serie jamás lo omite en silencio.
    base = tmp_path / "jean_flow_metrics.jsonl"
    assert launcher._metrics_series_paths(base) == [base]


# ---------------------------------------------------------------------------
# Gate de disco: números explícitos, evidencia escrita, fallo cerrado.
# ---------------------------------------------------------------------------

_Usage = namedtuple("_Usage", "total used free")


def test_disk_preflight_aprueba_y_deja_evidencia(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        launcher.shutil,
        "disk_usage",
        lambda _path: _Usage(total=500 * 1024**3, used=100 * 1024**3, free=400 * 1024**3),
    )
    evidencia = tmp_path / "evidencia"
    evidencia.mkdir()
    payload = launcher.disk_preflight(tmp_path / "runs", evidencia, mode="full")
    assert payload["pass"] is True
    assert payload["error_code"] == "PASS"
    assert payload["minimum_free_gib"] == 30.0
    escrito = (evidencia / "disk_preflight.json").read_text(encoding="utf-8")
    assert '"DISK_SPACE_INSUFFICIENT"' not in escrito


def test_disk_preflight_bloquea_sin_margen_y_lo_documenta(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        launcher.shutil,
        "disk_usage",
        lambda _path: _Usage(total=100 * 1024**3, used=95 * 1024**3, free=5 * 1024**3),
    )
    evidencia = tmp_path / "evidencia"
    evidencia.mkdir()
    with pytest.raises(launcher.LauncherFailure) as caught:
        launcher.disk_preflight(tmp_path / "runs", evidencia, mode="10m")
    assert caught.value.code == "DISK_SPACE_INSUFFICIENT"
    assert (evidencia / "disk_preflight.json").exists()


def test_disk_preflight_exige_tambien_el_15_por_ciento(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # 40 GiB libres superan los 30 del modo full, pero son el 4% del disco.
    monkeypatch.setattr(
        launcher.shutil,
        "disk_usage",
        lambda _path: _Usage(
            total=1000 * 1024**3, used=960 * 1024**3, free=40 * 1024**3
        ),
    )
    evidencia = tmp_path / "evidencia"
    evidencia.mkdir()
    with pytest.raises(launcher.LauncherFailure):
        launcher.disk_preflight(tmp_path / "runs", evidencia, mode="full")


def test_disk_preflight_falla_cerrado_si_no_puede_examinar(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    def _explota(_path: object) -> None:
        raise OSError("sin permisos")

    monkeypatch.setattr(launcher.shutil, "disk_usage", _explota)
    evidencia = tmp_path / "evidencia"
    evidencia.mkdir()
    with pytest.raises(launcher.LauncherFailure) as caught:
        launcher.disk_preflight(tmp_path / "runs", evidencia, mode="full")
    assert caught.value.code == "DISK_SPACE_INSUFFICIENT"


# ---------------------------------------------------------------------------
# Envolturas del reloj Linux: evidencia SIEMPRE escrita, fallo cerrado.
# ---------------------------------------------------------------------------


def test_linux_clock_preflight_escribe_evidencia_y_pasa(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from binance_collector import clock_linux

    monkeypatch.setattr(
        clock_linux,
        "preflight_clock",
        lambda *, warn_ms: {"pass": True, "error_code": "PASS", "warn_ms": warn_ms},
    )
    payload = launcher.linux_clock_preflight(tmp_path)
    assert payload["pass"] is True
    assert (tmp_path / "clock_preflight.json").exists()


def test_linux_clock_preflight_falla_cerrado_con_evidencia(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from binance_collector import clock_linux

    monkeypatch.setattr(
        clock_linux,
        "preflight_clock",
        lambda *, warn_ms: {
            "pass": False,
            "error_code": "CHRONY_UNSYNCHRONIZED",
            "message": "sin fuente",
        },
    )
    with pytest.raises(launcher.LauncherFailure) as caught:
        launcher.linux_clock_preflight(tmp_path)
    assert caught.value.code == "CHRONY_UNSYNCHRONIZED"
    assert (tmp_path / "clock_preflight.json").exists()


def test_linux_clock_postflight_falla_cerrado_con_evidencia(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from binance_collector import clock_linux

    monkeypatch.setattr(
        clock_linux,
        "read_clock_evidence",
        lambda *, warn_ms: {
            "pass": False,
            "error_code": "CLOCK_OFFSET_EXCEEDED",
            "message": "62 ms",
        },
    )
    with pytest.raises(launcher.LauncherFailure) as caught:
        launcher.linux_clock_postflight(tmp_path)
    assert caught.value.code == "CLOCK_OFFSET_EXCEEDED"
    assert (tmp_path / "clock_postflight.json").exists()


# ---------------------------------------------------------------------------
# El lock POSIX vive donde diga JEAN_FLOW_RUNTIME_DIR y su inode es estable.
# ---------------------------------------------------------------------------


def test_el_lock_posix_respeta_runtime_dir_y_no_borra_el_inode(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    lock_root = tmp_path / "run" / "jean-flow"
    monkeypatch.setenv("JEAN_FLOW_RUNTIME_DIR", str(lock_root))
    proyecto = tmp_path / "proyecto"
    proyecto.mkdir()
    instancia = launcher.SingleInstance(proyecto)
    assert instancia.lock_path.parent == lock_root.resolve()
    if os.name == "nt":  # pragma: no cover - esta batería corre en Linux
        return
    with instancia:
        assert instancia.lock_path.exists()
        inode = instancia.lock_path.stat().st_ino
    # El inode sobrevive al cierre: sin carrera flock/unlink.
    assert instancia.lock_path.exists()
    assert instancia.lock_path.stat().st_ino == inode
