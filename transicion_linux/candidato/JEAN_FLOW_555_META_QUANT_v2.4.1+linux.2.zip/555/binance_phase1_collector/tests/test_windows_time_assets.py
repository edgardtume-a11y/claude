from __future__ import annotations

import base64
import csv
import hashlib
import importlib.util
import io
import re
import zipfile
from pathlib import Path
from types import SimpleNamespace

import pytest

from binance_collector import launcher as launcher_module

ROOT = Path(__file__).resolve().parents[1]
RELEASE_ROOT = ROOT.parent
TIME_SYNC = ROOT / "tools" / "windows" / "time-sync"
PUBLIC_CMD = RELEASE_ROOT / "INICIAR.cmd"
BOOTSTRAP = RELEASE_ROOT / "jean_flow_launcher.py"
LAUNCHER = ROOT / "src" / "binance_collector" / "launcher.py"


def _text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _load_bootstrap():
    spec = importlib.util.spec_from_file_location("jean_flow_bootstrap_test", BOOTSTRAP)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _test_wheel(
    tmp_path: Path,
    *,
    include_pth: bool = False,
    include_data: bool = False,
) -> SimpleNamespace:
    tmp_path.mkdir(parents=True, exist_ok=True)
    wheel = tmp_path / "demo-1.0-py3-none-any.whl"
    record_name = "demo-1.0.dist-info/RECORD"
    payloads = {
        "demo/__init__.py": b"VALUE = 1\n",
        "demo-1.0.dist-info/METADATA": b"Name: demo\nVersion: 1.0\n",
    }
    if include_pth:
        payloads["demo.pth"] = b"import demo\n"
    if include_data:
        payloads["demo-1.0.data/scripts/demo.exe"] = b"not executable"
    rows: list[list[str]] = []
    for name, payload in payloads.items():
        encoded = base64.urlsafe_b64encode(hashlib.sha256(payload).digest()).rstrip(
            b"="
        )
        rows.append([name, "sha256=" + encoded.decode("ascii"), str(len(payload))])
    rows.append([record_name, "", ""])
    record = io.StringIO(newline="")
    csv.writer(record, lineterminator="\n").writerows(rows)
    with zipfile.ZipFile(wheel, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, payload in payloads.items():
            archive.writestr(name, payload)
        archive.writestr(record_name, record.getvalue().encode("utf-8"))
    return SimpleNamespace(
        distribution="demo",
        version="1.0",
        path=wheel,
        sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
    )


def test_powershell_variables_before_literal_colons_are_braced() -> None:
    unsafe = re.compile(r"\$(?!\{)[A-Za-z_][A-Za-z0-9_]*:(?![A-Za-z0-9_])")
    failures: list[str] = []
    for path in sorted(TIME_SYNC.glob("*.ps1")):
        for line_number, line in enumerate(_text(path).splitlines(), start=1):
            for match in unsafe.finditer(line):
                failures.append(f"{path.name}:{line_number}:{match.group(0)}")
    assert not failures, "Variables PowerShell sin delimitar: " + ", ".join(failures)


def test_static_assertion_is_bindable_when_parser_has_no_errors() -> None:
    script = _text(TIME_SYNC / "Test-TimeSyncAssets.ps1")
    assert "[AllowEmptyString()][string]$Message" in script
    assert "Assert-Condition -Condition $true -Message ''" in script
    assert "$parseFailureMessage = if ($parseFailures.Count -gt 0)" in script
    assert "-Message $parseFailureMessage" in script
    assert script.index("Language.Parser]::ParseFile") < script.index(
        ". (Join-Path $PSScriptRoot 'TimeSync-Common.ps1')"
    )
    common = _text(TIME_SYNC / "TimeSync-Common.ps1")
    assert "[AllowEmptyString()][string]$Message" in common
    assert "$Message = 'Sin detalle adicional.'" in common


def test_access_denied_source_query_uses_verbose_status_fallback() -> None:
    common = _text(TIME_SYNC / "TimeSync-Common.ps1")
    verifier = _text(TIME_SYNC / "Test-W32Time.ps1")
    configure = _text(TIME_SYNC / "Configure-W32Time.ps1")
    static = _text(TIME_SYNC / "Test-TimeSyncAssets.ps1")
    assert "function Get-JeanFlowClockSourceFromStatus" in common
    assert "function Resolve-JeanFlowClockSource" in common
    assert "function Test-JeanFlowAccessDenied" in common
    assert "Source|Origen|Origem|Origine|Quelle|Bron" in common
    assert "status_verbose_access_denied_fallback" in common
    assert "Resolve-JeanFlowClockSource" in verifier
    assert "Resolve-JeanFlowClockSource" in configure
    assert "source_evidence = $sourceOrigin" in verifier
    assert "source_query_exit_code = $sourceExit" in verifier
    assert "QUERY_ACCESS_DENIED" in verifier
    assert "abs_phase_offset_ms" in verifier
    assert "w32time_phase_offset" in verifier
    assert "Origen: 1.pool.ntp.org,0x8" in static
    assert "Source: time.windows.com,0x8" in static
    assert "Local CMOS Clock" in static


def test_w32time_repair_starts_service_before_first_config_update() -> None:
    script = _text(TIME_SYNC / "Configure-W32Time.ps1")
    backup = script.index("& $reg export")
    automatic = script.index("Set-Service -Name W32Time -StartupType Automatic")
    start = script.index("Start-Service -Name W32Time")
    wait = script.index("Wait-ForW32TimeRunning -TimeoutSeconds 20")
    configure = script.index('Invoke-W32Time /config "/manualpeerlist:')
    restart = script.index("Restart-Service -Name W32Time")
    resync = script.index("/resync /rediscover")
    assert backup < automatic < start < wait < configure < restart < resync


def test_resync_is_single_and_never_runs_in_hot_path_or_verifiers() -> None:
    configure = _text(TIME_SYNC / "Configure-W32Time.ps1")
    assert configure.count("/resync /rediscover") == 1
    for path in [
        TIME_SYNC / "Test-W32Time.ps1",
        TIME_SYNC / "Test-ClockSync.ps1",
        TIME_SYNC / "Test-MeinbergNtp.ps1",
        BOOTSTRAP,
    ]:
        assert "/resync" not in _text(path).lower()
    launcher = _text(LAUNCHER)
    assert launcher.count('request.lpParameters = "/resync"') == 1
    assert "request.lpFile = str(binary)" in launcher
    assert "ShellExecuteExW" in launcher
    for path in (ROOT / "src").rglob("*.py"):
        if path == LAUNCHER:
            continue
        source = _text(path).lower()
        assert "w32tm" not in source
        assert "ntpq" not in source


def test_repair_never_registers_service_or_opens_inbound_firewall() -> None:
    assets = "\n".join(
        _text(path)
        for path in TIME_SYNC.glob("*.ps1")
        if path.name != "Test-TimeSyncAssets.ps1"
    ).lower()
    assert "/unregister" not in assets
    assert " /register" not in assets
    assert "new-netfirewallrule" not in assets
    assert "netsh advfirewall" not in assets


def test_public_and_controlled_polling_profiles_are_separated() -> None:
    script = _text(TIME_SYNC / "Configure-W32Time.ps1")
    assert "$pollseconds -lt 1800" in script.lower()
    assert "{ 6 } else { 11 }" in script
    assert '"$_,0x8"' in script
    assert "ApprovedHighRateSource" in script
    assert "pool.ntp.org no puede usarse con el perfil de 64 segundos" in script
    assert "start/networkon stop/networkoff" in script


def test_w32time_diagnostics_have_required_machine_codes() -> None:
    script = _text(TIME_SYNC / "Test-W32Time.ps1")
    for code in [
        "SERVICE_STOPPED",
        "SERVICE_DISABLED",
        "NO_VALID_SOURCE",
        "OFFSET_OUT_OF_RANGE",
        "DOMAIN_POLICY",
        "MULTIPLE_TIME_SERVICES",
    ]:
        assert code in script
    common = _text(TIME_SYNC / "TimeSync-Common.ps1").lower()
    assert "local\\s+cmos" in common
    assert "reloj\\s+cmos" in common
    assert "abs_phase_offset_ms" in script
    assert "offset_observations = 1" in script
    assert "WarnMs = 50" in script
    assert "Test-JeanFlowPhaseOffsetWithinLimit" in script
    assert "$hasActivePeer" in script
    common = _text(TIME_SYNC / "TimeSync-Common.ps1")
    # [W1]/R1.5: los hechos ausentes se nombran uno a uno y un fallo de
    # PARSER se reporta como STATUS_LOCALE_UNSUPPORTED (exit 21), nunca como
    # NO_VALID_SOURCE.
    assert "$missingFacts" in common
    assert "missing_facts = $missingFacts" in common
    assert "STATUS_LOCALE_UNSUPPORTED" in script
    assert "Invoke-JeanFlowNativeQuery" in common
    assert "registry_read_ok" in script


def test_repair_checks_policy_and_other_services_before_mutation() -> None:
    script = _text(TIME_SYNC / "Configure-W32Time.ps1")
    policy = script.index("Get-JeanFlowClockPolicyState")
    external = script.index("$external =")
    backup = script.index("& $reg export")
    automatic = script.index("Set-Service -Name W32Time -StartupType Automatic")
    assert policy < external < backup < automatic
    assert "PartOfDomain" in _text(TIME_SYNC / "TimeSync-Common.ps1")


def test_uac_launcher_is_path_safe_and_single_elevation() -> None:
    launcher = _text(TIME_SYNC / "Start-W32TimeRepair.ps1")
    assert launcher.count("-Verb RunAs") == 1
    assert "-EncodedCommand" in launcher
    assert "$PSScriptRoot" in launcher
    assert "Language.Parser]::ParseFile" in launcher
    assert "Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1'" in launcher
    assert "TIME_SYNC_ASSET_PARSE_ERROR" in launcher


def test_release_has_exactly_one_public_cmd_and_it_is_path_safe() -> None:
    command_files = sorted(RELEASE_ROOT.rglob("*.cmd"))
    assert command_files == [PUBLIC_CMD]
    script = _text(PUBLIC_CMD)
    assert 'cd /d "%~dp0"' in script
    assert '"%JEAN_PY_EXE%"' in script
    assert '"%~dp0jean_flow_launcher.py"' in script
    assert "runas" not in script.lower()
    assert "powershell" not in script.lower()
    assert " -I -S -B -u " in script
    assert script.count(" -I -S -B -c ") == 1
    assert "where python" not in script.lower()
    assert "py -3.12" not in script.lower()
    assert "winget" not in script.lower()
    assert '"%SystemRoot%\\System32\\choice.exe"' in script
    assert ".venv\\Scripts\\python.exe" not in script


def test_bootstrap_runtime_is_hash_bound_and_never_trusts_venv_python() -> None:
    bootstrap = _text(BOOTSTRAP)
    assert "_safe_extract_wheel" in bootstrap
    # [S11]/P1.8c: una única implementación del verificador de wheels; el
    # bootstrap consume supply_chain en lugar de duplicar el extractor.
    assert "verified_wheel_payloads" in bootstrap
    assert "expected_runtime_inventory" in bootstrap
    assert "zipfile.ZipFile" not in bootstrap
    assert 'sys.executable, "-X", "utf8", "-I", "-S", "-B", "-c", probe' in bootstrap
    assert '"--inside-venv" in arguments' in bootstrap
    assert "RUNTIME_PACKAGES" in bootstrap
    assert "is_junction" in bootstrap
    assert 'RUNTIME_ROOT.with_name(".runtime_building")' in bootstrap
    assert "os.replace(staging_root, RUNTIME_ROOT)" in bootstrap
    assert "JEAN_FLOW_RUNTIME_INVENTORY_SHA256" in bootstrap
    assert "VENV_PYTHON" not in bootstrap
    assert "subprocess.call(command" not in bootstrap
    assert '"-e"' not in bootstrap
    assert "CreateMutexW" in bootstrap
    assert "msvcrt" not in bootstrap
    locked_body = bootstrap.split("with BootstrapLock():", 1)[1].split(
        'if __name__ == "__main__":', 1
    )[0]
    assert "return launcher_main(arguments)" in locked_body


def test_bootstrap_runtime_seal_is_derived_from_authenticated_wheel(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    bootstrap = _load_bootstrap()
    entry = _test_wheel(tmp_path)
    runtime_root = tmp_path / "runtime"
    packages = runtime_root / "packages"
    packages.mkdir(parents=True)
    manifest = runtime_root / "RUNTIME_MANIFEST.sha256"
    monkeypatch.setattr(bootstrap, "RUNTIME_ROOT", runtime_root)
    monkeypatch.setattr(bootstrap, "RUNTIME_PACKAGES", packages)
    monkeypatch.setattr(bootstrap, "RUNTIME_MANIFEST", manifest)

    bootstrap._safe_extract_wheel(entry, packages)
    expected = bootstrap._expected_runtime_hashes((entry,))
    manifest.write_text(
        "\n".join(f"{expected[name]}  {name}" for name in sorted(expected)) + "\n",
        encoding="ascii",
    )
    assert bootstrap._runtime_bytes_match_plan((entry,)) is True
    (packages / "demo" / "__init__.py").write_text("VALUE = 2\n", encoding="utf-8")
    assert bootstrap._runtime_bytes_match_plan((entry,)) is False


def test_bootstrap_rejects_wheel_swap_and_pth(tmp_path: Path) -> None:
    bootstrap = _load_bootstrap()
    entry = _test_wheel(tmp_path / "swap")
    entry.path.write_bytes(entry.path.read_bytes() + b"changed")
    with pytest.raises(
        bootstrap.BootstrapFailure, match="WHEEL_EXTRACT_FAILED.*cambi"
    ):
        bootstrap._safe_extract_wheel(entry, tmp_path / "swap-out")

    pth_entry = _test_wheel(tmp_path / "pth", include_pth=True)
    with pytest.raises(
        bootstrap.BootstrapFailure, match="WHEEL_EXTRACT_FAILED.*no admitida"
    ):
        bootstrap._safe_extract_wheel(pth_entry, tmp_path / "pth-out")

    data_entry = _test_wheel(tmp_path / "data", include_data=True)
    with pytest.raises(
        bootstrap.BootstrapFailure, match="WHEEL_EXTRACT_FAILED.*no admitida"
    ):
        bootstrap._safe_extract_wheel(data_entry, tmp_path / "data-out")


def test_python_launcher_owns_safe_sequence_and_no_shell_commands() -> None:
    script = _text(LAUNCHER)
    main = script.index("def main(")
    mutex = script.index("with SingleInstance(project_root)", main)
    identity = script.index("verify_runtime(project_root)", mutex)
    ntp = script.index("clock_preflight(project_root, preflight)", main)
    # [linux.1] existe un modo offline previo al reloj; en el camino de
    # captura el orden reloj→offline se conserva, y se ancla desde ntp.
    offline = script.index("offline_preflight(project_root, preflight)", ntp)
    capture = script.index("run_capture(", main)
    assert mutex < identity < ntp < offline < capture
    assert "shell=False" in script
    assert "shell=True" not in script
    assert 'RunSpec("10m", 600.0)' in script
    assert 'RunSpec("30m", 1_800.0)' in script
    assert 'RunSpec("120m", 7_200.0)' in script
    assert "CAPTURA_COMPLETA_AUDITADA" in script
    assert '"Start-W32TimeRepair.ps1"' not in script
    assert '"Configure-W32Time.ps1"' not in script
    assert "GetSystemDirectoryW" in script
    assert "GetTokenInformation" in script
    assert "ELEVATED_PROCESS_FORBIDDEN" in script
    assert '"WindowsPowerShell"' in script
    assert '"powershell.exe"' in script
    assert '"w32tm.exe"' in script
    assert "_w32_offset_recovery_eligible" in script
    assert "_run_elevated_w32time_resync" in script
    assert '["powershell.exe"' not in script
    assert "verify_runtime_tree" in script
    bootstrap = _text(BOOTSTRAP)
    assert "GetTokenInformation" in bootstrap
    assert "ELEVATED_PROCESS_FORBIDDEN" in bootstrap
    bootstrap_main = bootstrap.index("def main()")
    python_gate = bootstrap.index("_validate_bootstrap_python()", bootstrap_main)
    elevation_gate = bootstrap.index("_reject_elevated_process()", bootstrap_main)
    release_gate = bootstrap.index("_verify_release_integrity()", bootstrap_main)
    assert python_gate < elevation_gate < release_gate
    assert "RELEASE_VERIFIER_LOAD_FAILED" in bootstrap
    assert "BOOTSTRAP_INTERNAL_ERROR" in bootstrap
    assert "_invalidate_visible_certificate_after_integrity_failure" in bootstrap


def test_w32time_gate_uses_its_active_source_phase_offset() -> None:
    script = _text(TIME_SYNC / "Test-W32Time.ps1")
    assert "/stripchart" not in script.lower()
    assert "[Environment]::SystemDirectory" in script
    assert "$env:SystemRoot" not in script
    assert "w32time_phase_offset" in script
    assert "abs_phase_offset_ms" in script
    assert "Test-JeanFlowPhaseOffsetWithinLimit" in script
    common = _text(TIME_SYNC / "TimeSync-Common.ps1")
    assert "$currentPeerHost -eq $sourceHost" in common
    assert "1.pool.ntp.org,0x8 11.pool.ntp.org,0x8" in _text(
        TIME_SYNC / "Test-TimeSyncAssets.ps1"
    )
    dispatcher = _text(TIME_SYNC / "Test-ClockSync.ps1")
    assert "-Reference $Reference" not in dispatcher


def test_real_windows_offset_fixture_passes_against_the_active_source() -> None:
    payload = {
        "pass": True,
        "error_code": "PASS",
        "service": {
            "kind": "W32Time",
            "running": True,
            "state": "Running",
            "start_mode": "Auto",
        },
        "offset_method": "w32time_phase_offset",
        "phase_offset_ms": 2.426,
        "abs_phase_offset_ms": 2.4259,
        "phase_offset_ms_raw": 2.4259,
        "warn_ms": 50.0,
        "source": "1.pool.ntp.org,0x8",
        "source_from_status": "1.pool.ntp.org,0x8",
        "source_from_query": "1.pool.ntp.org,0x8",
        "source_query_access_denied": False,
        "active_peer_confirmed": True,
        "source_peer_active": True,
        "source_matches_configured_peer": True,
        "sync_type": "NTP",
        "registry_read_ok": True,
        "domain_joined": False,
        "policy_managed": False,
        "services": [
            {
                "kind": "W32Time",
                "running": True,
                "state": "Running",
                "start_mode": "Auto",
            }
        ],
        "last_sync_error": 0,
        "leap_indicator": 0,
        "stratum": 2,
        "state_machine": 1,
        "poll_seconds": 2048.0,
        "last_good_sync_age_seconds": 291.154,
        # Historical 2.2.1 diagnostics against an unrelated public endpoint
        # are deliberately irrelevant to the corrected decision.
        "legacy_stripchart_reference": "time.windows.com",
        "legacy_stripchart_p95_abs_offset_ms": 103.318,
    }
    assert launcher_module._clock_gate_passed(0, payload) is True
    payload["abs_phase_offset_ms"] = 50.0
    payload["phase_offset_ms"] = 50.0
    payload["phase_offset_ms_raw"] = 50.0
    assert launcher_module._clock_gate_passed(0, payload) is True
    # [W2]/M8: PS ([Math]::Round de .NET, ToEven) y CPython (round) divergen
    # en el 3,74 % de los valores representables de w32tm; la revalidación
    # cruzada tolera media unidad del último dígito (5e-4) en vez de 1e-9.
    payload["phase_offset_ms_raw"] = 13.5005
    payload["abs_phase_offset_ms"] = 13.5005
    payload["phase_offset_ms"] = 13.500  # .NET redondea ToEven: 13.500
    assert launcher_module._clock_gate_passed(0, payload) is True
    payload["phase_offset_ms"] = 13.501  # round() de CPython: 13.501
    assert launcher_module._clock_gate_passed(0, payload) is True
    # [W9]/R6.4: sin la evidencia del registro no hay PASS vacuo.
    degraded = dict(payload)
    degraded["registry_read_ok"] = False
    assert launcher_module._clock_gate_passed(0, degraded) is False
    empty_sync = dict(payload)
    empty_sync["sync_type"] = ""
    assert launcher_module._clock_gate_passed(0, empty_sync) is False
    # [W10]/R6.6: doble disciplinador falla cerrado también en la vía de PASS.
    double = dict(payload)
    double["services"] = [
        {"kind": "W32Time", "running": True},
        {"kind": "NetTime", "running": True},
    ]
    assert launcher_module._clock_gate_passed(0, double) is False
    payload["abs_phase_offset_ms"] = 50.000001
    payload["phase_offset_ms"] = 50.0
    payload["phase_offset_ms_raw"] = 50.000001
    assert launcher_module._clock_gate_passed(0, payload) is False


def _offset_payload(**overrides: object) -> dict[str, object]:
    service: dict[str, object] = {
        "kind": "W32Time",
        "name": "W32Time",
        "path": r"C:\Windows\System32\svchost.exe -k LocalService",
        "running": True,
        "state": "Running",
        "start_mode": "Auto",
    }
    payload: dict[str, object] = {
        "pass": False,
        "error_code": "OFFSET_OUT_OF_RANGE",
        "offset_method": "w32time_phase_offset",
        "warn_ms": 50.0,
        "domain_joined": False,
        "policy_managed": False,
        "sync_type": "NTP",
        "registry_read_ok": True,
        "configured_peer_list": "0.pool.ntp.org,0x8 1.pool.ntp.org,0x8",
        "service": service,
        "services": [dict(service)],
        "abs_phase_offset_ms": 75.0,
        "phase_offset_ms": 75.0,
        "phase_offset_ms_raw": 75.0,
        "source": "1.pool.ntp.org,0x8",
        "source_from_status": "1.pool.ntp.org,0x8",
        "source_from_query": "1.pool.ntp.org,0x8",
        "source_query_access_denied": False,
        "active_peer_confirmed": True,
        "source_peer_active": True,
        "source_matches_configured_peer": True,
        "last_sync_error": 0,
        "leap_indicator": 0,
        "stratum": 2,
        "state_machine": 1,
        "poll_seconds": 2048.0,
        "last_good_sync_age_seconds": 291.154,
    }
    payload.update(overrides)
    return payload


@pytest.mark.parametrize(
    "override",
    [
        {"domain_joined": True},
        {"policy_managed": True},
        {"service": {"kind": "MeinbergNtp", "running": True}},
        {"service": None},
        {"services": []},
        {
            "services": [
                {"kind": "W32Time", "running": True},
                {"kind": "NetTime", "running": True},
            ]
        },
        {"error_code": "NO_VALID_SOURCE"},
    ],
)
def test_offset_recovery_requires_complete_unmanaged_w32time(
    override: dict[str, object],
) -> None:
    assert launcher_module._w32_offset_recovery_eligible(_offset_payload()) is True
    assert (
        launcher_module._w32_offset_recovery_eligible(_offset_payload(**override))
        is False
    )


def test_clock_preflight_recovers_one_w32time_offset_and_preserves_evidence(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    initial = _offset_payload()
    passed = {
        "pass": True,
        "error_code": "PASS",
        "offset_method": "w32time_phase_offset",
        "abs_phase_offset_ms": 2.4259,
        "phase_offset_ms": 2.426,
        "phase_offset_ms_raw": 2.4259,
        "warn_ms": 50.0,
        "source": "1.pool.ntp.org,0x8",
        "source_from_status": "1.pool.ntp.org,0x8",
        "source_from_query": "1.pool.ntp.org,0x8",
        "source_query_access_denied": False,
        "active_peer_confirmed": True,
        "source_peer_active": True,
        "source_matches_configured_peer": True,
        "last_sync_error": 0,
        "leap_indicator": 0,
        "stratum": 2,
        "state_machine": 1,
        "poll_seconds": 2048.0,
        "last_good_sync_age_seconds": 5.0,
        "domain_joined": False,
        "policy_managed": False,
        "sync_type": "NTP",
        "registry_read_ok": True,
        "configured_peer_list": "0.pool.ntp.org,0x8 1.pool.ntp.org,0x8",
        "service": {
            "kind": "W32Time",
            "name": "W32Time",
            "path": r"C:\Windows\System32\svchost.exe -k LocalService",
            "running": True,
            "state": "Running",
            "start_mode": "Auto",
        },
        "services": [
            {
                "kind": "W32Time",
                "name": "W32Time",
                "path": r"C:\Windows\System32\svchost.exe -k LocalService",
                "running": True,
                "state": "Running",
                "start_mode": "Auto",
            }
        ],
    }
    calls = iter([(17, initial), (0, passed)])
    monkeypatch.setattr(
        launcher_module, "_run_clock_script", lambda *_args, **_kwargs: next(calls)
    )
    monkeypatch.setattr(launcher_module, "_confirm_clock_action", lambda _prompt: True)
    monkeypatch.setattr(
        launcher_module,
        "_run_elevated_w32time_resync",
        lambda: {"pass": True, "error_code": "PASS", "arguments": ["/resync"]},
    )
    result = launcher_module.clock_preflight(tmp_path, tmp_path)
    assert result == passed
    assert (
        launcher_module.read_json_object(tmp_path / "clock_preflight.json") == initial
    )
    recovery = launcher_module.read_json_object(tmp_path / "clock_offset_recovery.json")
    assert recovery["arguments"] == ["/resync"]
    assert (
        launcher_module.read_json_object(tmp_path / "clock_preflight_after_repair.json")
        == passed
    )


def test_clock_preflight_never_recovers_ineligible_or_declined_offset(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        launcher_module,
        "_run_clock_script",
        lambda *_args, **_kwargs: (17, _offset_payload(domain_joined=True)),
    )
    monkeypatch.setattr(
        launcher_module,
        "_confirm_clock_action",
        lambda _prompt: pytest.fail("no debe preguntar"),
    )
    with pytest.raises(launcher_module.LauncherFailure) as caught:
        launcher_module.clock_preflight(tmp_path, tmp_path)
    assert caught.value.code == "OFFSET_OUT_OF_RANGE"

    monkeypatch.setattr(
        launcher_module,
        "_run_clock_script",
        lambda *_args, **_kwargs: (17, _offset_payload()),
    )
    monkeypatch.setattr(launcher_module, "_confirm_clock_action", lambda _prompt: False)
    with pytest.raises(launcher_module.LauncherFailure) as caught:
        launcher_module.clock_preflight(tmp_path, tmp_path)
    assert caught.value.code == "CLOCK_REPAIR_DECLINED"

    monkeypatch.setattr(launcher_module, "_confirm_clock_action", lambda _prompt: True)
    monkeypatch.setattr(
        launcher_module,
        "_run_elevated_w32time_resync",
        lambda: (_ for _ in ()).throw(
            launcher_module.LauncherFailure("UAC_CANCELLED", "UAC cancelado")
        ),
    )
    with pytest.raises(launcher_module.LauncherFailure) as caught:
        launcher_module.clock_preflight(tmp_path, tmp_path)
    assert caught.value.code == "UAC_CANCELLED"
    failure = launcher_module.read_json_object(
        tmp_path / "clock_offset_recovery.json"
    )
    assert failure["pass"] is False
    assert failure["error_code"] == "UAC_CANCELLED"


def test_clock_postflight_is_read_only_on_offset_failure(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        launcher_module,
        "_run_clock_script",
        lambda *_args, **_kwargs: (17, _offset_payload()),
    )
    monkeypatch.setattr(
        launcher_module,
        "_run_elevated_w32time_resync",
        lambda: pytest.fail("postflight no puede resincronizar"),
    )
    with pytest.raises(launcher_module.LauncherFailure) as caught:
        launcher_module.clock_postflight(tmp_path, tmp_path)
    assert caught.value.code == "OFFSET_OUT_OF_RANGE"


def test_clock_gate_rejects_incomplete_or_incoherent_w32_evidence() -> None:
    valid = {
        "pass": True,
        "error_code": "PASS",
        "offset_method": "w32time_phase_offset",
        "abs_phase_offset_ms": 2.4259,
        "phase_offset_ms": 2.426,
        "phase_offset_ms_raw": 2.4259,
        "warn_ms": 50.0,
        "source": "1.pool.ntp.org,0x8",
        "source_from_status": "1.pool.ntp.org,0x8",
        "source_from_query": "1.pool.ntp.org,0x8",
        "source_query_access_denied": False,
        "active_peer_confirmed": True,
        "source_peer_active": True,
        "source_matches_configured_peer": True,
        "last_sync_error": 0,
        "leap_indicator": 0,
        "stratum": 2,
        "state_machine": 1,
        "poll_seconds": 2048.0,
        "last_good_sync_age_seconds": 10.0,
        "sync_type": "NTP",
        "registry_read_ok": True,
        "domain_joined": False,
        "policy_managed": False,
        "service": {
            "kind": "W32Time",
            "running": True,
            "state": "Running",
            "start_mode": "Auto",
        },
        "services": [
            {
                "kind": "W32Time",
                "running": True,
                "state": "Running",
                "start_mode": "Auto",
            }
        ],
    }
    assert launcher_module._clock_gate_passed(0, valid) is True
    for key, bad in [
        ("phase_offset_ms_raw", None),
        ("phase_offset_ms_raw", float("nan")),
        ("abs_phase_offset_ms", 1.0),
        ("source", ""),
        ("source_from_status", "0.pool.ntp.org,0x8"),
        ("source_from_query", "0.pool.ntp.org,0x8"),
        ("active_peer_confirmed", False),
        ("source_peer_active", False),
        ("source_matches_configured_peer", False),
        ("registry_read_ok", False),
        ("sync_type", ""),
        ("services", []),
        ("last_sync_error", 5),
        ("last_sync_error", False),
        ("leap_indicator", 3),
        ("leap_indicator", False),
        ("stratum", 0),
        ("state_machine", 3),
        ("state_machine", True),
        ("last_good_sync_age_seconds", 5000.0),
    ]:
        candidate = dict(valid)
        candidate[key] = bad
        assert launcher_module._clock_gate_passed(0, candidate) is False


def test_offset_recovery_fails_if_w32_configuration_changes(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    initial = _offset_payload()
    changed = dict(initial)
    changed.update(
        {
            "pass": True,
            "error_code": "PASS",
            "abs_phase_offset_ms": 1.0,
            "phase_offset_ms": 1.0,
            "phase_offset_ms_raw": 1.0,
            "configured_peer_list": "time.windows.com,0x8",
        }
    )
    calls = iter([(17, initial), (0, changed)])
    monkeypatch.setattr(
        launcher_module, "_run_clock_script", lambda *_args, **_kwargs: next(calls)
    )
    monkeypatch.setattr(launcher_module, "_confirm_clock_action", lambda _prompt: True)
    monkeypatch.setattr(
        launcher_module,
        "_run_elevated_w32time_resync",
        lambda: {"pass": True, "error_code": "PASS", "arguments": ["/resync"]},
    )
    with pytest.raises(launcher_module.LauncherFailure) as caught:
        launcher_module.clock_preflight(tmp_path, tmp_path)
    assert caught.value.code == "CLOCK_CONFIGURATION_CHANGED"


def test_meinberg_ntpq_is_bound_to_registered_service_directory() -> None:
    script = _text(TIME_SYNC / "Test-MeinbergNtp.ps1")
    assert "[string]($ntpd[0].path)" in script
    assert "Split-Path -Parent $ntpdPath" in script
    assert "Get-Command ntpq.exe" not in script
    assert "$env:ProgramFiles" not in script
    assert "[IO.Path]::IsPathRooted($serviceExecutable)" in script
    assert "$serviceCommandLine.Contains('%')" in script
    assert "[IO.FileAttributes]::ReparsePoint" in script
    assert "[ValidateRange(3, 200)][int]$Samples = 20" in script
    assert "for ($index = 0; $index -lt $Samples; $index++)" in script
    assert "offset_abs_ms = $null" in script
    assert "p95_abs_offset_ms" in script
    assert "max_abs_offset_ms" in script
    assert "$p95 -gt $WarnMs" in script
    dispatcher = _text(TIME_SYNC / "Test-ClockSync.ps1")
    assert "-Samples $Samples" in dispatcher


def test_meinberg_gate_authenticates_complete_sample_evidence() -> None:
    service = {
        "kind": "MeinbergNtp",
        "name": "NTP",
        "path": r'"C:\\Program Files\\NTP\\bin\\ntpd.exe" -U 3',
        "running": True,
        "state": "Running",
        "start_mode": "Auto",
    }
    runtime = [
        {
            "sample": index,
            "exit_code": 0,
            "output": [f"associd=0 status=0615 leap_none, offset={index / 10}"],
            "offset_abs_ms": index / 10,
        }
        for index in range(1, 21)
    ]
    payload: dict[str, object] = {
        "pass": True,
        "error_code": "PASS",
        "warn_ms": 50.0,
        "service": service,
        "services": [dict(service)],
        "ntpq_path": r"C:\\Program Files\\NTP\\bin\\ntpq.exe",
        "selected_peer": "*192.0.2.1 .GPS. 1 u 5 64 377 1.0 0.1 0.1",
        "peers": ["*192.0.2.1 .GPS. 1 u 5 64 377 1.0 0.1 0.1"],
        "samples": 20,
        "p95_abs_offset_ms": 1.9,
        "max_abs_offset_ms": 2.0,
        "runtime": runtime,
    }
    assert launcher_module._clock_gate_passed(0, payload) is True
    minimal = {
        "pass": True,
        "error_code": "PASS",
        "warn_ms": 50.0,
        "service": {"kind": "MeinbergNtp", "running": True},
        "samples": 20,
        "p95_abs_offset_ms": 1.0,
    }
    assert launcher_module._clock_gate_passed(0, minimal) is False
    for key, bad in [
        ("selected_peer", "192.0.2.1"),
        ("ntpq_path", "ntpq.exe"),
        ("samples", True),
        ("p95_abs_offset_ms", 0.1),
        ("max_abs_offset_ms", 1.9),
        ("runtime", runtime[:-1]),
    ]:
        candidate = dict(payload)
        candidate[key] = bad
        assert launcher_module._clock_gate_passed(0, candidate) is False
    raw_mismatch = [dict(sample) for sample in runtime]
    raw_mismatch[0]["output"] = ["associd=0 status=0615, offset=1000"]
    candidate = dict(payload)
    candidate["runtime"] = raw_mismatch
    assert launcher_module._clock_gate_passed(0, candidate) is False
