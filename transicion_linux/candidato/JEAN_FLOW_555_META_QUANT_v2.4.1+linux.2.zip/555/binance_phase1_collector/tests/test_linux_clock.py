from __future__ import annotations

from pathlib import Path

import pytest

from binance_collector.clock_linux import ChronyEvidenceError, parse_tracking_csv


def _tracking(**replacements: str) -> str:
    names = (
        "reference_id",
        "reference_source",
        "stratum",
        "reference_time",
        "system_time",
        "last_offset",
        "rms_offset",
        "frequency",
        "residual_frequency",
        "skew",
        "root_delay",
        "root_dispersion",
        "update_interval",
        "leap_status",
    )
    values = dict(
        zip(
            names,
            (
                "C0000201",
                "192.0.2.1",
                "2",
                "1700000000.0",
                "0.000001",
                "0.000002",
                "0.000003",
                "1.2",
                "0.1",
                "0.2",
                "0.001",
                "0.002",
                "16.0",
                "Normal",
            ),
        )
    )
    values.update(replacements)
    return ",".join(values[name] for name in names) + "\n"


def test_el_gate_vigente_es_el_offset_y_el_umbral_no_se_mueve() -> None:
    result = parse_tracking_csv(_tracking(), now_utc_s=1700000010.0)
    assert result["pass"] is True
    assert result["error_code"] == "PASS"
    assert result["warn_ms"] == 50.0
    # La banda honesta se PUBLICA junto al veredicto:
    assert result["banda_ms"] == 2.5
    assert result["incertidumbre_total_ms"] == 2.501
    assert result["utc_calificada"] == "DEMOSTRADA"


def test_el_gate_falla_con_offset_mayor_a_50_ms_sin_relajar_nada() -> None:
    result = parse_tracking_csv(_tracking(system_time="0.060"), now_utc_s=1700000010.0)
    assert result["pass"] is False
    assert result["error_code"] == "CLOCK_OFFSET_EXCEEDED"
    assert result["warn_ms"] == 50.0


def test_la_calidad_utc_es_informativa_y_nunca_niega_el_gate() -> None:
    # [DECISIÓN DEL PROYECTO, plan rector §6.3] el criterio |θ̂|+δ/2 <= L está
    # diseñado pero NO implementado como gate: con offset residual de 5 ms y
    # una banda de red de 120 ms, el gate vigente PASA y la calidad UTC
    # declara INSUFICIENTE — evidencia, no veto.
    result = parse_tracking_csv(
        _tracking(system_time="0.005", root_delay="0.200", root_dispersion="0.020"),
        now_utc_s=1700000010.0,
    )
    assert result["pass"] is True
    assert result["error_code"] == "PASS"
    assert result["utc_calificada"] == "INSUFICIENTE"
    assert result["incertidumbre_total_ms"] == pytest.approx(125.0)


@pytest.mark.parametrize(
    ("override", "code"),
    [
        ({"leap_status": "Not synchronised"}, "CHRONY_UNSYNCHRONIZED"),
        ({"stratum": "0"}, "CHRONY_UNSYNCHRONIZED"),
        ({"root_delay": "nan"}, "CHRONY_TRACKING_INVALID"),
        ({"reference_time": "1699990000"}, "CHRONY_REFERENCE_STALE"),
    ],
)
def test_chrony_parser_falla_cerrado(override: dict[str, str], code: str) -> None:
    with pytest.raises(ChronyEvidenceError) as caught:
        parse_tracking_csv(_tracking(**override), now_utc_s=1700000010.0)
    assert caught.value.code == code


def test_el_release_solo_lleva_ruedas_binarias_de_linux() -> None:
    project = Path(__file__).resolve().parents[1]
    wheels = sorted((project / "wheelhouse").glob("*.whl"))
    assert len(wheels) == 20
    assert not any("win_amd64" in wheel.name for wheel in wheels)
    linux_binary = [wheel for wheel in wheels if "cp312-cp312" in wheel.name]
    assert len(linux_binary) == 7
    assert all("manylinux" in wheel.name for wheel in linux_binary)
