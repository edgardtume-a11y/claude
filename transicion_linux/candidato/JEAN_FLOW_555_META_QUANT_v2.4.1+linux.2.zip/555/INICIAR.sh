#!/usr/bin/env bash
set -euo pipefail

umask 077
export LC_ALL=C.UTF-8
export LANG=C.UTF-8

if [[ "$(uname -s)" != "Linux" || "$(uname -m)" != "x86_64" ]]; then
  printf '%s\n' 'PLATFORM_UNSUPPORTED: se requiere Linux x86-64.' >&2
  exit 2
fi

if [[ "${EUID}" -eq 0 ]]; then
  printf '%s\n' 'ROOT_PROCESS_FORBIDDEN: ejecute con el usuario jean-flow, sin sudo.' >&2
  exit 2
fi

python_bin=/usr/bin/python3.12
if [[ ! -x "${python_bin}" ]]; then
  printf '%s\n' 'PYTHON_NOT_FOUND: falta /usr/bin/python3.12.' >&2
  exit 2
fi

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
exec "${python_bin}" -X utf8 -I -S -B -u \
  "${script_dir}/jean_flow_launcher.py" "$@"
